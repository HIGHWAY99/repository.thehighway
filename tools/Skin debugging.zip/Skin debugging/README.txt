Set-up

- Place Custom_Overlay.xml in your skin's XML folder (ie 720p, 1080i, etc)
- Place the relevant debuggrid PNG in the skin's root folder and change the Custom_Overlay.xml debug grid controls if neccessary
- Place the keymap.xml in your /userdata/keymaps folder (or add the actions to your current one)

Usage

F6 - enable/disable the debug grid
F7 - enable/disable debug info

Debug info

Left -
Current Window ID (BLUE)
Any active Dialogs (RED)

Right -
Current Control (BLUE)
Current Container's name (GREEN) - Current Container's path (RED)