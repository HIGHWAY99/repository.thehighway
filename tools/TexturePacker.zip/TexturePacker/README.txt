Instructions for use

1. Place any modified textures inside the media folder using the same folder layout as in the original

ie

media/background.png
media/list/listfocus.png

2. Double click the TexturePacker.bat to run the TexturePacker

3. TexturePacker will automatically check for any dupes and link them

4. The completed textures.xbt must then be renamed the same as your colour XML

5. Place the final XBT file in the skins media folder and change the theme via the Appearance settings