import os,xbmc,xbmcgui,xbmcaddon,sys,logging
addon=xbmcaddon.Addon(); 
addon_id   =addon.getAddonInfo('id'); 
addon_name =addon.getAddonInfo('name'); 
addon_path =addon.getAddonInfo('path'); addon_path8=addon.getAddonInfo('path').decode("utf-8"); 
#MediaPath  =xbmc.translatePath( os.path.join(addon_path8,'resources','skins','default','media').encode("utf-8") ).decode("utf-8"); 
MediaPath  =xbmc.translatePath( os.path.join(addon_path,'resources','skins','default','media') ); 
def MediaFile(n,e='',p=MediaPath): return os.path.join(p,n+e)
def MediaFileP(n,e='',p=MediaPath): return MediaFile(n,e='.png')
def MediaFileG(n,e='',p=MediaPath): return MediaFile(n,e='.gif')
def MediaFileJ(n,e='',p=MediaPath): return MediaFile(n,e='.jpg')
def getSet(id,d): 
    try: return addon.getSetting(id)
    except: return d
def setSet(id,v): 
    try: return addon.setSetting(id,v)
    except: pass
def tfalse(r,d=False): ## Get True / False
	if   (r.lower()=='true' ) or (r.lower()=='t') or (r.lower()=='y') or (r.lower()=='1') or (r.lower()=='yes'): return True
	elif (r.lower()=='false') or (r.lower()=='f') or (r.lower()=='n') or (r.lower()=='0') or (r.lower()=='no'): return False
	else: return d
def isPath(path): return os.path.exists(path)
def isFile(filename): return os.path.isfile(filename)


#class Screensaver(xbmcgui.WindowXML): #xbmcgui.WindowXMLDialog
class Screensaver(xbmcgui.WindowXMLDialog): #xbmcgui.WindowXMLDialog
    class ExitMonitor(xbmc.Monitor):
        def __init__(self,exit_callback):
            self.exit_callback=exit_callback
        def onScreensaverDeactivated(self):
            self.exit_callback()
    def onAction(self,action): self.exit()
    #def __init__(self,*args,**kwargs):
    #    pass
    def setWinProperty(self,prop,val):
        xbmcgui.Window(self.winid).setProperty(prop,val)
    #def SelectAspect(self):
    #    #self.aspectopt=getSet('aspect','').lower()
    #    if   self.aspectopt=='stretch':               self.aspect=0 # Stretch
    #    elif self.aspectopt.startswith('scale up'):   self.aspect=1 # Scale UP (crop)
    #    elif self.aspectopt.startswith('scale down'): self.aspect=2 # Scale DOWN (black bars)
    #    else:                                         self.aspect=0 # Stretch
    def CheckForValid(self):
        if len(self.imgurl)==0: self.imgurl=self.DefaultImage
        if isFile(self.imgurl)==False: self.imgurl=self.DefaultImage
    def CheckForCustom(self):
        if (self.useCustomImg==True) and (len(self.CustomImg) > 0):
            if self.CustomImg.lower().startswith('http://'):
                try: destfile='remote_'+( self.CustomImg.split('/')[-1] )+'.gif'
                except: destfile='remote_temp.gif'
                LocalCustomImg=MediaFile(destfile)
                if isFile(LocalCustomImg)==False:
                    import HiddenDownloader
                    HiddenDownloader.download(self.CustomImg,destfile,MediaPath)
                    xbmc.sleep(2000)
                if isFile(LocalCustomImg)==True:
                    self.CustomImg=LocalCustomImg
            self.imgurl=self.CustomImg
    def CheckSettings(self):
        self.DefaultImage=MediaFileG('snow_town_05')
        self.imgopt=getSet('imgopt','')
        self.useCustomImg=tfalse(getSet('usecustomimage','false'))
        self.CustomImg=getSet('customimage','')
        self.imgurl=self.DefaultImage
    def FillImageList(self):
        self.ImgList=[
            ['Transparent Snow 01','snow_transparent_01','http://i.imgur.com/UHtty7s.gif'],
            ['Snowy Forest 01','snow_forest_01c','http://i.imgur.com/VLRGkTr.gif'],
            ['Snowy Forest 02','snow_forest_02b','http://i.imgur.com/qIrt730.gif'],
            ['Snowy Town 01'  ,'snow_town_01c','http://i.imgur.com/ML8oqBU.gif'],
            ['Snowy Town 02'  ,'snow_town_02b','http://i.imgur.com/and9Tcz.gif'],
            #['Snowy Town 03'  ,'snow_town_03',''],
            ['Snowy Town 04'  ,'snow_town_04','http://i.imgur.com/TrxSwqn.gif'],
            ['Snowy Town 05'  ,'snow_town_05','http://i.imgur.com/fzWMVyv.gif'],
            #['Snowy Town 06'  ,'snow_town_06',''],
            #['Snowfall 01'    ,'snow_01',''],
            ['Snowfall 02'    ,'snow_02','http://i.imgur.com/EcGvdWS.gif'],
            #['Scooter Santa'  ,'animated-santa-on-motorcycle','http://i.imgur.com/hv5Apfo.gif'],
            #['Chimney Santa'  ,'santachimney2_e0','http://i.imgur.com/kQxfoHq.gif'],
            #['','',''],
            #['','',''],
            #['','',''],
            ['Testing'        ,'',''],
            #['','',''],
            ['Black','Black1',''],['Blank','Blank1',''] ]
    def CheckForImage(self):
        self.CheckSettings()
        self.FillImageList()
        # ################### #
        for (Aa,Bb,Cc) in self.ImgList:
            if self.imgopt==Aa:
                LocalImg=MediaFileG(Bb)
                if Cc.lower().startswith('http://'):
                    if isFile(LocalImg)==False:
                        import HiddenDownloader
                        HiddenDownloader.download(Cc,Bb+'.gif',MediaPath)
                        xbmc.sleep(2000)
                    if isFile(LocalImg)==True:
                        self.imgurl=LocalImg
                else: 
                    if isFile(LocalImg)==True: self.imgurl=LocalCustomImg
        # ################### #
        self.CheckForCustom()
        self.CheckForValid()
        # ################### #
    def onInit(self):
        self.abort_requested=False; 
        self.started=False; 
        self.exit_monitor=self.ExitMonitor(self.exit); 
        #if xbmc.Player().isPlayingAudio():
        #    xbmc.executebuiltin('RunScript(script.cu.lrclyrics)')
        ###
        #self.winid=xbmcgui.getCurrentWindowId(); 
        self.winid=xbmcgui.getCurrentWindowDialogId(); 
        self.image1=self.getControl(100); #Background Image.
        self.image2=self.getControl(101); #Foreground Image.
        self.blacken=tfalse(getSet('blacken','false')); 
        if self.blacken==True: self.image1.setImage(MediaFileP('black1'))
        else: self.image1.setImage(MediaFileP('blank1'))
        #self.SelectAspect()
        self.CheckForImage()
        self.image2.setImage(self.imgurl)
        
        
        
        
        ###
    def exit(self):
        self.abort_requested=True
        self.exit_monitor=None
        #if xbmc.Player().isPlayingAudio():
        #    xbmc.executebuiltin('Action(Back)')
        self.log('exit')
        self.close()
    def log(self,msg):
        #try: print ['Screensaver',msg]
        #except: pass
        try: xbmc.log(u'Screensaver: %s'%msg)
        except: pass

if __name__=='__main__':
    screensaver=Screensaver(
        'CustomScreenSaver.xml',addon_path,'default',
    )
    screensaver.doModal()
    del screensaver
    sys.modules.clear()




