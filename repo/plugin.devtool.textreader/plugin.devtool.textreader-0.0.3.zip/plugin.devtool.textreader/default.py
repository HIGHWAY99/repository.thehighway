#############################################################################
#############################################################################
import os,sys,re,urllib,urllib2,xbmc,xbmcplugin,xbmcaddon,xbmcgui,time,datetime
import common; from common import *
addon=common.addon; addonName=common.addonName; d=xbmcgui.Dialog(); r=False; 
#############################################################################
#############################################################################
class MainWindow(xbmcgui.WindowXML):
    c={}; closing=False; firsttime=False; fscreen=True; LastiAdv=''; CuriAdv=''; PfullScreen=False
    #P=xbmc.Player(); 
    def __init__(self,strXMLname,strFallbackPath): 
        self.fscreen=True; self.FirstTime=True; 
    def onInit(self):
        #deb('self.windowId',str(self.windowId)); 
        try: self.wID=xbmcgui.getCurrentWindowId()
        except: self.wID=0
        ## ### ## 
        
        
        
        ## ### ## 
        #if self.firsttime==True: return
        self.firsttime=True; 
        common.load_skin(self); self.setupScreen()
        #try: 
        self.setFocus(self.bLoad)
        #except: pass
        ## ### ## 
    def doSleep(self,n):
        for n2 in range(0,1000+1): 
            if self.closing==True: self.close()
            xbmc.sleep(int(n))
    def doTextLoad(self,Txt="",FNTxt="",Filter="",Location="special://home"):
      try:
            Location=xbmc.translatePath(Location)
            FNTxt=d.browse(1,'Select Text File','files',Filter,False,False,Location,False)
            if (FNTxt==False) or (len(FNTxt)==0) or (len(FNTxt)==1) or (not os.path.isfile(FNTxt)): return
            self.tFilePath.setLabel(FNTxt)
            Txt=common.File_Open(FNTxt)
            if FNTxt.endswith('.log'):
            	try:
            		for a,b in [('NOTICE: ','[COLOR FF00FF00]NOTICE:[/COLOR] '),('WARNING: ','[COLOR FFF5DD76]WARNING:[/COLOR] '),('ERROR: ','[COLOR FFFF0000]ERROR:[/COLOR] '),(' T:',' [COLOR FFFFFFFF]T:[/COLOR]'),(' </',' [COLOR deeppink]</[/COLOR]'),('<--',' [COLOR deeppink]<--[/COLOR]'),('<!-- ','[COLOR deeppink]<!--[/COLOR] '),(' <',' [COLOR deeppink]<[/COLOR]'),('>','[COLOR deeppink]>[/COLOR]'),(' --[COLOR deeppink]>[/COLOR]',' [COLOR deeppink]-->[/COLOR]'),('Error Type: ','[COLOR maroon]Error Type:[/COLOR] '),('Error Contents: ','[COLOR maroon]Error Contents: [/COLOR] '),("('expected an indented block', ('","[COLOR firebrick]('expected an indented block', ('[/COLOR]"),('IndentationError:','[COLOR maroon]IndentationError:[/COLOR]'),('://','[COLOR white]://[/COLOR]'),('AttributeError: ','[COLOR FFFF0000]AttributeError:[/COLOR] '),('", line ','[COLOR green]", line [/COLOR]'),(', in','[COLOR green], in[/COLOR]'),('Opening: ','[COLOR FFFF0000]Opening:[/COLOR] ')]: #,('','[COLOR ][/COLOR] '),('','[COLOR ][/COLOR] ')
            			try:
            				Txt=Txt.replace(a,b)
            			except: pass
            	except: pass
            self.tTextArea.setText(Txt)
            #self.tTextArea.setLabel(Txt)
            pass
      except Exception,e: common.debob(["Error",e])
      except: pass
    def doTextSave(self):
      try:
            FNTxt=self.tFilePath.getLabel()
            if (FNTxt==False) or (len(FNTxt)==0) or (len(FNTxt)==1): return
            Txt=self.tTextArea.getText()
            common.File_Save(FNTxt,Txt)
            pass
      except Exception,e: common.debob(["Error",e])
      except: pass
    def onClick(self,controlId): 
        try:
            if   controlId==self.c['bExit']: self.AskToClose()
            elif controlId==self.c['bLoad']: self.doTextLoad()
            #elif controlId==self.c['bSave']: self.doTextSave()
            #elif controlId==self.c['bFullScreen']:
            #    self.vFullViS=common.getStringValue('vFullVis').lower(); #common.deb('vFullVis',self.vFullViS)
            #    if self.vFullViS=='true': self.checkForANewAdvertisement() #self.doAdVideo()
            #    else: self.doFullVideo()
            #elif controlId==self.c['vL']: return
            #elif controlId==self.c['vFull']: return
        except Exception,e: common.debob(["Error",e])
        except: pass
    def onAction(self,action): 
      try:
        actId=int(action.getId()); actIds=str(action.getId()); actBC=str(action.getButtonCode()); 
        if   action==common.ACTION_PREVIOUS_MENU: self.AskToClose()
        elif action==common.ACTION_NAV_BACK: self.AskToClose()
        elif action==common.ACTION_MOVE_LEFT: pass
        elif action==common.ACTION_MOVE_RIGHT: pass
        elif action==common.ACTION_MOVE_UP: 
            #DoA("VolumeUp"); 
            pass
        elif action==common.ACTION_MOVE_DOWN: 
            #DoA("VolumeDown"); 
            pass
        elif action==common.ACTION_MOUSE_WHEEL_UP: 
            #DoA("VolumeUp"); 
            pass
        elif action==common.ACTION_MOUSE_WHEEL_DOWN: 
            #DoA("VolumeDown"); 
            pass
        elif action==common.ACTION_MOUSE_MOVE: pass
        elif actId == 100: 
            #common.deb("Remote Button Pressed","100"); common.deb('action.getId',str(actIds)); 
            pass
        #elif action == common.ACTION_SHOW_FULLSCREEN: 
        #    #if PfullScreen==True:
        #        DoA("togglefullscreen"); 
        #        pass
        #elif actId == common.ACTION_SHOW_FULLSCREEN: 
        #    #if PfullScreen==True:
        #        DoA("togglefullscreen"); 
        #        pass
        #elif action == common.ACTION_TOGGLE_FULLSCREEN: 
        #    if PfullScreen==True:
        #        DoA("togglefullscreen"); 
        #        PfullScreen=False
        #    else:
        #        PfullScreen=True
        #    pass
        elif actId == common.ACTION_aID_0: pass
        elif actId == common.ACTION_KEY_R: 
            #common.deb("Remote Button Pressed","rewind"); common.deb('action.getId',str(actIds)); 
            return
        elif actId == common.ACTION_KEY_F: 
            #common.deb("Remote Button Pressed","fast forward"); common.deb('action.getId',str(actIds)); 
            return
        elif actId == common.ACTION_REMOTE_INFO: 
            #common.deb("Remote Button Pressed","info"); common.deb('action.getId',str(actIds)); 
            return
        elif actId == common.ACTION_REMOTE_MUTE: 
            #common.deb("Remote Button Pressed","mute"); common.deb('action.getId',str(actIds)); 
            return
        elif actId == common.ACTION_REMOTE_CONTEXTMENU: 
            #common.deb("Remote Button Pressed","context menu"); common.deb('action.getId',str(actIds)); 
            return
        elif actId == common.ACTION_REMOTE_PLAYPAUSE: 
            #common.deb("Remote Button Pressed","playpause"); common.deb('action.getId',str(actIds)); 
            return
        ####elif actId == common.ACTION_REMOTE_FULLSCREEN: common.deb("Remote Button Pressed","fullscreen"); common.deb('action.getId',str(actIds)); return
        elif actId == common.ACTION_REMOTE_STOP: 
            #common.deb("Remote Button Pressed","stop"); common.deb('action.getId',str(actIds)); 
            self.CloseWindow(); return
        elif actId == common.ACTION_KEY_X: 
            #common.deb("Remote Button Pressed","stop"); common.deb('action.getId',str(actIds)); 
            self.CloseWindow(); return
        else: 
            #common.deb('action',str(action))
            if not actId==0:
                #common.deb('action.getButtonCode',str(actBC))
                #common.deb('action.getId',str(actIds))
                pass
        #elif action == ACTION_PARENT_DIR: self.CW()
        #elif action == ACTION_BACKSPACE: self.CW()
        #elif action == ACTION_SELECT_ITEM: changeAdv(); 
      except Exception,e: common.debob(["Error",e])
      except: pass
    def setupScreen(self):
        maxW=1280; maxH=720; 
        self.iBackground.setImage(common.artp("black1")); 
        #self.iBgBorder.setImage(common.artp("white1")); self.iBgBorder.setVisible(True)
        #self.iVideoBacking.setImage(common.artp("black1")); self.iVideoBacking.setVisible(True)
        #self.tTitle1.setLabel("Infomax"); self.tTitle1.setVisible(False)
        #self.tTitle2.setLabel("dotSmart"); self.tTitle2.setVisible(False)
        #self.bExit.setVisible(False); 
        #self.bFullScreen.setVisible(False); 
        ## ### ## 
    def CloseWindow(self):
        #self.close()
        try:
           #common.DoStopScript(common.addonId); 
           #common.DoA('Back'); #common.DoRW(0) #common.DoAW('home')
           self.closing=True; 
        #    xbmc.sleep(10)
        #    try: del self.c; del self.P; del self.iBackground; del self.iBgBorder; del self.iVideoBacking; del self.tTitle1; del self.tTitle2; 
        #    except Exception,e: common.debob(["Error",e])
        #    except: pass
        #    xbmc.sleep(10)
        except: pass
        self.close()
    def CW(self): self.CloseWindow()
    def AskToClose(self): 
        #if d.yesno(addonName," ",str(common.tQuit),"",str(common.tNO),str(common.tYES)): self.closing=True; self.CloseWindow()
        if d.yesno(addonName," ","Are you sure that you want to exit?","","No","Yes"): self.closing=True; self.CloseWindow()
        #self.closing=True; self.CloseWindow()
#############################################################################
#############################################################################
try:    Emulating=xbmcgui.Emulating
except: Emulating=False
#common.deb('Emulating',str(Emulating)); 
#############################################################################
#############################################################################
win=MainWindow(common.addonXml,common.addonPath) #,'Default','720p'
win.doModal()
del win

#############################################################################
#############################################################################
