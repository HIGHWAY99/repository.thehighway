"""
    Kodi urlresolver plugin
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from t0mm0.common.net import Net
from urlresolver import common
from urlresolver.plugnplay.interfaces import UrlResolver
from urlresolver.plugnplay.interfaces import PluginSettings
from urlresolver.plugnplay import Plugin
import os
import re
import urllib
import urllib2
import xbmc
import xbmcvfs


class VideomegaResolver(Plugin, UrlResolver, PluginSettings):
    implements = [UrlResolver, PluginSettings]
    name = "videomega"
    domains = ["videomega.tv"]

    def __init__(self):
        p = self.get_setting('priority') or 100
        self.priority = int(p)
        self.cookie = xbmc.translatePath(os.path.join(xbmc.translatePath(common.profile_path), 'videomega.txt'))
        if not xbmcvfs.exists(self.cookie):
            try:
                temp = xbmcvfs.File(self.cookie, 'w')
                temp.close()
            except:
                temp = open(self.cookie, 'w')
                temp.close()
        self.net = Net(cookie_file=self.cookie)
        self.net.set_cookies(self.cookie)
        self.useragent = 'Apple-iPhone/705.018'
        self.net.set_user_agent(self.useragent)
        self.headers = {'Referer': 'http://videomega.tv/'}

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        stream_url = None
        self.headers['Referer'] = web_url
        try:
            self.net.set_cookies(self.cookie)
            resp = self.net.http_GET(web_url, headers=self.headers)
            self.net.save_cookies(self.cookie)
        except urllib2.URLError, e:
            common.addon.log_error(self.name + ': got HTTP Error %d %s while fetching %s' % (e.code, e.reason, web_url))
            return self.unresolvable(code=3, msg=e)
        try:
            html = resp.content
            if 'Error connecting to db' in html: raise Exception('Error connecting to DB')
            r = re.compile('document.write.unescape."(.+?)"').findall(html)
            if r:
                unescaped_str = urllib.unquote(r[-1])
                r = re.search('file\s*:\s*"(.*?)"', unescaped_str)
                if r:
                    stream_url = r.group(1)
                    stream_url = stream_url.replace(" ", "%20")
            else:
                s = re.search('<video id="container".+?poster="(.+?)/videos/screenshots/[0-9a-zA-Z]+?\..+?".*?>', html)
                if s: stream_url = '%s/v/' % s.group(1)
                r = re.search('<source src=".+?/v/(.+?)" type="video.*?"/>', html)
                if r and stream_url: stream_url += r.group(1)
                else: stream_url = None
            if stream_url:
                useragent = urllib.quote(self.useragent)
                cookie = self.net.get_cookies()
                cookie = re.search('\s(__cfduid=.+?)\s', str(cookie['.videomega.tv']['/']['__cfduid'])).group(1)
                cookie = urllib.quote(cookie)
                referer = urllib.quote(web_url)
                return '%s|User-Agent=%s&Referer=%s&Cookie=%s' % (stream_url, useragent, referer, cookie)
            else: raise Exception('No playable video found.')
        except Exception, e:
            common.addon.log_error(self.name + ': %s' % e)
            return self.unresolvable(code=0, msg=e)

    def get_url(self, host, media_id):
        if len(media_id) == 60:
            try:
                web_url = 'http://%s/validatehash.php?hashkey=%s' % (host, media_id)
                html = self.net.http_GET(web_url, headers=self.headers).content
                if 'Error connecting to db' in html: raise Exception('Error connecting to DB')
                if 'ref=' in html:
                    return 'http://%s/cdn.php?ref=%s' % (host, re.compile('.*?ref="(.+?)".*').findall(html)[0])
                else: raise Exception('No playable video found.')
            except urllib2.URLError, e:
                common.addon.log_error(self.name + ': got HTTP Error %d %s while fetching %s' % (e.code, e.reason, web_url))
                return self.unresolvable(code=3, msg=e)
            except Exception, e:
                common.addon.log_error(self.name + ': %s' % e)
                return self.unresolvable(code=0, msg=e)
        else:
            return 'http://%s/iframe.php?ref=%s' % (host, media_id)

    def get_host_and_id(self, url):
        r = re.search('//((?:www\.)?(?:[^/]+))/.*(?:\?(?:ref|hashkey)=)([0-9a-zA-Z]+)', url)
        if r: return r.groups()
        else: return False

    def valid_url(self, url, host):
        if self.get_setting('enabled') == 'false': return False
        return re.match('http://(?:www.)?videomega.tv/(?:iframe|view|cdn|validatehash|\?ref=).(?:php|js|.*)\?*', url) or 'videomega' in host