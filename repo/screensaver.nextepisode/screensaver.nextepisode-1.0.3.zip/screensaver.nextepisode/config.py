def FetchDefault():
        return 'black1'
def FetchList(duropt=5):
        return [
            #[duropt,'',''],
            #[duropt,'',''],
            #[duropt,'',''],
            #[duropt,'',''],
            #[duropt,'',''],
            #[duropt,'',''],
            #[duropt,'',''],
            ]
