import os,xbmc,xbmcgui,xbmcaddon,sys,logging,time,random,datetime,re,urllib,urllib2
from config import *
from config import (FetchList,FetchDefault)
# ### 
UserAgent='Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
WebURL='http://next-episode.net'
# ### 
addon=xbmcaddon.Addon(); 
addon_id   =addon.getAddonInfo('id'); 
addon_name =addon.getAddonInfo('name'); 
addon_path =addon.getAddonInfo('path'); addon_path8=addon.getAddonInfo('path').decode("utf-8"); 
#MediaPath  =xbmc.translatePath( os.path.join(addon_path8,'resources','skins','default','media').encode("utf-8") ).decode("utf-8"); 
MediaPath  =xbmc.translatePath( os.path.join(addon_path,'resources','skins','default','media') ); 
def MediaFile(n,e='',p=MediaPath): return os.path.join(p,n+e)
def MediaFileP(n,e='',p=MediaPath): return MediaFile(n,e='.png')
def MediaFileG(n,e='',p=MediaPath): return MediaFile(n,e='.gif')
def MediaFileJ(n,e='',p=MediaPath): return MediaFile(n,e='.jpg')
def getSet(id,d): 
    try: return addon.getSetting(id)
    except: return d
def setSet(id,v): 
    try: return addon.setSetting(id,v)
    except: pass
def tfalse(r,d=False): ## Get True / False
	if   (r.lower()=='true' ) or (r.lower()=='t') or (r.lower()=='y') or (r.lower()=='1') or (r.lower()=='yes'): return True
	elif (r.lower()=='false') or (r.lower()=='f') or (r.lower()=='n') or (r.lower()=='0') or (r.lower()=='no'): return False
	else: return d
def isPath(path): return os.path.exists(path)
def isFile(filename): return os.path.isfile(filename)
def FileDoSave(path,data):
	file=open(path,'w')
	file.write(data)
	file.close()
def FileDoOpen(path,d=''):
	try:
		if os.path.isfile(path): ## File found.
			file=open(path, 'r')
			contents=file.read()
			file.close()
			return contents
		else: return d ## File not found.
	except: return d
def getURL(url,d=''):
	try:
		req=urllib2.Request(url)
		req.add_header('User-Agent',UserAgent) 
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except: return d
def nolines(t):
	it=t.splitlines()
	t=''
	for L in it:
		t=t+L
	t=((t.replace("\r","")).replace("\n","").replace("\a","").replace("\t",""))
	return t
# ### 
WebHTML=MediaFile('webhtml.txt')
WebDATE=MediaFile('webdate.txt')
LocalDate='%s-%s-%s'%(str(datetime.date.today().year),str(datetime.date.today().month),str(datetime.date.today().day))
try:
  if tfalse(getSet('hourly','false'))==True:
    LocalDate='%s-%s-%s:%s'%(str(datetime.date.today().year),str(datetime.date.today().month),str(datetime.date.today().day),str(datetime.datetime.now().hour))
except: pass
print ['Stamp',LocalDate]
# ### 
def getTheHtml():
	if (LocalDate==FileDoOpen(WebDATE).strip()) and (isFile(WebHTML)==True):
		thehtml=FileDoOpen(WebHTML)
		return thehtml
	else:
		#print '*Grabbing new copy of the html.'
		# ### ### ### #
		#thehtml=FileDoOpen(WebHTML)
		#return thehtml
		# ### ### ### #
		thehtml=getURL(WebURL)
		if len(thehtml) > 100:
			FileDoSave(WebHTML,thehtml)
			FileDoSave(WebDATE,LocalDate)
		else:
			thehtml=FileDoOpen(WebHTML)
			FileDoSave(WebDATE,LocalDate)
		return thehtml


#class Screensaver(xbmcgui.WindowXML): #xbmcgui.WindowXMLDialog
class Screensaver(xbmcgui.WindowXMLDialog): #xbmcgui.WindowXMLDialog
    class ExitMonitor(xbmc.Monitor):
        def __init__(self,exit_callback):
            self.exit_callback=exit_callback
        def onScreensaverDeactivated(self):
            self.exit_callback()
    def onAction(self,action): self.exit()
    #def __init__(self,*args,**kwargs):
    #    pass
    def setWinProperty(self,prop,val):
        xbmcgui.Window(self.winid).setProperty(prop,val)
    def CheckSettings(self):
        try: self.duropt=int(getSet('durationopt','5'))
        except: self.duropt=5
        pass
    def Sleepfor(self,T):
        xbmc.sleep( ( 1000*(T) ) )
        return
        for i in range(1,101):
            #if (self.abort_requested==True):
            #    self.close()
            #    return
            xbmc.sleep( ( 10*(T) ) )
            #xbmc.sleep( ( 100*(T) ) )
            ##xbmc.sleep( ( 1000*(T) ) )
            ##time.sleep.sleep(T)
    def FillImageList(self):
      #  #self.ImgList=FetchList()
      try: 
        self.ImgArray=[]
        self.thehtml=nolines(getTheHtml()).replace('</tr>','</tr\n\r>')
        #print ['Length of html',len(self.thehtml)]
        #print self.thehtml
        try: Rr1=re.compile(">([A-Za-z]+\'s Top TV Episodes)</h2></strong><br>\s*(.+?)\s*</tr").findall(self.thehtml)
        except: Rr1=[]
        #print ['Rr1',Rr1]
        if len(Rr1) > 0:
        	for catWhatList,dataShows in Rr1: #[::-1]:
        		try:
        			dataShows=dataShows.replace('','')
        			s='<a href="%s/.+?"\s+title="(.+?)">\s*<img src="(%s/tv-shows-images/thumb/.+?)" alt="(.+?)".*?">(.+?)</a>\s*<br>(.+?)</div>'%(WebURL,WebURL)
        			try: Rr2=re.compile(s).findall(dataShows)
        			except: Rr2=[]
        			#print ['Rr2',Rr2]
        			if len(Rr2) > 0:
        				random.shuffle(Rr2)
        				for (epTitle,imgUrl,showTitle,showTitle2,SxE) in Rr2:
        					imgUrl=imgUrl.replace('/tv-shows-images/thumb/','/tv-shows-images/big/')
        					epTitle=epTitle.replace(SxE+' - ','')
        					self.ImgArray.append([self.duropt,imgUrl,catWhatList,showTitle2,SxE,epTitle])
        		except: pass
        if len(self.ImgArray)==0:
            self.ImgArray.append([self.duropt,MediaFileP('black1'),'No shows were found.','Show Title','0x0','Episode Title'])
            #print 'Doing Black'
        #else:
        #    random.shuffle(self.ImgArray)
        #    #print 'Shuffled'
        
      except: #pass
        if len(self.ImgArray)==0:
            self.ImgArray.append([self.duropt,MediaFileP('black1'),'No shows were found.','Show Title','0x0','Episode Title'])
    def CheckForImage(self):
        self.FillImageList()
        # ################### #
        #print self.ImgArray
        while (self.abort_requested==False):
          try:
            #random.shuffle(self.ImgArray)
            for (aTime,aFile,catWhatList,showTitle2,SxE,epTitle) in self.ImgArray:
              try:
                if (self.abort_requested==True): return
                #print {'Image File':aFile}
                if not '://' in aFile:
                    LocalImg=MediaFile(aFile); 
                    if isFile(LocalImg):
                        aFile=LocalImg
                #self.image2.setVisible(False)
                self.image2.setImage(aFile)
                #self.image2.setVisible(True)
                
                self.label1.setLabel( '  [COLOR FFFF8335][B]'+			catWhatList			+'[/B][/COLOR]   ' )
                self.label2.setLabel( '  [COLOR FF1C6593][B]'+			showTitle2			+'[/B][/COLOR]   ' )
                self.label3.setLabel( '  [COLOR firebrick][B]'+			SxE.replace('x','[COLOR white] [/B]x[B] [/COLOR]')							+'[/B][/COLOR]   ' )
                self.label4.setLabel( '  [COLOR cornflowerblue][B]'+			epTitle					+'[/B][/COLOR]   ' )
                
                
                # ### ### ### #
                #self.SleepFor(aTime)
                xbmc.sleep( ( 1000*(aTime) ) )
                #time.sleep.sleep(aTime)
                #
              except: pass
            #
          except: pass
        
        # ################### #
        #for (Aa,Bb,Cc) in self.ImgList:
        #    if self.imgopt==Aa:
        #        self.FExt='.gif'; LCc=Cc.lower()
        #        if  '.jpeg' in LCc: self.FExt='.jpeg'
        #        elif '.png' in LCc: self.FExt='.png'
        #        elif '.jpg' in LCc: self.FExt='.jpg'
        #        elif '.bmp' in LCc: self.FExt='.bmp'
        #        if  '.jpeg' in Bb: 	self.FExt='.jpeg'
        #        elif '.png' in Bb: 	self.FExt='.png'
        #        elif '.jpg' in Bb: 	self.FExt='.jpg'
        #        elif '.bmp' in Bb: 	self.FExt='.bmp'
        #        if (self.FExt=='.gif') and (not '.gif' in Bb): LocalImg=MediaFileG(Bb); 
        #        else: LocalImg=MediaFile(Bb); 
        #        print {'LocalImg':LocalImg,'FExt':self.FExt,'Bb':Bb,'Aa':Aa,'Cc':Cc}
        #        if LCc.startswith('http://') or LCc.startswith('https://'):
        #            if isFile(LocalImg)==False:
        #                import HiddenDownloader
        #                HiddenDownloader.download(Cc,Bb+self.FExt,MediaPath)
        #                xbmc.sleep(2000)
        #            if isFile(LocalImg)==True:
        #                self.imgurl=LocalImg
        #        else: 
        #            if isFile(LocalImg)==True: self.imgurl=LocalImg
        # ################### #
        #self.CheckForCustom()
        #self.CheckForValid()
        # ################### #
    def onInit(self):
      try:
        self.abort_requested=False; 
        self.started=False; 
        self.exit_monitor=self.ExitMonitor(self.exit); 
        self.log('start')
        #if xbmc.Player().isPlayingAudio():
        #    xbmc.executebuiltin('RunScript(script.cu.lrclyrics)')
        ###
        #self.winid=xbmcgui.getCurrentWindowId(); 
        self.winid=xbmcgui.getCurrentWindowDialogId(); 
        self.image1=self.getControl(100); #Background Image.
        self.image2=self.getControl(101); #Foreground Image.
        self.blacken=tfalse(getSet('blacken','false')); 
        if self.blacken==True: self.image1.setImage(MediaFileP('black1'))
        else: self.image1.setImage(MediaFileP('blank1'))
        
        self.label1=self.getControl(103); #
        self.label2=self.getControl(104); #
        self.label3=self.getControl(105); #
        self.label4=self.getControl(106); #
        
        
        #self.SelectAspect()
        self.CheckSettings()
        self.CheckForImage()
        #self.image2.setImage(self.imgurl)
        ###
      except: self.exit() #pass
    def exit(self):
        try:
        	self.abort_requested=True
        	self.exit_monitor=None
        	#if xbmc.Player().isPlayingAudio():
        	#    xbmc.executebuiltin('Action(Back)')
        	self.log('exit')
        	#xbmc.sleep( 200 )
        except: pass
        self.close()
    def log(self,msg):
        #try: print ['Screensaver',msg]
        #except: pass
        try: xbmc.log(u'Screensaver: %s'%msg)
        except: pass
if __name__=='__main__':
    screensaver=Screensaver('CustomScreenSaver.xml',addon_path,'default')
    try:
      screensaver.doModal()
    except: pass
    del screensaver
    try: sys.modules.clear()
    except: pass
