import os,xbmc,xbmcgui,xbmcaddon,xbmcplugin,sys,logging,time,random,datetime,re,urllib,urllib2
from config import *
from config import (FetchList,FetchDefault)
# ### 
UserAgent='Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
WebURL='http://next-episode.net'
# ### 
addon=xbmcaddon.Addon(); 
addon_id   =addon.getAddonInfo('id'); 
addon_name =addon.getAddonInfo('name'); 
addon_path =addon.getAddonInfo('path'); addon_path8=addon.getAddonInfo('path').decode("utf-8"); 
#MediaPath  =xbmc.translatePath( os.path.join(addon_path8,'resources','skins','default','media').encode("utf-8") ).decode("utf-8"); 
MediaPath  =xbmc.translatePath( os.path.join(addon_path,'resources','skins','default','media') ); 

from addon.common.addon import Addon
_addon=Addon(addon_id,sys.argv); 
print ['_addon',addon_id,sys.argv]
def eod(succeeded=True,updateListing=False,cacheToDisc=True,h=int(sys.argv[1])): 
	#_addon.end_of_directory()
	xbmcplugin.endOfDirectory(h,succeeded=succeeded,updateListing=updateListing,cacheToDisc=cacheToDisc)
def addstv(id,value=''): _addon.addon.setSetting(id=id,value=value) ## Save Settings
def addst(r,s=''): 
	try: return _addon.get_setting(r)   ## Get Settings
	except: return s
def addpr(r,s=''): return _addon.queries.get(r,s) ## Get Params
def cFL( t,c='red'): return '[COLOR '+c+']'+t+'[/COLOR]' ### For Coloring Text ###
def cFL_(t,c='red'): return '[COLOR '+c+']'+t[0:1]+'[/COLOR]'+t[1:] ### For Coloring Text (First Letter-Only) ###

def MediaFile(n,e='',p=MediaPath): return os.path.join(p,n+e)
def MediaFileP(n,e='',p=MediaPath): return MediaFile(n,e='.png')
def MediaFileG(n,e='',p=MediaPath): return MediaFile(n,e='.gif')
def MediaFileJ(n,e='',p=MediaPath): return MediaFile(n,e='.jpg')
def getSet(id,d): 
    try: return addon.getSetting(id)
    except: return d
def setSet(id,v): 
    try: return addon.setSetting(id,v)
    except: pass
def tfalse(r,d=False): ## Get True / False
	if   (r.lower()=='true' ) or (r.lower()=='t') or (r.lower()=='y') or (r.lower()=='1') or (r.lower()=='yes'): return True
	elif (r.lower()=='false') or (r.lower()=='f') or (r.lower()=='n') or (r.lower()=='0') or (r.lower()=='no'): return False
	else: return d
def isPath(path): return os.path.exists(path)
def isFile(filename): return os.path.isfile(filename)
def FileDoSave(path,data):
	file=open(path,'w')
	file.write(data)
	file.close()
def FileDoOpen(path,d=''):
	try:
		if os.path.isfile(path): ## File found.
			file=open(path, 'r')
			contents=file.read()
			file.close()
			return contents
		else: return d ## File not found.
	except: return d
def getURL(url,d=''):
	try:
		req=urllib2.Request(url)
		req.add_header('User-Agent',UserAgent) 
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except: return d
def nolines(t):
	it=t.splitlines()
	t=''
	for L in it:
		t=t+L
	t=((t.replace("\r","")).replace("\n","").replace("\a","").replace("\t",""))
	return t
# ### 
WebHTML=MediaFile('webhtml.txt')
WebDATE=MediaFile('webdate.txt')
LocalDate='%s-%s-%s'%(str(datetime.date.today().year),str(datetime.date.today().month),str(datetime.date.today().day))
try:
  if tfalse(getSet('hourly','false'))==True:
    LocalDate='%s-%s-%s:%s'%(str(datetime.date.today().year),str(datetime.date.today().month),str(datetime.date.today().day),str(datetime.datetime.now().hour))
except: pass
print ['Stamp',LocalDate]
# ### 
def getTheHtml():
	if (LocalDate==FileDoOpen(WebDATE).strip()) and (isFile(WebHTML)==True):
		thehtml=FileDoOpen(WebHTML)
		return thehtml
	else:
		#print '*Grabbing new copy of the html.'
		# ### ### ### #
		#thehtml=FileDoOpen(WebHTML)
		#return thehtml
		# ### ### ### #
		thehtml=getURL(WebURL)
		if len(thehtml) > 100:
			FileDoSave(WebHTML,thehtml)
			FileDoSave(WebDATE,LocalDate)
		else:
			thehtml=FileDoOpen(WebHTML)
			FileDoSave(WebDATE,LocalDate)
		return thehtml
# ### ### ### #
def menu_main():
		try:
			ImgArray=[]
			thehtml=nolines(getTheHtml()).replace('</tr>','</tr\n\r>')
			#print ['length of html',len(thehtml)]
			try: Rr1=re.compile(">([A-Za-z]+\'s Top TV Episodes)</h2></strong><br>\s*(.+?)\s*</tr").findall(thehtml)
			except: Rr1=[]
			#print ['Rr1',Rr1]
			if len(Rr1) > 0:
				for catWhatList,dataShows in Rr1: #[::-1]:
						try:
							#dataShows=dataShows.replace('','')
							s='<a href="%s/.+?"\s+title="(.+?)">\s*<img src="(%s/tv-shows-images/thumb/.+?)" alt="(.+?)".*?">(.+?)</a>\s*<br>(.+?)</div>'%(WebURL,WebURL)
							try: Rr2=re.compile(s).findall(dataShows)
							except: Rr2=[]
							#print ['Rr2',Rr2]
							if len(Rr2) > 0:
								#random.shuffle(Rr2)
								for (epTitle,imgUrl,showTitle,showTitle2,SxE) in Rr2:
									try:
										showTitle2=showTitle2.replace('&#44;',',')
										imgUrl=imgUrl.replace('/tv-shows-images/thumb/','/tv-shows-images/big/')
										epTitle=epTitle.replace(SxE+' - ','').replace('&#44;',',')
										#ImgArray.append([duropt,imgUrl,catWhatList,showTitle2,SxE,epTitle])
										if not '://' in imgUrl:
											LocalImg=MediaFile(imgUrl); 
											if isFile(LocalImg): imgUrl=LocalImg
										if   "Yesterday's" in catWhatList: ww=cFL('-1','red')+' '
										elif "Today's" in catWhatList: ww=cFL('00','green')+' '
										elif "Tomorrow's" in catWhatList: ww=cFL('+1','yellow')+' '
										else: ww=''
										plot=catWhatList+'\nShow Title: '+showTitle2+'\n'+SxE+': '+epTitle+'\n: '
										labs={'title':ww+showTitle2+' '+SxE+'[CR]'+epTitle,'Plot':plot}
										pars={'mode':'show','show':showTitle2,'url':'','img':imgUrl}
										#print ['labs',labs]
										#print ['pars',pars]
										try: 
											_addon.add_directory(pars,labs,is_folder=True,fanart=imgUrl,img=imgUrl)
											##_addon.add_directory({'mode':'show'},{'title':'SxE'},is_folder=True,fanart=imgUrl,img=imgUrl)
											#addDir(ww+showTitle2,showTitle2,'show',imgUrl,imgUrl,imgUrl,plot)
										except: pass
									except: pass
						except: pass
		#	eod()
		except: pass
		eod()
def addDir(name,name2,mode,url,iconimage,fanimage,plot):
		ok=True; u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name2)+"&img="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanimage)
		liz=xbmcgui.ListItem(name,iconImage="DefaultFolder.png",thumbnailImage=iconimage)
		liz.setInfo(type="Video",infoLabels={"Title":name,"Plot":plot})
		liz.setProperty("Fanart_Image",fanimage)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		#return ok
def check_mode(mode):
		menu_main()
check_mode(addpr('mode',''))