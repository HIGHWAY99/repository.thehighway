"""
    Kodi urlresolver plugin
    Copyright (C) 2014  The Highway

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from t0mm0.common.net import Net
from urlresolver.plugnplay.interfaces import UrlResolver
from urlresolver.plugnplay.interfaces import PluginSettings
from urlresolver.plugnplay import Plugin
from urlresolver import common
from lib import jsunpack
import urllib2
import re


class DHappyMyvidstreamResolver(Plugin, UrlResolver, PluginSettings):
    implements = [UrlResolver, PluginSettings]
    name = "dh_myvidstream.net"
    domains = ["myvidstream.net"]

    def __init__(self):
        p = self.get_setting('priority') or 99
        self.priority = int(p)
        self.net = Net()
        self.pattern = 'http://((?:www)*\.*(?:myvidstream\.net))/embed-([0-9a-zA-Z/\?_=]+)[\-\?&\.]*.*'

    def get_url(self, host, media_id):
        return 'http://%s/embed-%s.html' % (host, media_id)

    def get_host_and_id(self, url):
        r = re.search(self.pattern, url)
        if r: return r.groups()
        else: return False

    def valid_url(self, url, host):
        if self.get_setting('enabled') == 'false': return False
        return re.match(self.pattern, url) or self.name in host

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        try:
            resp = self.net.http_GET(web_url)
            html = resp.content
        except urllib2.URLError, e:
            common.addon.log_error(self.name + ': got HTTP Error %d %s while fetching %s' % (e.code, e.reason, web_url))
            return self.unresolvable(code=3, msg=e)
        r = re.search('<div id="player_code"><span id=.+?</span>.+<script type=\'text/javascript\'>\s*(eval\(function\(p,a,c,k,e,d\).*?\|(?:mp4|flv)\|[0-9a-zA-Z]+\|files\|.*?)\s*</script>', html, re.DOTALL)
        if r:
            unpacked = jsunpack.unpack(r.group(1))
            if unpacked:
                unpacked = re.search('s1\.addVariable\(\'file\',\s*\'(.+?)\'\);', unpacked.replace('\\', ''))
                if unpacked: return unpacked.group(1)
            if not unpacked:
                common.addon.log_error(self.name + ': stream url not found')
                return self.unresolvable(code=0, msg='File not found or removed')
        else:
            common.addon.log_error(self.name + ': stream url not found')
            return self.unresolvable(code=0, msg='File not found or removed')
