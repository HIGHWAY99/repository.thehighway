import os,xbmc,xbmcgui,xbmcaddon,sys,logging,time,random
#from config import *
#from config import (FetchList,FetchDefault)
addon=xbmcaddon.Addon(); 
addon_id   =addon.getAddonInfo('id'); 
addon_name =addon.getAddonInfo('name'); 
addon_path =addon.getAddonInfo('path'); addon_path8=addon.getAddonInfo('path').decode("utf-8"); 
#MediaPath  =xbmc.translatePath( os.path.join(addon_path8,'resources','skins','default','media').encode("utf-8") ).decode("utf-8"); 
MediaPath  =xbmc.translatePath( os.path.join(addon_path,'resources','skins','default','media') ); 
def MediaFile(n,e='',p=MediaPath): return os.path.join(p,n+e)
def MediaFileP(n,e='',p=MediaPath): return MediaFile(n,e='.png')
def MediaFileG(n,e='',p=MediaPath): return MediaFile(n,e='.gif')
def MediaFileJ(n,e='',p=MediaPath): return MediaFile(n,e='.jpg')
def getSet(id,d): 
    try: return addon.getSetting(id)
    except: return d
def setSet(id,v): 
    try: return addon.setSetting(id,v)
    except: pass
def tfalse(r,d=False): ## Get True / False
	if   (r.lower()=='true' ) or (r.lower()=='t') or (r.lower()=='y') or (r.lower()=='1') or (r.lower()=='yes'): return True
	elif (r.lower()=='false') or (r.lower()=='f') or (r.lower()=='n') or (r.lower()=='0') or (r.lower()=='no'): return False
	else: return d
def isPath(path): return os.path.exists(path)
def isFile(filename): return os.path.isfile(filename)
def FileDoSave(path, data):
	file=open(path,'w')
	file.write(data)
	file.close()
def FileDoOpen(path):
	if os.path.isfile(path): ## File found.
		file=open(path, 'r')
		contents=file.read()
		file.close()
		return contents
	else: return '' ## File not found.

#class Screensaver(xbmcgui.WindowXML): #xbmcgui.WindowXMLDialog
class Screensaver(xbmcgui.WindowXMLDialog): #xbmcgui.WindowXMLDialog
    class ExitMonitor(xbmc.Monitor):
        def __init__(self,exit_callback):
            self.exit_callback=exit_callback
        def onScreensaverDeactivated(self):
            self.exit_callback()
    def onAction(self,action): self.exit()
    #def __init__(self,*args,**kwargs):
    #    pass
    def setWinProperty(self,prop,val):
        xbmcgui.Window(self.winid).setProperty(prop,val)
    #def SelectAspect(self):
    #    #self.aspectopt=getSet('aspect','').lower()
    #    if   self.aspectopt=='stretch':               self.aspect=0 # Stretch
    #    elif self.aspectopt.startswith('scale up'):   self.aspect=1 # Scale UP (crop)
    #    elif self.aspectopt.startswith('scale down'): self.aspect=2 # Scale DOWN (black bars)
    #    else:                                         self.aspect=0 # Stretch
    #def CheckForValid(self):
    #    if len(self.imgurl)==0: self.imgurl=self.DefaultImage
    #    if isFile(self.imgurl)==False: self.imgurl=self.DefaultImage
    #def CheckForCustom(self):
        #if (self.useCustomImg==True) and (len(self.CustomImg) > 0):
        #    self.LCustomImg=self.CustomImg.lower()
        #    if self.LCustomImg.startswith('http://') or self.LCustomImg.startswith('https://'):
        #        self.FExt='.gif'; 
        #        if  '.jpeg' in self.LCustomImg: self.FExt='.jpeg'
        #        elif '.png' in self.LCustomImg: self.FExt='.png'
        #        elif '.jpg' in self.LCustomImg: self.FExt='.jpg'
        #        elif '.bmp' in self.LCustomImg: self.FExt='.bmp'
        #        try: destfile='remote_'+( self.CustomImg.split('/')[-1] )+self.FExt
        #        except: destfile='remote_temp.gif'
        #        LocalCustomImg=MediaFile(destfile)
        #        if isFile(LocalCustomImg)==False:
        #            import HiddenDownloader
        #            HiddenDownloader.download(self.CustomImg,destfile,MediaPath)
        #            xbmc.sleep(2000)
        #        if isFile(LocalCustomImg)==True:
        #            self.CustomImg=LocalCustomImg
        #    self.imgurl=self.CustomImg
    def CheckSettings(self):
        #self.DefaultImage=MediaFileG(FetchDefault())
        #if isFile(self.DefaultImage)==False: self.DefaultImage=MediaFileP('Black1')
        #self.imgopt=getSet('imgopt','')
        try: self.duropt=int(getSet('durationopt','5'))
        except: self.duropt=5
        self.useIcon=tfalse(getSet('useicon','false'))
        #self.useCustomImg=tfalse(getSet('usecustomimage','false'))
        #self.CustomImg=getSet('customimage','')
        #self.imgurl=self.DefaultImage
        self.useAdultCheck=tfalse(getSet('useadultcheck','false'))
        pass
    def FillImageList(self):
        #self.ImgList=FetchList()
        self.ImgArray=[]
        AddonsFolder=xbmc.translatePath(os.path.join('special://home','addons'))
        #print {'AddonsFolder':AddonsFolder}
        for Aa in os.listdir(AddonsFolder):
            ThisFile=os.path.join(AddonsFolder,Aa,'fanart.jpg'); 
            ThisIcon=os.path.join(AddonsFolder,Aa,'icon.png'); 
            ThisXml=os.path.join(AddonsFolder,Aa,'addon.xml'); GoodToGo=True; 
            #print {'Folder':Aa}
            try:
              if self.useAdultCheck==True:
                html=FileDoOpen(ThisXml).lower()
                if ('adult' in html) or ('18+' in html): GoodToGo=False
              if (isFile(ThisFile)) and (GoodToGo==True):
                #print {'ThisFile':ThisFile}
                if (isFile(ThisIcon)) and (self.useIcon==True):
                    self.ImgArray.append([self.duropt,ThisFile,ThisIcon])
                else:
                    self.ImgArray.append([self.duropt,ThisFile,''])
                #
            except: pass
            #
        if len(self.ImgArray)==0:
            self.ImgArray.append([self.duropt,MediaFileP('black1'),''])
            #print 'Doing Black'
        else:
            random.shuffle(self.ImgArray)
            #print 'Shuffled'
        
    def CheckForImage(self):
        self.FillImageList()
        # ################### #
        #print self.ImgArray
        while (self.abort_requested==False):
            for (aTime,aFile,aIcon) in self.ImgArray:
              try:
                if (self.abort_requested==True): return
                #print {'Image File':aFile}
                self.image2.setImage(aFile)
                if len(aIcon) > 0:
                    self.image3.setVisible(True)
                    self.image3.setImage(aIcon)
                else:
                    self.image3.setVisible(False)
                xbmc.sleep( ( 1000*(aTime) ) )
                #time.sleep.sleep(aTime)
                
                #
              except: pass
            
            #
        
        # ################### #
        #for (Aa,Bb,Cc) in self.ImgList:
        #    if self.imgopt==Aa:
        #        self.FExt='.gif'; LCc=Cc.lower()
        #        if  '.jpeg' in LCc: self.FExt='.jpeg'
        #        elif '.png' in LCc: self.FExt='.png'
        #        elif '.jpg' in LCc: self.FExt='.jpg'
        #        elif '.bmp' in LCc: self.FExt='.bmp'
        #        if  '.jpeg' in Bb: 	self.FExt='.jpeg'
        #        elif '.png' in Bb: 	self.FExt='.png'
        #        elif '.jpg' in Bb: 	self.FExt='.jpg'
        #        elif '.bmp' in Bb: 	self.FExt='.bmp'
        #        if (self.FExt=='.gif') and (not '.gif' in Bb): LocalImg=MediaFileG(Bb); 
        #        else: LocalImg=MediaFile(Bb); 
        #        print {'LocalImg':LocalImg,'FExt':self.FExt,'Bb':Bb,'Aa':Aa,'Cc':Cc}
        #        if LCc.startswith('http://') or LCc.startswith('https://'):
        #            if isFile(LocalImg)==False:
        #                import HiddenDownloader
        #                HiddenDownloader.download(Cc,Bb+self.FExt,MediaPath)
        #                xbmc.sleep(2000)
        #            if isFile(LocalImg)==True:
        #                self.imgurl=LocalImg
        #        else: 
        #            if isFile(LocalImg)==True: self.imgurl=LocalImg
        # ################### #
        #self.CheckForCustom()
        #self.CheckForValid()
        # ################### #
    def onInit(self):
        self.abort_requested=False; 
        self.started=False; 
        self.exit_monitor=self.ExitMonitor(self.exit); 
        #if xbmc.Player().isPlayingAudio():
        #    xbmc.executebuiltin('RunScript(script.cu.lrclyrics)')
        ###
        #self.winid=xbmcgui.getCurrentWindowId(); 
        self.winid=xbmcgui.getCurrentWindowDialogId(); 
        self.image1=self.getControl(100); #Background Image.
        self.image2=self.getControl(101); #Foreground Image.
        self.image3=self.getControl(102); #Foreground Image.
        self.blacken=tfalse(getSet('blacken','false')); 
        if self.blacken==True: self.image1.setImage(MediaFileP('black1'))
        else: self.image1.setImage(MediaFileP('blank1'))
        self.image3.setVisible(False)
        #self.SelectAspect()
        self.CheckSettings()
        self.CheckForImage()
        #self.image2.setImage(self.imgurl)
        ###
    def exit(self):
        self.abort_requested=True
        self.exit_monitor=None
        #if xbmc.Player().isPlayingAudio():
        #    xbmc.executebuiltin('Action(Back)')
        self.log('exit')
        self.close()
    def log(self,msg):
        #try: print ['Screensaver',msg]
        #except: pass
        try: xbmc.log(u'Screensaver: %s'%msg)
        except: pass
if __name__=='__main__':
    screensaver=Screensaver('CustomScreenSaver.xml',addon_path,'default')
    screensaver.doModal()
    del screensaver
    sys.modules.clear()
