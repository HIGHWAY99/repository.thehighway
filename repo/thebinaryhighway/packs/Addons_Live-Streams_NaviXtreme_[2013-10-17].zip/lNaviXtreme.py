### ############################################################################################################
###	#	
### # Site: 				#		Navi Xtreme - http://www.navixtreme.com/
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re,urllib

from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart,PlayItCustom,_addonPath,_OpenFile,isPath,isFile,addstv,addst,_debugging)
### ############################################################################################################
### ############################################################################################################
SiteName='Navi Xtreme  [v0.0.1]  [Streams] * (Pro Users|Others be careful)[CR](Pleanty to watch.  Browse/Search and use your head)'
SiteTag='navixtreme.com'
mainSite='http://www.navixtreme.com/'
iconSite='http://media.navi-x.org/images/logos/viewed.png' #'http://media.navi-x.org/images/header.jpg'
fanartSite='http://media.navi-x.org/images/backgrounds/bkg_navix_bh_plain.jpg' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources'))
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		m+=CR+CR+'Known Hosts for Videos:  '
		m+=CR+'RTMP Streams | RTSP Streams | MMS Streams | .FLV | .MP4'
		m+=CR+CR+'Features:  '
		m+=CR+'* Ability to play "some" video streams / files.'
		m+=CR+'* Browse sort of ini-like playlist pages.'
		m+=CR+'* Results:  If result\'s type is playlist it\'ll send back to the same function.  If the type is video, it\'ll send the url to the common PlayURL function.'
		m+=CR+'* Search - Play around with it to get what results you can.'
		m+=CR+'* Repeat Last Search - Like it says, this shows up once you\'ve done a Search for the first time and allows you to repeat the last search term you used for this Site.  Yes, it\'s setup to save the setting for each site seperately.'
		m+=CR+'* Play - Tries MSS|MSSH|RTSP via a STRM file. Tries HTTP via url resolver before playing directly. Others like RTMP|RTMPE it tries to play directly.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* These Links are VERY unstable, so expect many problems with them, even xbmc freezing at times.'
		m+=CR+'* I\'d suggest not using MMS:// and RTSP:// links for now.'
		m+=CR+'* Several of the RTMP links as well won\'t play, but hopefully wont cause XBMC to stall as much.'
		m+=CR+'* If you turn on debugging, you just MIGHT see extra Menu Item(s).'
		m+=CR+'* The PodCast playlists do not seem to have listings in them  at the time I made this sub-addon.'
		m+=CR+'* Some of the default Playlists of playlists were having trouble being fetched at times, so this sub-addon now downloads them if the /resources/*.plx files are missing or if the day has changed forward.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
def wP(filename):
	return xbmc.translatePath(os.path.join(workingPath,filename))
### ############################################################################################################
### ############################################################################################################

def Search_Site(title='',url='',page='',metamethod='',endit=True):
	if url=='': 'http://www.navixtreme.com/wiilist/search/'
	#if url=='': url=mainSite+'anime/search'; deb('url',url)
	#if len(page) > 0: page='1'
	if (title==''): title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title)
	addstv('LastSearchTitle'+SiteTag,title) ## Save Setting ##
	addstv('LastSearchUrl'+SiteTag,url) ## Save Setting ##
	title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','%20')
	#title=title.replace(' ','+')
	Browse_INI_Lists(url+title+'/')
	#Browse_INI_Lists('http://www.navixtreme.com/wiilist/search/'+title)

def Browse_INI_Lists(url):
	if url=='': return
	deb('url provided',url); 
	if workingPath in url:
		if isFile(url): html=_OpenFile(url)
		else: html=''
	elif 'http://' in url:
		html=nURL(url); #html=messupText(html,True,True); s=[]; ItemCount=0
	else: html=''
	deb('Length of HTML',str(len(html))); #debob(html)
	if len(html)==0: myNote('HTML: '+url,'No page could be retreived.'); return
	html=html.replace('type=','|||item|||type=')
	#if (url=='http://www.navixtreme.com/wiilist/') or (url=='http://www.navixtreme.com/scrape/podcasts/'): matches=html.split('\n\n'); ItemCount=len(matches); #debob(matches)
	#else: matches=html.split('#'); ItemCount=len(matches); #debob(matches)
	matches=html.split('|||item|||'); ItemCount=len(matches)
	deb('No. of possible matches',str(ItemCount))
	if ItemCount > 0:
		for _item in matches:
			labs={}; labs['plot']=''+CR; _marker=''; 
			if '\nURL=' in _item:
				try: _url=_item.split('\nURL=')[1].split('\n')[0]
				except: url=''
				if len(_url) > 0:
					if ('\ndescription=' in _item) and ('/description\n' in _item): labs['plot']+=cFL(_item.split('\ndescription=')[1].split('/description\n')[0],colors['12'])
					if ('\nthumb=' in _item): img=_item.split('\nthumb=')[1].split('\n')[0]; fimg=img
					elif ('\nicon=' in _item): img=_item.split('\nicon=')[1].split('\n')[0]; fimg=img
					else: img=iconSite; fimg=fanartSite
					if ('\nname=' in _item): _name=_item.split('\nname=')[1].split('\n')[0]
					else: _name='[UNKNOWN]'
					if ('type=' in _item): _type=_item.split('type=')[1].split('\n')[0]
					else: _type='[UNKNOWN]'
					labs['plot']+=CR+cFL('URL:  ',colors['11'])+cFL(_url,colors['10'])
					uFe=_url[-3:]
					if   _url[-2:-1]=='.': uFe2=_url[-1:]
					elif _url[-3:-2]=='.': uFe2=_url[-2:]
					elif _url[-4:-3]=='.': uFe2=_url[-3:]
					elif _url[-5:-4]=='.': uFe2=_url[-4:]
					elif _url[-6:-5]=='.': uFe2=_url[-5:]
					elif _url[-7:-6]=='.': uFe2=_url[-6:]
					elif _url[-8:-7]=='.': uFe2=_url[-7:]
					else: uFe2='___'
					if uFe=='sdp': _marker=' *'
					if '://' in _url: uPre=_url.split('://')[0]
					else: uPre='____'
					### playlist | video | directory | window
					if   _type.lower()=='playlist':
						#_title=cFL(_name,'white')+cFL('[CR]['+cFL(_type,colors['10'])+']',colors['11'])
						_title=cFL(_name,'white')+cFL('[CR]['+cFL(_type,colors['10'])+' | '+cFL(uPre,colors['1'])+' | '+cFL(uFe2,colors['2'])+']',colors['11'])
						labs['plot']+=CR+cFL('URL:  ',colors['11'])+cFL(_url,colors['10'])
						pars={'mode':'INIlists','site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}; labs['title']=_title; 
						try: 
							contextLabs={'title':' '+cFL('['+cFL(_type,colors['10'])+']',colors['11'])+'  '+_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':labs['plot']}
							contextMenuItems=ContextMenu_LiveStreams(contextLabs) #contextMenuItems=[]; 
						except: contextMenuItems=[]
						try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
						except: pass
					elif _type.lower()=='video': #.replace('','')
						_url=_url.replace('rtmp://$OPT:','').replace('rtmp-raw=','').replace('%20',' ')
						#_url=_url.replace('webport.tv:1935/live?lp/','webport.tv:1935/live playpath=').replace('webport.tv/live?lp=','webport.tv/live playpath=')
						#if 'http://www.olweb.tv/' in _url:
						#
						#if (_url[:7].lower() is not 'http://') and (_url[:7].lower() is not 'rtmp://') and (_url[:7].lower() is not 'mms://') and (_url[:7].lower() is not 'rtsp://'): _url='rtmp://'+_url
						_title=cFL(_name,'white')+cFL('[CR]['+cFL(_type,colors['10'])+' | '+cFL(uPre,colors['1'])+' | '+cFL(uFe2,colors['2'])+']',colors['11'])
						labs['plot']+=CR+cFL('URL:  ',colors['11'])+cFL(_url,colors['10'])
						pars={'mode':'PlayURLs','site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}; labs['title']=_title+_marker; 
						try: 
							contextLabs={'title':' '+cFL('['+cFL(_type,colors['10'])+']',colors['11'])+'  '+_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':labs['plot']}
							contextMenuItems=ContextMenu_LiveStreams(contextLabs) #contextMenuItems=[]; 
						except: contextMenuItems=[]
						try: _addon.add_directory(pars,labs,is_folder=False,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
						except: pass
	set_view('tvshows',int(addst('tvshows-view'))); eod()

def Browse_Hosts(url,page='',content='list',view='50'):
	if url=='': return
	#if page=='': page='1'
	deb('url',url)
	#npage=str(int(page)+1); deb('url and npage',url+'?page='+npage)
	html=nURL(url); html=messupText(html,True,True)
	#if '">Next</a></li>' in html: _addon.add_directory({'mode':'Episodes','site':site,'section':section,'url':url,'page':npage},{'title':cFL_('  .Next Page > '+npage,colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	s='<iframe.*?src="((http://[www|embed]*[\.]*([A-Za-z0-9\.\-_]*))/.+?)"'; matches=re.compile(s).findall(html); ItemCount=len(matches)
	if ItemCount > 0:
		debob(matches)
		for _url,_hostdomain,_hostname in matches:
			if ('/ads/' not in _url) and ('facebook' not in _url) and (mainSite.lower() not in _url.lower()) and ('ubhappy.eu' not in _hostname) and ('advertising' not in _hostname):
				img=''+thumbnail; fimg=''+fanart; _title=''+cFL_(_hostname,'blueviolet')
				if checkHostProblems(_url)==True: _title+=cFL_('  *','blueviolet')
				contextLabs={'title':addpr('title',''),'year':'0000','url':_url,'img':img,'fanart':fimg,'hostname':_hostname,'hostdomain':_hostdomain,'destfile':addpr('title','')+'.flv'}; contextMenuItems=ContextMenu_Hosts(labs=contextLabs)
				pars={'mode':'PlayFromHost','site':site,'section':section,'title':addpr('title',''),'hostname':_hostname,'hostdomain':_hostdomain,'url':_url,'img':img,'fanart':fimg}
				labs={'title':_title}
				_addon.add_directory(pars,labs,is_folder=False,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
	set_view(content,view_mode=addst('links-view'))
	eod()

def Fav_List(site='',section='',subfav=''):
	debob(['test1',site,section,subfav])
	favs=fav__COMMON__list_fetcher(site=site,section=section,subfav=subfav)
	ItemCount=len(favs)
	debob('test2 - '+str(ItemCount))
	if len(favs)==0: myNote('Favorites','None Found'); eod(); return
	debob(favs)
	for (_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2) in favs:
		if _img > 0: img=_img
		else: img=iconSite
		if _fanart > 0: fimg=_fanart
		else: fimg=fanartSite
		debob('_ToDoParams'); debob(_ToDoParams)
		pars=_addon.parse_query(_ToDoParams)
		debob('pars'); debob(pars)
		_title=cFL_(_name,'white')
		if (len(_year) > 0) and (not _year=='0000'): _title+=cFL('  ('+cFL(_year,'deeppink')+')','pink')
		if len(_Country) > 0: _title+=cFL('  ['+cFL(_Country,'deeppink')+']','pink')
		
		contextLabs={'title':_name,'year':_year,'img':_img,'fanart':_fanart,'country':_Country,'url':_Url,'plot':_plot,'genres':_Genres,'site':_site,'subfav':_subfav,'section':_section,'todoparams':_ToDoParams,'commonid':_commonID,'commonid2':_commonID2}
		##contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}
		contextMenuItems=ContextMenu_Favorites(contextLabs)
		#contextMenuItems=[]
		if 'playlist' in _name.lower(): issyF=True
		else: issyF=False
		_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=issyF,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#
	#
	if 'movie' in section.lower(): content='movies'
	else: content='tvshows'
	set_view(content,view_mode=int(addst('tvshows-view'))); eod()


### ############################################################################################################
### ############################################################################################################
def PlxCheck(n,u):
	n='wiilist_'+n+'.plx'; _dL=False
	d=datetime.date.today()
	_y=str(d.year); _m=str(d.month); _d=str(d.day)
	if len(_m)==1: _m='0'+_m
	if len(_d)==1: _d='0'+_d
	_date=_y+_m+_d
	if (len(addst('NaviXtreme__'+n))==0): _dL=True
	elif (int(addst('NaviXtreme__'+n)) < int(_date)): _dL=True
	if (_dL==True) or (isFile(wP(n))==False): 
		urllib.urlretrieve(mainSite+'wiilist/'+u+'.plx',wP(n))
		addstv('NaviXtreme__'+n,_date)
def SectionMenu():
	#
	#try: PlxCheck('day','day')
	#except: pass
	#try: PlxCheck('week','week')
	#except: pass
	#try: PlxCheck('update','update')
	#except: pass
	#try: PlxCheck('new','new')
	#except: pass
	#try: PlxCheck('all','all')
	#except: pass
	
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	###_addon.add_directory({'mode':'Search','url':'http://www.navixtreme.com/search/','site':site},{'title':cFL_('Search [navixtreme]',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	_addon.add_directory({'mode':'Search','url':'http://www.navixtreme.com/playlist/search/','site':site},{'title':cFL_('Search [playlist]',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	_addon.add_directory({'mode':'Search','url':'http://www.navixtreme.com/wiilist/search/','site':site},{'title':cFL_('Search [wiilist]',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	if (len(addst('LastSearchTitle'+SiteTag)) > 0) and (len(addst('LastSearchUrl'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')

	
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/'},{'title':cFL_('playlist - navi-xtreme [COLOR=FF888888]>>[/COLOR] home',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logo-trans.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/live_streams.plx'},{'title':cFL_('playlist - Live Streams',colors['1'])},is_folder=True,fanart='http://media.navi-x.org/images/backgrounds/bkg_navix_bh_plain.jpg',img='http://media.navi-x.org/images/logo-trans.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/day.plx'},{'title':cFL_('playlist - Most-viewed lists of the last 24 hours',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/viewed.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/week.plx'},{'title':cFL_('playlist - Most-viewed lists of the last 7 days',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/viewed.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/update.plx'},{'title':cFL_('playlist - Most-recently updated lists',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/newest.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/new.plx'},{'title':cFL_('playlist - Latest media entries',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/newest.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/all.plx'},{'title':cFL_('playlist - User media - full list',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/users.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/users.plx'},{'title':cFL_('playlist - navi-xtreme [COLOR=FF888888]>>[/COLOR] by user',colors['1'])},is_folder=True,fanart='http://media.navi-x.org/images/backgrounds/bkg_navix_bh_plain.jpg',img='http://media.navi-x.org/images/logos/user.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/user/'},{'title':cFL_('playlist - user',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'wiilist/'},{'title':cFL_('wiilist',colors['1'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/logo.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_day.plx')},{'title':cFL_('wiilist - Most-viewed lists of the last 24 hours',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/viewed.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_week.plx')},{'title':cFL_('wiilist - Most-viewed lists of the last 7 days',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/viewed.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_update.plx')},{'title':cFL_('wiilist - Most-recently updated lists',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/newest.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_new.plx')},{'title':cFL_('wiilist - Latest media entries',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/newest.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_all.plx')},{'title':cFL_('wiilist - User media - full list',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/users.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'wiilist/users.plx'},{'title':cFL_('wiilist - navi-xtreme  -  by user',colors['1'])},is_folder=True,fanart='http://media.navi-x.org/images/backgrounds/bkg_navix_bh_plain.jpg',img='http://media.navi-x.org/images/logos/user.png')
	
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/36866/kartoon_kapers.plx'},{'title':cFL_('playlist - 36866 - kartoon_kapers',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/icons/2downarrow.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/2229/realtime_scrapers.plx'},{'title':cFL_('playlist - 2229 - realtime scrapers',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/scrape.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/56427/bigdog_2011-2012_movies.plx'},{'title':cFL_('playlist - 56427 - bigdog 2011-2012 Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/57713/movie_collections.plx'},{'title':cFL_('playlist - 57713 - Movie Collections',colors['1'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/viewed.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/65970/latest_in_theaters.plx'},{'title':cFL_('playlist - 65970 - Latest in Theaters',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'wiilist/84633/'},{'title':cFL_('wiilist - 84633',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	###_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/'},{'title':cFL_('playlist - ',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	
	
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/cracklemovies/'},{'title':cFL_('Scrape - Crackle Movies',colors['1'])},is_folder=True,fanart='http://www.navixtreme.com/images/backgrounds/bkg_movies.jpg',img='http://www.navixtreme.com/images/backgrounds/thumb_crackle.png')
	
	
	if (_debugging==True): _addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/podcasts/'},{'title':cFL_('Scrape - Apple iTunes Podcasts',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_podcast.png')
	
	
	mS='http://home.comcast.net/~kgoerbig/playlists/'
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'home.plx'},{'title':cFL_('kgoerbig - home',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'olivia.plx'},{'title':cFL_('kgoerbig - olivia',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'movies.plx'},{'title':cFL_('kgoerbig - movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'home.plx'},{'title':cFL_('kgoerbig - ',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	
	#
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'XML','site':site,'section':'movies','url':mainSite+'videositemap-1.xml'},{'title':cFL_('Browse XML (videositemap-1.xml)',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'List','site':site,'section':'movies','url':mainSite+'category/anime-movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'series'},{'title':cFL_('Anime Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'ongoing-anime'},{'title':cFL_('Ongoing Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'new-anime'},{'title':cFL_('New Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Episodes','site':site,'section':'series','url':mainSite+'surprise'},{'title':cFL_('Suprise Me',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Search','site':site,'section':'series'},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	### Favorites
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'3'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'4'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'5'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'6'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'7'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	### Advanced Users - used to clean-up Favorites folders.
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'' },{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'2'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'3'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'4'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'5'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'6'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'7'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	
	set_view('list',view_mode=addst('default-view')); eod()



### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='SubMenu'): 			SubMenu() #(site,section)
	elif (mode=='Page'): 					Browse_Page(url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='Episodes'): 			Browse_Episodes(url,page)
	elif (mode=='List'): 					Browse_List(url,page)
	elif (mode=='XML'): 					Browse_XML(url)
	elif (mode=='INIlists'): 			Browse_INI_Lists(url)
	elif (mode=='INIitems'): 			Browse_INI_Items(url)
	elif (mode=='GetLiveFeed'): 	GetLiveFeed(url,addpr('title',''),addpr('img',''))
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='AZ'): 						Browse_AZ()
	elif (mode=='Genres'): 				Browse_Genres()
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=addst('LastSearchUrl'+SiteTag),page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
	
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
