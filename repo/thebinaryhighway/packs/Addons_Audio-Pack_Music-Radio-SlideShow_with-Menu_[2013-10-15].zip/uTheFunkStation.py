### ############################################################################################################
###	#	
### # Site: 				#		TheDareRadio - by The Highway 2013.
### # Author: 			#		The Highway
### # Description: 	#		
### # Credits: 			#		Originally ported from the addon project known as TheFunkStation - The Highway 2013.
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import urllib,urllib2,re,cookielib,os,sys
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
#from resources.libs import main
from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart,_addonPath,TextBox2)
selfAddon=_plugin
#from universal import watchhistory
#wh=watchhistory.WatchHistory(ps('_addon_id'))
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR blue]The [COLOR red]Funk[/COLOR] Station[/COLOR]  [Radio]'
SiteTag='thedarewall.com'
mainSite='http://listento.thefunkstation.com:8000/'
iconSite='http://listento.thefunkstation.com/funkradio/templates/funkstationv1/images/header.jpg' #_artIcon
#	#
#	#
fanartSite='http://listento.thefunkstation.com/funkradio/templates/funkstationv1/images/Bottom_texture.jpg' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch (listen to) the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'RTMP Live Streams'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Categories.  '
		m+=CR+'* Browse Radio Stations.'
		m+=CR+'* Song History'
		m+=CR+'* Status'
		m+=CR+'* Slide Show'
		m+=CR+CR+'Notes:  '
		m+=CR+'* Last I saw they were having troubles diplaying the radio stations [2013-10-02]'
		#m+=CR+'* '
		m+=CR+''
		m+=CR+'My XBMC-HUB Refferal Code - http://www.xbmchub.com/forums/register.php?referrerid=15468  '+CR+'Please use it to register if you don\'t have an account.  It not\'s not much but it can help me out.  '
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

### ############################################################################################################
### ############################################################################################################

def SongHistory(url):
	if (url==''): myNote('URL Error', 'No URL was Found.'); return
	html=''; WhereAmI('@ Song History -- url: %s' % url)
	try: html=nURL(url)
	except: html=''
	if (html=='') or (html=='none') or (html==None): deb('Error','Problem with page'); myNote('Results:  '+section,'No results were found.'); return
	deb('Length of HTML',str(len(html)))
	html2=(html.split('<tr><td>Played @</td><td><b>Song Title</b></td></tr>')[1]).split('</table>')[0]
	html2=html2.replace('<b>','[B]').replace('<B>','[B]').replace('</b>','[/B]').replace('</B>','[/B]')
	html2=html2.replace('<i>','[I]').replace('<I>','[I]').replace('</i>','[/I]').replace('</I>','[/I]')
	html2=html2.replace('<tr>','').replace('<TR>','').replace('</tr>','[CR]').replace('</TR>','[CR]')
	html2=html2.replace('</td><td>','     ').replace('</TD><TD>','     ')
	html2=html2.replace('<td>','').replace('<TD>','').replace('</td>','').replace('</TD>','')
	html2=html2.replace('[B]Current Song[/B]','[B][COLOR grey]  << Current Song[/COLOR][/B]')
	#html2=html2.replace('','')
	#try: _addon.resolve_url(url)
	#except: t=''
	TextBox2().load_string( html2 , cFL('Song History',ps('cFL_color2')) )
	#eod()

def Status(url):
	if (url==''): myNote('URL Error', 'No URL was Found.'); return
	html=''; WhereAmI('@ Status -- url: %s' % url)
	try: html=nURL(url)
	except: html=''
	if (html=='') or (html=='none') or (html==None): deb('Error','Problem with page'); myNote('Results:  '+section,'No results were found.'); return
	deb('Length of HTML',str(len(html)))
	html2=(html.split('<table cellpadding=5 cellspacing=0 border=0 width=100%><tr><td bgcolor=#000025 colspan=2 align=center><font class=ST>Current Stream Information</font></td></tr></table><table cellpadding=2 cellspacing=0 border=0 align=center>')[1]).split('</table>')[0]
	html2=html2.replace('<b>','[B]').replace('<B>','[B]').replace('</b>','[/B]').replace('</B>','[/B]').replace('<i>','[I]').replace('<I>','[I]').replace('</i>','[/I]').replace('</I>','[/I]').replace('<tr>','').replace('<TR>','').replace('</tr>','[CR]').replace('</TR>','[CR]').replace('</td><td>','     ').replace('</TD><TD>','     ').replace('<td>','').replace('<TD>','').replace('</td>','').replace('</TD>','')
	html2=html2.replace('<td width=100 nowrap>','').replace('<font class=default>','').replace('</font>','')
	html2=html2.replace('<br>','[CR]').replace('<BR>','[CR]').replace('&nbsp;',' ').replace('[/B][/B]','[/B]')
	html2=html2.replace('</a>','[/COLOR]').replace('<a href="','[COLOR maroon]').replace('">','[/COLOR]     [COLOR red]')
	#html2=html2.replace('','')
	#try: _addon.resolve_url(url)
	#except: t=''
	TextBox2().load_string( html2 , cFL('Song History',ps('cFL_color2')) )
	#eod()

def SectionMenu(): #(site):
	fS=fanartSite; iS=iconSite
	_addon.add_directory({'mode':'PlayURL','site':site,'url':'http://listento.thefunkstation.com:8000/'},{'title':cFL_('Listen to The Funk Station',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'SongHistory','site':site,'url':'http://listento.thefunkstation.com:8000/played.html'},{'title':cFL_('Song History',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'Status','site':site,'url':'http://listento.thefunkstation.com:8000/index.html'},{'title':cFL_('Status',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'SlideShowStart','site':site},{'title':cFL_('Last[COLOR red]FM[/COLOR] (Packaged)',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	
	# 'mode': 'SongHistory','url':'http://listento.thefunkstation.com:8000/played.html'
	# 'mode': 'Status','url':'http://listento.thefunkstation.com:8000/index.html'
	# 'mode': 'SlideShowStart'
	
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'series'},{'title':cFL_('Anime Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'ongoing-anime'},{'title':cFL_('Ongoing Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'new-anime'},{'title':cFL_('New Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Episodes','site':site,'section':'series','url':mainSite+'surprise'},{'title':cFL_('Suprise Me',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	###if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site,'endit':'false'},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#
	set_view('list',view_mode=addst('default-view')); eod()


### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='SubMenu'): 			SubMenu() #(site,section)
	elif (mode=='Page'): 					Browse_Page(url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='Episodes'): 			Browse_Episodes(url,page)
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='AZ'): 						Browse_AZ()
	elif (mode=='Genres'): 				Browse_Genres()
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='RadioStations'): RadioStations(addpr('title',''))
	elif (mode=='SongHistory'):		SongHistory(url)
	elif (mode=='Status'):				Status(url)
	elif (mode=='SlideShowStart'): path = os.path.join(_addonPath, 'c_SlideShow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	#elif (mode=='iLivePlay'): 		iLivePlay(addpr('title',''),url,thumbnail)
	### \/ Testing \/
	#elif (mode=='SearchLast'): 		
	#	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	#	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=True) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#
	#
	#
	#elif (mode=='FavList'): 			Fav_List(site,section)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
		
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
