### ############################################################################################################
###	#	
### # Site: 				#		DubHappy.eu - http://www.dubhappy.eu/
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui

from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath)
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR lime][COLOR yellow][B]RAM FM[/B][/COLOR] [COLOR deeppink]Eighties[/COLOR] Hit Radio[/COLOR]  [v0.0.1]  [Radio]'
SiteTag='ramfm.org'
mainSite='http://ramfm.org/' #'http://ramradio.com/' #'http://ramradio.nl/'
iconSite='http://ramfm.org/images/logo_top.png' #'http://ramfm.org/images/party2.png' #_artIcon
fanartSite='http://ramfm.org/images/bg_gb.jpg' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl=mainSite+'ram.pls'
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'Live Streams Playlist (ram.pls)'
		m+=CR+CR+'Features:  '
		m+=CR+'* Listen to the available Radio Stream.'
		m+=CR+'* Browse #/A-Z'
		m+=CR+'* Browse Artist(s)/Song(s) available for request.'
		m+=CR+'* Submit Artist+Song Request while listening to the Radio Stream.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* Please make your listening to the radio stream while you try to request a song.'
		m+=CR+'* When requesting a song, please remember to move back (..) after you\ve submitted your request.'
		m+=CR+'* Please remember to be kind and respectful when using the Song Requester.'
		m+=CR+'* SlideShow may or may not work at times.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+'My XBMC-HUB Refferal Code - http://www.xbmchub.com/forums/register.php?referrerid=15468  '+CR+'Please use it to register if you don\'t have an account.  It not\'s not much but it can help me out.  '
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t

### ############################################################################################################
### ############################################################################################################











def NowPlaying():
	html=messupText(nURL(mainSite+'index.php'),True)
	deb('length of html',str(len(html))); #debob(html)
	s='<b>\s*%s\s*.*?\s*<b>:</b>\s*.*?\s*<b>\s*(.*?)\s*</b>' ## Note: some don't have </b> after the the initial string. ##
	#re.compile(s % ('')).findall(html)[0].replace('<br/>','')
	#<img src=&quot;http://ramfm.org/artistpic/Cardigans.gif&quot; width=&quot;200&quot; border=&quot;0&quot; />
	#_addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	try: img=re.compile('<img\s*src="(http://ramfm.org/artistpic/.+?)"\s*width="200"\s*border="0"\s*/>').findall(html.replace('&quot;','"'))[0].replace(' ','%20')
	except: img=iconSite
	#
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Artist:  '+cFL(re.compile('<img\s*src="http://ramfm.org/artistpic/.+?"\s*.*?\s*/>.*?<img src="http://ramfm.org/images/format.png".*?\s/>.*?<b>\s*(.+?)\s*</b>').findall(html.replace('&quot;','"'))[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Song:  '+cFL(re.compile('<img\s*src="http://ramfm.org/artistpic/.+?"\s*.*?\s*/>.*?<img src="http://ramfm.org/images/format.png".*?\s/>.*?<b>\s*.*?\s*</b>.*?<b>\s*(.+?)\s*</b>').findall(html.replace('&quot;','"'))[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Year:  '+cFL(re.compile('<img\s*src="http://ramfm.org/artistpic/.+?"\s*.*?\s*/>.*?<img src="http://ramfm.org/images/format.png".*?\s/>.*?<b>\s*.*?\s*</b>.*?<b>\s*.*?\s*</b>.*?<br />\s*(\d\d\d\d)\s*<br />').findall(html.replace('&quot;','"'))[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Last Played:  '+cFL(re.compile(s % ('last played')).findall(html)[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Requested:  '+cFL(re.compile(s % ('requested')).findall(html)[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Average Rotation:  '+cFL(re.compile(s % ('average rotation')).findall(html)[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	#_addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL(':  '+cFL(re.compile(s % ('')).findall(html)[0].replace('<br/>',''),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	set_view('list',view_mode=addst('default-view')); eod()

def ListAZ():
	_addon.add_directory({'mode':'List','title':'0','site':site},{'title':cFL('0-9',colors['0'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/request.gif')
	for i in range(65, 91):
		_addon.add_directory({'mode':'List','title':chr(i),'site':site},{'title':cFL(chr(i),colors['0'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/request.gif')
	set_view('list',view_mode=addst('default-view')); eod()

def Browse_List(title):
	if len(title)==0: return
	deb('playlist url',mainSite+'requests/playlist'+str(title)+'.php')
	html=messupText(nURL(mainSite+'requests/playlist'+str(title)+'.php'),True)
	#html=nolines(html)
	#html=spAfterSplit(html,'>Search Artist by Last Name</font>'); html=spBeforeSplit(html,'<b>Search Artist by Last Name</b>'); 
	deb('length of html',str(len(html))); #debob(html)
	#s='<table.*?>\s*\n*\s*<tr>\s*\n*\s*<td.*?>\s*\n*\s*\n*\s*\n*\s*<img src="(http://ramfm.org/artistpic/.+?)".*?>\s*</a>\s*</td>\s*\n*\s*\n*\s*<td.*?>\s*<font.*?>\s*(*+?)\s*-\s*(.+?)\s*<br />\s*</font>\s*</td>\s*\n*\s*<td.*?><p.*??<font.*?><a href="javascript:request\((\d+),\'(\d+\.\d+\.\d+\.\d+)\',\'(\d+)\'\)">\s*\n*\s*<img\s*\n*\s*.*?Request this song now.*?></a></font>\s*</td>\s*\n*\s*</tr>\s*\n*\s*</table>'
	s='<table cellpadding="0" cellspacing="0" width="100%" align="center">\s*\n*\s*<tr>\s*\n*\s*<td nowrap align="left" bgcolor="#000000" width="10%">\s*\n*\s*\n*\s\n*\s*<img src="(http://ramfm.org/artistpic/.+?)" width="30" height="30" border="0" /></a></td>\s*\n*\s*\n*\s*'
	s+='<td align="left" bgcolor="#000000" width="80%"><font style="font-size: 9pt" color="#FFFF99" face="verdana">\s*(.+?)\s*-\s*(.+?)\s*<br /></font></td>\s*\n*\s*'
	s+='<td bgcolor="#000000" width="10%"><p align="right"><font size="2" color="#003366"><a href="javascript:request\((\d+),\'(\d+.\d+.\d+.\d+)\',\'(\d+)\'\)">\s*\n*\s*'
	#s+='<img\s*\n*\s*src="http://ramfm.org/images/request.gif" alt="Request this song now!" border="0" align="middle"></a></font>\s*</td>\s*\n*\s*</tr>\s*\n*\s*</table>'
	matches=re.compile(s).findall(html)
	deb('# of matches found',str(len(matches))); debob(matches)
	if len(matches)==0: return
	for (img,artist,songtitle,songid,samhost,samport) in matches:
		_url=mainSite+'req/request.php?songid='+str(songid)+'&samport='+str(samport)+'&samhost='+str(samhost)
		_title='['+songid+']  '+cFL(artist+' - '+cFL(songtitle,colors['10']),colors['6'])
		try: _addon.add_directory({'mode':'DoRequest','url':_url,'title':artist+' - '+songtitle,'site':site},{'title':_title},is_folder=True,fanart=fanartSite,img=img)
		except: pass
	set_view('list',view_mode=addst('default-view')); eod()

def DoRequest(url,title):
	if (len(url)==0) or (len(title)==0): return
	if len(title) > 0: s=''+title+' - '
	else: s=''
	if (url==addst('LastRequestURL'+SiteTag)) or (title==addst('LastRequestTitle'+SiteTag)):
		_addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'Denied!  You just requested this song already.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
	elif xbmc.Player().isPlaying()==False:
		_addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'Denied!  Must be listening to Submit a REQUEST.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
	else:
		addstv('LastRequestURL'+SiteTag,url); addstv('LastRequestTitle'+SiteTag,title)
		html=nURL(url)
		if 'Request OK' in html:
			_addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'[Submitted] Request OK.'+'[CR]Please allow them 10 to 15 minutes to process your request.  (ramradio.com)'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
		else:
			_addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'[Submitted] Request may have had a problem.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
		
	set_view('list',view_mode=addst('default-view')); eod()
	

### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	###
	#_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=False,fanart=fanartSite,img=iconSite)
	
	_addon.add_directory({'mode':'PlayURL','url':workingUrl,'site':site},{'title':cFL_('Listen to the Radio Stream',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/party2.png')
	_addon.add_directory({'mode':'NowPlaying','site':site},{'title':cFL_('Now Playing...',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/format.png')
	_addon.add_directory({'mode':'ListAZ','site':site},{'title':cFL('Song Requester',colors['4'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/request.png')
	#_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'SlideShowStart','site':site},{'title':cFL_('Last[COLOR red]FM[/COLOR] SlideShow (Packaged)',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/party2.png')
	
	#addDir('Listen to Stream',        _PLAYNOW, False)
	#addDir('Record Stream',           _RECORD,  False)
	#addDir('Song Requester',          _REQUEST, True)
	#addDir('Start Last.FM Slideshow', _LASTFM,  False)
	
	
	
	###
	set_view('list',view_mode=addst('default-view')); eod()






### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='NowPlaying'): 		NowPlaying()
	elif (mode=='ListAZ'): 				ListAZ()
	elif (mode=='List'): 					Browse_List(addpr('title',''))
	elif (mode=='DoRequest'): 		DoRequest(url,addpr('title',''))
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	#elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	#elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='SlideShowStart'): path = os.path.join(_addonPath, 'c_SlideShow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
