### ############################################################################################################
###	#	
### # Site: 				#		Nickelodeon NL - http://www.nickelodeon.nl/
### # Author: 			#		The Highway
### # Description: 	#		
### # Credits: 			#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import common
from common import *
from common import (_debugging,_addon,_artIcon,_artFanart,_addonPath,_OpenFile,isPath,isFile,popYN,_SaveFile,popOK,CopyAFile,RefreshList,DownloadThis,getFileExtension)
### ############################################################################################################
### ############################################################################################################
SiteName='Nickelodeon NL (v0.0.2)  [Cartoons][CR] (Under Construction)'
SiteTag='disneyinternational.com'
mainSite='http://www.nickelodeon.nl'
iconSite='http://www.nickelodeon.nl/assets/nickelodeon_logo-ca7f2e7c885b67cedfebdfb0e52d1e64.png' #_artIcon
fanartSite='http://www.nickelodeon.nl/assets/main_bg-ebb0192283db86f1e3ba9b21ad021568.gif' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl='http://module.disneyinternational.com//xml/videoPlaylist.view?instanceId=282091'
#workingUrl='http://module.disneyinternational.com/xml/videoPlaylist.view?instanceId=282091'
workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources'))
workingFile='themoonlitroad.txt'
workingFileWP=xbmc.translatePath(os.path.join(workingPath,workingFile))
### ############################################################################################################
### ############################################################################################################
site=addpr('site',''); section=addpr('section',''); url=addpr('url',''); thumbnail=addpr('img',''); fanart=addpr('fanart',''); page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		#m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'... | ... | ... | ...'
		m+=CR+CR+'Features:  '
		#m+=CR+'* '
		#m+=CR+'* '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+CR+'Notes:  '
		#m+=CR+'* Those with a "[COLOR red] *[/COLOR]" may have a good chance of not working.'
		#m+=CR+'* Not all stations will play.  There\'s simply too many to try and make sure every single one will work.  So please be happy with what does.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
def TP(s): return xbmc.translatePath(s)
def TPap(s,fe='.py'): return xbmc.translatePath(os.path.join(_addonPath,s+fe))
### ############################################################################################################
### ############################################################################################################
def UpdateWorkingFile(): _SaveFile(workingFileWP,messupText(nURL(workingUrl),True,True))


def GetMedia(url,img,title):
	html1=messupText(nolines(nURL(url)),True,True)
	#s="<meta content='(.+?)' property='og:video'>"
	#s="<meta content='(.+?)' property='og:video:secure_url'>"
	s="mrss\s*:\s*'(.+?)'"
	url2=re.compile(s).findall(html1)[0]; #debob(stream_url)
	debob(url2)
	html2=messupText(nolines(nURL(url2)),True,True)
	#debob(html2)
	s="<media:content .*?url='(.+?)'"
	url3=re.compile(s).findall(html2)[0]; #debob(stream_url)
	debob(url3)
	html=messupText(nolines(nURL(url3)),True,True)
	s="<src>(.+?://.+?)</src>"
	fimg=fanartSite
	#s='\\"url\\"\s*:\s*\\"(http://.+?)\\"'; 
	##s='\\"url\\"\s*:\s*\\"(http://.+?pls.*?)\\"'; 
	#stream_url=re.compile(s).findall(html)[0]; debob(stream_url)
	urls=re.compile(s).findall(html); #debob(stream_url)
	for _url in urls:
		try: r1=re.compile('(\d+k)').findall(_url)[0]
		except: r1=''
		try: r2=re.compile('(\d+x\d+)').findall(_url)[0]
		except: r2=''
		_title=title
		if len(r2) > 0: _title+='  ('+r2+')'
		if len(r1) > 0: _title+='  ['+r1+']'
		_title+=CR+_url
		_addon.add_directory({'url':_url,'mode':'PlayURL','title':title,'img':img,'site':site},{'title':_title,},is_folder=False,fanart=fimg,img=img)
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	#set_view('list',view_mode=addst('default-view')); eod()
	return
	##stream_url=re.compile(s).findall(nolines(html))[1]; debob(stream_url)
	##PlayURL(stream_url); return
	PlayItCustom(url,stream_url,img,title,studio=''); #return
	try: matches=re.compile(s).findall(nolines(html)) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		debob(matches)
		for stream_url in matches:
			if ('pls' in stream_url) or ('.flv' in stream_url) or ('.mp3' in stream_url) or ('rtmp://' in stream_url) or ('.asx' in stream_url):
				#try: PlayURL(stream_url); return
				try: PlayItCustom(url,stream_url,img,title,studio=''); return
				except: pass
		stream_url=re.compile(s).findall(nolines(html))[0]; debob(stream_url)
		PlayItCustom(url,stream_url,img,title,studio=''); #return
		#for stream_url in matches:
		#	#try: PlayURL(stream_url); return
		#	try: PlayItCustom(url,stream_url,img,title,studio=''); return
		#	except: pass



def TestPlay(url):
	try: _addon.resolve_url(url)
	except: pass
	deb('url',url); import c_HiddenDownloader as downloader; downloader.download(url,'test.mp3',workingPath,False)

def Browse_Shows1(url,domain):
	#if len(url) > 7:
	#	if url[:7]=='http://': url2=url
	#	else: url2=domain+url
	#else: url2=domain+url
	url2=url; deb('url 2 get',url2); html=messupText(nolines(nURL(url2)),True,True)
	##s='<img.*?src="(http://.+?)"\s*title="(.+?)".*?<a\s*href="(/videos/show/\d+)"'; 
	#s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"\s*title="(.+?)".*?<a\s*href="(/videos/show/\d+.*?)"'; 
	#try: matches=re.compile(s).findall(html) #,re.DOTALL
	#except: matches=''
	#ItemCount=len(matches)
	#if ItemCount > 0:
	#	#debob('lists'); debob(matches)
	#	for (img,_name,_url) in matches:
	#		fimg=fanartSite
	#		_title=''+cFL_(_name,colors['0']) #+CR+_id
	#		_plot=''
	#		if len(_url.strip()) > 0:
	#			_addon.add_directory({'url':mainSite+_url,'mode':'BVideos','title':_name,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
	##
	s='<a class="next_page" rel="next" href="(/videos/.*?)"'; 
	try: matches=re.compile(s).findall(html)[0] #,re.DOTALL
	except: matches=''
	if len(matches) > 0: _addon.add_directory({'url':mainSite+matches,'mode':'BShows','title':'','img':iconSite,'site':site},{'title':'[Next Page]','plot':''},is_folder=True,fanart=fanartSite,img=iconSite)
	#
	s='<a href="(/videos/.*?)" class="orange_link_button"><span>(.*?)</span>'; 
	try: (matches,matches2)=re.compile(s).findall(html)[0] #,re.DOTALL
	except: matches=''; matches2=''
	if len(matches) > 0: _addon.add_directory({'url':mainSite+matches,'domain':domain,'mode':'BShows','title':'','img':iconSite,'site':site},{'title':''+matches2+'','plot':''},is_folder=True,fanart=fanartSite,img=iconSite)
	#
	s='<a\s*href="(/videos/show/\d+.*?)".*?<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"\s*title="(.+?)"'; 
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		debob('lists'); debob(matches)
		fimg=fanartSite; _plot=''
		for (_url,img,_name) in matches:
			_title=''+cFL_(_name,colors['1']) #+CR+_id
			if len(_url.strip()) > 0: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'BShows','title':_name,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
	#
	#s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*?<h3>(.*?)</h3>\s*<a\s*href="(/videos/\d+-(.+?))"'; 
	s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*?title="(.*?)".*?<a\s*href="(/videos/\d+-(.+?))"'; 
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		debob('lists'); debob(matches)
		fimg=fanartSite; 
		for (img,_name,_url,_tag) in matches:
			_title=''+cFL_(_name,colors['8'])
			_plot=''+CR+_tag
			if len(_url.strip()) > 0: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'GetMedia','title':_name,'img':img,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	#set_view('list',view_mode=addst('default-view')); eod()

def Browse_Shows(url,domain):
	#if len(url) > 7:
	#	if url[:7]=='http://': url2=url
	#	else: url2=domain+url
	#else: url2=domain+url
	url2=url; deb('url 2 get',url2); html=messupText(nolines(nURL(url2)),True,True)
	##s='<img.*?src="(http://.+?)"\s*title="(.+?)".*?<a\s*href="(/videos/show/\d+)"'; 
	#s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"\s*title="(.+?)".*?<a\s*href="(/videos/show/\d+.*?)"'; 
	#try: matches=re.compile(s).findall(html) #,re.DOTALL
	#except: matches=''
	#ItemCount=len(matches)
	#if ItemCount > 0:
	#	#debob('lists'); debob(matches)
	#	for (img,_name,_url) in matches:
	#		fimg=fanartSite
	#		_title=''+cFL_(_name,colors['0']) #+CR+_id
	#		_plot=''
	#		if len(_url.strip()) > 0:
	#			_addon.add_directory({'url':mainSite+_url,'mode':'BVideos','title':_name,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
	## Next Button
	if '<a class="next_page" rel="next" href="' in html:
		s='<a class="next_page" rel="next" href="(/videos/.*?)"'; 
		try: matches=re.compile(s).findall(html)[0] #,re.DOTALL
		except: matches=''
		deb('next page',mainSite+matches)
		if len(matches) > 0: _addon.add_directory({'url':mainSite+matches,'mode':'BShows','title':'','img':iconSite,'site':site},{'title':'[Meer Video\'s]','plot':''},is_folder=True,fanart=fanartSite,img=iconSite)
	# Meer Button
	if '" class="orange_link_button"><span>' in html:
		s='<a href="(/videos/[A-Za-z0-9\-_/]*)" class="orange_link_button"><span>(.*?)</span>'; 
		try: (matches,matches2)=re.compile(s).findall(html)[0] #,re.DOTALL
		except: matches=''; matches2=''
		#deb('more page',mainSite+matches)
		if len(matches) > 0: _addon.add_directory({'url':mainSite+matches,'domain':domain,'mode':'BShows','title':'','img':iconSite,'site':site},{'title':''+matches2+'','plot':''},is_folder=True,fanart=fanartSite,img=iconSite)
	## Lists
	s='<a\s*href="(/videos/show/\d+.*?)".*?<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"\s*title="(.+?)"'; 
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		fimg=fanartSite; _plot=''; #debob('lists'); debob(matches)
		for (_url,img,_name) in matches:
			_title=''+cFL_(_name,colors['1']) #+CR+_id
			if len(_url.strip()) > 0: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'BShows','title':_name,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
	## Videos
	##s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*?<h3>(.*?)</h3>\s*<a\s*href="(/videos/\d+-(.+?))"'; 
	#s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*?title="(.*?)".*?<a\s*href="(/videos/\d+-(.+?))"'; 
	s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+" title="[A-Za-z0-9\-_\'`\s]*"><span>[A-Za-z0-9\-_\'`\s]*</span>\s*<span class=\'playicon\'>Play</span>\s*<img alt="[A-Za-z0-9\-_\'`\s]*" height="\d+" src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)" title="([A-Za-z0-9\-_\'`\s]*)"'
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		fimg=fanartSite; debob('lists'); debob(matches)
		for (_url,_tag,img,_name) in matches:
			_title=''+cFL_(_name,colors['8'])
			_plot=''+CR+_tag+CR+_url
			if len(_url.strip()) > 0:
				try: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'GetMedia','title':_name,'img':img,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
				except: pass
	## Videos 2
	#s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img alt="[A-Za-z0-9\-_\'`\s]*" height="\d+" src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)" title="([A-Za-z0-9\-_\'`\s]*)"'
	#s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img alt="([A-Za-z0-9\-_\'`\s]*)" height="\d+" src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"'
	#s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img [A-Za-z\-_\=/\s\'\`]*src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"[A-Za-z\-_\=/\s\'\`]*>\s*</a><div class=\'description\'>\s*<h3>([A-Za-z0-9\-_\'\`\s]*)<'
	s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img (?:alt="[A-Za-z0-9\-_\'`\s]*" )?(?:height="\d+" )?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"(?: title="[A-Za-z0-9\-_\'`\s]*")?(?: width="\d+")? />\s*</a><div class=\'description\'>\s*<h3>([A-Za-z0-9\-_\'\`\s]*)<'
	
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		debob('lists'); debob(matches)
		fimg=fanartSite; 
		for (_url,_tag,img,_name) in matches:
			_title=''+cFL_(_name,colors['8'])
			_plot=''+CR+_tag+CR+_url
			if len(_url.strip()) > 0:
				try: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'GetMedia','title':_name,'img':img,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
				except: pass
	#
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	#set_view('list',view_mode=addst('default-view')); eod()

def Browse_Shows2(url,domain):
	#if len(url) > 7:
	#	if url[:7]=='http://': url2=url
	#	else: url2=domain+url
	#else: url2=domain+url
	url2=url; deb('url 2 get',url2); html=messupText(nolines(nURL(url2)),True,True)
	##s='<img.*?src="(http://.+?)"\s*title="(.+?)".*?<a\s*href="(/videos/show/\d+)"'; 
	#s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"\s*title="(.+?)".*?<a\s*href="(/videos/show/\d+.*?)"'; 
	#try: matches=re.compile(s).findall(html) #,re.DOTALL
	#except: matches=''
	#ItemCount=len(matches)
	#if ItemCount > 0:
	#	#debob('lists'); debob(matches)
	#	for (img,_name,_url) in matches:
	#		fimg=fanartSite
	#		_title=''+cFL_(_name,colors['0']) #+CR+_id
	#		_plot=''
	#		if len(_url.strip()) > 0:
	#			_addon.add_directory({'url':mainSite+_url,'mode':'BVideos','title':_name,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
	## Next Button
	if '<a class="next_page" rel="next" href="' in html:
		s='<a class="next_page" rel="next" href="(/videos/.*?)"'; 
		try: matches=re.compile(s).findall(html)[0] #,re.DOTALL
		except: matches=''
		deb('next page',mainSite+matches)
		if len(matches) > 0: _addon.add_directory({'url':mainSite+matches,'mode':'BShows2','title':'','img':iconSite,'site':site},{'title':'[Meer Video\'s]','plot':''},is_folder=True,fanart=fanartSite,img=iconSite)
	# Meer Button
	if '" class="orange_link_button"><span>' in html:
		s='<a href="(/videos/[A-Za-z0-9\-_/]*)" class="orange_link_button"><span>(.*?)</span>'; 
		try: (matches,matches2)=re.compile(s).findall(html)[0] #,re.DOTALL
		except: matches=''; matches2=''
		#deb('more page',mainSite+matches)
		if len(matches) > 0: _addon.add_directory({'url':mainSite+matches,'domain':domain,'mode':'BShows2','title':'','img':iconSite,'site':site},{'title':''+matches2+'','plot':''},is_folder=True,fanart=fanartSite,img=iconSite)
	## Lists
	#s='<a\s*href="(/videos/show/\d+.*?)".*?<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"\s*title="(.+?)"'; 
	s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*?<h3>(.+?)</h3>.*?<a\s*href="(/videos/show/\d+[A-Za-z0-9\-_/]*)"'; 
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		fimg=fanartSite; _plot=''; debob('lists'); debob(matches)
		for (img,_name,_url) in matches:
			_title=''+cFL_(_name,colors['1']); _plot=CR+_url
			if len(_url.strip()) > 0: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'BShows2','title':_name,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
	## Videos
	##s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*?<h3>(.*?)</h3>\s*<a\s*href="(/videos/\d+-(.+?))"'; 
	#s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*?title="(.*?)".*?<a\s*href="(/videos/\d+-(.+?))"'; 
	s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+" title="[A-Za-z0-9\-_\'`\s]*"><span>[A-Za-z0-9\-_\'`\s]*</span>\s*<span class=\'playicon\'>Play</span>\s*<img alt="[A-Za-z0-9\-_\'`\s]*" height="\d+" src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)" title="([A-Za-z0-9\-_\'`\s]*)"'
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		fimg=fanartSite; debob('lists'); debob(matches)
		for (_url,_tag,img,_name) in matches:
			_title=''+cFL_(_name,colors['8'])
			_plot=''+CR+_tag+CR+_url
			if len(_url.strip()) > 0:
				try: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'GetMedia','title':_name,'img':img,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
				except: pass
	#
	#s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span>[A-Za-z0-9\-_\'`\s]*</span>\s*<span class=\'playicon\'>Play</span>\s*<img alt="[A-Za-z0-9\s\-_\'\`]*" height="\d+" src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)" title="([A-Za-z0-9\s\-_\'\`]*)"'
	s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img alt=".*?" height="\d+" src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)" title="(.*?)"'
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		fimg=fanartSite; debob('lists'); debob(matches)
		for (_url,_tag,img,_name) in matches:
			_title=''+cFL_(_name,colors['8'])
			_plot=''+CR+_tag+CR+_url
			if len(_url.strip()) > 0:
				try: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'GetMedia','title':_name,'img':img,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
				except: pass
	## Videos 2
	#s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img alt="[A-Za-z0-9\-_\'`\s]*" height="\d+" src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)" title="([A-Za-z0-9\-_\'`\s]*)"'
	#s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img alt="([A-Za-z0-9\-_\'`\s]*)" height="\d+" src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"'
	#s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img [A-Za-z\-_\=/\s\'\`]*src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"[A-Za-z\-_\=/\s\'\`]*>\s*</a><div class=\'description\'>\s*<h3>([A-Za-z0-9\-_\'\`\s]*)<'
	s='<a href="(/videos/\d+([A-Za-z0-9\-_/]*))" class="\D+"><span class=\'playicon\'>Play</span>\s*<img (?:alt="[A-Za-z0-9\-_\'`\s]*" )?(?:height="\d+" )?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)"(?: title="[A-Za-z0-9\-_\'`\s]*")?(?: width="\d+")? />\s*</a><div class=\'description\'>\s*<h3>([A-Za-z0-9\-_\'\`\s]*)<'
	
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		debob('lists'); debob(matches)
		fimg=fanartSite; 
		for (_url,_tag,img,_name) in matches:
			_title=''+cFL_(_name,colors['8'])
			_plot=''+CR+_tag+CR+_url
			if len(_url.strip()) > 0:
				try: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'GetMedia','title':_name,'img':img,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
				except: pass
	#
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	#set_view('list',view_mode=addst('default-view')); eod()

def Browse_Videos(url,domain):
	#if len(url) > 7:
	#	if url[:7]=='http://': url2=url
	#	else: url2=domain+url
	#else: url2=domain+url
	url2=url; deb('url 2_get',url2); html=messupText(nolines(nURL(url2)),True,True)
	#s='<img.*src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*<h3>(.+?)</h3>\s*<a\s*href="(/videos/\d+-.+?)"'; 
	s='<a class="next_page" rel="next" href="(/videos/.*?page.*?)">'; 
	try: matches=re.compile(s).findall(html)[0] #,re.DOTALL
	except: matches=''
	if len(matches) > 0: _addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'BVideos','title':'','img':iconSite,'site':site},{'title':'[Next Page]','plot':''},is_folder=True,fanart=fanartSite,img=iconSite)
	s='<img.*?src="(http://images.mtvnn.com/[A-Za-z0-9]+/\d+x\d+[_]*)".*?<h3>(.*?)</h3>\s*<a\s*href="(/videos/\d+-(.+?))"'; 
	try: matches=re.compile(s).findall(html) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		#debob('lists'); debob(matches)
		for (img,_name,_url,_tag) in matches:
			fimg=fanartSite
			_title=''+cFL_(_name,colors['8'])+CR+_tag
			_plot=''
			if len(_url.strip()) > 0:
				_addon.add_directory({'url':mainSite+_url,'domain':domain,'mode':'GetMedia','title':_name,'img':img,'site':site},{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img)
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	#set_view('list',view_mode=addst('default-view')); eod()

### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	cNumber ='8'; cNumber2='2'; cNumber3='4'; 
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	
	##_addon.add_directory({'url':'http://provisioning.streamtheworld.com/pls/CKYEFMAAC.pls','title':'red fm','img':iconSite,'mode':'PlayURL','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'http://streema.com/radios/play/12929','title':'red fm','img':iconSite,'mode':'GetMedia','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'url':'http://provisioning.streamtheworld.com/pls/CKYEFMAAC.pls','title':'red fm','img':iconSite,'mode':'GetMedia','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	
	#_addon.add_directory({'url':'http://module.disneyinternational.com//xml/videoPlaylist.view?instanceId=282091','domain':'http://module.disneyinternational.com','mode':'SubMenu2','site':site},{'title':cFL_('English',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'/radios','domain':'http://fr.streema.com','mode':'SubMenu2','site':site},{'title':cFL_('Francais',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'url':'http://www.nickelodeon.nl/videos','domain':'','mode':'BShows','site':site},{'title':cFL_('Videos',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'url':'http://www.nickelodeon.nl/kanalen/18','domain':'','mode':'BShows2','site':site},{'title':cFL_('Nick Jr',colors['8'])},is_folder=True,fanart='http://www.nickelodeon.nl/assets/nickjr_wallpaper_north-200e41db7a6df95c93722eea1c51e98d.jpg',img='http://images.mtvnn.com/0b4f73f5f01fb507ebd39110a61cd8b4/275x80_')
	_addon.add_directory({'url':'http://www.nickelodeon.nl/kanalen/28?window=nicktoons','domain':'','mode':'BShows','site':site},{'title':cFL_('Nick Toons',colors['8'])},is_folder=True,fanart='http://www.nickelodeon.nl/assets/main_bg-ebb0192283db86f1e3ba9b21ad021568.gif',img='http://images.mtvnn.com/0a55e4a3f31205c36844c271971b81a8/275x80_')
	_addon.add_directory({'url':'http://www.nickelodeon.nl/kanalen/28?window=nickhits','domain':'','mode':'BShows','site':site},{'title':cFL_('NIck Hits',colors['8'])},is_folder=True,fanart='http://www.nickelodeon.nl/assets/main_bg-ebb0192283db86f1e3ba9b21ad021568.gif',img='http://images.mtvnn.com/ca0354e619f3c8c2f6fb2946cefde4df/275x80_')
	_addon.add_directory({'url':'http://www.nickelodeon.nl/kanalen/28?window=teennick','domain':'','mode':'BShows','site':site},{'title':cFL_('Teen Nick',colors['8'])},is_folder=True,fanart='http://ops.mtvnn.com/nickelodeon/nl_2011/background_images/teennick_bg.jpg',img='http://images.mtvnn.com/d5b21c0cbc1c8f27f0d69587a10edb3a/275x80_')
	_addon.add_directory({'url':'http://www.kindernet.nl/','domain':'','mode':'BShows','site':site},{'title':cFL_('Kindernet',colors['8'])},is_folder=True,fanart='http://www.kindernet.nl/assets/css/main_bg-55edb37a3799e66c2ddf272bddcec53c.jpg',img=iconSite)
	#_addon.add_directory({'url':'','domain':'','mode':'SubMenu2','site':site},{'title':cFL_('UK',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'','domain':'','mode':'SubMenu2','site':site},{'title':cFL_('UK',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'','domain':'','mode':'SubMenu2','site':site},{'title':cFL_('UK',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'','domain':'','mode':'SubMenu2','site':site},{'title':cFL_('UK',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	#http://module.disneyinternational.com//xml/videoPlaylist.view?instanceId=385026
	#_addon.add_directory({'url':'http://module.disneyinternational.com//xml/videoPlaylist.view?instanceId=282091','domain':'http://disney.nl','mode':'SubMenu2','site':site},{'title':cFL_('Nederland',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'http://module.disneyinternational.com//xml/videoPlaylist.view?instanceId=336610','domain':'http://disney.co.uk','mode':'SubMenu2','site':site},{'title':cFL_('UK',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	#############################################
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'http://url...to...video/...file.flv','mode':'PlayURL','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	
	
	#
	#eod()
	#set_view('movies',view_mode=addst('movies-view')); eod(); 
	set_view('list',view_mode=addst('default-view')); eod() ##

### ############################################################################################################
### ############################################################################################################
## This function handles forwarding the mode param message code and directing the sub-addon to wherever it needs to go... like a GO-TO-Function command. ##
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() ## The Binary Highway usually sends 'SectionMenu' as the mode when initially calling the sub-addon.  is also good to use:  or (mode=='') or (mode=='main') ##
	elif (mode=='SubMenu'): 			SubMenu(url)
	elif (mode=='SubMenu2'): 			SubMenu2(url,addpr('domain',''))
	elif (mode=='BShows'): 				Browse_Shows(url,addpr('domain',''))
	elif (mode=='BShows1'): 			Browse_Shows1(url,addpr('domain',''))
	elif (mode=='BShows2'): 			Browse_Shows2(url,addpr('domain',''))
	elif (mode=='BShows3'): 			Browse_Shows3(url,addpr('domain',''))
	elif (mode=='BVideos'): 			Browse_Videos(url,addpr('domain',''))
	#
	#elif (mode=='NameYourMode'): 	NameYourFuction(url=url,addpr('title',''),addpr('img',''))
	#
	#
	#
	#
	elif (mode=='GetMedia'):			GetMedia(url,addpr('img',''),addpr('title',''))
	elif (mode=='TestPlay'):			TestPlay(url)
	elif (mode=='UpdateWorkingFile'):	UpdateWorkingFile(); RefreshList()
	elif (mode=='About'): 				About()  ## In most of my Sub-Addons. ##
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain  ## If a mode can not be found ##
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
