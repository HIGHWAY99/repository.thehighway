### ############################################################################################################
###	#	
### # Site: 				#		Anime FATE - http://www.animefate.com/
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui
from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath)
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR orange][I]Anime[/I][/COLOR] [COLOR purple][B]FATE[/B][/COLOR]  [v0.0.1]  [Anime]'
SiteTag='animefate.com'
mainSite='http://www.animefate.com'
mainSite2='http://www.animefate.com'
iconSite='http://www.animefate.com/wp-content/uploads/2012/09/animefate_logo.png' #_artIcon
fanartSite='http://www.animefate.com/wp-content/themes/MagMan/i/footer-overlay.png' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyGenres=[' Action','Action','Adventure','Animation','Cars','Comedy','Dementia','Demons','Drama','Ecchi','Fantasy','Game','Harem','Historical','Horror','Josei','Kids','Magic','Martial Arts','Mecha','Military','Movie','Music','Mutants','Mystery','Parody','Police','Psychological','Romance','Samurai','School','Sci-Fi','Seinen','Shoujo','Shoujo Ai','Shounen','Shounen Ai','Slice of Life','Space','Sports','Super Power','Supernatural','Thriller','Vampire']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl=mainSite+'ram.pls'
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'Live Streams (RTMPE)'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Shows'
		m+=CR+'* Browse Episodes'
		m+=CR+'* Browse Host Links'
		m+=CR+'* Play Videos with UrlResolver'
		m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
### ############################################################################################################
### ############################################################################################################
def GetMedia(Url,title,imdb_id,img,fimg,stitle,etitle):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('imdb_id',imdb_id); deb('title',title); deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	s='<iframe\s+id="video"\s+src="(http[s]*://.+?)"'; 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		#for (url,img,name,genres,status,NoEps,year) in matches:
		iC=len(matches); 
		try: import urlresolver
		except: pass
		for m in matches:
			cMI=[]; 
			labs={'title':m}
			pars={'mode':'PlayFromHost','url':m,'studio':stitle+' - '+etitle,'title':title,'etitle':etitle,'stitle':title,'imdb_id':imdb_id,'img':img,'fimg':fimg,'site':site}; 
			if urlresolver.HostedMediaFile(m).valid_url(): labs[u'title']=cFL(m,'blue'); 
			else: labs[u'title']=cFL(m,'red'); 
			try: _addon.add_directory(pars,labs,is_folder=False,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
	# <iframe id="video" src="
	#html=messupText(nURL('http://metaframe.digitalsmiths.tv/v2/WBtv/assets/'+VideoID+'/partner/11?format=json'),True)
	#s='"length": (\d+), "bitrate": "(.+?)", "uri": "(.+?://.+?)"'; matches=re.compile(s).findall(nolines(html)); deb('# of matches found',str(len(matches))); #debob(matches)
	#for (_length,_name,_url) in matches:
	#	labs={'title':title+' - ['+_name+']'}
	#	try: _addon.add_directory({'mode':'PlayVideo','img':img,'studio':'['+_name+']','url':_url,'title':title,'site':site},labs,is_folder=False,fanart=fanartSite,img=img)
	#	except: pass
	set_view('list',view_mode=addst('default-view')); eod()

def ListPopularShows(Url=mainSite):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	s='</div><div class=\'pop_img_list\'>\s*<div class="img_hor_strip">\s*\n*\s*<a href="(http://www.animefate.com/series/.+?/)" title=".+? English Dubbed Anime">\s*\n*\s*'; 
	s+='<img src="(http://www.animefate.com/images/.+?-\d+x\d+.[jpg|png|gif]+)" alt=".+?" title=".+?" />\s*</div>\s*\n*\s*<p class="pop_anime_name">(.+?)</p>\s*\n*\s*</a>'; 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for (img,url,name) in matches:
			cMI=[]; img=img.replace(' ','%20'); fimg=fanartSite; deb('img',img); Genres2=""; g="<a href='http://www.animefate.com/.genre=.+?'>\s*(.+?)\s*</a>"; plot=""; labs={}; 
			#try: Genres1=re.compile(g).findall(genres); debob(Genres1); 
			#except: Genres1=""; 
			#for g in Genres1: Genres2+="["+g+"] "; 
			if enMeta==True: 
				try: labs=grab.get_meta('tvshow',name); 
				except: pass
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			debob(labs); 
			#labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			#
			#plot+=CR+"Genres:  [COLOR purple]"+Genres2+"[/COLOR]"; #plot+="[CR]Year: [COLOR purple]"+year+"[/COLOR]"; plot+=" [COLOR black]|[/COLOR] Status: [COLOR purple]"+status+"[/COLOR]"; plot+=" [COLOR black]|[/COLOR] Episodes: [COLOR purple]"+NoEps+"[/COLOR]"; 
			pars={'mode':'ListEpisodes','url':url,'title':name,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site}; 
			labs[u'plot']=plot+CR+CR+cFL(labs[u'plot'],'tan'); labs[u'title']=cFL(name,'orange'); 
			labs[u'plot']=messupText(labs[u'plot'],True,True,True); labs[u'title']=messupText(labs[u'title'],True,True,True); 
			#Clabs=labs; 
			Clabs={'title':name,'year':labs[u'year'],'url':url,'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs); 
			#try: cMI=ContextMenu_Episodes(Clabs); 
			except: pass
			#labs[u'title']+=cFL(' ('+cFL(year,'orange')+') ['+cFL(NoEps,'blue')+']'+CR+'['+status+']','purple')
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	#set_view('episodes',view_mode=addst('episode-view')); eod()

def ListLatestShows(Url=mainSite):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	s='<div class=\'index_img_list\'><img src="(http://www.animefate.com/images/.+?-\d+x\d+.[jpg|png|gif]+)" alt=".+?" title=".+?" /></div>\s*<div class="blog-title">\s*\n*\s*'; 
	s+='<h2><a href="(http://www.animefate.com/series/.+?/)" title=".+? English Dubbed Anime"><strong>(.+?)</strong></a></h2>\s*\n*\s*<p class="small_post_info">Genres:(.+?)</p>\s*\n*\s*\n*\s*</div>'; 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for (img,url,name,genres) in matches:
			cMI=[]; img=img.replace(' ','%20'); fimg=fanartSite; deb('img',img); Genres2=""; g="<a href='http://www.animefate.com/.genre=.+?'>\s*(.+?)\s*</a>"; plot=""; labs={}; 
			try: Genres1=re.compile(g).findall(genres); debob(Genres1); 
			except: Genres1=""; 
			for g in Genres1: Genres2+="["+g+"] "; 
			if enMeta==True: 
				try: labs=grab.get_meta('tvshow',name); 
				except: pass
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			#labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			#
			plot+=CR+"Genres:  [COLOR purple]"+Genres2+"[/COLOR]"; #plot+="[CR]Year: [COLOR purple]"+year+"[/COLOR]"; plot+=" [COLOR black]|[/COLOR] Status: [COLOR purple]"+status+"[/COLOR]"; plot+=" [COLOR black]|[/COLOR] Episodes: [COLOR purple]"+NoEps+"[/COLOR]"; 
			pars={'mode':'ListEpisodes','url':url,'title':name,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site}; 
			labs[u'plot']=plot+CR+CR+cFL(labs[u'plot'],'tan'); labs[u'title']=cFL(name,'orange'); 
			labs[u'plot']=messupText(labs[u'plot'],True,True,True); labs[u'title']=messupText(labs[u'title'],True,True,True); 
			#Clabs=labs; 
			Clabs={'title':name,'year':labs[u'year'],'url':url,'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs); 
			#try: cMI=ContextMenu_Episodes(Clabs); 
			except: pass
			#labs[u'title']+=cFL(' ('+cFL(year,'orange')+') ['+cFL(NoEps,'blue')+']'+CR+'['+status+']','purple')
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	#set_view('episodes',view_mode=addst('episode-view')); eod()

def ListLatestEpisodes(Url=mainSite):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	s='<div class="blog-title">\s*\n*\s*<div class=\'index_img_list\'><img src="(http://www.animefate.com/images/.+?-\d*x\d*.[jpg|png|gif]+)" alt=".+?" title=".+?" /></div>\s*<h2><a href="(http://www.animefate.com/.+?/)"><strong>(.+?)</strong></a></h2>\s*\n*\s*'; 
	s+='<p class="small_post_info">Posted on: (.+?)</p>\s*\n*\s*<p class="small_post_info">Full Episodes List: <a href="(http://www.animefate.com/series/.+?/)" title="View all posts in .+?" rel="category tag">(.+?)</a>\s*</p>\s*\n*\s*</div>\s*\n*\s*<div class="clear"></div>'; 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for (img,url,name,datestamp,showUrl,showName) in matches:
			cMI=[]; img=img.replace(' ','%20'); fimg=fanartSite; deb('img',img); Genres2=""; g="<a href='http://www.animefate.com/.genre=.+?'>\s*(.+?)\s*</a>"; plot=""; labs={}; 
			#try: Genres1=re.compile(g).findall(genres); debob(Genres1); 
			#except: Genres1=""; 
			#for g in Genres1: Genres2+="["+g+"] "; 
			#Genres2=str(Genres1); 
			if enMeta==True: 
				try: labs=grab.get_meta('tvshow',showName); 
				except: pass
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			#labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			labs[u'title']=name; 
			#
			#plot+=CR+"Genres:  [COLOR purple]"+Genres2+"[/COLOR]"; plot+="[CR]Year: [COLOR purple]"+year+"[/COLOR]"; plot+=" [COLOR black]|[/COLOR] Status: [COLOR purple]"+status+"[/COLOR]"; plot+=" [COLOR black]|[/COLOR] Episodes: [COLOR purple]"+NoEps+"[/COLOR]"; 
			pars={'mode':'GetMedia','url':url,'title':name,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site}; 
			labs[u'plot']=plot+CR+CR+cFL(labs[u'plot'],'tan'); labs[u'title']=cFL(name,'blue'); 
			labs[u'plot']=messupText(labs[u'plot'],True,True,True); labs[u'title']=messupText(labs[u'title'],True,True,True); 
			#Clabs=labs; 
			Clabs={'title':name,'year':labs[u'year'],'url':url,'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			#try: cMI=ContextMenu_Series(Clabs); 
			try: cMI=ContextMenu_Episodes(Clabs); 
			except: pass
			#labs[u'title']+=cFL(' ('+cFL(year,'orange')+') ['+cFL(NoEps,'blue')+']'+CR+'['+status+']','purple')
			labs[u'title']+=CR+cFL('['+datestamp+']','purple'); 
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
			#
			
			
			labs[u'title']=showName; 
			pars={'mode':'ListEpisodes','url':showUrl,'title':name,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site}; 
			labs[u'title']=cFL(showName,'orange'); 
			try: cMI=ContextMenu_Series(Clabs); 
			except: pass
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
			
	#set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	set_view('episodes',view_mode=addst('episode-view')); eod()

def ListEpisodes(Url,title,imdb_id,img,fimg):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('imdb_id',imdb_id); deb('title',title); deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	s='<li>\s*\n*\s*<a href="(http://www.animefate.com/.+?/)" rel="bookmark" title=".+?">\s*\n*\s*<p class="episode_number">\s*(.+?)\s*</p>\s*\n*\s*<p title="Added on .+?" class="date_published">(.+?)</p>\s*\n*\s*</a>\s*\n*\s*<div class="clear"></div>\s*\n*\s*</li>'; 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		#for (url,img,name,genres,status,NoEps,year) in matches:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); n=False
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for (url,name,datestamp) in matches:
			name=name.replace(title,''); cMI=[]; labs={}; #labs['plot']=''; labs['plotoutline']=''; labs['showtitle']=''; labs['episodetitle']=''; labs['videoid']=''; 
			if "Episode " in name: 
				try: e=re.compile("Episode (\d+)").findall(name)[0]; 
				except: e=""; 
			else: e=""; 
			if enMeta==True:
				s='1'; 
				if len(e) > 0:
					try: labs=grab.get_episode_meta(tvshowtitle=title,imdb_id=imdb_id,season=s,episode=e,air_date='',episode_title='',overlay=6); 
					except: n=True;
					try:
						if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
					except: pass
					try:
						if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
					except: pass
				else: n=True; 
			else: n=True; 
			if n==True: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			if len(labs[u'title'])==0: labs[u'title']=name; 
			etitle=labs[u'title']; 
			if len(e) > 0:labs[u'title']=cFL(e+') ','blue')+cFL(labs[u'title'],'orange'); 
			else: labs[u'title']=cFL(labs[u'title'],'orange')
			labs[u'plot']=CR+labs[u'plot']; labs[u'title']+=CR+cFL("["+datestamp+"]",'purple'); 
			pars={'mode':'GetMedia','url':url,'title':name,'etitle':etitle,'stitle':title,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site}; 
			Clabs={'title':name,'year':'','url':url,'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Episodes(Clabs); 
			except: pass
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
	set_view('episodes',view_mode=addst('episode-view')); eod()

def ListShows(Url):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	#s='<div class=\'anime_list_info\'>\s*<a href="(http://www.animefate.com/series/.+?/)" title=".+? English Dubbed Anime">\s*\n*\s*<div class="info_list_cover">\s*\n*\s*'; #s+='<img src="(http://www.animefate.com/images/.+?-\d+x\d+.[jpg|png|gif]+)" alt=".+?" title=".+?" />\s*\n*\s*</div>\s*\n*\s*<div class="info_list_description">\s*\n*\s*'; #s+='<p class=\'anime_list_title\'><strong>(.+?)</strong></p></a><p><strong>Genres: </strong>(.+?)</p>'; #s+='<p><strong>Status: </strong><span class=\'.+?\'>\s*(\D+)\s*</span></p>'; #s+='<p><strong>No. of Episodes: </strong>\s*(\d*)\s*</p><p><strong>Released: </strong>\s*(\d*)\s*</p>\s*\n*\s*</div>\s*\n*\s*</div>'; 
	s="<div class='index_img_list'>"+'<img src="(http://www.animefate.com/images/.+?)" alt=".+?" title=".+?" /></div>'; s+='<li><div class="listupdate">'; s+="<h2><a href='(http://www.animefate.com/series/.+?/)'>(.+?)</a></h2>"; s+="<span><em>Genres: </em>(.+?)</span>"; s+='<div class="clear"></div></div></li>'; 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		#for (url,img,name,genres,status,NoEps,year) in matches:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for (img,url,name,genres) in matches:
			cMI=[]; img=img.replace(' ','%20'); fimg=fanartSite; deb('img',img); Genres2=""; g="<a href='http://www.animefate.com/.genre=.+?'>\s*(.+?)\s*</a>"; plot=""; labs={}; 
			try: Genres1=re.compile(g).findall(genres); debob(Genres1); 
			except: Genres1=""; 
			for g in Genres1: Genres2+="["+g+"] "; 
			#Genres2=str(Genres1); 
			if enMeta==True: 
				try: labs=grab.get_meta('tvshow',name); 
				except: pass
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			plot+=CR+"Genres:  [COLOR purple]"+Genres2+"[/COLOR]"; #plot+="[CR]Year: [COLOR purple]"+year+"[/COLOR]"; #plot+="[CR]Status: [COLOR purple]"+status+"[/COLOR]"; #plot+="[CR]Number of Episodes: [COLOR purple]"+NoEps+"[/COLOR]"; 
			pars={'mode':'ListEpisodes','url':url,'title':name,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site}; 
			labs[u'plot']=plot+CR+CR+cFL(labs[u'plot'],'tan'); labs[u'title']=cFL(name,'orange'); 
			#Clabs=labs; 
			Clabs={'title':name,'year':labs[u'year'],'url':url,'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs); 
			except: pass
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()

def ListShows2(Url):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	s='<div class=\'anime_list_info\s*[clear]*\'>\s*<a href="(http://www.animefate.com/series/.+?/)" title=".+? English Dubbed Anime">\s*\n*\s*<div class="info_list_cover">\s*\n*\s*'; s+='<img src="(http://www.animefate.com/images/.+?-\d+x\d+.[jpg|png|gif]+)" alt=".+?" title=".+?" />\s*\n*\s*</div>\s*\n*\s*<div class="info_list_description">\s*\n*\s*'; s+='<p class=\'anime_list_title\'><strong>(.+?)</strong></p></a><p><strong>Genres: </strong>(.+?)'; s+='<p><strong>Status: </strong><span class=\'.+?\'>\s*(\D+)\s*</span></p>'; s+='<p><strong>No. of Episodes: </strong>\s*(\d*)\s*</p><p><strong>Released: </strong>\s*(\d*)\s*</p>\s*\n*\s*</div>\s*\n*\s*</div>'; 
	#s='<div class=\'anime_list_info\'>\s*<a href="(http://www.animefate.com/series/.+?/)" title=".+? English Dubbed Anime">\s*\n*\s*<div class="info_list_cover">\s*\n*\s*'; s+='<img src="(http://www.animefate.com/images/.+?-\d+x\d+.[jpg|png|gif]+)" alt=".+?" title=".+?" />\s*\n*\s*</div>\s*\n*\s*<div class="info_list_description">\s*\n*\s*'; s+='<p class=\'anime_list_title\'><strong>(.+?)</strong></p></a><p><strong>Genres: </strong>(.+?)'; s+='<p><strong>Status: </strong><span class=\'.+?\'>\s*(\D+)\s*</span></p>'; s+='<p><strong>No. of Episodes: </strong>\s*(\d*)\s*</p><p><strong>Released: </strong>\s*(\d*)\s*</p>\s*\n*\s*</div>\s*\n*\s*</div>'; 
	#s="<div class='index_img_list'>"+'<img src="(http://www.animefate.com/images/.+?)" alt=".+?" title=".+?" /></div>'; s+='<li><div class="listupdate">'; s+="<h2><a href='(http://www.animefate.com/series/.+?/)'>(.+?)</a></h2>"; s+="<span><em>Genres: </em>(.+?)</span>"; s+='<div class="clear"></div></div></li>'; 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		#for (img,url,name,genres) in matches:
		for (url,img,name,genres,status,NoEps,year) in matches:
			cMI=[]; img=img.replace(' ','%20'); fimg=fanartSite; deb('img',img); Genres2=""; g="<a href='http://www.animefate.com/.genre=.+?'>\s*(.+?)\s*</a>"; plot=""; labs={}; 
			try: Genres1=re.compile(g).findall(genres); debob(Genres1); 
			except: Genres1=""; 
			for g in Genres1: Genres2+="["+g+"] "; 
			#Genres2=str(Genres1); 
			if enMeta==True: 
				try: labs=grab.get_meta('tvshow',name); 
				except: pass
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			plot+=CR+"Genres:  [COLOR purple]"+Genres2+"[/COLOR]"; 
			plot+="[CR]Year: [COLOR purple]"+year+"[/COLOR]"; 
			plot+=" [COLOR black]|[/COLOR] Status: [COLOR purple]"+status+"[/COLOR]"; 
			plot+=" [COLOR black]|[/COLOR] Episodes: [COLOR purple]"+NoEps+"[/COLOR]"; 
			pars={'mode':'ListEpisodes','url':url,'title':name,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site}; 
			labs[u'plot']=plot+CR+CR+cFL(labs[u'plot'],'tan'); labs[u'title']=cFL(name,'orange'); 
			labs[u'plot']=messupText(labs[u'plot'],True,True,True); labs[u'title']=messupText(labs[u'title'],True,True,True); 
			#Clabs=labs; 
			Clabs={'title':name,'year':labs[u'year'],'url':url,'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs); 
			except: pass
			labs[u'title']+=cFL(' ('+cFL(year,'orange')+') ['+cFL(NoEps,'blue')+']'+CR+'['+status+']','purple')
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()

def Fav_List(site='',section='',subfav=''):
	debob(['test1',site,section,subfav])
	favs=fav__COMMON__list_fetcher(site=site,section=section,subfav=subfav)
	ItemCount=len(favs)
	debob('test2 - '+str(ItemCount))
	if len(favs)==0: myNote('Favorites','None Found'); eod(); return
	debob(favs)
	for (_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2) in favs:
		if _img > 0: img=_img
		else: img=iconSite
		if _fanart > 0: fimg=_fanart
		else: fimg=fanartSite
		debob('_ToDoParams'); debob(_ToDoParams)
		pars=_addon.parse_query(_ToDoParams)
		debob('pars'); debob(pars)
		_title=cFL_(_name,'white')
		if (len(_year) > 0) and (not _year=='0000'): _title+=cFL('  ('+cFL(_year,'deeppink')+')','pink')
		if len(_Country) > 0: _title+=cFL('  ['+cFL(_Country,'deeppink')+']','pink')
		
		contextLabs={'title':_name,'year':_year,'img':_img,'fanart':_fanart,'country':_Country,'url':_Url,'plot':_plot,'genres':_Genres,'site':_site,'subfav':_subfav,'section':_section,'todoparams':_ToDoParams,'commonid':_commonID,'commonid2':_commonID2}
		##contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}
		contextMenuItems=ContextMenu_Favorites(contextLabs)
		#contextMenuItems=[]
		_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#
	#
	if 'movie' in section.lower(): content='movies'
	else: content='tvshows'
	set_view(content,view_mode=int(addst('tvshows-view'))); eod()


### ############################################################################################################
### ############################################################################################################
def MenuAZ():
	_addon.add_directory({'mode':'ListShows2','url':'/anime-list/?starting_char=all','site':site},{'title':cFL('ALL',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite); 
	_addon.add_directory({'mode':'ListShows2','url':'/anime-list/','site':site},{'title':cFL('#',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite); 
	for az in MyAlphabet:
		az=az.upper(); _addon.add_directory({'mode':'ListShows2','url':'/anime-list/?starting_char='+az,'site':site},{'title':cFL(az,colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite); 
	###
	# http://www.animefate.com/anime-list/?starting_char=all
	# http://www.animefate.com/anime-list/
	# http://www.animefate.com/anime-list/?starting_char=A
	###
	set_view('list',view_mode=addst('default-view')); eod()

def MenuGenre():
	for az in MyGenres: _addon.add_directory({'mode':'ListShows','url':'/?genre='+az.replace(' ','%20'),'site':site},{'title':cFL(az,colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite); 
	###
	# http://www.animefate.com/?genre=Slice%20of%20Life
	###
	set_view('list',view_mode=addst('default-view')); eod()

def SectionMenu():
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	#_addon.add_directory({'mode':'ListShows','site':site},{'title':cFL_('Cartoon List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'MenuAZ','site':site},{'title':cFL_('Anime List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'MenuGenre','site':site},{'title':cFL_('Genre List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListLatestEpisodes','site':site},{'title':cFL_('Latest Episodes',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListLatestShows','site':site},{'title':cFL_('Latest Series',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListPopularShows','site':site},{'title':cFL_('Popular Anime Series',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	
	#
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'3'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'4'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'5'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'6'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'7'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#
	###
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='NowPlaying'): 		NowPlaying()
	elif (mode=='ListAZ'): 				ListAZ()
	elif (mode=='List'): 					Browse_List(addpr('title',''))
	elif (mode=='DoRequest'): 		DoRequest(url,addpr('title',''))
	elif (mode=='ListShows'): 		ListShows(url)
	elif (mode=='ListShows2'): 		ListShows2(url)
	elif (mode=='ListEpisodes'): 	ListEpisodes(url,addpr('title',''),addpr('imdb_id',''),addpr('img',''),addpr('fimg',''))
	elif (mode=='ListLatestEpisodes'): ListLatestEpisodes()
	elif (mode=='ListLatestShows'): ListLatestShows()
	elif (mode=='ListPopularShows'): ListPopularShows()
	elif (mode=='GetMedia'): 			GetMedia(url,addpr('title',''),addpr('imdb_id',''),addpr('img',''),addpr('fimg',''),addpr('stitle',''),addpr('etitle',''))
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	#elif (mode=='Search'): 			Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	#elif (mode=='SearchLast'): 	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='SlideShowStart'): path = os.path.join(_addonPath, 'c_SlideShow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	elif (mode=='MenuAZ'): 				MenuAZ()
	elif (mode=='MenuGenre'): 		MenuGenre()
	elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
