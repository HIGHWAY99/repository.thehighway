### ############################################################################################################
###	#	
### # Site: 				#		iLiVE - http://www.iguide.to/
### # Author: 			#		The Highway
### # Description: 	#		
### # Credits: 			#		Originally ported from the addon project known as Mash Up - by Mash2k3 2012.
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import urllib,urllib2,re,cookielib,os,sys
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
#from resources.libs import main
from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart)
selfAddon=_plugin
#from universal import watchhistory
#wh=watchhistory.WatchHistory(ps('_addon_id'))
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR lime]i[COLOR white]GiUDE[/COLOR][/COLOR]  [v0.0.1]  [Streams] *'
SiteTag='iguide.to'
mainSite='http://www.iguide.to/'
iconSite=_artIcon
fanartSite=_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		m+=CR+CR+'Known Hosts for Videos:  '
		m+=CR+'RTMP Live Streams'
		m+=CR+CR+'Features:  '
		m+=CR+'* Includes my Increased List of Categories.  '
		m+='Those which often have no items are marked as such.  '
		m+='Some of My English Shortcuts are included as well.'
		m+=CR+'* Browse Live Channels.'
		m+=CR+'* Play Live Channels.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* Originally ported from ??\'s ??.'
		m+=CR+'* This Project has been given a major overhaul and been reworked to work with my own project\'s functions and methods.'
		#m+=CR+'* Checkout:  Try ?? @ ??\'s Repo.'
		#m+=CR+'* If you really enjoy these addons, please check out the originals'
		#m+=CR+'* Some -ORIGINALS- may or may not have stuff like GA-Tracking, Advertisements....'
		m+=CR+'* Some Sub-Addons may be outdated.  Please check their repos for the latest version of their Full-Fledge Addon(s).'
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

### ############################################################################################################
### ############################################################################################################

def getToken(url):
	html=net.http_GET(url).content
	token_url=re.compile('\$.getJSON\("(.+?)",').findall(html)[0]
	import datetime,time
	time_now=datetime.datetime.now()
	epoch=time.mktime(time_now.timetuple())+(time_now.microsecond/1000000.)
	epoch_str=str('%f' % epoch); epoch_str=epoch_str.replace('.',''); epoch_str=epoch_str[:-3]
	token_url=token_url + '&_=' + epoch_str
	#
	tokhtml=net.http_GET(token_url+'&_='+str(epoch), headers={'Referer':url}).content
	#debob('tokhtml: ')
	#debob(tokhtml)
	token=re.compile('":"(.+?)"').findall(tokhtml)[0]
	#token=re.compile('":"(.+?)"').findall(net.http_GET(token_url+'&_='+str(epoch), headers={'Referer':url}).content)[0]
	return token

def iLivePlay(mname,murl,thumb):
	myNote('Please Wait!','Opening Stream',3000); stream_url=False; link=nURL(murl); deb('murl',murl)
	if link:
		link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
		match=re.compile('http://www.iguide.to/embed/(.+?)&width=(.+?)&height=(.+?)&autoplay=true').findall(link)
		#debob(match)
		for fid,wid,hei in match: pageUrl='http://www.iguide.to/embedplayer.php?width='+wid+'&height='+hei+'&channel='+fid+'&autoplay=true'; debob(pageUrl)
		#debob(pageUrl)
		#link=nURL(pageUrl); playpath=re.compile('file: "(.+?).flv"').findall(link); token=getToken(pageUrl)
		link=nURL(pageUrl); playpath=re.compile('file\s*:\s*"(.+?)\.flv"').findall(link); token=getToken(pageUrl)
		#debob(playpath)
		if len(playpath)==0: playpath=re.compile('http://static.ilive.to/images/channels/(.+?)_snapshot.jpg').findall(thumb)
		#debob(playpath)
		#for playPath in playpath: debob(playPath); stream_url='rtmp://live.iguide.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.iguide.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		#for playPath in playpath: debob(playPath); stream_url='rtmp://live.iguide.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.iguide.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		for playPath in playpath: debob(playPath); stream_url='rtmp://da.iguide.to/iguide playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.iguide.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		#for playPath in playpath: debob(playPath); stream_url='rtmp://live.iguide.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.iguide.to/secure_player_ilive_z.swf pageUrl="+pageUrl+" token="+token
		#####for playPath in playpath: debob(playPath); stream_url='rtmp://live.iguide.to/edge playpath='+playPath+".flv live=1 timeout=15 swfUrl=http://player.iguide.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		#PlayItCustom(url=murl,stream_url=stream_url,img=thumb,title=mname)
		PlayItCustom(url=murl,stream_url=stream_url,img='http://static.ilive.to/images/channels/'+playPath+'_snapshot.jpg',title=mname)
		#

def iLiveList(mmurl):
	murl=mmurl.lower()
	if murl=='general':
		try: urllist=['http://www.iguide.to/channels/General','http://www.iguide.to/channels/General?p=2']
		except: urllist=['http://www.iguide.to/channels/General']
	if murl=='entertainment':
		try: urllist=['http://www.iguide.to/channels/Entertainment','http://www.iguide.to/channels/Entertainment?p=2','http://www.iguide.to/channels/Entertainment?p=3','http://www.iguide.to/channels/Entertainment?p=4','http://www.iguide.to/channels/Entertainment?p=5','http://www.iguide.to/channels/Entertainment?p=6']
		except: urllist=['http://www.iguide.to/channels/Entertainment','http://www.iguide.to/channels/Entertainment?p=2','http://www.iguide.to/channels/Entertainment?p=3','http://www.iguide.to/channels/Entertainment?p=4','http://www.iguide.to/channels/Entertainment?p=5']
	if murl=='sports':
		try: urllist=['http://www.iguide.to/channels/Sport','http://www.iguide.to/channels/Sport?p=2','http://www.iguide.to/channels/Sport?p=3','http://www.iguide.to/channels/Sport?p=4']
		except: urllist=['http://www.iguide.to/channels/Sport','http://www.iguide.to/channels/Sport?p=2','http://www.iguide.to/channels/Sport?p=3']
	if murl=='news':
		try: urllist=['http://www.iguide.to/channels/News']
		except: urllist=['http://www.iguide.to/channels/News']
	if murl=='music':
		try: urllist=['http://www.iguide.to/channels/Music']
		except: urllist=['http://www.iguide.to/channels/Music']
	if murl=='animation':
		try: urllist=['http://www.iguide.to/channels/Animation','http://www.iguide.to/channels/Animation?p=2']
		except: urllist=['http://www.iguide.to/channels/Animation']
	if murl=='family':
		try: urllist=['http://www.iguide.to/channels/Family']
		except: urllist=['http://www.iguide.to/channels/Family']
	if murl=='lifecaster':
		try: urllist=['http://www.iguide.to/channels/Lifecaster']
		except: urllist=['http://www.iguide.to/channels/Lifecaster']
	if murl=='gaming':
		try: urllist=['http://www.iguide.to/channels/Gaming']
		except: urllist=['http://www.iguide.to/channels/Gaming']
	if murl=='mobile':
		try: urllist=['http://www.iguide.to/channels/Mobile']
		except: urllist=['http://www.iguide.to/channels/Mobile']
	if murl=='religion':
		try: urllist=['http://www.iguide.to/channels/Religion']
		except: urllist=['http://www.iguide.to/channels/Religion']
	if murl=='radio':
		try: urllist=['http://www.iguide.to/channels/Radio']
		except: urllist=['http://www.iguide.to/channels/Radio']
	if murl=='all1':
		try: urllist=['http://www.iguide.to/channels','http://www.iguide.to/channels?p=2']
		except: urllist=['http://www.iguide.to/channels']
	if murl=='all0':
		try: urllist=['http://www.iguide.to/channels']
		except: urllist=['http://www.iguide.to/channels']
	if murl=='all':
		try: urllist=['http://www.iguide.to/channels','http://www.iguide.to/channels?p=2','http://www.iguide.to/channels?p=3','http://www.iguide.to/channels?p=4','http://www.iguide.to/channels?p=5','http://www.iguide.to/channels?p=6','http://www.iguide.to/channels?p=7','http://www.iguide.to/channels?p=8','http://www.iguide.to/channels?p=9','http://www.iguide.to/channels?p=10','http://www.iguide.to/channels?p=11','http://www.iguide.to/channels?p=12','http://www.iguide.to/channels?p=13','http://www.iguide.to/channels?p=14','http://www.iguide.to/channels?p=15','http://www.iguide.to/channels?p=16']
		except: urllist=['http://www.iguide.to/channels','http://www.iguide.to/channels?p=2','http://www.iguide.to/channels?p=3','http://www.iguide.to/channels?p=4','http://www.iguide.to/channels?p=5','http://www.iguide.to/channels?p=6','http://www.iguide.to/channels?p=7','http://www.iguide.to/channels?p=8','http://www.iguide.to/channels?p=9','http://www.iguide.to/channels?p=10']
	if murl=='allenglish':
		try: urllist=['http://www.iguide.to/channels?lang=1','http://www.iguide.to/channels?lang=1&p=2','http://www.iguide.to/channels?lang=1&p=3','http://www.iguide.to/channels?lang=1&p=4','http://www.iguide.to/channels?lang=1&p=5','http://www.iguide.to/channels?lang=1&p=6','http://www.iguide.to/channels?lang=1&p=7','http://www.iguide.to/channels?lang=1&p=8','http://www.iguide.to/channels?lang=1&p=9','http://www.iguide.to/channels?lang=1&p=10']
		except: urllist=['http://www.iguide.to/channels?lang=1','http://www.iguide.to/channels?lang=1&p=2','http://www.iguide.to/channels?lang=1&p=3','http://www.iguide.to/channels?lang=1&p=4','http://www.iguide.to/channels?lang=1&p=5','http://www.iguide.to/channels?lang=1&p=6','http://www.iguide.to/channels?lang=1&p=7','http://www.iguide.to/channels?lang=1&p=8','http://www.iguide.to/channels?lang=1&p=9']
	if murl=='entertainmentenglish':
		try: urllist=['http://www.iguide.to/channels/Entertainment?lang=1','http://www.iguide.to/channels/Entertainment?lang=1&p=2','http://www.iguide.to/channels/Entertainment?lang=1&p=3','http://www.iguide.to/channels/Entertainment?lang=1&p=4','http://www.iguide.to/channels/Entertainment?lang=1&p=5','http://www.iguide.to/channels/Entertainment?lang=1&p=6']
		except: urllist=['http://www.iguide.to/channels/Entertainment?lang=1','http://www.iguide.to/channels/Entertainment?lang=1&p=2','http://www.iguide.to/channels/Entertainment?lang=1&p=3','http://www.iguide.to/channels/Entertainment?lang=1&p=4','http://www.iguide.to/channels/Entertainment?lang=1&p=5']
	if murl=='sportsenglish':
		try: urllist=['http://www.iguide.to/channels/Sport?lang=1','http://www.iguide.to/channels/Sport?lang=1&p=2']
		except: urllist=['http://www.iguide.to/channels/Sport?lang=1']
	pLd='Pages loaded :: [B]'; loadedLinks=0; totalLinks=len(urllist); dialogWait=xbmcgui.DialogProgress()
	remaining_display=pLd+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'; ret=dialogWait.create('Please wait until channel list is loaded.')
	dialogWait.update(0,'[B]Loading.....[/B]',remaining_display)
	for durl in urllist:
		link=html=messupText(nURL(durl),True,True)
		link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
		debob(str(len(link)))
		#s='src=".+?" alt=".+?<img width=".+?" height=".+?" src="([^<]+)" alt=".+?"/></noscript></a><a href="(.+?)"><strong>(.+?)</strong></a><br/>.+?<a href="http://[A-Za-z0-9\.]*/channels\?lang=\d*">([A-Za-z]*)</a>'
		#s='src=".+?" alt=".+?\s*\n*\s*.*?<img width=".+?" height=".+?" src="([^<]+)" alt=".+?"\s*/>\s*\n*\s*</noscript>\s*\n*\s*.*?\s*\n*\s*</a>\s*\n*\s*<a href="(.+?)"><strong>\s*\n*\s*(.+?)\s*\n*\s*</strong>\s*\n*\s*</a>\s*\n*\s*<br/>'
		#s='<img width=".+?" height=".+?" src="([^<]+)" alt=".+?"\s*/>\s*\n*\s*</noscript>\s*\n*\s*.*?\s*\n*\s*</a>\s*\n*\s*<a href="(.+?)"><strong>\s*\n*\s*(.+?)\s*\n*\s*</strong>\s*\n*\s*</a>\s*\n*\s*<br/>'
		s='<noscript><img width="[0-9]*" height="[0-9]*" src="([^<]+)" alt=""/></noscript>\s*\n*\s*</a>\s*\n*\s*<a href="(.+?)"><strong>(.+?)</strong>'
		#
		match=re.compile(s).findall(link) ## From TheHighway
		#match=re.compile('src=".+?" alt=".+?<img width=".+?" height=".+?" src="([^<]+)" alt=".+?"/></noscript></a><a href="(.+?)"><strong>(.+?)</strong></a><br/>').findall(link) ## From MashUP
		#match=sorted(match, key=lambda item: item[2], reverse=False)
		#match=sorted(match, key=lambda item: item[3], reverse=False)
		debob(match)
		for thumb,url,name in match: #for thumb,url,name in match:
			#try: _addon.add_directory({'mode':'iLivePlay','site':site,'section':section,'title':name,'url':url,'fanart':thumb,'img':thumb},{'title':cFL_(name,colors['6'])},is_folder=False) #,fanart=thumb,img=thumb
			try: _addon.add_directory({'mode':'iLivePlay','site':site,'section':section,'title':name,'url':url,'fanart':thumb,'img':thumb},{'title':cFL_(name,colors['6'])},is_folder=False,fanart=thumb,img=thumb)
			except:
				try: _addon.add_directory({'mode':'iLivePlay','site':site,'section':section,'title':'[Unknown]','url':url,'fanart':thumb,'img':thumb},{'title':cFL_('[Unknown]',colors['6'])},is_folder=False,fanart=thumb,img=thumb)
				except: pass
			##match=re.compile('Hongkong').findall(name)
			##match2=re.compile('sex').findall(name)
			##if len(match)==0 and len(match2)==0:
			#	#if name != 'Playboy TV':
			#	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':name,'url':url},{'title':cFL_(name,colors['6'])},is_folder=True,fanart=thumb,img=thumb)
			#	#main.addPlayL(name+'  ['+lang+']',url,121,thumb,'','','','','') #main.addPlayL(name,url,121,thumb,'','','','','')
		#
		s='<noscript><img width="[0-9]*" height="[0-9]*" src="([^<]+)" alt=""/></noscript>\s*\n*\s*<span class="premium_only">Premium Only</span>\s*</a>\s*\n*\s*<a href="(.+?)"><strong>(.+?)</strong>'
		match=re.compile(s).findall(link) ## From TheHighway
		debob(match)
		for thumb,url,name in match: #for thumb,url,name in match:
			#try: _addon.add_directory({'mode':'iLivePlay','site':site,'section':section,'title':name,'url':url,'fanart':thumb,'img':thumb},{'title':cFL_(name,colors['6'])},is_folder=False) #,fanart=thumb,img=thumb
			try: _addon.add_directory({'mode':'iLivePlay','site':site,'section':section,'title':name,'url':url,'fanart':thumb,'img':thumb},{'title':cFL_(name+' *  (Premium Only)',colors['6'])},is_folder=False,fanart=thumb,img=thumb)
			except:
				try: _addon.add_directory({'mode':'iLivePlay','site':site,'section':section,'title':'[Unknown]','url':url,'fanart':thumb,'img':thumb},{'title':cFL_('[Unknown] *',colors['6'])},is_folder=False,fanart=thumb,img=thumb)
				except: pass
		loadedLinks=loadedLinks + 1; percent=(loadedLinks * 100)/totalLinks; remaining_display=pLd+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'; dialogWait.update(percent,'[B]Loading.....[/B]',remaining_display)
		if (dialogWait.iscanceled()): return False
	dialogWait.close(); del dialogWait
	set_view('list',view_mode=addst('default-view')); eod()

def SectionMenu(): #(site):
	sC1='section'; sC2='live'; iLL='iLiveList'; fS=fanartSite; iS=iconSite
	_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'all1'},{'title':cFL_('All (2 Pages)',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'allenglish'},{'title':cFL_('All [English]',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'entertainmentenglish'},{'title':cFL_('Entertainment [English]',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'sportsenglish'},{'title':cFL_('Sports [English]',colors['6'])},is_folder=True,fanart=fS,img=iS)
	_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'all'},{'title':cFL_('All',colors['6'])},is_folder=True,fanart=fS,img=iS)
	_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'General'},{'title':cFL_('General',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'Entertainment'},{'title':cFL_('Entertainment',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'Sports'},{'title':cFL_('Sports',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'News'},{'title':cFL_('News',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'Music'},{'title':cFL_('Music',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'Animation'},{'title':cFL_('Animation',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'Family'},{'title':cFL_('Family',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'lifecaster'},{'title':cFL_('Lifecaster (Often Empty)',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'gaming'},{'title':cFL_('Gaming (Often Empty)',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'mobile'},{'title':cFL_('Mobile (Often Empty)',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'religion'},{'title':cFL_('Religion (Often Empty)',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'radio'},{'title':cFL_('Radio (Often Empty)',colors['6'])},is_folder=True,fanart=fS,img=iS)
	##_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':''},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fS,img=iS)
	##_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':''},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fS,img=iS)
	
	##_addon.add_directory({'mode':'SubMenu','site':site,'section':'movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'SubMenu','site':site,'section':'series'},{'title':cFL_('Anime Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'ongoing-anime'},{'title':cFL_('Ongoing Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'new-anime'},{'title':cFL_('New Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'Episodes','site':site,'section':'series','url':mainSite+'surprise'},{'title':cFL_('Suprise Me',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	####if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site,'endit':'false'},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	#
	set_view('list',view_mode=addst('default-view')); eod()


### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='SubMenu'): 			SubMenu() #(site,section)
	elif (mode=='Page'): 					Browse_Page(url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='Episodes'): 			Browse_Episodes(url,page)
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='AZ'): 						Browse_AZ()
	elif (mode=='Genres'): 				Browse_Genres()
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='iLiveList'): 		iLiveList(addpr('title',''))
	elif (mode=='iLivePlay'): 		iLivePlay(addpr('title',''),url,thumbnail)
	### \/ Testing \/
	#elif (mode=='SearchLast'): 		
	#	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	#	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=True) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#
	#
	#
	#elif (mode=='FavList'): 			Fav_List(site,section)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
		
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
