### ############################################################################################################
###	#	
### # Site: 				#		CAST ALBA TV - http://castalba.tv/
### # Author: 			#		The Highway
### # Description: 	#		
### # Credits: 			#		Originally ported from the addon project known as Mash Up - by Mash2k3 2012.
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import urllib,urllib2,re,cookielib,os,sys
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
#from resources.libs import main
from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart)
selfAddon=_plugin
#from universal import watchhistory
#wh=watchhistory.WatchHistory(ps('_addon_id'))
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR cadetblue]CAST ALBA [COLOR white]TV[/COLOR][/COLOR]  [Streams]'
SiteTag='castalba.tv'
mainSite='http://castalba.tv/'
iconSite='http://castalba.tv/images/logo.gif' #_artIcon
fanartSite='http://castalba.tv/images/logo.gif' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		m+=CR+CR+'Known Hosts for Videos:  '
		m+=CR+'RTMP Live Streams'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Live Channels.'
		m+=CR+'* Play Live Channels.'
		m+=CR+CR+'Notes:  Some of these are teasers for Nice Addons which you can find on their own Repos.'
		m+=CR+'* Originally ported from mash2k3\'s Mash UP.'
		m+=CR+'* This Project has been given a major overhaul and been reworked to work with my own project\'s functions and methods.'
		m+=CR+'* Checkout:  Try the iLiVE, CAST ALBA TV, and the rest of Mash Up @ Mash2k3\'s Repo.'
		m+=CR+'* If you really enjoy these addons, please check out the originals'
		m+=CR+'* Some -ORIGINALS- may or may not have stuff like GA-Tracking, Advertisements....'
		m+=CR+'* Some Sub-Addons may be outdated.  Please check their repos for the latest version of their Full-Fledge Addon(s).'
		#m+=CR+'* '
		m+=CR+''
		m+=CR+'My XBMC-HUB Refferal Code - http://www.xbmchub.com/forums/register.php?referrerid=15468  '+CR+'Please use it to register if you don\'t have an account.  It not\'s not much but it can help me out.  '
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

### ############################################################################################################
### ############################################################################################################
def LivePlay(mname,murl,thumb):
	myNote('Please Wait!','Opening Stream',3000); stream_url=False; link=nURL(murl)
	if link:
		link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
		match=re.compile('<script type="text/javascript">\s*id="(.+?)";\s*ew="(.+?)";\s*eh="(.+?)";\s*</script>').findall(link)
		debob(match)
		for fid,wid,hei in match: pageUrl='http://castalba.tv/embed.php?cid='+fid+'&wh='+wid+'&ht='+hei; debob(pageUrl)
		link2=nURL(pageUrl)
		rtmp=re.compile("'streamer\':\s*\'(.+?)\',").findall(link2)
		swfUrl=re.compile('flashplayer\':\s*"(.+?)"').findall(link2)
		playPath=re.compile("'file\':\s*\'(.+?)\',\r\n\r\n\t\t\t\'streamer\'").findall(link2)
		stream_url=rtmp[0]+' playpath='+playPath[0]+' swfUrl='+swfUrl[0]+' live=true timeout=15 swfVfy=true pageUrl='+pageUrl
		debob(stream_url)
		PlayItCustom(url=murl,stream_url=stream_url,img=thumb,title=mname)

def LiveList(mmurl):
	murl=mmurl.lower()
	try:    urllist=['http://castalba.tv/channels/p=1','http://castalba.tv/channels/p=2']
	except: urllist=['http://castalba.tv/channels/p=1']
	pLd='Pages loaded :: [B]'; loadedLinks=0; totalLinks=len(urllist); dialogWait=xbmcgui.DialogProgress()
	remaining_display=pLd+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'; ret=dialogWait.create('Please wait until channel list is loaded.')
	dialogWait.update(0,'[B]Loading.....[/B]',remaining_display)
	for durl in urllist:
		link=html=nURL(durl)
		link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
		match=re.compile('<li><div class="vediodiv"><a href=".+?"><img src="../(images/.+?.jpg)" alt=""/><span class="time">.+?</span></a><a href=".+?" class="addtoplaylist"><img src=".+?" alt=""/></a></div><div class="clear"></div><h4><a class="colr2" href="../(channel/.+?)">(.+?)</a></h4><p class="by">In: <a href="../channels/.+?" class="undrlne">(.+?)</a></p></li>').findall(link)
		#match=sorted(match, key=lambda item: item[2], reverse=False)
		#match=sorted(match, key=lambda item: item[3], reverse=False)
		#debob(match)
		#debob(link)
		#for thumb,url,name,lang in match: #for thumb,url,name in match:
		for thumb,url,name,cat in match:
			thumb=mainSite+thumb; url=mainSite+url
			_addon.add_directory({'mode':'LivePlay','site':site,'section':section,'title':name,'url':url,'fanart':thumb,'img':thumb},{'title':cFL_(name,colors['6'])+'  ['+cFL(cat,colors['6'])+']'},is_folder=False,fanart=thumb,img=thumb)
			##match=re.compile('Hongkong').findall(name)
			##match2=re.compile('sex').findall(name)
			##if len(match)==0 and len(match2)==0:
			#	#if name != 'Playboy TV':
			#	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':name,'url':url},{'title':cFL_(name,colors['6'])},is_folder=True,fanart=thumb,img=thumb)
			#	#main.addPlayL(name+'  ['+lang+']',url,121,thumb,'','','','','') #main.addPlayL(name,url,121,thumb,'','','','','')
		loadedLinks=loadedLinks + 1; percent=(loadedLinks * 100)/totalLinks; remaining_display=pLd+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'; dialogWait.update(percent,'[B]Loading.....[/B]',remaining_display)
		if (dialogWait.iscanceled()): return False
	dialogWait.close(); del dialogWait
	set_view('list',view_mode=addst('default-view')); eod()

def SectionMenu(): #(site):
	sC1='section'; sC2='live'; iLL='LiveList'; fS=fanartSite; iS=iconSite
	_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':'All'},{'title':cFL_('All',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':''},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fS,img=iS)
	#_addon.add_directory({'mode':iLL,'site':site,sC1:sC2,'title':''},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fS,img=iS)
	
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'series'},{'title':cFL_('Anime Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'ongoing-anime'},{'title':cFL_('Ongoing Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'new-anime'},{'title':cFL_('New Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Episodes','site':site,'section':'series','url':mainSite+'surprise'},{'title':cFL_('Suprise Me',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	###if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site,'endit':'false'},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	#
	set_view('list',view_mode=addst('default-view')); eod()


### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='SubMenu'): 			SubMenu() #(site,section)
	elif (mode=='Page'): 					Browse_Page(url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='Episodes'): 			Browse_Episodes(url,page)
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='AZ'): 						Browse_AZ()
	elif (mode=='Genres'): 				Browse_Genres()
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='LiveList'): 			LiveList(addpr('title',''))
	elif (mode=='LivePlay'): 			LivePlay(addpr('title',''),url,thumbnail)
	### \/ Testing \/
	#elif (mode=='SearchLast'): 		
	#	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	#	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=True) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#
	#
	#
	#elif (mode=='FavList'): 			Fav_List(site,section)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
		
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
