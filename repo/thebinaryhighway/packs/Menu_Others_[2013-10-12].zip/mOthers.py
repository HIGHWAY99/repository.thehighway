### ############################################################################################################
###	#	
### # Project: 			#		? - by The Highway 2013.
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re

from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_OpenFile)

### ############################################################################################################
### ############################################################################################################
SiteName='Others'
SiteTag=''
mainSite=''
iconSite='http://media.lifehealthpro.com/lifehealthpro/article/2012/04/13/SocialMediaHighway-resize-380x300.JPG' #_artIcon
fanartSite='http://i.imgur.com/N8TFtcq.jpg' #'http://i.imgur.com/UtL1F8j.png' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}
collartag='v'

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+''
		#m+=CR+CR+'Valid Folders:  '
		#m+=CR+''
		m+=CR+CR+'Features:  '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+CR+'Notes:  Some of these are teasers for Nice Addons which you can find on their own Repos.'
		#m+=CR+'* Checkout:  MerDB.ru @ The Highway\'s Repo [XBMCHUB.com]'
		#m+=CR+'* Checkout:  Single[COLOR red]Link[/COLOR]Moviez @ TheYid\'s Repo (tcz009) [XBMCHUB.com].  Also try some other great addons by TheYid such as 1-LinkMovies and Ultra-Vid.'
		m+=CR+'* Checkout:  WWE Online @ the-one\'s Repo.  The Initial attempt to PORT this addon caused a break somewhere preventing me from being able to play the videos.  For now you can use this to browse, but to play the vidoes you may consider downloading the Full-Fledge addon from it\'s original author\'s Repo.'
		#m+=CR+CR+''
		m+=CR+'* If you really enjoy these addons, please check out the originals'
		m+=CR+'* Some -ORIGINALS- may or may not have stuff like GA-Tracking, Advertisements....'
		m+=CR+'* Some Sub-Addons may be outdated.  Please check their repos for the latest version of their Full-Fledge Addon(s).'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+'My XBMC-HUB Refferal Code - http://www.xbmchub.com/forums/register.php?referrerid=15468  '+CR+'Please use it to register if you don\'t have an account.  It not\'s not much but it can help me out.  '
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

### ############################################################################################################
### ############################################################################################################










### ############################################################################################################
### ############################################################################################################

def Menu_CustomMenu():
	#AnimeGet
	#Anime44
	#AnimePlus
	#AnimeZone
	#DubbedAnimeOn
	#DubHappy.eu
	#WatchDub
	#GoodDrama
	#
	#
	cNumber ='8'
	cNumber2='2'
	cNumber3='4'
	##_addon.add_directory({'mode':'SectionMenu','site':'AnimeGet'},{'title':cFL_('AnimeGet',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	##_addon.add_directory({'mode':'SectionMenu','site':'Anime44'},{'title':cFL_('Anime44',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	##_addon.add_directory({'mode':'SectionMenu','site':'AnimePlus'},{'title':cFL_('AnimePlus *',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	##_addon.add_directory({'mode':'SectionMenu','site':'AnimeZone'},{'title':cFL_('AnimeZone *',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	##_addon.add_directory({'mode':'SectionMenu','site':'DubbedAnimeOn'},{'title':cFL_('DubbedAnimeOn *',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	##_addon.add_directory({'mode':'SectionMenu','site':'DubHappyeu'},{'title':cFL_('DubHappy.eu *',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	##_addon.add_directory({'mode':'SectionMenu','site':'WatchDub'},{'title':cFL_('WatchDub *',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	#_addon.add_directory({'mode':'SectionMenu','site':'GoodDrama'},{'title':cFL_('GoodDrama *',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	#_addon.add_directory({'mode':'SectionMenu','site':'iLiveTo'},{'title':cFL_('iLiveTo',colors[cNumber])},is_folder=True,fanart=_artFanart,img=_artIcon)
	#
	for root, d, names in os.walk(_addonPath):
		if root==_addonPath:
			#deb('root',root); deb('dir',str(len(d))) #; debob(names)
			for filename in names:
				fe=getFileExtension(filename); fullF=xbmc.translatePath(os.path.join(root,filename))
				if (filename[:1]==collartag) and (fe=='py') and (isFile(fullF)==True):
					pyName=filename[:-3]
					tt=_OpenFile(fullF)
					try: 
						if   "SiteName='" in tt: pyTitle=re.compile("SiteName='(.+?)'").findall(tt)[0]
						elif 'SiteName="' in tt: pyTitle=re.compile('SiteName="(.+?)"').findall(tt)[0]
						elif "SiteName = '" in tt: pyTitle=re.compile("SiteName = '(.+?)'").findall(tt)[0]
						elif 'SiteName = "' in tt: pyTitle=re.compile('SiteName = "(.+?)"').findall(tt)[0]
						else: pyTitle=filename[1:-3]
					except: pyTitle=filename[1:-3]
					try: 
						if   "iconSite='" in tt: img=re.compile("iconSite='(.+?)'").findall(tt)[0]
						elif 'iconSite="' in tt: img=re.compile('iconSite="(.+?)"').findall(tt)[0]
						elif "iconSite = '" in tt: img=re.compile("iconSite = '(.+?)'").findall(tt)[0]
						elif 'iconSite = "' in tt: img=re.compile('iconSite = "(.+?)"').findall(tt)[0]
						else: img=_artIcon
					except: img=_artIcon
					try: 
						if   "fanartSite='" in tt: fimg=re.compile("fanartSite='(.+?)'").findall(tt)[0]
						elif 'fanartSite="' in tt: fimg=re.compile('fanartSite="(.+?)"').findall(tt)[0]
						elif "fanartSite = '" in tt: fimg=re.compile("fanartSite = '(.+?)'").findall(tt)[0]
						elif 'fanartSite = "' in tt: fimg=re.compile('fanartSite = "(.+?)"').findall(tt)[0]
						else: fimg=_artFanart
					except: fimg=_artFanart
					if pyTitle[:1] is not '[': pyTitle=cFL_(pyTitle,colors[cNumber])
					_addon.add_directory({'mode':'SectionMenu','site':pyName},{'title':pyTitle+ps('filemarker')},is_folder=True,fanart=fimg,img=img)
	#
	#
	#
	#
	#_addon.add_directory({'mode':'TextBoxFile','url':xbmc.translatePath(os.path.join(_addonPath,'resources','urlresolver','list.txt')),'title':cFL('My list.txt for (UrlResolver) related information.',colors['9'])},{'title':cFL_('List.txt [Local]',colors[cNumber2])},is_folder=False,fanart=_artFanart,img=_artIcon)
	#_addon.add_directory({'mode':'TextBoxFile','url':xbmc.translatePath(os.path.join(_addonPath,'changelog.txt')),'title':cFL('ChangeLog',colors['9'])},{'title':cFL_('ChangeLog  [Local]',colors[cNumber2])},is_folder=False,fanart=_artFanart,img=_artIcon)
	#_addon.add_directory({'mode':'Settings'}, 			 {'title':  cFL_('Plugin Settings',colors[cNumber2])}			,is_folder=False,img=_artIcon,fanart=_artFanart)
	#_addon.add_directory({'mode':'ResolverSettings'},{'title':  cFL_('Url-Resolver Settings',colors[cNumber3])},is_folder=False,img=_artIcon,fanart=_artFanart)
	#_addon.add_directory({'mode':'ResolverUpdateHostFiles'},{'title':  cFL_('Url-Resolver Update Host Files',colors[cNumber3])},is_folder=False,img=_artIcon,fanart=_artFanart)
	#
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	eod()

### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='main') or (mode=='') or (mode=='SectionMenu'): 		Menu_CustomMenu()
	elif (mode=='About'): 				About()
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
	
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))

#Menu_CustomMenu()
### ############################################################################################################
### ############################################################################################################
