### ############################################################################################################
###	#	
### # Project: 			#		? - by The Highway 2013.
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re

from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_OpenFile)

### ############################################################################################################
### ############################################################################################################
SiteName='Sports'
SiteTag=''
mainSite=''
iconSite='' #_artIcon
fanartSite='' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}
collartag='r'

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+''
		#m+=CR+CR+'Valid Folders:  '
		#m+=CR+''
		m+=CR+CR+'Features:  '
		#m+=CR+'* '
		#m+=CR+'* '
		#m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+'My XBMC-HUB Refferal Code - http://www.xbmchub.com/forums/register.php?referrerid=15468  '+CR+'Please use it to register if you don\'t have an account.  It not\'s not much but it can help me out.  '
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

### ############################################################################################################
### ############################################################################################################

def Menu_CustomMenu():
	cNumber ='8'; cNumber2='2'; cNumber3='4'; cNumber4='9'
	for root, d, names in os.walk(_addonPath):
		if root==_addonPath:
			#deb('root',root); deb('dir',str(len(d))) #; debob(names)
			for filename in names:
				fe=getFileExtension(filename); fullF=xbmc.translatePath(os.path.join(root,filename))
				if (filename[:1]==collartag) and (fe=='py') and (isFile(fullF)==True):
					pyName=filename[:-3]; tt=_OpenFile(fullF)
					try: 
						if   "SiteName='" in tt: pyTitle=re.compile("SiteName='(.+?)'").findall(tt)[0]
						elif 'SiteName="' in tt: pyTitle=re.compile('SiteName="(.+?)"').findall(tt)[0]
						elif "SiteName = '" in tt: pyTitle=re.compile("SiteName = '(.+?)'").findall(tt)[0]
						elif 'SiteName = "' in tt: pyTitle=re.compile('SiteName = "(.+?)"').findall(tt)[0]
						else: pyTitle=filename[1:-3]
					except: pyTitle=filename[1:-3]
					try: 
						if   "iconSite='" in tt: img=re.compile("iconSite='(.+?)'").findall(tt)[0]
						elif 'iconSite="' in tt: img=re.compile('iconSite="(.+?)"').findall(tt)[0]
						elif "iconSite = '" in tt: img=re.compile("iconSite = '(.+?)'").findall(tt)[0]
						elif 'iconSite = "' in tt: img=re.compile('iconSite = "(.+?)"').findall(tt)[0]
						else: img=_artIcon
					except: img=_artIcon
					try: 
						if   "fanartSite='" in tt: fimg=re.compile("fanartSite='(.+?)'").findall(tt)[0]
						elif 'fanartSite="' in tt: fimg=re.compile('fanartSite="(.+?)"').findall(tt)[0]
						elif "fanartSite = '" in tt: fimg=re.compile("fanartSite = '(.+?)'").findall(tt)[0]
						elif 'fanartSite = "' in tt: fimg=re.compile('fanartSite = "(.+?)"').findall(tt)[0]
						else: fimg=_artFanart
					except: fimg=_artFanart
					if pyTitle[:1] is not '[': pyTitle=cFL_(pyTitle,colors['0'])
					_addon.add_directory({'mode':'SectionMenu','site':pyName},{'title':pyTitle+ps('filemarker')},is_folder=True,fanart=fimg,img=img)
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	eod()

### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		Menu_CustomMenu()
	elif (mode=='About'): 				About()
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
	
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
