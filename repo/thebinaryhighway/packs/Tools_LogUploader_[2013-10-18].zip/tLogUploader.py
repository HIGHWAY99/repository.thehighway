### ############################################################################################################
###	#	
### # Project: 			#		Url Tester
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import common
from common import *
from common import (_debugging,_addon,_artIcon,_artFanart,_addonPath,_OpenFile,isPath,isFile,popYN,_SaveFile,popOK,CopyAFile,RefreshList,DownloadThis,getFileExtension)
### ############################################################################################################
### ############################################################################################################
SiteName='Log Uploader  (v0.0.1)  [Player Tool]'
SiteTag='Log Uploader Tool'
mainSite=''
iconSite='http://tny.cz/public/images/logo.png' #_artIcon
fanartSite='http://tny.cz/public/images/bg.png' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

#workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources'))
#workingFile='UrlTester.txt'
#workingFileWP=xbmc.translatePath(os.path.join(workingPath,workingFile))
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		#m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+''
		m+=CR+CR+'Features:  '
		m+=CR+'* Right Click Menu Access @ About or Url(s).'
		m+=CR+'* Menu Items: Add Url | Remove Url'
		m+=CR+'* Extra:  If you got the addon\'s Debugging to file setting turned on, you can view an Add Url link in the menu as well.'
		m+=CR+'* Attempt to Play the Url(s) that you supply.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* This tool is still being worked on, so things may not be perfect yet.'
		m+=CR+'* This tool is mainly meant to help devs check links to see if they\'re playable or not.'
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
### ############################################################################################################
### ############################################################################################################
def UploadItTNYcz(url):
	dd=_OpenFile(url); deb('opened file for uploading',url); deb('length of opened file',str(len(dd))); 
	if len(dd)==0: eod(); return
	html1=nURL('http://tny.cz/'); deb('length of html',str(len(html1))); 
	try: _timestamp=re.compile("<input type=hidden name=timestamp value='(.+?)'>").findall(html1)[0]
	except: _timestamp=''
	deb('timestamp from tny.cz',_timestamp)
	if len(_timestamp)==0: eod(); return
	html=messupText(nURL('http://tny.cz/index.php?act=submit',method='post',form_data={'subdomain':'','antispam':'1','website':'','paste_title':'','timestamp':_timestamp,'input_text':dd,'paste_password':'xbmc','codeSyntax':'0','code':'0'},headers={'Referer':'http://tny.cz/'}),True,True,True); deb('length of html',str(len(html))); 
	try: _url=re.compile('<a href="(http://.+?)">Paste submitted successfully').findall(html)[0]
	except: _url='';
	if len(_url)==0: 
		_SaveFile(TPap('temp','.html'),html)
		try: debob(html)
		except: pass
		myNote('Error','could not catch url sucessfully.'); eod(); return
	else:
		_addon.add_directory({'mode':'SectionMenu','site':site,'section':section},{'title':cFL_('Paste Submitted successfully!',colors['0'])},is_folder=True,fanart=fanartSite,img='http://tny.cz/public/images/successfullheader.png')
		_addon.add_directory({'mode':'SectionMenu','site':site,'section':section},{'title':cFL_(_url,colors['6'])},is_folder=True,fanart=fanartSite,img='http://tny.cz/public/images/logo.png')
		t=showkeyboard(txtMessage=_url,txtHeader="Remember this URL (Password is 'xbmc')")
	eod()
### ############################################################################################################
### ############################################################################################################
def TP(s): return xbmc.translatePath(s)
def TPap(s,fe='.py'): return xbmc.translatePath(os.path.join(_addonPath,s+fe))
def SectionMenu():
	s=[]; cNumber ='8'; cNumber2='2'; cNumber3='0'; cNumber4='9'; cNumber5='6'
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	s.append(('XBMC.log',xbmc.translatePath(os.path.join("special://logpath","xbmc.log")),fanartSite,iconSite))
	s.append(('XBMC.old.log',xbmc.translatePath(os.path.join("special://logpath","xbmc.old.log")),fanartSite,iconSite))
	for sT,sU,sF,sI in s:
		if isFile(sU)==True:
			_addon.add_directory({'site':site,'mode':'UploadItTNYcz','url':sU},{'title':cFL_(''+sT+'',colors[cNumber5])},is_folder=True,fanart=sF,img=sI)
	eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	#elif (mode=='AddUrlToList'): 	AddUrlToList(url=url)
	#elif (mode=='RemoveUrlToList'): 	RemoveUrlToList(url=url)
	elif (mode=='About'): 				About()
	#elif (mode=='CustomUpdate'): 	Update_CustomUpdate(addpr('path',''),addpr('filename',''))
	elif (mode=='UploadItTNYcz'): UploadItTNYcz(url)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
