### ############################################################################################################
###	#	
### # Site: 				#		!!Name of the Site this addon is made to handle!! - http://www. !!url for the site this addon is made to handle!! /
### # Author: 			#		!!A nickname you want to be known by!!
### # Description: 	#		!!Any kind of description of what this addon is for!!
### # Credits: 			#		!!For any credits you may want to add (Example: The Highway)!!
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import common
from common import *
###                       \/ You may sometimes need to add more to this for variables used in common.py.  Functions won't need to be there but i've put some of them there anyways.
from common import (_debugging,_addon,_artIcon,_artFanart,_addonPath,_OpenFile,isPath,isFile,popYN,_SaveFile,popOK,CopyAFile,RefreshList,DownloadThis,getFileExtension)
### ############################################################################################################
### ############################################################################################################
SiteName='Example (v0.0.1)  [Example]' ## SiteName='Text to appear on menu in xbmc.  Name your Sub-Addon here.  Please include a (v#.#.#) version number and a [tag] to describe what type of addon it is. 1 [CR] can be used to make use of the optional 2nd line (3rd lines dont show up).  other coding like [B] [I] or [COLOR red] canbe usedd to with their [/B] slash ending type included as well for each.' ##
SiteTag='An Example for new Devs' ## Not really important at this time ##
mainSite='' ## The common url used for the main site being handled if you want to re-use it later to make it easier to fix if they change domains. ##
iconSite=_artIcon  ## ='http://url......' ## Used to set the common image used within this a Sub-Addon as well as what's used for it on the Menu.  If not set, it'll use that menu's default image. ##
fanartSite=_artFanart ## ='http://url......' ## Used to set the common image used within this a Sub-Addon as well as what's used for it on the Menu. ##
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'} ## just some common colors that I often use and ocassionally add to. ##

CR='[CR]'  ## next line / line return shortcut ##
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'] ## a-z alphabet ##
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'] ## User-Agent string for browser usage ##

workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources'))  ## Sometimes I have reason to use a working path. ##
workingFile='_.txt' ## Sometimes I have use for a working file. ##
workingFileWP=xbmc.translatePath(os.path.join(workingPath,workingFile)) ## Working file's filename with workingpath's path included. ##
### ############################################################################################################
### ############################################################################################################
## Just some common variables being set. ##
## 'site' being used to carry things back to this Sub-Addon, make sure to include it in almost all menu items / links. ##
site=addpr('site',''); section=addpr('section',''); url=addpr('url',''); thumbnail=addpr('img',''); fanart=addpr('fanart',''); page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
## About Window that I try to have in most Sub-Addons to get accross any useful information. ##
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'... | ... | ... | ...'
		m+=CR+CR+'Features:  '
		m+=CR+'* '
		m+=CR+'* '
		m+=CR+'* '
		m+=CR+'* '
		m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg') ## << My XBMC HUB Forum Code and Message to get credit for Referring other to the forum. ##
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
def TP(s): return xbmc.translatePath(s)
def TPap(s,fe='.py'): return xbmc.translatePath(os.path.join(_addonPath,s+fe))
### ############################################################################################################
### ############################################################################################################

## Any Misc. functions used for this Sub-Addon.







### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	#
	
	## Add some Menu Items. ##
	## Make sure to set is_folder=True when adding a directory to the menu that goes to another menu.  Set to False if its going to Play a Video or such. ##
	## Make sure to also have { 'site':site in the params } so you'll be taken back to this Sub-Addon. ##
	_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	## One of many ways to play a video with from a direct link. ##
	_addon.add_directory({'url':'http://url...to...video/...file.flv','mode':'PlayURL','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	
	
	#
	## About window that I try to have in most Sub-Addons ##
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	eod() ## eod() is my function that does the code which tells XBMC to print the menu. ##
	## \/ I usually use a set_view() function in other functions / menus for either list movies tvshows seasons or episodes and the such. ##
	## set_view('list',view_mode=addst('default-view')); eod() ##

### ############################################################################################################
### ############################################################################################################
## This function handles forwarding the mode param message code and directing the sub-addon to wherever it needs to go... like a GO-TO-Function command. ##
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() ## The Binary Highway usually sends 'SectionMenu' as the mode when initially calling the sub-addon.  is also good to use:  or (mode=='') or (mode=='main') ##
	#
	#elif (mode=='NameYourMode'): 	NameYourFuction(url=url,addpr('title',''),addpr('img',''))
	#
	#
	#
	#
	elif (mode=='About'): 				About()  ## In most of my Sub-Addons. ##
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain  ## If a mode can not be found ##
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
