### ############################################################################################################
###	#	
### # Site: 				#		TheDareRadio - http://www.thedarewall.com/mp3/radio.php
### # Author: 			#		The Highway
### # Description: 	#		
### # Credits: 			#		Originally ported from the addon project known as The Dare TV - The_Silencer and The Highway 2013.
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import urllib,urllib2,re,cookielib,os,sys
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
#from resources.libs import main
from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart)
selfAddon=_plugin
#from universal import watchhistory
#wh=watchhistory.WatchHistory(ps('_addon_id'))
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR white]The Dare [COLOR orange]Radio[/COLOR][/COLOR]  [v0.0.1]  [Radio] * (List @ Site Broken)'
SiteTag='thedarewall.com'
mainSite='http://www.thedarewall.com/'
iconSite='http://www.thedarewall.com/mp3/images/bgcont.png' #_artIcon
#	#
#	#
fanartSite='http://www.thedarewall.com/mp3/images/bg.png' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch (listen to) the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'RTMP Live Streams'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Categories.  '
		m+=CR+'* Browse Radio Stations.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* Last I saw they were having troubles diplaying the radio stations [2013-10-02]'
		m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
### ############################################################################################################
### ############################################################################################################
##### Browse Radio Stations #####
def RadioStations(url): ### mode=301
	html=nURL(url)
	s='>\s*<span\s+id="radiop">\s*</span>\s*&nbsp;\s*(.+?)</div>\';[\n]'+"\s*var\s+so\s+=\s+new\s+SWFObject\('http.+?.swf','\D+','\d+','\d+','\d+','#\d+'\);[\n]\s*so.addParam\('.+?'\s*,\s*'.+?'\);[\n]\s*so.addParam\('.+?'\s*,\s*'.+?'\);[\n]\s*so.addParam\('.+?'\s*,\s*'.+?'\);[\n]\s*so.addVariable\('src'\s*,\s*'(.+?)'\)"
	matches=re.compile(s).findall(html)
	if (not matches): eod(); return
	ItemCount=len(matches)
	for name, path in matches:
		try:		img=re.compile('<img src="(http://.+?)" alt="'+name+'"').findall(html)[0]
		except:	img=iconSite
		labs={'title':name}; pars={'mode':'PlayURL','site':site,'section':section,'url':path}
		contextMenuItems=[]; 
		#contextMenuItems.append(('Download', ''))
		addon.add_directory(pars, labs, img=img, contextmenu_items=contextMenuItems, total_items=ItemCount)
	set_view('list'); eod()
##### /\ ##### Browse Radio Stations #####
### ############################################################################################################
### ############################################################################################################
def SectionMenu(): #(site):
	fS=fanartSite; iS=iconSite
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	prefix='http://www.thedarewall.com/mp3/radio.php'
	html=nURL('http://www.thedarewall.com/mp3/radio.php'); s='<div\s+id="tabtop"\s+style="background:\s*#282828;">\s*<a\s+href="(\?genre=.+?)">(.+?)</a>\s*</div>' ## works
	matches=re.compile(s).findall(html)
	if (not matches): eod(); return
	ItemCount=len(matches)
	for path, name in matches:
		labs={'title':name}; pars={'mode':'RadioStations','site':site,'section':section,'url':prefix+path}
		contextMenuItems=[]; 
		addon.add_directory(pars,labs,fanart=fanartSite,img=iconSite,contextmenu_items=contextMenuItems,total_items=ItemCount)
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='RadioStations'): RadioStations(addpr('title',''))
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#elif (mode=='FavList'): 			Fav_List(site,section)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
