### ############################################################################################################
###	#	
### # Site: 				#		Navi Xtreme - http://www.navixtreme.com/
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re,urllib

from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart,PlayItCustom,_addonPath,_OpenFile,isPath,isFile,addstv,addst,_debugging)
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR lime]Navi[/COLOR]-[COLOR white]Xtreme[/COLOR]  [v0.0.2]  [Streams] * (Pro Users|Others be careful)[CR](Pleanty to watch.  Browse/Search and use your head)'
SiteTag='navixtreme.com'
mainSite='http://www.navixtreme.com/'
iconSite='http://media.navi-x.org/images/logos/viewed.png' #'http://media.navi-x.org/images/header.jpg'
fanartSite='http://media.navi-x.org/images/backgrounds/bkg_navix_bh_plain.jpg' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources'))
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		m+=CR+CR+'Known Hosts for Videos:  '
		m+=CR+'RTMP Streams | RTSP Streams | MMS Streams | .FLV | .MP4'
		m+=CR+CR+'Features:  '
		m+=CR+'* Ability to play "some" video streams / files.'
		m+=CR+'* Browse sort of ini-like playlist pages.'
		m+=CR+'* Results:  If result\'s type is playlist it\'ll send back to the same function.  If the type is video, it\'ll send the url to the common PlayURL function.'
		m+=CR+'* Search - Play around with it to get what results you can.'
		m+=CR+'* Repeat Last Search - Like it says, this shows up once you\'ve done a Search for the first time and allows you to repeat the last search term you used for this Site.  Yes, it\'s setup to save the setting for each site seperately.'
		m+=CR+'* Play - Tries MSS|MSSH|RTSP via a STRM file. Tries HTTP via url resolver before playing directly. Others like RTMP|RTMPE it tries to play directly.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* These Links are VERY unstable, so expect many problems with them, even xbmc freezing at times.'
		m+=CR+'* I\'d suggest not using MMS:// and RTSP:// links for now.'
		m+=CR+'* Several of the RTMP links as well won\'t play, but hopefully wont cause XBMC to stall as much.'
		m+=CR+'* If you turn on debugging, you just MIGHT see extra Menu Item(s).'
		m+=CR+'* The PodCast playlists do not seem to have listings in them  at the time I made this sub-addon.'
		m+=CR+'* Some of the default Playlists of playlists were having trouble being fetched at times, so this sub-addon now downloads them if the /resources/*.plx files are missing or if the day has changed forward.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
def wP(filename):
	return xbmc.translatePath(os.path.join(workingPath,filename))
### ############################################################################################################
### ############################################################################################################

def Search_Site(title='',url='',page='',metamethod='',endit=True):
	if url=='': 'http://www.navixtreme.com/wiilist/search/'
	#if url=='': url=mainSite+'anime/search'; deb('url',url)
	#if len(page) > 0: page='1'
	if (title==''): title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title)
	addstv('LastSearchTitle'+SiteTag,title) ## Save Setting ##
	addstv('LastSearchUrl'+SiteTag,url) ## Save Setting ##
	title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','%20')
	#title=title.replace(' ','+')
	Browse_INI_Lists(url+title+'/')
	#Browse_INI_Lists('http://www.navixtreme.com/wiilist/search/'+title)

def Browse_INI_Lists(url):
	deb('url provided',url); 
	if url=='': return
	elif 'http://' in url: html=nURL(url); #html=messupText(html,True,True); s=[]; ItemCount=0
	elif workingPath in url:
		if isFile(url): html=_OpenFile(url)
		else: html=''
	else: html=''
	deb('Length of HTML',str(len(html))); #debob(html)
	if len(html)==0: myNote('HTML: '+url,'No page could be retreived.'); return
	html=html.replace('type=','|||item|||type=')
	#if (url=='http://www.navixtreme.com/wiilist/') or (url=='http://www.navixtreme.com/scrape/podcasts/'): matches=html.split('\n\n'); ItemCount=len(matches); #debob(matches)
	#else: matches=html.split('#'); ItemCount=len(matches); #debob(matches)
	matches=html.split('|||item|||'); ItemCount=len(matches)
	deb('No. of possible matches',str(ItemCount))
	if ItemCount > 0:
		for _item in matches:
			labs={}; labs['plot']=''+CR; _marker=''; 
			if '\nURL=' in _item:
				try: _url=_item.split('\nURL=')[1].split('\n')[0]
				except: url=''
				if len(_url) > 0:
					if ('\ndescription=' in _item) and ('/description\n' in _item): labs['plot']+=cFL(_item.split('\ndescription=')[1].split('/description\n')[0],colors['12'])
					if ('\nthumb=' in _item): img=_item.split('\nthumb=')[1].split('\n')[0]; fimg=img
					elif ('\nicon=' in _item): img=_item.split('\nicon=')[1].split('\n')[0]; fimg=img
					else: img=iconSite; fimg=fanartSite
					if ('\nname=' in _item): _name=_item.split('\nname=')[1].split('\n')[0]
					else: _name='[UNKNOWN]'
					if ('type=' in _item): _type=_item.split('type=')[1].split('\n')[0]
					else: _type='[UNKNOWN]'
					labs['plot']+=CR+cFL('URL:  ',colors['11'])+cFL(_url,colors['10'])
					uFe=_url[-3:]
					if   _url[-2:-1]=='.': uFe2=_url[-1:]
					elif _url[-3:-2]=='.': uFe2=_url[-2:]
					elif _url[-4:-3]=='.': uFe2=_url[-3:]
					elif _url[-5:-4]=='.': uFe2=_url[-4:]
					elif _url[-6:-5]=='.': uFe2=_url[-5:]
					elif _url[-7:-6]=='.': uFe2=_url[-6:]
					elif _url[-8:-7]=='.': uFe2=_url[-7:]
					else: uFe2='___'
					if uFe=='sdp': _marker=' *'
					if '://' in _url: uPre=_url.split('://')[0]
					else: uPre='____'
					### playlist | video | directory | window
					if   _type.lower()=='playlist':
						#_title=cFL(_name,'white')+cFL('[CR]['+cFL(_type,colors['10'])+']',colors['11'])
						_title=cFL(_name,'white')+cFL('[CR]['+cFL(_type,colors['10'])+' | '+cFL(uPre,colors['1'])+' | '+cFL(uFe2,colors['2'])+']',colors['11'])
						labs['plot']+=CR+cFL('URL:  ',colors['11'])+cFL(_url,colors['10'])
						pars={'mode':'INIlists','site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}; labs['title']=_title; 
						try: 
							contextLabs={'title':' '+cFL('['+cFL(_type,colors['10'])+']',colors['11'])+'  '+_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':labs['plot']}
							contextMenuItems=ContextMenu_LiveStreams(contextLabs) #contextMenuItems=[]; 
						except: contextMenuItems=[]
						try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
						except: pass
					elif _type.lower()=='video': #.replace('','')
						_url=_url.replace('rtmp://$OPT:','').replace('rtmp-raw=','').replace('%20',' ')
						#_url=_url.replace('webport.tv:1935/live?lp/','webport.tv:1935/live playpath=').replace('webport.tv/live?lp=','webport.tv/live playpath=')
						#if 'http://www.olweb.tv/' in _url:
						#
						#if (_url[:7].lower() is not 'http://') and (_url[:7].lower() is not 'rtmp://') and (_url[:7].lower() is not 'mms://') and (_url[:7].lower() is not 'rtsp://'): _url='rtmp://'+_url
						_title=cFL(_name,'white')+cFL('[CR]['+cFL(_type,colors['10'])+' | '+cFL(uPre,colors['1'])+' | '+cFL(uFe2,colors['2'])+']',colors['11'])
						labs['plot']+=CR+cFL('URL:  ',colors['11'])+cFL(_url,colors['10'])
						pars={'mode':'PlayURLs','site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}; labs['title']=_title+_marker; 
						try: 
							contextLabs={'title':' '+cFL('['+cFL(_type,colors['10'])+']',colors['11'])+'  '+_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':labs['plot']}
							contextMenuItems=ContextMenu_LiveStreams(contextLabs) #contextMenuItems=[]; 
						except: contextMenuItems=[]
						try: _addon.add_directory(pars,labs,is_folder=False,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
						except: pass
	set_view('tvshows',int(addst('tvshows-view'))); eod()

def Browse_Hosts(url,page='',content='list',view='50'):
	if url=='': return
	#if page=='': page='1'
	deb('url',url)
	#npage=str(int(page)+1); deb('url and npage',url+'?page='+npage)
	html=nURL(url); html=messupText(html,True,True)
	#if '">Next</a></li>' in html: _addon.add_directory({'mode':'Episodes','site':site,'section':section,'url':url,'page':npage},{'title':cFL_('  .Next Page > '+npage,colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	s='<iframe.*?src="((http://[www|embed]*[\.]*([A-Za-z0-9\.\-_]*))/.+?)"'; matches=re.compile(s).findall(html); ItemCount=len(matches)
	if ItemCount > 0:
		debob(matches)
		for _url,_hostdomain,_hostname in matches:
			if ('/ads/' not in _url) and ('facebook' not in _url) and (mainSite.lower() not in _url.lower()) and ('ubhappy.eu' not in _hostname) and ('advertising' not in _hostname):
				img=''+thumbnail; fimg=''+fanart; _title=''+cFL_(_hostname,'blueviolet')
				if checkHostProblems(_url)==True: _title+=cFL_('  *','blueviolet')
				contextLabs={'title':addpr('title',''),'year':'0000','url':_url,'img':img,'fanart':fimg,'hostname':_hostname,'hostdomain':_hostdomain,'destfile':addpr('title','')+'.flv'}; contextMenuItems=ContextMenu_Hosts(labs=contextLabs)
				pars={'mode':'PlayFromHost','site':site,'section':section,'title':addpr('title',''),'hostname':_hostname,'hostdomain':_hostdomain,'url':_url,'img':img,'fanart':fimg}
				labs={'title':_title}
				_addon.add_directory(pars,labs,is_folder=False,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
	set_view(content,view_mode=addst('links-view'))
	eod()

def Fav_List(site='',section='',subfav=''):
	debob(['test1',site,section,subfav])
	favs=fav__COMMON__list_fetcher(site=site,section=section,subfav=subfav)
	ItemCount=len(favs)
	debob('test2 - '+str(ItemCount))
	if len(favs)==0: myNote('Favorites','None Found'); eod(); return
	debob(favs)
	for (_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2) in favs:
		if _img > 0: img=_img
		else: img=iconSite
		if _fanart > 0: fimg=_fanart
		else: fimg=fanartSite
		debob('_ToDoParams'); debob(_ToDoParams)
		pars=_addon.parse_query(_ToDoParams)
		debob('pars'); debob(pars)
		_title=cFL_(_name,'white')
		if (len(_year) > 0) and (not _year=='0000'): _title+=cFL('  ('+cFL(_year,'deeppink')+')','pink')
		if len(_Country) > 0: _title+=cFL('  ['+cFL(_Country,'deeppink')+']','pink')
		
		contextLabs={'title':_name,'year':_year,'img':_img,'fanart':_fanart,'country':_Country,'url':_Url,'plot':_plot,'genres':_Genres,'site':_site,'subfav':_subfav,'section':_section,'todoparams':_ToDoParams,'commonid':_commonID,'commonid2':_commonID2}
		##contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}
		contextMenuItems=ContextMenu_Favorites(contextLabs)
		#contextMenuItems=[]
		if 'playlist' in _name.lower(): issyF=True
		else: issyF=False
		_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=issyF,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#
	#
	if 'movie' in section.lower(): content='movies'
	else: content='tvshows'
	set_view(content,view_mode=int(addst('tvshows-view'))); eod()


### ############################################################################################################
### ############################################################################################################
def PlxCheck(n,u):
	n='wiilist_'+n+'.plx'; _dL=False
	d=datetime.date.today()
	_y=str(d.year); _m=str(d.month); _d=str(d.day)
	if len(_m)==1: _m='0'+_m
	if len(_d)==1: _d='0'+_d
	_date=_y+_m+_d
	if (len(addst('NaviXtreme__'+n))==0): _dL=True
	elif (int(addst('NaviXtreme__'+n)) < int(_date)): _dL=True
	if (_dL==True) or (isFile(wP(n))==False): 
		urllib.urlretrieve(mainSite+'wiilist/'+u+'.plx',wP(n))
		addstv('NaviXtreme__'+n,_date)
def ScrapeMenu():
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/2229/realtime_scrapers.plx?action=sortsel&cur=ord'},{'title':cFL_('Sorted [COLOR=FF00FF00][COLOR=FF00FF00]by user-assigned order[/COLOR][/COLOR]',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/icons/2downarrow.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/abc/'},{'title':'Scrape - '+cFL_('ABC',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_abc.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/animefreak/'},{'title':'Scrape - '+cFL_('Animefreak.tv',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_animefreak.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':'http://www.straumr.dk/host/BBC_Archive_scraper_plx.php'},{'title':'Host - '+cFL_('BBC Archive',colors['2'])},is_folder=True,fanart=fanartSite,img='http://www.straumr.dk/host/BBC_Archive_inv.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/cbs_sports/'},{'title':'Scrape - '+cFL_('CBS Sports',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_cbssports.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/cbs/'},{'title':'Scrape - '+cFL_('CBS',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_cbs.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/cnn/'},{'title':'Scrape - '+cFL_('CNN',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_cnn.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/cracklemovies/'},{'title':'Scrape - '+cFL_('Crackle Movies',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_crackle.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/crackletv/'},{'title':'Scrape - '+cFL_('Crackle TV',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_crackle.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/15649/dailymotion_user_lists.plx'},{'title':'Playlist - '+cFL_('Dailymotion User Lists',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_dailymotion.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/discovery/'},{'title':'Scrape - '+cFL_('Discovery Networks',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_discovery_dsc.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/divxstage/'},{'title':'Scrape - '+cFL_('DivxStage',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_divxstage.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/diynetwork/'},{'title':'Scrape - '+cFL_('DIY Network',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_diynetwork.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/ebaumsworld/'},{'title':'Scrape - '+cFL_("eBaum's World",colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.ebaumsworld.com/img/headerlogo.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/filmtrailer/'},{'title':'Scrape - '+cFL_('Filmtrailer.com',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_filmtrailer.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/fraggme/'},{'title':'Scrape - '+cFL_('Fragg.me',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_fraggme.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/g4tv/'},{'title':'Scrape - '+cFL_('G4TV',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_g4tv.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/gamefaqs/'},{'title':'Scrape - '+cFL_('GameFAQs',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_gamefaqs.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/gamekings/'},{'title':'Scrape - '+cFL_('Gamekings',colors['6'])},is_folder=True,fanart=fanartSite,img='ttp://media.navi-x.org/images/backgrounds/thumb_gamekings.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/gametrailers/'},{'title':'Scrape - '+cFL_('GameTrailers.com',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_gametrailers.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/httpfilm/'},{'title':'Scrape - '+cFL_('HTTPfilm.com',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_httpfilm.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/icefilms/'},{'title':'Scrape - '+cFL_('IceFilms.info',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_icefilms.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/librivox/'},{'title':'Scrape - '+cFL_('Librivox Audio Books',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_librivox.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/livewellhd/'},{'title':'Scrape - '+cFL_('Live Well HD',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_livewellhd.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/maxim/'},{'title':'Scrape - '+cFL_('Maxim',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logo_maxim.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/mekongtv/'},{'title':'Scrape - '+cFL_('Mekong TV',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_mekongtv.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/mtv_music/'},{'title':'Scrape - '+cFL_('MTV Music Videos',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_mtv.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/natgeo/'},{'title':'Scrape - '+cFL_('National Geographic',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_natgeo.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/nbc/'},{'title':'Scrape - '+cFL_('NBC',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_nbc.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/nfb_ca/'},{'title':'Scrape - '+cFL_('NFB',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_nfb_ca.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/nfl/'},{'title':'Scrape - '+cFL_('NFL',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_nfl.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/pbskids/'},{'title':'Scrape - '+cFL_('PBS Kids',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_pbskids.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/pbs/'},{'title':'Scrape - '+cFL_('PBS',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_pbs.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/pokertube/'},{'title':'Scrape - '+cFL_('PokerTube',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_pokertube.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/radiolala/'},{'title':'Scrape - '+cFL_('Radiolala',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_radiolala.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/scifi/'},{'title':'Scrape - '+cFL_('SyFy',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_syfy.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/tgwtg/'},{'title':'Scrape - '+cFL_('That Guy With The Glasses',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_tgwtg2.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/top40charts/'},{'title':'Scrape - '+cFL_('Top 40 Charts',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_top40-charts.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/trutv/'},{'title':'Scrape - '+cFL_('TruTV',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_trutv.gif')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/vidics/'},{'title':'Scrape - '+cFL_('VidIcs',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_vidics.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/youtube_shows/'},{'title':'Scrape - '+cFL_('Youtube Shows',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_youtube_shows.jpg')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':'http://scrape.navixtreme.com/cgi-bin/boseman/Scrapers/ct_veehd'},{'title':'Scrape - '+cFL_('VeeHD',colors['6'])},is_folder=True,fanart=fanartSite,img='http://static.veehd.com/logo.gif')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/scrape//'},{'title':'Scrape - '+cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img='')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/scrape//'},{'title':'Scrape - '+cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img='')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/scrape//'},{'title':'Scrape - '+cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img='')
	#
	set_view('list',view_mode=addst('default-view')); eod()

def KgoerbigMenu():
	mS='http://home.comcast.net/~kgoerbig/playlists/'
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'home.plx'},{'title':cFL_('kgoerbig - Home',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'olivia.plx'},{'title':cFL_('kgoerbig - Olivia',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'movies.plx'},{'title':cFL_('kgoerbig - Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'history.plx'},{'title':cFL_('kgoerbig - History',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mS+'home.plx'},{'title':cFL_('kgoerbig - ',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	set_view('list',view_mode=addst('default-view')); eod()

def SectionMenu():
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	if (len(addst('LastSearchTitle'+SiteTag)) > 0) and (len(addst('LastSearchUrl'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	###_addon.add_directory({'mode':'Search','url':'http://www.navixtreme.com/search/','site':site},{'title':cFL_('Search [navixtreme]',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	_addon.add_directory({'mode':'Search','url':'http://www.navixtreme.com/playlist/search/','site':site},{'title':cFL_('Search [playlist]',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	_addon.add_directory({'mode':'Search','url':'http://www.navixtreme.com/wiilist/search/','site':site},{'title':cFL_('Search [wiilist]',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	#
	_addon.add_directory({'mode':'ScrapeMenu','site':site},{'title':'Menu - '+cFL('Scrapers',colors['6'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/scrape.png')
	_addon.add_directory({'mode':'KgoerbigMenu','site':site},{'title':'Menu - '+cFL('Kgoerbig',colors['3'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/scrape.png')
	#
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/'},{'title':cFL_('playlist - Navi-Xtreme [COLOR=FF888888]>>[/COLOR] Home',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logo-trans.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/live_streams.plx'},{'title':cFL_('playlist - Live Streams',colors['1'])},is_folder=True,fanart='http://media.navi-x.org/images/backgrounds/bkg_navix_bh_plain.jpg',img='http://media.navi-x.org/images/logo-trans.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/day.plx'},{'title':cFL_('playlist - Most-Viewed Lists of The Last 24 Hours',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/viewed.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/week.plx'},{'title':cFL_('playlist - Most-Viewed Lists of The Last 7 Days',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/viewed.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/update.plx'},{'title':cFL_('playlist - Most-Recently updated lists',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/newest.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/new.plx'},{'title':cFL_('playlist - Latest Media Entries',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/newest.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/all.plx'},{'title':cFL_('playlist - User Media - Full List',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/users.png')
	_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/users.plx'},{'title':cFL_('playlist - Navi-Xtreme [COLOR=FF888888]>>[/COLOR] by User',colors['1'])},is_folder=True,fanart='http://media.navi-x.org/images/backgrounds/bkg_navix_bh_plain.jpg',img='http://media.navi-x.org/images/logos/user.png')
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/user/'},{'title':cFL_('playlist - User',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'INIlists','site':site,'url':mainSite+'playlist/user_lists.plx'},{'title':cFL_('playlist - User Lists',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'INIlists','site':site,'url':mainSite+'playlist/realtime_scrapers.plx'},{'title':cFL_('playlist - Realtime Scrapers',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'INIlists','site':site,'url':mainSite+'playlist/mine.plx'},{'title':cFL_('playlist - mine.plx',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'INIlists','site':site,'url':mainSite+'playlist/navi-xtreme_nxportal_home.plx'},{'title':cFL_('playlist - user_lists',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/user_lists.plx'},{'title':cFL_('playlist - user_lists',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#
	if (_debugging==True): 
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/36866/kartoon_kapers.plx'},{'title':cFL_('playlist - 36866 - kartoon_kapers',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/icons/2downarrow.png')
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/2229/realtime_scrapers.plx'},{'title':cFL_('playlist - 2229 - realtime scrapers',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/logos/scrape.png')
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/56427/bigdog_2011-2012_movies.plx'},{'title':cFL_('playlist - 56427 - bigdog 2011-2012 Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/57713/movie_collections.plx'},{'title':cFL_('playlist - 57713 - Movie Collections',colors['1'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/viewed.png')
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/65970/latest_in_theaters.plx'},{'title':cFL_('playlist - 65970 - Latest in Theaters',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'wiilist/84633/'},{'title':'wiilist - '+cFL_('Live Tv (NB Indholder Adult Links)',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/cracklemovies/'},{'title':cFL_('Scrape - Crackle Movies',colors['1'])},is_folder=True,fanart='http://www.navixtreme.com/images/backgrounds/bkg_movies.jpg',img='http://www.navixtreme.com/images/backgrounds/thumb_crackle.png')
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'scrape/podcasts/'},{'title':cFL_('Scrape - Apple iTunes Podcasts',colors['1'])},is_folder=True,fanart=fanartSite,img='http://media.navi-x.org/images/backgrounds/thumb_podcast.png')
		#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'wiilist/'},{'title':cFL_('wiilist',colors['1'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/logo.png')
		#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_day.plx')},{'title':cFL_('wiilist - Most-viewed lists of the last 24 hours',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/viewed.png')
		#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_week.plx')},{'title':cFL_('wiilist - Most-viewed lists of the last 7 days',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/viewed.png')
		#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_update.plx')},{'title':cFL_('wiilist - Most-recently updated lists',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/newest.png')
		#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_new.plx')},{'title':cFL_('wiilist - Latest media entries',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/newest.png')
		#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':wP('wiilist_all.plx')},{'title':cFL_('wiilist - User media - full list',colors['1'])},is_folder=True,fanart=fanartSite,img=mainSite+'images/logos/users.png')
		#_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'wiilist/users.plx'},{'title':cFL_('wiilist - navi-xtreme  -  by user',colors['1'])},is_folder=True,fanart='http://media.navi-x.org/images/backgrounds/bkg_navix_bh_plain.jpg',img='http://media.navi-x.org/images/logos/user.png')
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/97048/live_tv_channels.plx'},{'title':'playlist - '+cFL_(' [COLOR=FF00FF00]Live TV Channels[/COLOR]',colors['1'])},is_folder=True,fanart='http://wallpaperhires.com/wp-content/uploads/2013/10/bubles-abstract-wallpaper.jpg',img='http://upload.wikimedia.org/wikipedia/commons/b/b2/Etiqueta_HD_TV.jpg')
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/112567/live_tv_channels.plx'},{'title':'playlist - '+cFL_('Live TV Channels',colors['1'])},is_folder=True,fanart='http://www.hdwallpaperspot.com/wp-content/uploads/2013/02/24-desktop-backgrounds-snow-storm-sky.jpg',img='http://sat-mactep.ru/liteplus.JPG')
		_addon.add_directory({'mode':'INIlists','site':site,'section':'','url':mainSite+'playlist/125509/live_tv_channels_(porkies_playlist)_stop_copying_my_list_or_i_will_remove_my_list_and_you_will_have_nothing_to_copy._dont_be_lazy_make_your_own_list_dont_steal_mine.plx'},{'title':'playlist - '+cFL_("Live TV Channels (Porkie's Playlist)",colors['1'])},is_folder=True,fanart='http://hdwallpapercorner.com/gallery/2603-apple-focus-colors.jpeg',img='http://www.userlogos.org/files/logos/igor23/livetv_black.png')
	
	
	
	
	#
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'XML','site':site,'section':'movies','url':mainSite+'videositemap-1.xml'},{'title':cFL_('Browse XML (videositemap-1.xml)',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'List','site':site,'section':'movies','url':mainSite+'category/anime-movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'series'},{'title':cFL_('Anime Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'ongoing-anime'},{'title':cFL_('Ongoing Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'new-anime'},{'title':cFL_('New Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Episodes','site':site,'section':'series','url':mainSite+'surprise'},{'title':cFL_('Suprise Me',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Search','site':site,'section':'series'},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	### Favorites
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'3'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'4'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'5'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'6'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'7'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	### Advanced Users - used to clean-up Favorites folders.
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'' },{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'2'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'3'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'4'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'5'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'6'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'7'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	
	set_view('list',view_mode=addst('default-view')); eod()



### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='SubMenu'): 			SubMenu() #(site,section)
	elif (mode=='ScrapeMenu'): 		ScrapeMenu()
	elif (mode=='KgoerbigMenu'): 	KgoerbigMenu()
	elif (mode=='Page'): 					Browse_Page(url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='Episodes'): 			Browse_Episodes(url,page)
	elif (mode=='List'): 					Browse_List(url,page)
	elif (mode=='XML'): 					Browse_XML(url)
	elif (mode=='INIlists'): 			Browse_INI_Lists(url)
	elif (mode=='INIitems'): 			Browse_INI_Items(url)
	elif (mode=='GetLiveFeed'): 	GetLiveFeed(url,addpr('title',''),addpr('img',''))
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='AZ'): 						Browse_AZ()
	elif (mode=='Genres'): 				Browse_Genres()
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=addst('LastSearchUrl'+SiteTag),page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
	
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
