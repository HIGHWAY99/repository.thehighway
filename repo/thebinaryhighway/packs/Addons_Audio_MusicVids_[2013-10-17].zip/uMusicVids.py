### ############################################################################################################
###	#	
### # Site: 				#		80s & 90s Music Videos - 80smusicvids.com | 90smusicvidz.com
### # Author: 			#		The Highway
### # Description: 	#		
### # Credits: 			#		Originally ported from the addon project known as 80s Music Videos - by spoyser.
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import urllib,urllib2,re,cookielib,os,sys
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
#from resources.libs import main
from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart)
selfAddon=_plugin
#from universal import watchhistory
#wh=watchhistory.WatchHistory(ps('_addon_id'))
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR white][COLOR red]80[/COLOR]s & [COLORred]90[/COLOR]s Music Videos[/COLOR]  [v0.0.1]  [Music Videos]'
SiteTag='80smusicvids.com'
mainSite='http://www.80smusicvids.com/'
mainSite2='http://www.90smusicvidz.com/'
iconSite='http://www.90smusicvidz.com/img/top.jpg' #_artIcon
iconSite1='http://www.80smusicvids.com/img/top.jpg'
iconSite2='http://www.90smusicvidz.com/img/top.jpg'
#	#
#	#
fanartSite='http://www.80smusicvids.com/img/top.jpg' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Domain:  '+mainSite2+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch (listen to) the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'RTMP Live Streams'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Music Videos from 80s.'
		m+=CR+'* Browse Music Videos from 90s.'
		m+=CR+'* Play Music Videos.'
		#m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
### ############################################################################################################
### ############################################################################################################
def Browse_Hosts(url,page=''):
	if url=='': return
	deb('url',url)
	html=nURL(url); html=messupText(html,True,True)
	s='flashvars=".*?file=[\.]*(.*?)&image=[\.]*.*?[&]*.*?"'; matches=re.compile(s).findall(nolines(html))
	debob(matches)
	#s='http://www\.([80|90]smusicvid[s|z].com)/'; base=re.compile(s).findall(url)[0]
	if '90smusicvidz.com' in url: base=mainSite2
	else: base=mainSite
	debob(base)
	PlayVideo(base+matches[0])

def Browse_Items(url):
	html=nURL(url)
	s='- <a target="_self" href="(index.php\?vid=.*?)">(.*?)</a><br>'
	matches=re.compile(s).findall(html)
	if (not matches): eod(); return
	ItemCount=len(matches)
	for path,name in matches:
		img=url+'img/top.jpg'; path=url+path
		labs={'title':name}; pars={'mode':'Hosts','site':site,'section':section,'url':path}
		contextMenuItems=[]; 
		#contextMenuItems.append(('Download', ''))
		addon.add_directory(pars,labs,fanart=img,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount,is_folder=False)
	set_view('list'); eod()
##### /\ ##### Browse Radio Stations #####
### ############################################################################################################
### ############################################################################################################
def SectionMenu(): #(site):
	fS=fanartSite; iS=iconSite
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	_addon.add_directory({'mode':'Items','site':site,'url':mainSite},{'title':cFL_('80s Music Videos',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite1)
	_addon.add_directory({'mode':'Items','site':site,'url':mainSite2},{'title':cFL_('90s Music Videos',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite2)
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='Items'): 				Browse_Items(url)
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='RadioStations'): RadioStations(addpr('title',''))
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#elif (mode=='FavList'): 			Fav_List(site,section)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
