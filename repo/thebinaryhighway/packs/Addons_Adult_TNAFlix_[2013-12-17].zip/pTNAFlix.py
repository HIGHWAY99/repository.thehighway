### ############################################################################################################
###	#	
### # Site: 				#		
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui

from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_SaveFile)
### ############################################################################################################
### ############################################################################################################
SiteName='TnA flix (18+)  [v0.0.1]  [Adult Videos]'
SiteTag='TnAflix'
mainSite='http://www.tnaflix.com'
iconSite='http://i.imgur.com/HspwNx3.png'
fanartSite=_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl=mainSite+'ram.pls'
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'Live Streams (RTMPE)'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Videos'
		m+=CR+'* Play Videos'
		m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t

### ############################################################################################################
### ############################################################################################################

def Fav_List(site='',section='',subfav=''):
	debob(['test1',site,section,subfav])
	favs=fav__COMMON__list_fetcher(site=site,section=section,subfav=subfav)
	ItemCount=len(favs)
	debob('test2 - '+str(ItemCount))
	if len(favs)==0: myNote('Favorites','None Found'); eod(); return
	debob(favs)
	for (_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2) in favs:
		if _img > 0: img=_img
		else: img=iconSite
		if _fanart > 0: fimg=_fanart
		else: fimg=fanartSite
		debob('_ToDoParams'); debob(_ToDoParams)
		pars=_addon.parse_query(_ToDoParams)
		debob('pars'); debob(pars)
		_title=cFL_(_name,'white')
		if (len(_year) > 0) and (not _year=='0000'): _title+=cFL('  ('+cFL(_year,'deeppink')+')','pink')
		if len(_Country) > 0: _title+=cFL('  ['+cFL(_Country,'deeppink')+']','pink')
		try: pars['url']=pars['plugin://'+ps('addon_id')+'/?url']
		except: pass
		contextLabs={'title':_name,'year':_year,'img':_img,'fanart':_fanart,'country':_Country,'url':_Url,'plot':_plot,'genres':_Genres,'site':_site,'subfav':_subfav,'section':_section,'todoparams':_ToDoParams,'commonid':_commonID,'commonid2':_commonID2}
		##contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}
		contextMenuItems=ContextMenu_Favorites(contextLabs)
		#contextMenuItems=[]
		if ('thumbs' in _Url) or ('thumbs' in pars): TTFF=False; TTFFM=' [Watch] '
		else: TTFF=True; TTFFM=' [Browse] '
		try: _addon.add_directory(pars,{'title':_title+CR+TTFFM,'plot':_plot},is_folder=TTFF,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		except: pass
		#_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#
	#
	if 'movie' in section.lower(): content='movies'
	else: content='tvshows'
	set_view(content,view_mode=int(addst('tvshows-view'))); eod()

def Search_Site(title='',url='',page='',metamethod='',endit=True):
	#if url=='': url=mainSite+'anime/search'
	#if len(page) > 0: page='1'
	#deb('url',url)
	if (title==''): title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title)
	addstv('LastSearchTitle'+SiteTag,title) ## Save Setting ##
	title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','+')
	#title=title.replace(' ','+')
	if len(page) > 0: npage=str(int(page)+1); #p='&page='+page; 
	else: npage='2'; #p=''; 
	Browse_List('/?s=search&search='+title,page)

def GetMedia(title='',url='',img=iconSite):
	__url=''+url
	#try: _addon.resolve_url(url)
	#except: pass
	if len(url)==0: return
	if mainSite not in url: url=mainSite+url
	deb('url',url); html=messupText(nURL(url),True); 
	s='flashvars.config\s*=\s*escape\("(http://.+?)"\)'; 
	url2=re.compile(s).findall(nolines(html))[0]; #deb('# of matches found',str(len(matches))); #debob(matches)
	#deb('url2',url2); PlayItCustom(__url,url2,img,title)
	html2=messupText(nURL(url2),True); 
	s2='<item>\s*<res>(.+?)</res>\s*<videoLink>(http://.+?)</videoLink>\s*</item>'
	url3=re.compile(s2).findall(nolines(html2)); ItemCount=len(url3); deb('length',str(len(url3))); debob(url3); 
	#
	for res,videoLink in url3:
		_title=title+' - '+res
		fimg=img
		pars={'mode':'PlayItCustom','url':videoLink,'streamurl':videoLink,'title':_title,'img':img,'site':site}; 
		#contextLabs={'title':_title,'year':'0000','url':videoLink,'img':img,'fanart':fimg,'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':''}; 
		#contextMenuItems=ContextMenu_Movies(contextLabs)
		#try: 
		#deb('test',_title)
		#debob((pars,fimg,img))
		_addon.add_directory(pars,{'title':_title+CR+res},is_folder=False,fanart=fimg,img=img)
		#_addon.add_directory(pars,{'title':_title},is_folder=False)
		#_addon.add_directory(pars,{'title':_title},is_folder=False,contextmenu_items=contextMenuItems,total_items=ItemCount,fanart=fimg,img=img)
		#except: pass
	set_view('movies',view_mode=addst('movies-view')); eod(); 

def Browse_Tags(url,page='0'):
	if len(url)==0: return
	#if len(str(page))==0: url2=url; p='1'
	#else:
	#	if '?' in url: url2=url+'&p='+page; p=page
	#	else: url2=url+'?p='+page; p=page
	url2=url
	if mainSite not in url2: url2=mainSite+url2
	deb('url2',url2); #deb('url',url); 
	html=nolines(messupText(nURL(url2),True)); deb('length of html',str(len(html))); #debob(html)
	if len(html)==0: return
	#s='<div><a href="(.+?)" title="(.+?)"><img src="(http://.+?\.[jpg|JPG|png|PNG|gif|GIF]+)" /><b>(.+?)</b></a>\s*\(\s*(\d+)\s*Video[s]*\s*\)\s*</div>'
	#s='<div><a href="(.+?)" title="(.+?)"><img src="(http://.+?\.[jpg|JPG|png|PNG|gif|GIF]+)" />\s*(.+?)\s*\(\s*(\d+)\s*Video[s]*\s*\)\s*</a></div>'
	s='<div class="tagrow">\s*<a href="(.+?)">(.+?)</a>\s*<span style="font-size: \d+px;">(\d+)</span>\s*</div>'
	try: matches=re.compile(s).findall(html); ItemCount=len(matches); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''
	#try: NextPage=re.compile('<li><a href=".+?\?p=(.+?)">Next</a></li>').findall(html)[0]
	#except: NextPage=''
	#if (len(NextPage) > 0) or ('">Next</a></li>' in html):
	#	debob(str(int(p)+1))
	#	try: _addon.add_directory({'url':url,'page':str(int(p)+1),'mode':addpr('mode',''),'site':site},{'title':'  Next'},is_folder=True,fanart=fanartSite,img=iconSite)
	#	except: pass
	if len(matches)==0: return
	for (_url,_name,_count) in matches:
		img=iconSite
		_title=cFL(_name,colors['10'])+'  ['+cFL(_count,colors['11'])+']'; fimg=''+img; pars={'mode':'Browse','url':_url,'title':_name,'img':img,'site':site}; contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':''}; contextMenuItems=ContextMenu_Movies(contextLabs)
		try: _addon.add_directory(pars,{'title':_title},is_folder=True,contextmenu_items=contextMenuItems,total_items=ItemCount,fanart=fimg,img=img)
		except: pass
	set_view('movies',view_mode=addst('movies-view')); eod(); 

def Browse_Lists(url,page):
	if len(url)==0: return
	if len(str(page))==0: url2=url; p='1'
	else:
		if '?' in url: url2=url+'&p='+page; p=page
		else: url2=url+'?p='+page; p=page
	if mainSite not in url2: url2=mainSite+url2
	deb('url2',url2); #deb('url',url); 
	html=messupText(nURL(url2),True); deb('length of html',str(len(html))); #debob(html)
	if len(html)==0: return
	#s='<div><a href="(.+?)" title="(.+?)"><img src="(http://.+?\.[jpg|JPG|png|PNG|gif|GIF]+)" /><b>(.+?)</b></a>\s*\(\s*(\d+)\s*Video[s]*\s*\)\s*</div>'
	s='<div><a href="(.+?)" title="(.+?)"><img src="(http://.+?\.[jpg|JPG|png|PNG|gif|GIF]+)" />\s*(.+?)\s*\(\s*(\d+)\s*Video[s]*\s*\)\s*</a></div>'
	try: matches=re.compile(s).findall(html); ItemCount=len(matches); deb('# of matches found',str(len(matches))); debob(matches)
	except: matches=''
	try: NextPage=re.compile('<li><a href=".+?\?p=(.+?)">Next</a></li>').findall(html)[0]
	except: NextPage=''
	if (len(NextPage) > 0) or ('">Next</a></li>' in html):
		debob(str(int(p)+1))
		try: _addon.add_directory({'url':url,'page':str(int(p)+1),'mode':addpr('mode',''),'site':site},{'title':'  Next'},is_folder=True,fanart=fanartSite,img=iconSite)
		except: pass
	if len(matches)==0: return
	for (_url,_name2,img,_name,_dur) in matches:
		_title=cFL(_name,colors['10'])+CR+cFL(_dur+' Video(s)',colors['11']); fimg=''+img; pars={'mode':'Browse','url':_url,'title':_name,'img':img,'site':site}; contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':''}; contextMenuItems=ContextMenu_Movies(contextLabs)
		try: _addon.add_directory(pars,{'title':_title},is_folder=True,contextmenu_items=contextMenuItems,total_items=ItemCount,fanart=fimg,img=img)
		except: pass
	set_view('movies',view_mode=addst('movies-view')); eod(); 

def Browse_List(url,page):
	if len(url)==0: return
	#if len(str(page))==0: url2=url; p='1'
	#else:
	#	if '?' in url: url2=url+'&p='+page; p=page
	#	else: url2=url+'?p='+page; p=page
	url2=url
	if mainSite not in url2: url2=mainSite+url2
	deb('url2',url2); #deb('url',url); 
	html=nolines(messupText(nURL(url2),True)); deb('length of html',str(len(html))); #debob(html)
	if len(html)==0: return
	#s='<a target="_blank" href="(/cgi-bin/atx/out.cgi.*?u=\.\./\.\./[\?|&]+v=[0-9A-Za-z]+)" title="(.+?)">\s*'; s+='<img.*?src="(http://.+?\.[jpg|JPG|png|PNG|gif|GIF]+)" /><br></a></div><div class="dur">\s*(.+?)\s*</div>'
	#s='<a href="(/cgi-bin/atx/out.cgi.*?u=\.\./\.\./[\?|&]+v=[0-9A-Za-z]+)" title="(.+?)" target="_blank">\s*'; s+='<img.*?src="(http://.+?\.[jpg|JPG|png|PNG|gif|GIF]+)" /><br></a></div><div class="dur">\s*(.+?)\s*</div>'
	s='<a href=".+?" class="videoThumb" title=""> <img class="thumbload" onmouseover="movieStart'+"\('\d+', 'thumb', '(http://.+?)', '.+?', '\d+'\);"+'" src="/images/blank.gif" data-src="(http://.+?)" title=".+?" alt=".+?" id="\d+" width="\d+" height="\d+" /></a>\s*<a class="thumbs_title" href="(.+?)"  title="" ><h2>(.+?)</h2></a>\s*<span class="duringTime">(\d+:\d+)</span>'
	try: matches=re.compile(s).findall(html); ItemCount=len(matches); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''
	try: NextPage=re.compile('<a\s*class="navLink"\s*href="([0-9A-Za-z/_\-]+)">next').findall(html)[0]
	except: NextPage=''
	if len(NextPage) > 0:
		#debob(str(int(p)+1))
		deb('next',NextPage)
		try: _addon.add_directory({'url':mainSite+NextPage,'page':'','mode':addpr('mode',''),'site':site},{'title':'  Next'},is_folder=True,fanart=fanartSite,img=iconSite)
		except: pass
	if len(matches)==0: return
	for (preview,img,_url,_name,_dur) in matches: # preview-flv,img,url,description,duration
		_title=cFL(_name,colors['10'])+CR+cFL(_dur,colors['11']); fimg=''+img; pars={'mode':'GetMedia','url':mainSite+_url,'title':_name,'img':img,'site':site}; contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':''}; contextMenuItems=ContextMenu_Movies(contextLabs)
		try: _addon.add_directory(pars,{'title':_title},is_folder=True,contextmenu_items=contextMenuItems,total_items=ItemCount,fanart=fimg,img=img)
		except: pass
	set_view('movies',view_mode=addst('movies-view')); eod(); 


### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	##_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Browse','url':'/','site':site},{'title':cFL_('Home',colors['10'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Browse','url':'/?s=recent','site':site},{'title':cFL_('Most Recent',colors['10'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Browse','url':'/?s=viewed','site':site},{'title':cFL_('Most Viewed',colors['10'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Lists','url':'/?s=categories','site':site},{'title':cFL_('Categories',colors['11'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Lists','url':'/?s=channels','site':site},{'title':cFL_('Channels',colors['11'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'Browse','url':'/','site':site},{'title':cFL_('',colors['10'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'Browse','url':'/','site':site},{'title':cFL_('',colors['10'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'Browse','url':'/','site':site},{'title':cFL_('Home List',colors['10'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	_addon.add_directory({'mode':'Tags','url':'/tag_list.php?order_desc=1','site':site},{'title':cFL_('Tags',colors['11'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	
	### Favorites
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'3'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'4'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'5'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'6'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'7'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	### Advanced Users - used to clean-up Favorites folders.
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'' },{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'2'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'3'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'4'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'5'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'6'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'7'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	###
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='NowPlaying'): 		NowPlaying()
	elif (mode=='Browse'): 				Browse_List(url,addpr('page',''))
	elif (mode=='Lists'): 				Browse_Lists(url,addpr('page',''))
	elif (mode=='Tags'): 					Browse_Tags(url,addpr('page',''))
	elif (mode=='GetMedia'): 			GetMedia(addpr('title',''),url,addpr('img',''))
	#elif (mode=='List'): 				Browse_List(addpr('title',''))
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='SlideShowStart'): path = os.path.join(_addonPath, 'c_SlideShow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
