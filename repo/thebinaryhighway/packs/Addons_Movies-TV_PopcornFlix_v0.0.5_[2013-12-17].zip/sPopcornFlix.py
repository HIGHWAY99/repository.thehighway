### ############################################################################################################
###	#	
### # Site: 				#		Popcorn Flix - http://popcornflix.com/
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui

from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_SaveFile)
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR orange]p[COLOR blue]o[/COLOR]pcorn[COLOR blue]flix[/COLOR].com[/COLOR]  [v0.0.5]  [Movies]'
SiteTag='popcornflix.com'
mainSite='http://popcornflix.com'
iconSite='http://popcornflix.com/images/logo.png' #_artIcon
fanartSite=_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl=mainSite+'ram.pls'
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'Live Streams (RTMPE)'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Movies'
		m+=CR+'* Play Videos'
		m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t

### ############################################################################################################
### ############################################################################################################

def PlayItCustomL2(url,stream_url,img,title,studio=''):
	PlayerMethod=addst("core-player")
	if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER
	elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER
	elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER
	else: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	listitem=xbmcgui.ListItem(title,iconImage=img,thumbnailImage=img); listitem.setInfo('video',{'Title':title,'Genre':'Live','Studio':studio})
	PL=xbmc.PlayList(xbmc.PLAYLIST_VIDEO); PL.clear(); #PL.add(stream_url,listitem)
	#
	html=nURL(stream_url); deb('Length of html',str(len(html))); 
	#debob(html)
	#matches=re.compile('\n+\s*(.*?://.*)\s*\n+').findall(html)
	##matches=re.compile('(\D+://.+?)\s*\n*\r*').findall(html)
	##debob(matches)
	#if len(matches) > 0:
	#	for match in matches:
	#		debob(match)
	#		#debob(nURL(match))
	#		PL.add(match,listitem)
	#
	html=html.replace('#EXT-X-STREAM-INF:PROGRAM-ID=','#EXT-X-STREAM-INF:NAME="'+title+'",PROGRAM-ID=')
	PlaylistFile=xbmc.translatePath(os.path.join(_addonPath,'resources','playlist.txt')); debob(PlaylistFile)
	_SaveFile(PlaylistFile,html)
	PL.add(PlaylistFile,listitem)
	try: _addon.resolve_url(url)
	except: t=''
	try: play=xbmc.Player(PlayerMeth); play.play(PL)
	except: t=''

def GetMedia(title='',url='',img=iconSite):
	__url=''+url
	try: _addon.resolve_url(url)
	except: pass
	if len(url)==0: return
	if mainSite not in url: url=mainSite+url
	deb('url',url)
	html=messupText(nURL(url),True)
	s='<div class="b-video" id="flashContent" data-videosrc="(.+?)" data-videodata="(.+?)">'; (data_videosrc,url2)=re.compile(s).findall(nolines(html))[0]; #deb('# of matches found',str(len(matches))); #debob(matches)
	deb('url2',url2)
	try: deb('data_videosrc',data_videosrc)
	except: pass
	if data_videosrc=='undefined':
		myNote("data-videosrc","undefined")
		#return
	html=messupText(nURL(url2),True)
	s='"urls"\s*:\s*{\s*".+?"\s*:\s*"(.+?)"'; url3=re.compile(s).findall(nolines(html))[0]; #deb('# of matches found',str(len(matches))); #debob(matches)
	url3=url3.replace('\/','/').replace('\\/','/')
	deb('url3',url3)
	#html=nURL(url3); deb('length of html',str(len(html))); debob(html); 
	
	PlayItCustomL2(__url,url3,img,title)
	#PlayItCustomL(__url,url3,img,title)
	#PlayItCustom(__url,url3,img,title)

def ListShows(url):
	if len(url)==0: return
	if mainSite not in url: url=mainSite+url
	deb('url',url)
	html=messupText(nURL(url),True); deb('length of html',str(len(html))); #debob(html)
	#html=spAfterSplit(html,''); html=spBeforeSplit(html,''); 
	if len(html)==0: return
	s='<li>\s*\n*\s*<a href="(/.+?)">\s*\n*\s*<img width="\d*" height="\d*" src="(http://.+?)" alt="(.+?)"\s*[/]*>\s*\n*\s*</a>\s*\n*\s*</li>'
	matches=re.compile(s).findall(html); ItemCount=len(matches); deb('# of matches found',str(len(matches))); debob(matches)
	if len(matches)==0: return
	for (_url,img,_name) in matches:
		_title=cFL_(_name,colors['1']); fimg=''+img
		pars={'mode':'GetMedia','url':_url,'title':_name,'img':img,'site':site}
		contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':''}
		contextMenuItems=ContextMenu_Movies(contextLabs)
		try: libs=MetaGrab("m",_name)
		except: libs={'title':_title}
		try: fimg=libs['backdrop_url']
		except: fimg=fanartSite
		try: _addon.add_directory(pars,libs,is_folder=False,contextmenu_items=contextMenuItems,total_items=ItemCount,fanart=fimg,img=img)
		except: pass
	set_view('movies',view_mode=addst('movies-view')); eod(); 

def Fav_List(site='',section='',subfav=''):
	debob(['test1',site,section,subfav])
	favs=fav__COMMON__list_fetcher(site=site,section=section,subfav=subfav)
	ItemCount=len(favs)
	debob('test2 - '+str(ItemCount))
	if len(favs)==0: myNote('Favorites','None Found'); eod(); return
	debob(favs)
	for (_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2) in favs:
		if _img > 0: img=_img
		else: img=iconSite
		if _fanart > 0: fimg=_fanart
		else: fimg=fanartSite
		debob('_ToDoParams'); debob(_ToDoParams)
		pars=_addon.parse_query(_ToDoParams)
		debob('pars'); debob(pars)
		_title=cFL_(_name,'white')
		if (len(_year) > 0) and (not _year=='0000'): _title+=cFL('  ('+cFL(_year,'deeppink')+')','pink')
		if len(_Country) > 0: _title+=cFL('  ['+cFL(_Country,'deeppink')+']','pink')
		try: pars['url']=pars['plugin://'+ps('addon_id')+'/?url']
		except: pass
		contextLabs={'title':_name,'year':_year,'img':_img,'fanart':_fanart,'country':_Country,'url':_Url,'plot':_plot,'genres':_Genres,'site':_site,'subfav':_subfav,'section':_section,'todoparams':_ToDoParams,'commonid':_commonID,'commonid2':_commonID2}
		##contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}
		contextMenuItems=ContextMenu_Favorites(contextLabs)
		#contextMenuItems=[]
		_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=False,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#
	#
	if 'movie' in section.lower(): content='movies'
	else: content='tvshows'
	set_view(content,view_mode=int(addst('tvshows-view'))); eod()

def Search_Site(title='',url='',page='',metamethod='',endit=True):
	#if url=='': url=mainSite+'anime/search'
	#if len(page) > 0: page='1'
	#deb('url',url)
	if (title==''): title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title)
	addstv('LastSearchTitle'+SiteTag,title) ## Save Setting ##
	title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','+')
	#title=title.replace(' ','+')
	if len(page) > 0: npage=str(int(page)+1); #p='&page='+page; 
	else: npage='2'; #p=''; 
	ListShows('/search?query='+title)
	#
	##deb('url and page',url+'?key='+title+'&search_submit=Go&page='+page)
	#html=nURL(url+'?key='+title+'&search_submit=Go&page='+page,headers={'Referer':mainSite})
	##html=nURL(url,method='get',form_data={'key':title,'search_submit':'Go','page':page},headers={'Referer':mainSite})
	#if (len(html)==0): myNote('Search:  '+title,'No page found.'); return
	###if '">Next</a></li>' in html: _addon.add_directory({'mode':'Page','site':site,'section':section,'url':url,'page':npage},{'title':cFL_('  .Next Page > '+npage,colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#addstv('LastSearchTitle'+SiteTag,title) ## Save Setting ##
	#Browse_Items(html,metamethod)
	#if endit==True: eod()




### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	###
	#_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=False,fanart=fanartSite,img=iconSite)
	#        main.addDir('Looney Tunes','Looney Tunes',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/LooneyTunes_video.jpg')
	#        main.addDir('Ozzy and Drix','Ozzy & Drix',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/OzzieDrix_video.jpg')
	#        main.addDir('Shaggy and Scoobydoo Get A Clue','Shaggy & Scooby-Doo Get A Clue!',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/ShaggyScoobyGetAClue_video.jpg')
	#        main.addDir('The Smurfs','Smurfs',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/smurf_video.jpg')
	#        main.addDir('The Flintstones','The Flintstones',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/Flintstones_video.jpg')
	#        main.addDir('The Jetsons','The Jetsons',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/Jetsons_video.jpg')
	#        main.addDir('The New Scoobydoo Mysteries','The New Scooby-Doo Mysteries',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/ScoobyDooMysteries_video.jpg')
	#        main.addDir('Thundercats','ThunderCats',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/Thundercats.jpg')
	#        main.addDir('Tom and Jerry Tales','Tom And Jerry Tales',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/TomJerryTales_video.jpg')
	#        main.addDir('Xiaolin Showdown','Xiaolin Showdown',78,'http://staticswf.kidswb.com/franchise/content/images/touts/video_channel_thumbs/XiaolinShowdown_video.jpg')
	
	#_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/','site':site},{'title':cFL_('Home List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/New-Arrivals-movies','site':site},{'title':cFL_('New Arrival List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/most-popular-movies','site':site},{'title':cFL_('Most Popular List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Staff-Picks-movies','site':site},{'title':cFL_('Staff Picks',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	#
	_addon.add_directory({'mode':'ListShows','url':'/Rock-Star-movies','site':site},{'title':cFL_('Rock Stars List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Action/Thriller-movies','site':site},{'title':cFL_('Action/Thriller List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Comedy-movies','site':site},{'title':cFL_('Comedy List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Horror-movies','site':site},{'title':cFL_('Horror List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Drama-movies','site':site},{'title':cFL_('Drama List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Romance-movies','site':site},{'title':cFL_('Romance List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Family/Kids-movies','site':site},{'title':cFL_('Family/Kids List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Urban-movies','site':site},{'title':cFL_('Urban List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Documentary/Shorts-movies','site':site},{'title':cFL_('Documentary/Shorts List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/TV-Series','site':site},{'title':cFL_('TV Series List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Bollywood-movies','site':site},{'title':cFL_('Bollywood List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Espanol-movies','site':site},{'title':cFL_('Espanol List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/Film-School-Originals-movies','site':site},{'title':cFL_('Film School Originals List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	#_addon.add_directory({'mode':'PlayURL','url':workingUrl,'site':site},{'title':cFL_('Listen to the Radio Stream',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/party2.png')
	#_addon.add_directory({'mode':'NowPlaying','site':site},{'title':cFL_('Now Playing...',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/format.png')
	#_addon.add_directory({'mode':'ListAZ','site':site},{'title':cFL('Song Requester',colors['4'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/request.png')
	##_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SlideShowStart','site':site},{'title':cFL_('Last[COLOR red]FM[/COLOR] SlideShow (Packaged)',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/party2.png')
	
	### Favorites
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'3'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'4'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'5'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'6'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'7'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	### Advanced Users - used to clean-up Favorites folders.
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'' },{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'2'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'3'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'4'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'5'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'6'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'7'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	###
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='NowPlaying'): 		NowPlaying()
	elif (mode=='ListShows'): 		ListShows(url)
	elif (mode=='GetMedia'): 			GetMedia(addpr('title',''),url,addpr('img',''))
	#elif (mode=='List'): 					Browse_List(addpr('title',''))
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='SlideShowStart'): path = os.path.join(_addonPath, 'c_SlideShow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
