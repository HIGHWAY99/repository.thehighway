### ############################################################################################################
###	#	
### # Project: 			#		The Anime Highway Remake - by The Highway 2013.
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re

from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_OpenFile,isPath,isFile,popYN,_SaveFile,popOK,CopyAFile)

### ############################################################################################################
### ############################################################################################################
SiteName='XBMC Fixes'
SiteTag='XBMCFixes'
mainSite=''
iconSite='http://i.imgur.com/XMClMrQ.png' #'http://xbmc.org/wp-content/themes/paradise/Paradise/images/logo.png' #_artIcon
fanartSite='http://s9.postimg.org/uy7tu92jz/1013960_471938356223940_1093377719_n.jpg' #'http://xbmc.org/wp-content/uploads/xbmc-eden-announce-2-650-1-600x336.jpg' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources','misc'))
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		#m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'videofun.me | video44.net | novamov.com | yourupload.com' # | play44.net | vidzur.com'
		#m+=CR+CR+'Valid Folders:  '
		#m+=CR+'script.module.urlresolver | script.module.urlresolver-master | script.module.urlresolver-2.0.9 | script.module.urlresolver-1.0.0'
		m+=CR+CR+'Features:  '
		m+=CR+'* Tools Related to XBMC.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* A Restart of XBMC may be needed after using some fixes before you notice changes.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+'My XBMC-HUB Refferal Code - http://www.xbmchub.com/forums/register.php?referrerid=15468  '+CR+'Please use it to register if you don\'t have an account.  It not\'s not much but it can help me out.  '
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def TP(s): return xbmc.translatePath(s)



### ############################################################################################################
### ############################################################################################################











### ############################################################################################################
### ############################################################################################################
def Tool_FixMouseMoveA():
	#ttFileName='mouse.xml'; 
	eMsgHead='Copy File: '+'mouse.xml'
	destPath=xbmc.translatePath(os.path.join('special://home','system'))
	if isPath(destPath)==False: myNote(eMsgHead,'Making Folder: '+'system'); os.mkdir(destPath)
	destPath=xbmc.translatePath(os.path.join(destPath,'keymaps'))
	if isPath(destPath)==False: myNote(eMsgHead,'Making Folder: '+'keymaps'); os.mkdir(destPath)
	fromFile='mouse.xml'; tFrom=xbmc.translatePath(os.path.join(workingPath,fromFile))
	toFile='mouse.xml'; tTo=xbmc.translatePath(os.path.join(destPath,toFile))
	r=popYN('Would you like to copy this File?',fromFile,'to:  '+tTo,'',n='Cancel',y='Copy It')
	if r==False: popOK('File could not be copied.',title=eMsgHead,line2='',line3='')
	elif (isFile(tFrom)==True) and (isFile(tTo)==False): CopyAFile(tFrom,tTo)
### ############################################################################################################
### ############################################################################################################
def Tool_Fix_1Channel_Remove_HostHandledCheck():
	eMsgHead='Fixing: '+'(plugin.video.1channel/default.py)'
	StringOld="if urlresolver.HostedMediaFile(item['url']).valid_url():"
	StringNew="if item==item: #urlresolver.HostedMediaFile(item['url']).valid_url():"
	destPath=xbmc.translatePath(os.path.join('special://home','addons','plugin.video.1channel'))
	if isPath(destPath)==False: myNote(eMsgHead,'Folder not found.'); return
	destFile=xbmc.translatePath(os.path.join(destPath,'default.py'))
	if isFile(destFile)==False: myNote(eMsgHead,'File not found.'); return
	CopyAFile(destFile,destFile+'.bup'); 
	tt=_OpenFile(destFile); 
	tt=tt.replace(StringOld,StringNew); 
	_SaveFile(destFile,tt); 
	myNote(eMsgHead,'File should now be fixed.')

def Tool_Fix_1Channel_Restore_HostHandledCheck():
	eMsgHead='Fixing: '+'(plugin.video.1channel/default.py)'
	StringOld="if item==item: #urlresolver.HostedMediaFile(item['url']).valid_url():"
	StringNew="if urlresolver.HostedMediaFile(item['url']).valid_url():"
	destPath=xbmc.translatePath(os.path.join('special://home','addons','plugin.video.1channel'))
	if isPath(destPath)==False: myNote(eMsgHead,'Folder not found.'); return
	destFile=xbmc.translatePath(os.path.join(destPath,'default.py'))
	if isFile(destFile)==False: myNote(eMsgHead,'File not found.'); return
	CopyAFile(destFile,destFile+'.bup'); 
	tt=_OpenFile(destFile); 
	tt=tt.replace(StringOld,StringNew); 
	_SaveFile(destFile,tt); 
	myNote(eMsgHead,'File should now be fixed.')

def Tool_Fix_LastFM_Remove_AccountNotice():
	eMsgHead='Fixing: '+'(plugin.audio.lastfm/default.py)'
	StringOld=" xbmc.executebuiltin('Notification(%s,%s,%i)' % (LANGUAGE(32011), LANGUAGE(32027), 7000))"
	StringNew=" ttTempFixTT='' #xbmc.executebuiltin('Notification(%s,%s,%i)' % (LANGUAGE(32011), LANGUAGE(32027), 7000))"
	destPath=xbmc.translatePath(os.path.join('special://home','addons','plugin.audio.lastfm'))
	if isPath(destPath)==False: myNote(eMsgHead,'Folder not found.'); return
	destFile=xbmc.translatePath(os.path.join(destPath,'utils.py'))
	if isFile(destFile)==False: myNote(eMsgHead,'File not found.'); return
	CopyAFile(destFile,destFile+'.bup'); 
	tt=_OpenFile(destFile); 
	tt=tt.replace(StringOld,StringNew); 
	_SaveFile(destFile,tt); 
	myNote(eMsgHead,'File should now be fixed.')

def Tool_Fix_LastFM_Restore_AccountNotice():
	eMsgHead='Fixing: '+'(plugin.audio.lastfm/default.py)'
	StringOld=" ttTempFixTT='' #xbmc.executebuiltin('Notification(%s,%s,%i)' % (LANGUAGE(32011), LANGUAGE(32027), 7000))"
	StringNew=" xbmc.executebuiltin('Notification(%s,%s,%i)' % (LANGUAGE(32011), LANGUAGE(32027), 7000))"
	destPath=xbmc.translatePath(os.path.join('special://home','addons','plugin.audio.lastfm'))
	if isPath(destPath)==False: myNote(eMsgHead,'Folder not found.'); return
	destFile=xbmc.translatePath(os.path.join(destPath,'utils.py'))
	if isFile(destFile)==False: myNote(eMsgHead,'File not found.'); return
	CopyAFile(destFile,destFile+'.bup'); 
	tt=_OpenFile(destFile); 
	tt=tt.replace(StringOld,StringNew); 
	_SaveFile(destFile,tt); 
	myNote(eMsgHead,'File should now be fixed.')


### ############################################################################################################
### ############################################################################################################



### ############################################################################################################
### ############################################################################################################



### ############################################################################################################
### ############################################################################################################






### ############################################################################################################
### ############################################################################################################


### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	cNumber ='8'; cNumber2='2'; cNumber3='4'; 
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	#
	_addon.add_directory({'mode':'1CHHostCheckRemove','site':site},{'title':cFL_('1CH - Remove Host Check (Faster Display)[CR]Thx for this fix goes to: HIGHWAY99',colors['9'])},is_folder=False,fanart='http://s9.postimg.org/w2vvcentb/primewire.jpg',img='http://i2.ytimg.com/vi/i_yPxLAlKzg/mqdefault.jpg')
	_addon.add_directory({'mode':'1CHHostCheckRestore','site':site},{'title':cFL_('1CH - Restore Host Check',colors['9'])},is_folder=False,fanart='http://s9.postimg.org/w2vvcentb/primewire.jpg',img='http://i2.ytimg.com/vi/i_yPxLAlKzg/mqdefault.jpg')
	
	_addon.add_directory({'mode':'LastFMAccountNoticeRemove','site':site},{'title':cFL_('LastFM - Remove Notice of username/pasword[CR]Thx for this fix goes to: vict0r',colors['9'])},is_folder=False,fanart='http://s9.postimg.org/w2vvcentb/primewire.jpg',img='http://i2.ytimg.com/vi/i_yPxLAlKzg/mqdefault.jpg')
	_addon.add_directory({'mode':'LastFMAccountNoticeRestore','site':site},{'title':cFL_('LastFM - Restore Notice of username/pasword',colors['9'])},is_folder=False,fanart='http://s9.postimg.org/w2vvcentb/primewire.jpg',img='http://i2.ytimg.com/vi/i_yPxLAlKzg/mqdefault.jpg')
	
	
	#
	#
	#
	if isFile(TP(os.path.join(workingPath,'mouse.xml')))==True: _addon.add_directory({'mode':'FixMouseMove','site':site},{'title':cFL_('Prevent exiting FullScreen due to Mouse Movement [CR]while watching a video. (Mouse.xml) [restart]',colors['9'])},is_folder=False,fanart='http://i00.i.aliimg.com/wsphoto/v1/673900382_2/T2-Air-Fly-Mouse-2-4G-3D-Motion-Stick-Remote-PC-Mouse-for-TV-Box-TV.jpg',img='http://i138.photobucket.com/albums/q260/Ygdrassil/stuff/Mouse-Keyboard-B-1815.jpg')
	#
	eod()

### ############################################################################################################
### ############################################################################################################

def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='CopyPlugin'): 		CopyPlugin(addpr('title',''))
	elif (mode=='List'): 					Browse_List(url,page)
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='AZ'): 						Browse_AZ()
	elif (mode=='Genres'): 				Browse_Genres()
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='FixMouseMove'): 	Tool_FixMouseMoveA()
	elif (mode=='1CHHostCheckRemove'):	Tool_Fix_1Channel_Remove_HostHandledCheck()
	elif (mode=='1CHHostCheckRestore'):	Tool_Fix_1Channel_Restore_HostHandledCheck()
	elif (mode=='LastFMAccountNoticeRemove'):	Tool_Fix_LastFM_Remove_AccountNotice()
	elif (mode=='LastFMAccountNoticeRestore'):	Tool_Fix_LastFM_Restore_AccountNotice()
	elif (mode=='About'): 				About()
	#elif (mode=='FavList'): 			Fav_List(site,section)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
	
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
