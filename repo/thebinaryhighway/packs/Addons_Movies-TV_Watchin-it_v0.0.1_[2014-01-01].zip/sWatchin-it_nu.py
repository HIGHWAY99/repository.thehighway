### ############################################################################################################
###	#	
### # Site: 				#		Watchin-it - http://www.watchin-it.nu/
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui

from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_SaveFile)
### ############################################################################################################
### ############################################################################################################
SiteName='Watchin-it  [v0.0.1]  [Movies-TV]'
SiteTag='Watchin-it.nu'
mainSite='http://www.watchin-it.nu'
iconSite='http://www.watchin-it.nu/images/logo_xmas.png' #_artIcon
fanartSite='http://www.watchin-it.nu/styles/prosilver_se/theme/images/1bg-tile.png' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl=mainSite+'ram.pls'
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'Live Streams (RTMPE)'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Videos'
		m+=CR+'* Play Videos'
		m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t

### ############################################################################################################
### ############################################################################################################

def GetMedia(title='',url='',img=iconSite,fimg=fanartSite):
	__url=''+url
	#try: _addon.resolve_url(url)
	#except: pass
	if len(url)==0: return
	if mainSite not in url: url=mainSite+url
	deb('url',url)
	html=messupText(nolines(nURL(url)),True,True)
	s='<td style="padding-right:10px;padding-left:10px;padding-top:10px;padding-bottom:10px;"><center>\s*\n*\s*<a class="image2" href="(http://.+?)" target="1">'; 
	matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	import urlresolver
	for url2 in matches:
		#if ' ' in url2: url2=url2.split(' ')[0]
		deb('url2',url2)
		if urlresolver.HostedMediaFile(url2).valid_url():
			pars={'title':title,'img':img,'fanart':fimg,'url':url2,'mode':'PlayFromHost','streamurl':url2,'site':site}
			libs={'title':url2.replace('http://','').split('/')[0],'img':img}
			contextMenuItems=[]
			try: _addon.add_directory(pars,libs,is_folder=False,contextmenu_items=contextMenuItems,total_items=len(matches),fanart=fimg,img=img)
			except: pass
	set_view('movies',view_mode=addst('movies-view')); eod(); 

def ListShows(url):
	if len(url)==0: return
	if mainSite not in url: url=mainSite+url
	deb('url',url); html=messupText(nolines(nURL(url)),True,True); deb('length of html',str(len(html))); #html=spAfterSplit(html,''); html=spBeforeSplit(html,''); #debob(html)
	if len(html)==0: return
	### Next Page Coding ###
	try: (nextPageUrl,nextPageNum)=re.compile('<a href="(index.php.[A-Za-z0-9\-\=\&]+&page=(\d+))">next ').findall(html)[0]; 
	except: nextPageNum=''
	if len(nextPageNum) > 0:
		deb('NextPageUrl','/'+nextPageUrl); 
		try: _addon.add_directory({'mode':'ListShows','url':'/'+nextPageUrl,'site':site},{'title':cFL_('Next Page ('+str(nextPageNum)+')',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
		except: pass
	### /\ ###
	#
	s ='<li><a\s+href="(index.php.movieAct=movie&movie=(\d+))".*?title="(.+?)".*?><img\s+class="poster"\s+src="(watchinIncludes/imdb/posters/([0-9A-Za-z]+).jpg)"\s*/><br\s*/>'; s+='\s*<font\s+class="name">\s*((.+?)\s*\((\d\d\d\d)\))\s*</font></a></li>'
	matches=re.compile(s).findall(html); ItemCount=len(matches); deb('# of matches found',str(len(matches))); #debob(matches)
	if len(matches)==0: return
	for (_url,_MovieID,_TitleOnly,img,_IMDB_ID,_TitleAndDate,_name,_year) in matches:
		img=mainSite+'/'+img; fimg=''+img; 
		if ' ('+_year+')' in _TitleOnly: _title=cFL_(_TitleOnly,colors['1']); 
		else: _title=cFL_(_TitleOnly.strip()+' ('+_year+')',colors['1']); # cFL_(_name,colors['1']); 
		if ' - S0' in _TitleOnly:
			deb('Title',_TitleOnly.split(' - S')[0])
			try: libs=MetaGrab("t",_TitleOnly.split(' - S')[0].strip(),year=_year,imdb_id=_IMDB_ID)
			except: libs={'title':_title,'year':_year}
		else:
			deb('Title',_TitleOnly.replace(' ('+_year+')',''))
			try: libs=MetaGrab("m",_TitleOnly.replace(' ('+_year+')','').strip(),year=_year,imdb_id=_IMDB_ID)
			except: libs={'title':_title,'year':_year}
		#
		try: 		fimg=libs['backdrop_url']
		except: fimg=fanartSite
		try: 		_plot=libs['plot']
		except: _plot=''
		try: libs[u'title']=_title
		except: pass
		pars={'mode':'GetMedia','url':'/'+_url,'title':_TitleAndDate,'img':img,'fanart':fimg,'site':site,'year':_year,'showtitle':_TitleOnly}
		contextLabs={'title':_TitleOnly,'year':_year,'url':'/'+_url,'img':img,'fanart':fimg,'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section,'plot':_plot}
		contextMenuItems=ContextMenu_Movies(contextLabs)
		try: _addon.add_directory(pars,libs,is_folder=True,contextmenu_items=contextMenuItems,total_items=ItemCount,fanart=fimg,img=img)
		except: pass
	set_view('movies',view_mode=addst('movies-view')); eod(); 

def Fav_List(site='',section='',subfav=''):
	debob(['test1',site,section,subfav])
	favs=fav__COMMON__list_fetcher(site=site,section=section,subfav=subfav)
	ItemCount=len(favs)
	debob('test2 - '+str(ItemCount))
	if len(favs)==0: myNote('Favorites','None Found'); eod(); return
	debob(favs)
	for (_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2) in favs:
		if _img > 0: img=_img
		else: img=iconSite
		if _fanart > 0: fimg=_fanart
		else: fimg=fanartSite
		debob('_ToDoParams'); debob(_ToDoParams)
		pars=_addon.parse_query(_ToDoParams)
		debob('pars'); debob(pars)
		_title=cFL_(_name,'white')
		if (len(_year) > 0) and (not _year=='0000'): _title+=cFL('  ('+cFL(_year,'deeppink')+')','pink')
		if len(_Country) > 0: _title+=cFL('  ['+cFL(_Country,'deeppink')+']','pink')
		try: pars['url']=pars['plugin://'+ps('addon_id')+'/?url']
		except: pass
		contextLabs={'title':_name,'year':_year,'img':_img,'fanart':_fanart,'country':_Country,'url':_Url,'plot':_plot,'genres':_Genres,'site':_site,'subfav':_subfav,'section':_section,'todoparams':_ToDoParams,'commonid':_commonID,'commonid2':_commonID2}
		##contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}
		contextMenuItems=ContextMenu_Favorites(contextLabs)
		#contextMenuItems=[]
		_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#
	#
	if 'movie' in section.lower(): content='movies'
	else: content='tvshows'
	set_view(content,view_mode=int(addst('tvshows-view'))); eod()

def Search_Site(title='',url='',page='',metamethod='',endit=True):
	# http://www.watchin-it.nu/index.php?movieSort=search&search=1
	# <form name="movieSubmit" action="index.php?movieSort=search&search=1" method="POST">Search: <input type="text" name="search" ><input type="submit" class="button2 alignright" name="submit" value="Go" />
	# 
	##if url=='': url=mainSite+'anime/search'
	##if len(page) > 0: page='1'
	##deb('url',url)
	#if (title==''): title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	#if (title=='') or (title=='none') or (title==None) or (title==False): return
	#deb('Searching for',title)
	#addstv('LastSearchTitle'+SiteTag,title) ## Save Setting ##
	#title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','+')
	##title=title.replace(' ','+')
	#if len(page) > 0: npage=str(int(page)+1); #p='&page='+page; 
	#else: npage='2'; #p=''; 
	#ListShows('/search?query='+title)
	return




### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	#_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	###
	#_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/index.php','site':site},{'title':cFL_('Home List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','url':'/index.php?movieSort=latest','site':site},{'title':cFL_('Latest Releases',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'mode':'ListShows','url':'/most-popular-movies','site':site},{'title':cFL_('Most Popular List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'ListShows','url':'/Staff-Picks-movies','site':site},{'title':cFL_('Staff Picks',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	
	#_addon.add_directory({'mode':'PlayURL','url':workingUrl,'site':site},{'title':cFL_('Listen to the Radio Stream',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/party2.png')
	#_addon.add_directory({'mode':'NowPlaying','site':site},{'title':cFL_('Now Playing...',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/format.png')
	#_addon.add_directory({'mode':'ListAZ','site':site},{'title':cFL('Song Requester',colors['4'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/request.png')
	##_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SlideShowStart','site':site},{'title':cFL_('Last[COLOR red]FM[/COLOR] SlideShow (Packaged)',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/party2.png')
	
	### Favorites
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'3'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'4'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'5'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'6'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'7'},{'title':cFL_(ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	###
	
	for az in MyAlphabet:
		_addon.add_directory({'mode':'ListShows','url':'/index.php?movieSort=name&name='+az.upper(),'site':site},{'title':cFL_(az.upper(),colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	### Advanced Users - used to clean-up Favorites folders.
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'' },{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.1.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'2'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.2.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'3'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.3.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'4'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.4.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'5'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.5.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'6'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.6.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':'7'},{'title':cFL_('Clear '+ps('WhatRFavsCalled')+addst('fav.tv.7.name'),ps('cFL_color3'))},fanart=fanartSite,img=iconSite)
	###
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='NowPlaying'): 		NowPlaying()
	elif (mode=='ListShows'): 		ListShows(url)
	elif (mode=='GetMedia'): 			GetMedia(addpr('title',''),url,addpr('img',''),addpr('fanart',''))
	#elif (mode=='List'): 					Browse_List(addpr('title',''))
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='SlideShowStart'): path = os.path.join(_addonPath, 'c_SlideShow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
