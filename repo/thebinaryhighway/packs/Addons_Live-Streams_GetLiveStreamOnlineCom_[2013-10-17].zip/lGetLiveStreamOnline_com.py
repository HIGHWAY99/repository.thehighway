### ############################################################################################################
###	#	
### # Site: 				#		Anime44 - http://www.anime44.com/
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re

from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart,PlayItCustom)
### ############################################################################################################
### ############################################################################################################
SiteName='Get Live Stream Online  [v0.0.1]  [Streams] *  (Player Broken|iLiVE)'
SiteTag='getlivestreamonline.com'
mainSite='http://www.getlivestreamonline.com/'
iconSite='http://www.getlivestreamonline.com/thumbnails/1328241506.png'
fanartSite=_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		m+=CR+CR+'Known Hosts for Videos:  '
		m+=CR+'videofun.me | video44.net | novamov.com | yourupload.com' # | play44.net | vidzur.com'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Items on Pages'
		m+=CR+'* Browse Url/Name-only Items on Pages'
		m+=CR+'* Browse Episodes - Browse Episodes, Movies and other such Items.'
		m+=CR+'* Browse Hosts.'
		m+=CR+'* Uses urlResolver().'
		m+=CR+'* Play Videos via Handled Hosts.'
		m+=CR+'* Browse Genres and A-Z - Browse Item Pages by A-Z/Others or by Genres (fetched from the site with item count for each genre.'
		m+=CR+'* Search - Just a normal Title Search was available for this site, though it uses a Post-method and their site search seems to have some problems at times.'
		m+=CR+'* Repeat Last Search - Like it says, this shows up once you\'ve done a Search for the first time and allows you to repeat the last search term you used for this Site.  Yes, it\'s setup to save the setting for each site seperately.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* This site doesn\'t seem to have as many methods to browse Movies.  About all there seemed to be was a single long Url/Name-ONLY list.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
### ############################################################################################################
### ############################################################################################################

def Search_Site(title='',url='',page='',metamethod='',endit=True):
	if url=='': url=mainSite+'anime/search'
	if len(page) > 0: page='1'
	deb('url',url)
	if (title==''): title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title)
	title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','+')
	#title=title.replace(' ','+')
	if len(page) > 0: npage=str(int(page)+1); #p='&page='+page; 
	else: npage='2'; #p=''; 
	deb('url and page',url+'?key='+title+'&search_submit=Go&page='+page)
	html=nURL(url+'?key='+title+'&search_submit=Go&page='+page,headers={'Referer':mainSite})
	#html=nURL(url,method='get',form_data={'key':title,'search_submit':'Go','page':page},headers={'Referer':mainSite})
	if (len(html)==0): myNote('Search:  '+title,'No page found.'); return
	##if '">Next</a></li>' in html: _addon.add_directory({'mode':'Page','site':site,'section':section,'url':url,'page':npage},{'title':cFL_('  .Next Page > '+npage,colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	addstv('LastSearchTitle'+SiteTag,title) ## Save Setting ##
	Browse_Items(html,metamethod)
	if endit==True: eod()





def Browse_Page(url,page='',metamethod=''):
	if url=='': return
	if len(page) > 0: p='/'+page; npage=str(int(page)+1)
	else: p=''; npage='2'
	deb('url and page',url+p)
	html=nURL(url+p)
	if (len(html)==0): return
	if '">Next</a></li>' in html: _addon.add_directory({'mode':'Page','site':site,'section':section,'url':url,'page':npage},{'title':cFL_('  .Next Page > '+npage,colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	Browse_Items(html,metamethod)
	eod()

def Browse_Items(html,metamethod='',content='tvshows',view='515'):
	if (len(html)==0): return
	s='<a href="(.+?)"><img src="(.+?)" width="120" height="168" alt="Watch (.+?) online"'; html=messupText(html,True,True); matches=re.compile(s).findall(html) #,re.DOTALL
	ItemCount=len(matches)
	if ItemCount > 0:
		#debob(matches)
		for _url,_img,_name in matches:
			labs={}; _NameTag='alt="Watch '+_name+' online"'; SN1S='<span class="small">'; SN1B='<span class="bold">'; SN2='</span>'
			img =''+_img; fimg=''+_img ##img=_artIcon; fimg=_artFanart
			try: 
				labs['plot']=html.split(_NameTag)[1].split('<div class="descr">')[1].split('</div>')[0].strip()
				if ('[<a href' in labs['plot']): labs['plot']=labs['plot'].split('[<a href')[0].strip()
				labs['plot']+='...'
				labs['plot']=cFL(labs['plot'],colors['12'])
			except: labs['plot']=''
			try: labs['year']=html.split(_NameTag)[1].split(SN1S+'Released:'+SN2)[1].split(SN1B)[1].split(SN2)[0].strip()
			except: labs['year']=''
			if len(labs['year']) > 0: labs['plot']+=CR+cFL('Year:  ',colors['11'])+cFL(labs['year'],colors['10'])
			try: labs['type']=html.split(_NameTag)[1].split('<span class="type_indic">')[1].split(SN2)[0].strip()
			except: labs['type']=''
			if len(labs['type']) > 0: labs['plot']+=CR+cFL('Video Type:  ',colors['11'])+cFL(labs['type'],colors['10'])
			try: labs['status']=html.split(_NameTag)[1].split(SN1S+'Status:'+SN2)[1].split(SN1B)[1].split(SN2)[0].strip()
			except: labs['status']=''
			if len(labs['status']) > 0: labs['plot']+=CR+cFL('Status:  ',colors['11'])+cFL(labs['status'],colors['10'])
			try: labs['rating']=html.split(_NameTag)[1].split(SN1S+'Rating:'+SN2)[1].split(SN1B)[1].split(SN2)[0].strip()
			except: labs['rating']=''
			if len(labs['rating']) > 0: labs['plot']+=CR+cFL('Rating:  ',colors['11'])+cFL(labs['rating'],colors['10'])
			if   'movie' in labs['type'].lower(): section='movie'
			elif 'show'  in labs['type'].lower(): section='series'
			else: section='series'
			#
			contextLabs={'title':_name,'year':labs['year'],'url':_url,'img':img,'fanart':fimg}
			if   section=='movie':  contextMenuItems=ContextMenu_Movies(contextLabs)
			elif section=='series': contextMenuItems=ContextMenu_Series(contextLabs)
			else: contextMenuItems=[]
			pars={'mode':'Episodes','site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg,'year':labs['year']}
			labs['title']=cFL_(_name,'white')
			_addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
	set_view(content,view_mode=addst('tvshows-view')); #set_view(content,int(view)); 
	#eod()


def Browse_List(url,page='',content='tvshows',view='515'):
	if url=='': return
	html=nURL(url); html=messupText(html,True,True)
	html=spAfterSplit(html,'<div id="videos_link">'); html=spAfterSplit(html,'<div id="videos">'); html=spBeforeSplit(html,'<ul class="pagination">')
	s='<li>\s*\n*\s*<a href="(.+?)">\s*\n*\s*(.+?)\s*\n*\s*</a>\s*\n*\s*</li>'
	matches=re.compile(s).findall(html)
	ItemCount=len(matches)
	if ItemCount > 0:
		for _url,_name in matches:
			labs={}; labs['plot']=''
			img=''+thumbnail; fimg=''+fanart ##img=_artIcon; fimg=_artFanart
			_title=''+cFL_(_name,'white')
			#
			contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':''}
			if   section=='movies':  contextMenuItems=ContextMenu_Movies(contextLabs)
			elif section=='series': contextMenuItems=ContextMenu_Series(contextLabs)
			else: contextMenuItems=[]
			if section=='movies': pars={'mode':'Hosts'   ,'site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}
			else:                pars={'mode':'Episodes','site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}
			labs['title']=_title
			_addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
	set_view(content,int(addst('episode-view'))); eod()

def getToken(url):
	html=net.http_GET(url).content
	token_url=re.compile('\$.getJSON\("(.+?)",').findall(html)[0]
	import datetime,time
	time_now=datetime.datetime.now()
	epoch=time.mktime(time_now.timetuple())+(time_now.microsecond/1000000.)
	epoch_str=str('%f' % epoch); epoch_str=epoch_str.replace('.',''); epoch_str=epoch_str[:-3]
	token_url=token_url + '&_=' + epoch_str
	#
	tokhtml=net.http_GET(token_url+'&_='+str(epoch), headers={'Referer':url}).content
	debob('tokhtml: ')
	debob(tokhtml)
	token=re.compile('":"(.+?)"').findall(tokhtml)[0]
	token=re.compile('":"(.+?)"').findall(net.http_GET(token_url+'&_='+str(epoch), headers={'Referer':url}).content)[0]
	#if '#' in token: token=token.split('#')[0]
	#if '#' in token: token=token.split('#')[1]
	#if '#' in token: token=token.split('#')[0]+token.split('#')[1]
	debob(token)
	return token

def iLivePlay(mname,murl,thumb):
	myNote('Please Wait!','Opening Stream',3000); stream_url=False; link=nURL(murl); deb('murl',murl)
	if link:
		link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
		match=re.compile('http://www.ilive.to/embed/(.+?)&width=(.+?)&height=(.+?)&autoplay=true').findall(link)
		#debob(match)
		_fid=''
		for fid,wid,hei in match: pageUrl='http://www.ilive.to/embedplayer.php?width='+wid+'&height='+hei+'&channel='+fid+'&autoplay=true'; debob(pageUrl); _fid=fid
		#debob(pageUrl)
		#link=nURL(pageUrl); playpath=re.compile('file: "(.+?).flv"').findall(link); token=getToken(pageUrl)
		link=nURL(pageUrl); playpath=re.compile('file\s*:\s*"(.+?)\.flv"').findall(link); token=getToken(pageUrl); debob(playpath)
		if len(playpath)==0: playpath=re.compile('http://snapshots.ilive.to/snapshots/(.+?)_snapshot.jpg').findall(thumb); debob(playpath)
		#for playPath in playpath: debob(playPath); stream_url='rtmp://live.ilive.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		#for playPath in playpath: debob(playPath); stream_url='rtmp://live.ilive.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		#for playPath in playpath: debob(playPath); stream_url='rtmp://live.ilive.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/secure_player_ilive_z.swf pageUrl="+pageUrl+" token="+token
		
		for playPath in playpath: debob(playPath); stream_url='rtmp://live.ilive.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		#for playPath in playpath: debob(playPath); stream_url='rtmp://stream.ilive.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		#for playPath in playpath: debob(playPath); stream_url='rtmp://stream.ilive.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/secure_player_ilive_z.swf pageUrl="+pageUrl+" token="+token
		#for playPath in playpath: debob(playPath); stream_url='rtmp://live.ilive.to:1935/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/secure_player_ilive_z.swf pageUrl="+pageUrl+" token="+token
		
		#for playPath in playpath: debob(playPath); stream_url='rtmp://stream.ilive.to:1935/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		#for playPath in playpath: debob(playPath); stream_url='rtmp://live.ilive.to:1935/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token
		
		#for playPath in playpath: debob(playPath); stream_url='rtmp://stream.ilive.to:1935/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/player.swf pageUrl="+pageUrl+" token="+token

def GetLiveFeed(url,title,ithumb):
	if url=='': return
	myNote('Checking Page',url,1500); debob(url)
	html=nURL(url); html=messupText(html,True,True); 
	#html=spAfterSplit(html,'<div class="main_content"'); 
	#html=spAfterSplit(html,'<div id="movie"'); 
	#html=spBeforeSplit(html,'</div>');
	s='<center><script type="text/javascript" src="(http://.*?)"></script></center>'
	#debob(html)
	matches=re.compile(s).findall(html); debob(matches)
	ItemCount=len(matches)
	if (ItemCount > 0):
		myNote('Checking Page',matches[0],1500)
		if ('http://www.ilive.to/embed/' in matches[0]):
			match=re.compile('http://www.ilive.to/embed/(.+?)&width=(.+?)&height=(.+?)&autoplay=true').findall(matches[0])
			for fid,wid,hei in match: pageUrl='http://www.ilive.to/embedplayer.php?width='+wid+'&height='+hei+'&channel='+fid+'&autoplay=true'; debob(pageUrl)
			link=nURL(pageUrl); playpath=re.compile('file\s*:\s*"(.+?)\.flv"').findall(link); token=getToken(pageUrl); debob(playpath)
			if len(playpath)==0: playpath=re.compile('http://snapshots.ilive.to/snapshots/(.+?)_snapshot.jpg').findall(thumb); debob(playpath)
			for playPath in playpath: debob(playPath); stream_url='rtmp://live.ilive.to/edge playpath='+playPath+" live=1 timeout=15 swfUrl=http://player.ilive.to/player_ilive_2.swf pageUrl="+pageUrl+" token="+token; debob(stream_url)
			PlayItCustom(url=url,stream_url=stream_url,img='http://snapshots.ilive.to/snapshots/'+playPath+'_snapshot.jpg',title=title)

def Browse_XML(url,page='',content='tvshows',view='515'):
	if url=='': return
	html=nURL(url); html=messupText(html,True,True)
	###html=spAfterSplit(html,'<div id="videos_link">'); html=spAfterSplit(html,'<div id="videos">'); html=spBeforeSplit(html,'<ul class="pagination">')
	s='<url>\s*\n*\s*<loc>(http://.*?)</loc>\s*\n*\s*<video:video>\s*\n*\s*<video:thumbnail_loc>(http://.*?)</video:thumbnail_loc>\s*\n*\s*<video:title>(.*?)</video:title>\s*\n*\s*<video:description>(.*?)</video:description>\s*\n*\s*</video:video>\s*\n*\s*</url>'
	matches=re.compile(s).findall(html)
	ItemCount=len(matches)
	if ItemCount > 0:
		for _url,_thumb,_name,_desc in matches:
			labs={}; labs['plot']=''+_desc
			img=''+_thumb; fimg=''+_thumb ##img=_artIcon; fimg=_artFanart
			_nameA=''+_name; _name=_name.replace(' free','').replace(' Free','').replace(' Online','').replace(' online','').replace(' Streaming','').replace(' Stream','').replace(' Live','').replace(' live','').replace(' Channel','').replace(' TV','').replace(' Watch','').replace(' watch','').replace(' streaming','').replace(' Tv','').replace(' channel','').replace(' tv','').replace(' stream','')
			_title=''+cFL_(_name,'white')
			#
			contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':''}
			#if   section=='movies':  contextMenuItems=ContextMenu_Movies(contextLabs)
			#elif section=='series': contextMenuItems=ContextMenu_Series(contextLabs)
			#else: contextMenuItems=[]
			contextMenuItems=[]
			#if section=='movies': pars={'mode':'Hosts'   ,'site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}
			#else:                pars={'mode':'Episodes','site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}
			pars={'mode':'GetLiveFeed','site':site,'section':section,'title':_name,'url':_url,'img':img,'fanart':fimg}
			labs['title']=_title
			_addon.add_directory(pars,labs,is_folder=False,fanart=fimg,img=img,contextmenu_items=contextMenuItems,total_items=ItemCount)
	set_view('tvshows',int(addst('tvshows-view'))); eod()



### ############################################################################################################
### ############################################################################################################
def SubMenu(): #(site,section=''):
	if section=='movies':
		scolor=colors['1']
		_addon.add_directory({'mode':'Page','site':site,'section':section,'url':mainSite+'popular-movies'},{'title':cFL_('Popular',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'Page','site':site,'section':section,'url':mainSite+'new-movies'},{'title':cFL_('New Series',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'Page','site':site,'section':section,'url':mainSite+'recent-movies'},{'title':cFL_('Recent',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'AZ','site':site,'section':section},{'title':cFL_('A-Z',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'Genres','site':site,'section':section},{'title':cFL_('Genres',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
	if section=='series':
		scolor=colors['2']
		_addon.add_directory({'mode':'Page','site':site,'section':section,'url':mainSite+'popular-anime'},{'title':cFL_('Popular',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'Page','site':site,'section':section,'url':mainSite+'new-anime'},{'title':cFL_('New Series',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'Page','site':site,'section':section,'url':mainSite+'recent-anime'},{'title':cFL_('Recent',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'Page','site':site,'section':section,'url':mainSite+'ongoing-anime'},{'title':cFL_('Ongoing Series',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'Page','site':site,'section':section,'url':mainSite+'completed-anime'},{'title':cFL_('Completed',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'AZ','site':site,'section':section},{'title':cFL_('A-Z',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
		_addon.add_directory({'mode':'Genres','site':site,'section':section},{'title':cFL_('Genres',scolor)},is_folder=True,fanart=fanartSite,img=iconSite)
	set_view('list',view_mode=addst('default-view')); eod()
	#

def SectionMenu():
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'XML','site':site,'section':'movies','url':mainSite+'videositemap-1.xml'},{'title':cFL_('Browse XML (videositemap-1.xml)',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'List','site':site,'section':'movies','url':mainSite+'category/anime-movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'series'},{'title':cFL_('Anime Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'ongoing-anime'},{'title':cFL_('Ongoing Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'new-anime'},{'title':cFL_('New Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Episodes','site':site,'section':'series','url':mainSite+'surprise'},{'title':cFL_('Suprise Me',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Search','site':site,'section':'series'},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	#_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	
	set_view('list',view_mode=addst('default-view')); eod()



### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='SubMenu'): 			SubMenu() #(site,section)
	elif (mode=='Page'): 					Browse_Page(url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='Episodes'): 			Browse_Episodes(url,page)
	elif (mode=='List'): 					Browse_List(url,page)
	elif (mode=='XML'): 					Browse_XML(url)
	elif (mode=='GetLiveFeed'): 	GetLiveFeed(url,addpr('title',''),addpr('img',''))
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='AZ'): 						Browse_AZ()
	elif (mode=='Genres'): 				Browse_Genres()
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#elif (mode=='FavList'): 			Fav_List(site,section)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
	
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
