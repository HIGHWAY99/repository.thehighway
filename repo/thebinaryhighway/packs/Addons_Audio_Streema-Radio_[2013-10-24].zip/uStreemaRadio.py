### ############################################################################################################
###	#	
### # Site: 				#		Streema - http://streema.com/
### # Author: 			#		The Highway
### # Description: 	#		
### # Credits: 			#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import common
from common import *
from common import (_debugging,_addon,_artIcon,_artFanart,_addonPath,_OpenFile,isPath,isFile,popYN,_SaveFile,popOK,CopyAFile,RefreshList,DownloadThis,getFileExtension)
### ############################################################################################################
### ############################################################################################################
SiteName='Streema Radio (v0.0.1)  [Radio]'
SiteTag='streema.com'
mainSite='http://streema.com/'
iconSite='http://d2kvtqb4z47ggs.cloudfront.net//img/landing/icon_radios.png' #'streema.com/static/img/logo.streema.header.png' #_artIcon
fanartSite='http://d2kvtqb4z47ggs.cloudfront.net/img/txture_25px.png?ed9ae27f1886' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl='http://themoonlitroad.libsyn.com/rss'
workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources'))
workingFile='themoonlitroad.txt'
workingFileWP=xbmc.translatePath(os.path.join(workingPath,workingFile))
### ############################################################################################################
### ############################################################################################################
site=addpr('site',''); section=addpr('section',''); url=addpr('url',''); thumbnail=addpr('img',''); fanart=addpr('fanart',''); page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'... | ... | ... | ...'
		m+=CR+CR+'Features:  '
		m+=CR+'* Grab Listings in English, French, or Dutch.'
		#m+=CR+'* '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+CR+'Notes:  '
		m+=CR+'* Those with a "[COLOR red] *[/COLOR]" may have a good chance of not working.'
		m+=CR+'* Not all stations will play.  There\'s simply too many to try and make sure every single one will work.  So please be happy with what does.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
def TP(s): return xbmc.translatePath(s)
def TPap(s,fe='.py'): return xbmc.translatePath(os.path.join(_addonPath,s+fe))
### ############################################################################################################
### ############################################################################################################
def UpdateWorkingFile(): _SaveFile(workingFileWP,messupText(nURL(workingUrl),True,True))


def GetMedia(url,img,title):
	html=nURL(url)
	s='\\"url\\"\s*:\s*\\"(http://.+?)\\"'; 
	#s='\\"url\\"\s*:\s*\\"(http://.+?pls.*?)\\"'; 
	#stream_url=re.compile(s).findall(nolines(html))[0]; debob(stream_url)
	#stream_url=re.compile(s).findall(nolines(html))[1]; debob(stream_url)
	#PlayURL(stream_url); return
	#PlayItCustom(url,stream_url,img,title,studio=''); #return
	try: matches=re.compile(s).findall(nolines(html)) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		debob(matches)
		for stream_url in matches:
			if ('pls' in stream_url) or ('.flv' in stream_url) or ('.mp3' in stream_url) or ('rtmp://' in stream_url) or ('.asx' in stream_url):
				#try: PlayURL(stream_url); return
				try: PlayItCustom(url,stream_url,img,title,studio=''); return
				except: pass
		stream_url=re.compile(s).findall(nolines(html))[0]; debob(stream_url)
		PlayItCustom(url,stream_url,img,title,studio=''); #return
		#for stream_url in matches:
		#	#try: PlayURL(stream_url); return
		#	try: PlayItCustom(url,stream_url,img,title,studio=''); return
		#	except: pass



def TestPlay(url):
	try: _addon.resolve_url(url)
	except: pass
	deb('url',url); import c_HiddenDownloader as downloader; downloader.download(url,'test.mp3',workingPath,False)

def SubMenu2(url,domain):
	if len(url) > 7:
		if url[:7]=='http://': url2=url
		else: url2=domain+url
	else: url2=domain+url
	deb('url 2 get',url2); html=messupText(nolines(nURL(url2)),True,True)
	try: 
		next_page=re.compile('<li\s*class="next">\s*<a href="(/.+?)"\s*class="next">\s*Next\s*&raquo;</a>\s*</li>').findall(nolines(html))[0]; deb('next page',next_page)
		_addon.add_directory({'url':next_page,'mode':'SubMenu2','domain':domain,'site':site},{'title':'['+cFL('NEXT',colors['8'])+']'},is_folder=True,fanart=fanartSite,img=iconSite)
	except: pass
	#try: 
	#	more_page=re.compile('<a\s*href="(.+?)">More</a>').findall(nolines(html))[0]; deb('more page',more_page)
	#	_addon.add_directory({'url':url+more_page,'mode':'SubMenu2','domain':domain,'site':site},{'title':'['+cFL('MORE',colors['8'])+']'},is_folder=True,fanart=fanartSite,img=iconSite)
	#except: pass
	if '<a href="?type=more-stations">More</a>' in nolines(html): _addon.add_directory({'url':url+'?type=more-stations','mode':'SubMenu2','domain':domain,'site':site},{'title':'['+cFL('MORE',colors['8'])+']'},is_folder=True,fanart=fanartSite,img=iconSite)
	s='<li>\s*<a\s*href="(/[0-9A-Za-z/_\-=\?&]+)\s*"\s*>\s*(.+?)\s*<'; 
	try: matches=re.compile(s).findall(nolines(html)) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		#debob('lists'); debob(matches)
		for (_url,_name) in matches:
			if not _name in ['TV','Radio']: _addon.add_directory({'url':_url,'mode':'SubMenu2','domain':domain,'site':site},{'title':'List: '+cFL_(_name,colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	###
	#s='<div\s*clas="item"\s*data-role=".*?"\s*data-url="(/.+?)"' #.*?title="(.+?)"'#.*?>.*?<div.*?clas="item-logo".*?>.*?<img.*?src="(http.+?)".*?>'; 
	s='<div\s*class="item"\s*data-role="player-popup"\s*data-url="(/radios/play/\d+)"\s*data-profile-url="/radios/[A-Za-z0-9_\-/\.]+"\s*title="[Play|Spiele|couter]+\s+(.+?)"\s*>\s*<div\s*class="item-logo">\s*<img\s*src="(http.+?)"'
	#debob(messupText(nolines(html),True,True))
	try: matches=re.compile(s).findall(messupText(nolines(html),True,True)) #,re.DOTALL
	except: matches=''
	ItemCount=len(matches)
	if ItemCount > 0:
		debob('stations'); debob(matches)
		for (_url,_name,img) in matches:
			if '>' in _name: _name=_name.split('>')[0].replace('"','').strip()+cFL(' *','red')
			_addon.add_directory({'url':domain+_url,'title':_name,'img':img,'mode':'GetMedia','domain':domain,'site':site},{'title':'Station: '+cFL_(_name,colors['8'])},is_folder=False,fanart=fanartSite,img=img)
	#
	set_view('list',view_mode=addst('default-view')); eod()

def SubMenu(url):
	_addon.add_directory({'url':'','mode':'SubMenu2','domain':url,'site':site},{'title':cFL_('English',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	set_view('list',view_mode=addst('default-view')); eod()

### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	cNumber ='8'; cNumber2='2'; cNumber3='4'; 
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	
	##_addon.add_directory({'url':'http://provisioning.streamtheworld.com/pls/CKYEFMAAC.pls','title':'red fm','img':iconSite,'mode':'PlayURL','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'http://streema.com/radios/play/12929','title':'red fm','img':iconSite,'mode':'GetMedia','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	##_addon.add_directory({'url':'http://provisioning.streamtheworld.com/pls/CKYEFMAAC.pls','title':'red fm','img':iconSite,'mode':'GetMedia','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	
	_addon.add_directory({'url':'/radios','domain':'http://streema.com','mode':'SubMenu2','site':site},{'title':cFL_('English',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'url':'/radios','domain':'http://fr.streema.com','mode':'SubMenu2','site':site},{'title':cFL_('Francais',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'url':'/radios','domain':'http://de.streema.com','mode':'SubMenu2','site':site},{'title':cFL_('Deutsch',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	
	#############################################
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SetYourMode (where to go next)','site':site},{'title':cFL_('!!Menu Item Text Goes HERE!!',colors['8'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'url':'http://url...to...video/...file.flv','mode':'PlayURL','site':site},{'title':cFL_('Play a Video',colors['0'])},is_folder=False,fanart=fanartSite,img=iconSite)
	
	
	#
	#eod()
	#set_view('movies',view_mode=addst('movies-view')); eod(); 
	set_view('list',view_mode=addst('default-view')); eod() ##

### ############################################################################################################
### ############################################################################################################
## This function handles forwarding the mode param message code and directing the sub-addon to wherever it needs to go... like a GO-TO-Function command. ##
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() ## The Binary Highway usually sends 'SectionMenu' as the mode when initially calling the sub-addon.  is also good to use:  or (mode=='') or (mode=='main') ##
	elif (mode=='SubMenu'): 			SubMenu(url)
	elif (mode=='SubMenu2'): 			SubMenu2(url,addpr('domain',''))
	#
	#elif (mode=='NameYourMode'): 	NameYourFuction(url=url,addpr('title',''),addpr('img',''))
	#
	#
	#
	#
	elif (mode=='GetMedia'):			GetMedia(url,addpr('img',''),addpr('title',''))
	elif (mode=='TestPlay'):			TestPlay(url)
	elif (mode=='UpdateWorkingFile'):	UpdateWorkingFile(); RefreshList()
	elif (mode=='About'): 				About()  ## In most of my Sub-Addons. ##
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain  ## If a mode can not be found ##
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
