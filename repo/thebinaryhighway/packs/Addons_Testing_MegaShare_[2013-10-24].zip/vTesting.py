### ############################################################################################################
###	#	
### # Project: 			#		Url Tester
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import common
from common import *
from common import (_debugging,_addon,_artIcon,_artFanart,_addonPath,_OpenFile,isPath,isFile,popYN,_SaveFile,popOK,CopyAFile,RefreshList,DownloadThis,getFileExtension)
### ############################################################################################################
### ############################################################################################################
SiteName='Test & Log (v0.0.1)  [Testing Tool]'
SiteTag='Test and Log Tester Tool'
mainSite=''
iconSite=_artIcon
fanartSite=_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources','urlresolver'))
workingFile='log.txt'
workingFileWP=xbmc.translatePath(os.path.join(workingPath,workingFile))
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		#m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+''
		m+=CR+CR+'Features:  '
		m+=CR+'* Right Click Menu Access @ About or Url(s).'
		m+=CR+'* Menu Items: Add Url | Remove Url'
		m+=CR+'* Extra:  If you got the addon\'s Debugging to file setting turned on, you can view an Add Url link in the menu as well.'
		m+=CR+'* Attempt to Play the Url(s) that you supply.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* This tool is still being worked on, so things may not be perfect yet.'
		m+=CR+'* This tool is mainly meant to help devs check links to see if they\'re playable or not.'
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
def TP(s): return xbmc.translatePath(s)
def TPap(s,fe='.py'): return xbmc.translatePath(os.path.join(_addonPath,s+fe))
### ############################################################################################################
### ############################################################################################################
def Test(url):
	PlayerMethod=addst("core-player")
	if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER
	elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER
	elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER
	else: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	play=xbmc.Player(PlayerMeth) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	try: _addon.resolve_url(url)
	except: pass
	html=nURL(url)
	url2=re.compile('<iframe.*?src="(http://.+?)".*?>').findall(html)[0]; deb('url#2',url2)
	img=re.compile('<img border="0" src="(http://.+?)" width="100" height="140">').findall(html)[0]; deb('image',img)
	name=re.compile('<b><font size="\d+">\s*(.+?)\s*</font></b>').findall(html)[0]; deb('name',img)
	listitem=xbmcgui.ListItem(name,iconImage=img,thumbnailImage=img); listitem.setInfo('video',{'Title':name})
	PL=xbmc.PlayList(xbmc.PLAYLIST_VIDEO); PL.clear(); 
	try:
		import urlresolver
		stream_url=urlresolver.HostedMediaFile(url2).resolve()
		PL.add(stream_url,listitem)
		play.play(PL)
	except: pass


### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	#
	#u="http://cheesestream.com/embed_ext/videoweed/4f4d5748c8f56&width=600&height=438"; _SaveFile(TP(workingFileWP),messupText(nURL(u),True,True))
	
	
	
	
	_addon.add_directory({'url':'http://megashare.info/video.php?id=TmprM09RPT0&vhost=putlocker','mode':'Test','site':site},{'title':cFL_('Test',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	
	#
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='AddUrlToList'): 	AddUrlToList(url=url)
	elif (mode=='RemoveUrlToList'): 	RemoveUrlToList(url=url)
	elif (mode=='Test'): 					Test(url)
	elif (mode=='About'): 				About()
	elif (mode=='CustomUpdate'): 	Update_CustomUpdate(addpr('path',''),addpr('filename',''))
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
