### ############################################################################################################
###	#	
### # Site: 				#		Run Programs Tool
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re,urllib

from common import *
from common import (_addon,addon,_plugin,net,_artIcon,_artFanart,PlayItCustom,_addonPath,_OpenFile,isPath,isFile,addstv,addst,_debugging)
### ############################################################################################################
### ############################################################################################################
SiteName='Run Programs [Windows]'
SiteTag=''
mainSite=''
iconSite='http://i.imgur.com/XMClMrQ.png' #_artIcon
fanartSite=_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources'))
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'RTMP Streams | RTSP Streams | MMS Streams | .FLV | .MP4'
		m+=CR+CR+'Features:  '
		m+=CR+'* Run a select of misc. programs.  The list that I initially included is mainly for use in Windows.  For another OS, feel free to provide information.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
def wP(filename):
	return xbmc.translatePath(os.path.join(workingPath,filename))
### ############################################################################################################
### ############################################################################################################



### ############################################################################################################
### ############################################################################################################



def SectionMenu():
	#
	cNumber ='8'; cNumber2='2'; cNumber3='4'; cNumber4='9'
	s=[]
	#s.append(('XBMCHUB.com','http://www.xbmchub.com/forums/','https://github.com/HIGHWAY99?tab=repositories','http://s9.postimg.org/6izlt73n3/1011445_473021149448994_84427075_n.jpg','http://s9.postimg.org/uy7tu92jz/1013960_471938356223940_1093377719_n.jpg'))
	#s.append(('#'+cFL('XBMCHUB','blue')+' @ '+cFL('irc.freenode.net','red'),'http://webchat.freenode.net/?channels=xbmchub&uio=d4',_artFanart,_artIcon))
	s.append(('Run: Windows Explorer [Windows]','explorer',_artFanart,_artIcon))
	s.append(('Run: System Configuration (MSConfig) [Windows]','msconfig',_artFanart,_artIcon))
	s.append(('Run: Registry Editor [Windows]','regedit',_artFanart,_artIcon))
	s.append(('Run: Command Prompt (Dos Window) [Windows]','cmd',_artFanart,_artIcon))
	s.append(('Run: Calculator [Windows]','calc',_artFanart,_artIcon))
	s.append(('Run: Registry Editor [Windows]','regedit',_artFanart,_artIcon))
	s.append(('Run: Disk Management [Windows]','diskmgmt.msc',_artFanart,_artIcon))
	b=xbmc.translatePath("C:\Windows\System32\drivers\etc\hosts.")
	if isFile(b): s.append(('Run: Windows` Hosts File [Windows][CR](Choose notepad or a text editor to load it)',b,_artFanart,_artIcon))
	b=xbmc.translatePath("C:\Windows\System32\drivers\hosts.")
	if isFile(b): s.append(('Run: Windows` Hosts File [Windows][CR](Choose notepad or a text editor to load it)',b,_artFanart,_artIcon))
	b=xbmc.translatePath("C:\Windows\System\drivers\etc\hosts.")
	if isFile(b): s.append(('Run: Windows` Hosts File [Windows][CR](Choose notepad or a text editor to load it)',b,_artFanart,_artIcon))
	b=xbmc.translatePath("C:\Windows\System\drivers\hosts.")
	if isFile(b): s.append(('Run: Windows` Hosts File [Windows][CR](Choose notepad or a text editor to load it)',b,_artFanart,_artIcon))
	b=xbmc.translatePath("C:\Windows\SysWOW64\drivers\etc\hosts.")
	if isFile(b): s.append(('Run: Windows` Hosts File [Windows][CR](Choose notepad or a text editor to load it)',b,_artFanart,_artIcon))
	b=xbmc.translatePath("C:\Windows\SysWOW64\drivers\hosts.")
	if isFile(b): s.append(('Run: Windows` Hosts File [Windows][CR](Choose notepad or a text editor to load it)',b,_artFanart,_artIcon))
	s.append(('Run: Notepad [Windows]','notepad',_artFanart,_artIcon))
	s.append(('Run: Magnifier [Windows]','magnify.exe',_artFanart,_artIcon))
	s.append(('Run: Resource Monitor [Windows]','perfmon.exe /res',_artFanart,_artIcon))
	s.append(('Run: System Information [Windows]','msinfo32.exe',_artFanart,_artIcon))
	s.append(('Run: Character Map [Windows]','charmap.exe',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	#s.append(('Run:  [Windows]','',_artFanart,_artIcon))
	
	# workingPath=xbmc.translatePath(os.path.join(_addonPath,'resources'))
	#s.append(('','',_artFanart,_artIcon))
	#s.append(('','','',''))
	for sT,sU,sF,sI in s:
		_addon.add_directory({'site':site,'mode':'System.Exec','url':sU},{'title':cFL_(''+sT+'',colors[cNumber4])},is_folder=False,fanart=sF,img=sI)
	
	
	
	
	#
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'XML','site':site,'section':'movies','url':mainSite+'videositemap-1.xml'},{'title':cFL_('Browse XML (videositemap-1.xml)',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'List','site':site,'section':'movies','url':mainSite+'category/anime-movies'},{'title':cFL_('Anime Movies',colors['1'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'SubMenu','site':site,'section':'series'},{'title':cFL_('Anime Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'ongoing-anime'},{'title':cFL_('Ongoing Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Page','site':site,'section':'series','url':mainSite+'new-anime'},{'title':cFL_('New Series',colors['2'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Episodes','site':site,'section':'series','url':mainSite+'surprise'},{'title':cFL_('Suprise Me',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'Search','site':site,'section':'series'},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img=iconSite)
	
	#_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	#if (len(addst('LastSearchTitle'+SiteTag)) > 0): _addon.add_directory({'mode':'SearchLast','site':site},{'title':cFL_('Repeat Last Search',colors['0'])},is_folder=True,fanart=fanartSite,img='http://www.navixtreme.com/images/logos/search.png')
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	
	set_view('list',view_mode=addst('default-view')); eod()



### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu() #(site)
	elif (mode=='SubMenu'): 			SubMenu() #(site,section)
	elif (mode=='Page'): 					Browse_Page(url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='Episodes'): 			Browse_Episodes(url,page)
	elif (mode=='List'): 					Browse_List(url,page)
	elif (mode=='XML'): 					Browse_XML(url)
	elif (mode=='INIlists'): 			Browse_INI_Lists(url)
	elif (mode=='INIitems'): 			Browse_INI_Items(url)
	elif (mode=='GetLiveFeed'): 	GetLiveFeed(url,addpr('title',''),addpr('img',''))
	elif (mode=='Hosts'): 				Browse_Hosts(url)
	elif (mode=='AZ'): 						Browse_AZ()
	elif (mode=='Genres'): 				Browse_Genres()
	elif (mode=='PlayFromHost'): 	PlayFromHost(url)
	elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	elif (mode=='Mute'): 								xbmc.executebuiltin("XBMC.Mute()")
	elif (mode=='System.Exec'): 				xbmc.executebuiltin("XBMC.System.Exec(%s)" % url)
	elif (mode=='System.ExecWait'): 		xbmc.executebuiltin("XBMC.System.ExecWait(%s)" % url)
	elif (mode=='Minimize'): 						xbmc.executebuiltin("XBMC.Minimize()")
	elif (mode=='ActivateScreensaver'): xbmc.executebuiltin("XBMC.ActivateScreensaver()")
	#elif (mode=='FavList'): 			Fav_List(site,section)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
	
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
