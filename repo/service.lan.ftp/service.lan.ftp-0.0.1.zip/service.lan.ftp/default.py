import os,sys,re
import xbmcplugin,xbmcaddon,xbmc
try: 			from addon.common.addon 				import Addon
except:
	try: 		from t0mm0.common.addon 				import Addon
	except: 
		try: from c_t0mm0_common_addon 				import Addon
		except: pass
addon_id="service.lan.ftp"
addon_name="FTP Server"
try: 		addon=Addon(addon_id, sys.argv); 
except: 
	try: addon=Addon(addon_id, addon.handle); 
	except: addon=Addon(addon_id, 0); 
plugin=xbmcaddon.Addon(id=addon_id); 
print "%s @ %s" % (addon_name,addon_id)

print "test"
addon.show_settings()
