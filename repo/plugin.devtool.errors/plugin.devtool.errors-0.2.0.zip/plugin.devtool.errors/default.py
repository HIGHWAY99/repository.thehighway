#############################################################################
#############################################################################
import common
from common import *
from common import (addon_id,addon_name,addon_path)

#############################################################################
#############################################################################
ACTION_PREVIOUS_MENU 		=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT 				=   1	## Left arrow key
ACTION_MOVE_RIGHT 			=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_CLICK_LEFT	= 101	## Mouse click left ??
ACTION_MOUSE_WHEEL_UP 	= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN = 105	## Mouse wheel down
ACTION_MOUSE_DRAG 			= 106	## Mouse drag
ACTION_MOUSE_MOVE 			= 107	## Mouse move
#
ACTION_KEY_P						=	 79	## P - Pause
ACTION_KEY_R						=	 78	## R - Rewind
ACTION_KEY_F						=	 77	## F - Fast Forward
ACTION_SELECT_ITEM			=		7	## ?
ACTION_PARENT_DIR				=		9	## ?
ACTION_CONTEXT_MENU			=	117	## ?
ACTION_NEXT_ITEM				=	 14	## ?
ACTION_BACKSPACE				=	110	## ?
#
ACTION_KEY_X						=	 13	## X - Stop
ACTION_aID_0						=	  0	## ???
#
ACTION_REMOTE_MUTE					=	 91	## MUTE
#ACTION_REMOTE_FULLSCREEN		=	 ??	## FullScreen
ACTION_REMOTE_INFO					=	 11	## Info
ACTION_REMOTE_PLAYPAUSE			=	 12	## Play / Pause
ACTION_REMOTE_CONTEXTMENU		=	117	## Context Menu
ACTION_REMOTE_STOP					=	 13	## Stop
#
ACTION_KEY_VOL_MINUS				=	 89	## F - Fast Forward
ACTION_KEY_VOL_PLUS					=	 88	## F - Fast Forward
#
ACTION_SHOW_FULLSCREEN			=  36 ## Show Full Screen
ACTION_TOGGLE_FULLSCREEN		= 199 ## Toggle Full Screen
#############################################################################
#############################################################################

d=xbmcgui.Dialog(); 

class CustomWindow(xbmcgui.WindowXML):
#class CustomWindow(xbmcgui.WindowXMLDialog):
		closing=False; firsttime=False; c={}; strXMLname=''; strFallbackPath=''; List01D=[]; List01DB=[]
		maxW=1280; maxH=720; 
		##
		def __init__(self,strXMLname,strFallbackPath):
			self.strXMLname=strXMLname
			self.strFallbackPath=strFallbackPath
		def onInit(self):
			try:
				try: self.wID=xbmcgui.getCurrentWindowId()
				except: self.wID=0
				deb('CurrentWindowId()',str(self.wID)); 
				deb('getResolution()',str(self.getResolution())); 
				self.firsttime=True
				debob(['screen size',self.getWidth(),self.getHeight()])
				debob(['skin size',self.maxW,self.maxH])
				self.LoadSkinItems()
				try: self.setFocus(self.bExit)
				except: pass
				self.setupScreen()
				#try: self.setFocus(self.List01)
				#except: pass
			except: pass
		def ResetTheList(self):
			try: self.ScrTp('0','erCount'); self.List01.reset(); self.List01DB=[]; self.ErrLabel01.setLabel(' '); 
			except: pass
		def loadLogFile(self):
			try:
				self.ResetTheList()
				PathA=tP('special://logpath/kodi.log'); PathB=tP('special://logpath/xbmc.log'); 
				#PathA=addonPath2('test.txt')
				if isFile(PathA): html=FileOPEN(PathA); debob({'Loading file':PathA})
				elif isFile(PathB): html=FileOPEN(PathB); debob({'Loading file':PathB})
				else: html=''; debob({'Loading file':'no file was found.'})
				self.loadLogList(html)
			except: pass
		def loadOldLogFile(self):
			try:
				self.ResetTheList()
				PathA=tP('special://logpath/kodi.old.log'); PathB=tP('special://logpath/xbmc.old.log'); 
				if isFile(PathA): html=FileOPEN(PathA); debob({'Loading file':PathA})
				elif isFile(PathB): html=FileOPEN(PathB); debob({'Loading file':PathB})
				else: html=''; debob({'Loading file':'no file was found.'})
				self.loadLogList(html)
			except: pass
		def loadLogList(self,html=''):
			try:
				debob({'Length of data':len(html)})
				self.ResetTheList()
				if len(html)==0: return
				s ='(\d+:\d+:\d+\s+T:\d+\s+(ERROR): .*?\n'; 
				s+='\s+.*?\n'; 
				s+="\s+Error Type: <\D+ '([^']+)'>\n"; 
				s+="\s+Error Contents: ([^\n]+)\n"; 
				s+="(?:\s+Traceback \(most recent call last\):\n)?"; 
				s+='('; 
				s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; 
				s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; 
				s+='(?:\s+File "[^"]+", line \d+, in .*?\n\s+.+?\n)?'; 
				s+="(?:\s+\D+Error:\s*\('[^']+',\s*\('[^']+',\s*\d+,\s*\d+,\s*'[^']+'\)\)\n)?"; 
				s+='(?:\s+(\D+): ([^\n]+))\n)?'; 
				s+=')'; 
				s+='\s+...End of Python script error report'
				try: r=re.compile(s).findall(html)
				except: r=[]
				debob({'Number Found':len(r)}); #debob(r); 
				#return
				self.List01D=reversed(r); #debob(self.List01D)
				self.List01.reset(); self.List01DB=[]; iCount=0; 
				for tAll,tErrorError,tErrorType,tErrorContents,tErrorData,tNameErrorA,tNameErrorB in self.List01D:
					try:
						s='\s+File "([^"]+)", (line (\d+)), in (.*?)\n\s+(.+?)\n'
						try: r2=re.compile(s).findall(tErrorData)
						except: r2=[]
						#print 'r2*'; debob(r2); debob([tAll,tErrorError,tErrorType,tErrorContents]); 
						if len(r2)==0:
							#s="\s+\D+Error:\s*\('[^']+',\s*\('([^']+)',\s*(\d+),\s*\d+,\s*'([^']+)'\)\)\n"
							#s="\s+\D+Error:\s*\('[^']+',\s*\('([^']+)',\s*(\d+),"
							s="\s+\D+Error:\s*\('[^']+',\s*\('([^']+)'()()"
							try: r2=re.compile(s).findall(tErrorData)
							except: r2=[]
							#print 'r2**'; debob(['tErrorData',tErrorData]); debob(r2); print '---'; 
						if len(r2) > 0:
							try:
								FirstGroup=r2[0]; FirstItem=FirstGroup[0]; 
								#debob(['FirstItem',FirstItem])
								a1,a2=FirstItem.replace('\\','/').replace('//','/').split('/addons/'); 
								tErrorFirstAddonName=a2.split('/')[0]; 
								tErrorFirstAddonFolder=a1.replace('/','\\')+'\\addons\\'+tErrorFirstAddonName; 
							except:
								tErrorFirstAddonName='[ Unknown ]'; tErrorFirstAddonFolder=''; 
						else:
								tErrorFirstAddonName='[ Unknown ]'; tErrorFirstAddonFolder=''; 
						#debob([tErrorFirstAddonName,tErrorFirstAddonFolder])
						if len(tErrorFirstAddonFolder) > 0:
							i=os.path.join(tErrorFirstAddonFolder,'icon.png'); #deb('thumb',i)
						else: i=''
						t=tErrorFirstAddonName+'\n'+tNameErrorA+': '+tNameErrorB
						self.List01DB.append((iCount,tAll,tErrorError,tErrorType,tErrorContents,tErrorData,tNameErrorA,tNameErrorB,tErrorFirstAddonName,tErrorFirstAddonFolder,i,t))
						item=xbmcgui.ListItem(t); 
						item.setThumbnailImage(i); item.setIconImage(i); item.setArt({'thumb':i,'poster':i,'banner':i,'fanart':i,'clearart':i,'clearlogo':i,'landscape':i}); 
						item.setLabel(t); 
						item.setProperty('iCount',str(iCount)); 
						item.setProperty('iThumb',str(i)); 
						self.List01.addItem(item); iCount=iCount+1; 
					except: pass
				if int(self.List01.size()) > 0:
					try: self.setFocus(self.List01)
					except: pass
					self.ScrTp(str(self.List01.size()),'erCount'); 
					self.List01.selectItem(0)
					iCount=int(self.List01.getListItem(0).getProperty('iCount')); 
					name=self.List01.getListItem(0).getLabel(); 
					self.useItem(iCount,name); 
			except: pass
		def setupScreen(self):
			try:
				#self.iBack.setImage(artp("black1")); 
				self.iBackground.setImage(MediaFile("black1.png")); 
				
				#wegweg
				#return
				self.loadLogFile()
				
				##
			except: pass
		def LoadSkinItems(self):
			try:
				self.c['iBack']=1; 
				self.c['iBackground']=2; 
				self.c['bExit']=10; 
				try: self.iBack=self.getControl(self.c['iBack']); 
				except: pass
				try: self.iBackground=self.getControl(self.c['iBackground']); 
				except: pass
				try: self.bExit=self.getControl(self.c['bExit']); 
				except: pass
				
				self.c['List01']=9000; 
				try: self.List01=self.getControl(self.c['List01']); 
				except: pass
				self.c['ErrLabel01']=9001; 
				try: self.ErrLabel01=self.getControl(self.c['ErrLabel01']); 
				except: pass
				self.c['ErrLabel02']=101; 
				try: self.ErrLabel02=self.getControl(self.c['ErrLabel02']); 
				except: pass
				self.c['BtnLog01']=400; 
				try: self.BtnLog01=self.getControl(self.c['BtnLog01']); 
				except: pass
				self.c['BtnLog02']=401; 
				try: self.BtnLog02=self.getControl(self.c['BtnLog02']); 
				except: pass
				self.c['ImgLog01']=402; 
				try: self.ImgLog01=self.getControl(self.c['ImgLog01']); 
				except: pass
				
				self.ScrTp('0','erCount'); 
				
				
				
			except: pass
		def ScrTp(self,s='',v='ScreenType'):
			try:
				if len(v) > 0:
					self.setProperty(v,s); 
			except: pass
		def useItem(self,iCount,name):
			try:
					CurItem=self.List01DB[iCount]
					iCount,tAll,tErrorError,tErrorType,tErrorContents,tErrorData,tNameErrorA,tNameErrorB,tErrorFirstAddonName,tErrorFirstAddonFolder,i,t=CurItem
					tt=tAll.replace('                                            ','')
					tt=tt.replace('\n  File "','\n\n  [COLOR red]File "[/COLOR][COLOR cornflowerblue]')
					tt=tt.replace('\n'+tNameErrorA+': ','\n\n[COLOR green]'+tNameErrorA+':[/COLOR] ')
					tt=tt.replace('", line ','[/COLOR][COLOR red]", [/COLOR]\n[COLOR FFFFFFFF]line [/COLOR][COLOR yellow]')
					tt=tt.replace(', in ','[/COLOR][COLOR FFFFFFFF], in[/COLOR] ')
					tt=tt.replace('-->Python callback/script returned the following error<--','')
					tt=tt.replace(' - NOTE: IGNORING THIS CAN LEAD TO MEMORY LEAKS!\n','')
					debob({'tErrorType':tErrorType})
					debob({'tErrorContents':tErrorContents})
					tt=tt.replace(tErrorType,'[COLOR orange]'+tErrorType+'[/COLOR]')
					tt=tt.replace(tErrorContents,'[COLOR orange]'+tErrorContents+'[/COLOR]')
					tt=tt.replace(tNameErrorB,'[COLOR orange]'+tNameErrorB+'[/COLOR]')
					if len(tErrorFirstAddonFolder) > 0:
						tt=tt.replace(tErrorFirstAddonFolder,'[COLOR pink]'+tErrorFirstAddonFolder+'[/COLOR]')
					if (len(tErrorFirstAddonName) > 0) and (not tErrorFirstAddonName=='[ Unknown ]'):
						tt=tt.replace(tErrorFirstAddonName,'[COLOR deeppink]'+tErrorFirstAddonName+'[/COLOR]')
					self.ErrLabel01.setLabel(tt)
					#debob(self.ErrLabel01.getLabel())
					self.ImgLog01.setImage(i)
			except: pass
		def onClick(self,controlId):
			try:
				if   controlId==self.c['bExit']: self.AskToClose()
				#elif   controlId==self.c['SideGroup01ocBtn']: 
				#	gX=self.SideGroup01.getX(); gY=self.SideGroup01.getY(); 
				#	debob(['From',gX,gY])
				#	if gX==self.maxW: self.SideGroup01.setPosition(1030,gY); debob(['To',1030,gY])
				#	else: self.SideGroup01.setPosition(self.maxW,gY); debob(['To',self.maxW,gY])
				#	
				#	pass
				elif   controlId==self.c['BtnLog01']: self.loadLogFile()
				elif   controlId==self.c['BtnLog02']: self.loadOldLogFile()
				elif   controlId==self.c['List01']: 
					iCount=int(self.List01.getSelectedItem().getProperty('iCount')); 
					name=self.List01.getSelectedItem().getLabel(); 
					self.useItem(iCount,name); 
				else:
					try:
						
						pass
					except: pass
			except Exception,e: debob(["Error",e])
			except: pass
		def onAction(self,action): 
			try:
				actId=int(action.getId()); actIds=str(action.getId()); actBC=str(action.getButtonCode()); xx=0; yy=0; 
				try: actAmnt1=action.getAmount1()
				except: actAmnt1=0-900
				try: actAmnt2=action.getAmount2()
				except: actAmnt2=0-900
				mW=self.maxW; mH=self.maxH; mWa=int(self.getWidth()); mHa=int(self.getHeight()); 
				actAmnt1k=int(actAmnt1*mW/mWa); actAmnt2k=int(actAmnt2*mH/mHa); 
				##
				if   action==ACTION_PREVIOUS_MENU: self.AskToClose()
				elif action==ACTION_NAV_BACK: self.AskToClose()
				else:
					if not actId==0:
						#debob({'action type':'UNKNOWN','getId':actId,'getButtonCode':actBC,'getAmount1':actAmnt1,'getAmount2':actAmnt2})
						pass
						##
					##
				##
			except Exception,e: debob(["Error",e]); debob([actId,actIds,actBC])
			except: pass
		def CloseWindow(self):
			try:
				self.closing=True; 
			except: pass
			self.close()
		def CW(self): self.CloseWindow()
		def AskToClose(self):
			try:
				if self.closing==False:
					if d.yesno(addonName," ","Are you sure that you want to exit?","","No","Yes"): self.closing=True; self.CloseWindow()
				else: self.CloseWindow()
			except: pass
		##
######


#############################################################################
#############################################################################
skinFilename='CustomWindow001.xml'
try:    Emulating=xbmcgui.Emulating
except: Emulating=False
if __name__=='__main__':
	#cWind=CustomWindow(skinFilename,addon_path,'default')
	cWind=CustomWindow(skinFilename,addon_path) #,'default'
	cWind.doModal()
	del cWind
	sys.modules.clear()

#############################################################################
#############################################################################
