### ############################################################################################################
###	#	
### # Site: 				#		KinderTube.NL
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui
from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,RefreshList)
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR blue]Kinder[/COLOR][COLOR red]tube[/COLOR][COLOR green].[B]NL[/B][/COLOR]  [v0.0.1]  [Cartoons] (Netherlands)[CR] (Under Construction)'
SiteTag='kindertube.nl'
mainSite='http://www.kindertube.nl'
mainSite2=''
iconSite='http://www.kindertube.nl/images/kindertube.gif' #_artIcon
fanartSite=_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl=mainSite+'ram.pls'
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		#m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'Live Streams (RTMPE)'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Categories'
		m+=CR+'* Browse Shows'
		m+=CR+'* Browse Episodes'
		m+=CR+'* Play Videos hosted @ Youtube and Vimeo'
		m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
	eod()
def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
### ############################################################################################################
### ############################################################################################################
def ListEpisodes(url,title):
	if len(url)==0: return
	if mainSite not in url: url=mainSite+url
	deb('url',url); html=(messupText(nURL(url),True,True)); deb('length of html',str(len(html))); #debob(html)
	#html=spAfterSplit(html,'<ul id="videoList_ul">'); html=spBeforeSplit(html,'</ul>'); 
	if len(html)==0: return
	s='<div style="width:\d+px;display:inline-block;"><a id="([A-Za-z0-9\-_]+)" href="#top"><img src="(http://.+?)"  height="\d+" width="\d+"></a><div style="overflow:hidden;width:\d+px;height:\d+px;text-align:center;color:#[A-Za-z0-9]+;margin:\d+px \d+px;">\s*(.+?)\n*\s*</div></div>'
	matches=re.compile(s).findall(html); 
	deb('# of matches found',str(len(matches))); #debob(matches)
	if len(matches) > 0:
		for IdTag,img,name in matches:
			debob((IdTag,img,name)); 
			s2 ='.\("a.'+IdTag+'"\).live\("click",function\(\){\n*\s*'; 
			s2+='.\(".videowrapper"\).html\(\'<iframe width="\d+" height="\d+" src="(http://.+?'+IdTag+'.+?)"\s*[frameborder\=\"\d]*\s*allowfullscreen></iframe>\'\);\n*\s*}\);';
			##mUrl=re.search(s2,html).group(1); 
			mUrl=re.compile(s2).findall(html)[0]; 
			#deb('mUrl',mUrl); 
			if 'http://www.youtube.com/embed/' in mUrl: pUrl='plugin://plugin.video.youtube/?action=play_video&videoid='+IdTag; pColor='orange'; sTag='Youtube'; 
			elif 'http://player.vimeo.com/video/': pUrl='plugin://plugin.video.vimeo/?action=play_video&videoid='+IdTag; pColor='blue'; sTag='Vimeo'; 
			else: pUrl=''; pColor='white'; sTag=''; 
			pars={'mode':'PlayURL','img':img,'url':pUrl,'title':name,'site':site}
			if len(pUrl)==0: labs={'title':''+cFL(name,'yellow')+''+'[CR]'+cFL('Fout [Error] ','red')+IdTag+''}
			else: labs={'title':''+cFL(name,'yellow')+cFL(' @ '+sTag+'')+''+'[CR]'+cFL('Afspelen [Play] ',pColor)+IdTag+''}
			try: _addon.add_directory(pars,labs,is_folder=False,fanart=fanartSite,img=img)
			except: pass
	s='<div style="width:\d+px;display:inline-block;"><a id="([A-Za-z0-9\-_]+)" href="(http://www.kindertube.nl/.+?)"><img src="(http://.+?)"\s+height="\d+" width="\d+"></a><div style="overflow:hidden;width:\d+px;height:\d+px;text-align:center;color:.[A-Za-z0-9]+;margin:\d+px \d+px;">\s*(.+?)\n*\s*</div></div>'
	matches3=re.compile(s).findall(html); 
	deb('# of matches found',str(len(matches3))); #debob(matches2)
	if len(matches3) > 0:
		for IdTag,mUrl,img,name in matches3:
			debob((IdTag,mUrl,img,name)); 
			labs={'title':''+cFL(name,'deeppink')+'[CR]'+''+mUrl+''}
			pars={'mode':'ListEpisodes','img':img,'url':mUrl,'title':name,'site':site}
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fanartSite,img=img)
			except: pass
	s='{ value: "(http://www.kindertube.nl/.+?/.+?.html)", label: "(.+?)" },'
	matches2=re.compile(s).findall(html); 
	deb('# of matches found',str(len(matches2))); #debob(matches2)
	if len(matches2) > 0:
		for mUrl,name in matches2:
			debob((mUrl,name)); 
			img=iconSite; labs={'title':''+cFL(name,'green')+'[CR]'+''+mUrl+''}
			pars={'mode':'ListEpisodes','img':img,'url':mUrl,'title':name,'site':site}
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fanartSite,img=img)
			except: pass
	set_view('episodes',view_mode=addst('episode-view')); eod()

### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	c='cornflowerblue'
	_addon.add_directory({'mode':'Over [About]','site':site},{'title':cFL_('About',colors['9'])},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	#_addon.add_directory({'mode':'ListShows','site':site},{'title':cFL_('Cartoon List',colors['5'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+'/'																				},{'title':cFL_('Home',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+'/babyfilmpjes.html'												},{'title':cFL_('Baby',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+'/peuterfilmpjes.html'											},{'title':cFL_('Peuter',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+'/kleuterfilmpjes.html'										},{'title':cFL_('Kleuter',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+'/schoolgaand.html'												},{'title':cFL_('Schoolgaand',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+'/tekenfilms-van-vroeger.html'							},{'title':cFL_('Vroeger',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+'/muziek-voor-kinderen.html'								},{'title':cFL_('Muziek',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+'/voorlezen-en-digitale-prentenboeken.html'},{'title':cFL_('Sprookjes & verhaal	tjes',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+''},{'title':cFL_('Cartoon',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+''},{'title':cFL_('Cartoon',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+''},{'title':cFL_('Cartoon',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	#_addon.add_directory({'mode':'ListEpisodes','site':site,'url':mainSite+''},{'title':cFL_('Cartoon',c)},is_folder=True,fanart=fanartSite,img=iconSite)
	###
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='') or (mode=='main') or (mode=='MainMenu') or (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='PlayURL'): 			PlayURL(url)
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='NowPlaying'): 		NowPlaying()
	elif (mode=='ListAZ'): 				ListAZ()
	elif (mode=='List'): 					Browse_List(addpr('title',''))
	elif (mode=='DoRequest'): 		DoRequest(url,addpr('title',''))
	elif (mode=='ListShows'): 		ListShows()
	elif (mode=='ListEpisodes'): 	ListEpisodes(url,addpr('title',''))
	elif (mode=='GetMedia'): 			GetMedia(addpr('videoid',''),addpr('title',''),url,addpr('img',''))
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	#elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	#elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				About()
	#elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='SlideShowStart'): path = os.path.join(_addonPath, 'c_SlideShow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
### Notes: 
#Marquerite: 
#		Play = Afspelen
#		Error = Fout
#		About = Over

### ############################################################################################################
### ############################################################################################################
