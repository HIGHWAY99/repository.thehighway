import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,htmllib
import shutil
#import fileinput
#import elementtree as ET2
import elementtree.ElementTree as ET1
#import elementtree.ElementTree as ET
from elementtree.ElementTree import parse

from config import Config as Config

try: from sqlite3 import dbapi2 as orm
except: from pysqlite2 import dbapi2 as orm
DB='sqlite'; 
DB_File='Addons15.db'; DB_DIR=os.path.join(xbmc.translatePath("special://database"),DB_File); 
DB_File2='Addons.db';  DB_DIR2=os.path.join(xbmc.translatePath("special://database"),DB_File2); 
if os.path.isfile(DB_DIR)==True: print "Database Found: "+DB_DIR; 
else: print "Unable to locate Database"

MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

#def unCacheAnImage(url):
#	if os.path.isfile(DB_DIR)==True: 
#		db=orm.connect(DB_DIR); 
#		#g='Select cachedurl FROM texture WHERE url = "'+url+'";'; print g; 
#		#a=db.execute(g); print str(a); 
#		s='DELETE FROM texture WHERE url = "'+url+'";'; print s; 
#		db.execute(s); 
#		db.commit(); db.close(); 
#	##

def getITEMS(table='repo',where=''):
	if os.path.isfile(DB_DIR)==True: 
		db=orm.connect(DB_DIR); 
		dbc = db.cursor()
		s='SELECT * FROM '+table+where; debob(s); 
		dbc.execute(s); 
		return dbc.fetchall()
		#r0=dbc.fetchall()
		db.close(); 
		return r0 #db.fetchall()
		#db.commit(); db.close(); 
	
def getITEM(table='repo',where=''):
	if os.path.isfile(DB_DIR)==True: 
		db=orm.connect(DB_DIR); 
		dbc = db.cursor()
		s='SELECT * FROM '+table+where; debob(s); 
		dbc.execute(s); 
		db.close(); 
		return dbc.fetchone()
		#db.commit(); db.close(); 


ACTION_PREVIOUS_MENU = 10	## ESC action
ACTION_NAV_BACK = 92	## Backspace action
ACTION_MOVE_LEFT = 1	## Left arrow key
ACTION_MOVE_RIGHT = 2	## Right arrow key
ACTION_MOVE_UP = 3	## Up arrow key
ACTION_MOVE_DOWN = 4	## Down arrow key
ACTION_MOUSE_WHEEL_UP = 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN = 105	## Mouse wheel down
ACTION_MOUSE_DRAG = 106	## Mouse drag
ACTION_MOUSE_MOVE = 107	## Mouse move

class MyWindow(xbmcgui.Window):
	#
	#
	button={}
	def __init__(self):
		self.background=(xbmc.translatePath(Config.fanart))
		#if len(self.background)==0: self.background="0x00000000"
		#if len(self.background)==0: self.background="0x00FFFFFF"
		self.background=artp("XBMCHUB_D5")
		self.b1=artp("black1")
		deb("BG",self.background)
		BG=xbmcgui.ControlImage(0,0,1280,720,self.background,aspectRatio=1)
		self.addControl(BG)
		focus=artp("button-focus2")
		nofocus=artp("button-nofocus")
		self.RepoFanart2=xbmcgui.ControlImage(30,120,400,460,self.b1,aspectRatio=1); self.addControl(self.RepoFanart2); 
		self.RepoFanart=xbmcgui.ControlImage(30,120,330,460,self.b1,aspectRatio=1); self.addControl(self.RepoFanart); 
		self.RepoThumbnail=xbmcgui.ControlImage(330,120,100,100,self.background,aspectRatio=1); self.addControl(self.RepoThumbnail); 
		
		self.LabTitle=xbmcgui.ControlLabel(30,20,1000,50,'','font30','0xFFFF0000'); self.addControl(self.LabTitle)
		self.LabTitle.setLabel(Config.name.replace("XBMCHUB ","[COLOR deepskyblue][B][I]XBMCHUB[/I][/B][/COLOR]  "))
		#self.button[0]=xbmcgui.ControlButton(30, 70, 135, 30, "Exit")
		self.button[0]=xbmcgui.ControlButton(30, 70, 135, 30, "Exit",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus)
		self.addControl(self.button[0])
		#time.sleep(2); 
		self.CtrlList=xbmcgui.ControlList(30,120,400,500,font='font12',textColor="0xFFFF0000",selectedColor="0xFF00FF00",buttonFocusTexture=focus,buttonTexture=nofocus); self.CtrlList.setSpace(2); self.addControl(self.CtrlList); 
		self.LabCurrentRepo=xbmcgui.ControlLabel(400,80,400,30,'','font12','0xFF00BFFF',alignment=1); self.addControl(self.LabCurrentRepo)
		self.RepoCatList=xbmcgui.ControlList(440,120,400,480,font='font12',textColor="0xFFFF0000",selectedColor="0xFF00FF00",buttonFocusTexture=focus,buttonTexture=nofocus); self.RepoCatList.setSpace(5); self.addControl(self.RepoCatList); 
		self.AddonsList=xbmcgui.ControlList(850,120,400,480,font='font12',textColor="0xFFFF0000",selectedColor="0xFF00FF00",buttonFocusTexture=focus,buttonTexture=nofocus); self.AddonsList.setSpace(5); self.addControl(self.AddonsList); 
		
		#self.CtrlList.addItem("repository.TheHighway1")
		#self.CtrlList.addItem("repository.TheHighway2")
		#self.CtrlList.addItem("repository.TheHighway3")
		#self.CtrlList.addItem( xbmcgui.ListItem("repository.TheHighway4","The Highway's Addons4") )
		##self.CtrlList.addItem( xbmcgui.ListItem("The Highway's Addons",path="repository.TheHighway") )
		
		#self.AddRepo("repository.thehighway","The Highway's Addons","0.0.4")
		#self.AddRepo("repository.thehighway.bb","The Highway's Addons [Backup]","0.0.5")
		Items=getITEMS(table='repo',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)'); debob(Items); 
		Items=sorted(Items, key=lambda item: item[1], reverse=False)
		for (i_id,i_addonID,i_checksumb,i_lastcheck) in Items:
			debob((i_id,i_addonID))
			addon_path="special://home"; addon_file=repo(i_addonID,"addon.xml")
			if os.path.isfile(addon_file)==False: addon_path="special://xbmc"; addon_file=repox(i_addonID,"addon.xml"); 
			if os.path.isfile(addon_file)==True:
				pleaseSkip=False
				try: addon_xml=nolines(_OpenFile(addon_file))
				except: pleaseSkip=True
				#addon_xml_addon=addon_xml.split("<addon",re.IGNORECASE)[1].split(">")[0]
				try: addon_xml_addon=re.compile("<addon(.*?)>",re.IGNORECASE).findall(addon_xml)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_inner=re.compile("<addon.*?>(.*?)</addon>",re.IGNORECASE).findall(addon_xml)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_name=re.compile('\s+name="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_version=re.compile('\s+version="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_author=re.compile('\s+provider-name="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
				except:
					try: addon_xml_addon_author=re.compile("\s+provider-name='(.*?)'",re.IGNORECASE).findall(addon_xml_addon)[0]
					except: addon_xml_addon_author="[UNKNOWN]"
				try: addon_xml_addon_url=re.compile('<info.*?>(.*?)</info>',re.IGNORECASE).findall(addon_xml_addon_inner)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_urlmd5=re.compile('<checksum.*?>(.*?)</checksum>',re.IGNORECASE).findall(addon_xml_addon_inner)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_urlpath=re.compile('<datadir.*?>(.*?)</datadir>',re.IGNORECASE).findall(addon_xml_addon_inner)[0]
				except: pleaseSkip=True
				debob((i_addonID,addon_xml_addon_url,addon_xml_addon_urlmd5,addon_xml_addon_urlpath))
				
				#addon_xml_addon=ET.Element("addon")
				#addon_xml_addon_name=ET.SubElement(addon_xml_addon,"name")
				#addon_xml_addon_version=ET.SubElement(addon_xml_addon,"version")
				#addon_xml_addon_author=ET.SubElement(addon_xml_addon,"provider-name")
				
				if pleaseSkip==False:
					self.AddRepo(RepoID=str(i_addonID),RepoName=str(addon_xml_addon_name),RepoVersion=str(addon_xml_addon_version),RepoNumber=str(i_id),RepoLastCheck=str(i_lastcheck),RepoChecksum=str(i_checksumb),RepoSummary="",RepoDescription="",RepoDisclaimer="",RepoAuthor=str(addon_xml_addon_author),InstalledPath=addon_path,RepoURL=addon_xml_addon_url,RepoURLMD5=addon_xml_addon_urlmd5,RepoURLPath=addon_xml_addon_urlpath)
				#self.AddRepo(RepoID=str(i_addonID),RepoName=str(i_addonID),RepoVersion="0.0.4",RepoNumber=str(i_id),RepoLastCheck=str(i_lastcheck),RepoChecksum=str(i_checksumb))
			##
		##
		
		#self.AddRepo("","")
		
		self.button[0].controlDown(self.CtrlList)
		self.CtrlList.controlUp(self.button[0])
		self.RepoCatList.controlUp(self.button[0])
		self.AddonsList.controlUp(self.button[0])
		self.CtrlList.controlRight(self.RepoCatList)
		self.RepoCatList.controlRight(self.AddonsList)
		self.AddonsList.controlLeft(self.RepoCatList)
		self.RepoCatList.controlLeft(self.CtrlList)
		
		
		self.setFocus(self.button[0])
		##
	def AddRepo(self,RepoID="",RepoName="",RepoVersion="",RepoNumber="",RepoLastCheck="",RepoChecksum="",RepoSummary="",RepoDescription="",RepoDisclaimer="",RepoAuthor="",InstalledPath="special://home",RepoURL="",RepoURLMD5="",RepoURLPath=""):
		r1=repo(RepoID,"icon.png",h=InstalledPath)
		r2=repo(RepoID,"fanart.jpg",h=InstalledPath)
		deb("icon",r1)
		c1=xbmcgui.ListItem(RepoName,RepoVersion,iconImage=r1,thumbnailImage=r1)
		c1.setProperty("repository.id",RepoID)
		c1.setProperty("repository.number",RepoNumber)
		c1.setProperty("repository.lastcheck",RepoLastCheck)
		c1.setProperty("repository.checksum",RepoChecksum)
		c1.setProperty("repository.icon",r1)
		c1.setProperty("repository.fanart",r2)
		c1.setProperty("repository.summary",RepoSummary)
		c1.setProperty("repository.description",RepoDescription)
		c1.setProperty("repository.disclaimer",RepoDisclaimer)
		c1.setProperty("repository.version",RepoVersion)
		c1.setProperty("repository.name",RepoName)
		c1.setProperty("repository.author",RepoAuthor)
		c1.setProperty("repository.installedpath",InstalledPath)
		c1.setProperty("repository.url",RepoURL)
		c1.setProperty("repository.urlmd5",RepoURLMD5)
		c1.setProperty("repository.urlpath",RepoURLPath)
		c1.setProperty("repository.category","")
		self.CtrlList.addItem(c1)
		
	def AddRepoCat(self,RepoID="",RepoName="",RepoVersion="",RepoCategory="",RepoSummary="",RepoDescription="",RepoDisclaimer="",RepoAuthor="",InstalledPath="special://home"):
		r1=repo(RepoID,"icon.png",h=InstalledPath)
		r2=repo(RepoID,"fanart.jpg",h=InstalledPath)
		deb("icon",r1)
		c1=xbmcgui.ListItem(RepoCategory,"",iconImage=r1,thumbnailImage=r1)
		c1.setProperty("repository.id",RepoID)
		c1.setProperty("repository.icon",r1)
		c1.setProperty("repository.fanart",r2)
		c1.setProperty("repository.summary",RepoSummary)
		c1.setProperty("repository.description",RepoDescription)
		c1.setProperty("repository.disclaimer",RepoDisclaimer)
		c1.setProperty("repository.version",RepoVersion)
		c1.setProperty("repository.name",RepoName)
		c1.setProperty("repository.category","")
		self.RepoCatList.addItem(c1)
		
	def FillInRepoCatList(self,SelectedRepo):
		#SelectedRepo.getProperty("repository.icon")
		RepoID=SelectedRepo.getProperty("repository.id")
		RepoName=SelectedRepo.getProperty("repository.name")
		RepoVersion=SelectedRepo.getProperty("repository.version")
		RepoURL=SelectedRepo.getProperty("repository.url")
		RepoURLMD5=SelectedRepo.getProperty("repository.urlmd5")
		RepoURLPath=SelectedRepo.getProperty("repository.urlpath")
		self.LabCurrentRepo.setLabel(RepoName)
		self.RepoCatList.reset()
		
		RepoDATA=getURL(RepoURL)
		
		#AddRepoCat(RepoID,RepoName,RepoVersion,"")
		zz=["Video Addons","Music Addons","Program Addons",str(len(RepoDATA))]
		for z in zz:
			self.AddRepoCat(RepoID,RepoName,RepoVersion,z)
		
		self.setFocus(self.RepoCatList)
	#def onFocus(self,control):
	#	#try: 
	#	if len(str(self.CtrlList.getSelectedItem().getProperty("repository.icon"))) > 0:
	#			self.RepoThumbnail.setImage(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
	#			debob(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
	#	else:
	#			self.RepoThumbnail.setImage(self.background)
	#	#except: self.RepoThumbnail.setImage(self.background)
	#	#debob(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
	def onAction(self,action):
		#non Display Button control
		if   action == ACTION_PREVIOUS_MENU: self.close()
		elif action == ACTION_NAV_BACK: self.close()
		#try: 
		rpI=str(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
		if (len(rpI) > 0) and (os.path.isfile(rpI)==True):
				self.RepoThumbnail.setImage(rpI); self.RepoThumbnail.setVisible(True)
		#elif (len(rpI) > 0):
		#		self.RepoThumbnail.setImage(rpI); self.RepoThumbnail.setVisible(True)
		else: self.RepoThumbnail.setImage(self.b1); self.RepoThumbnail.setVisible(False)
		rpF=str(self.CtrlList.getSelectedItem().getProperty("repository.fanart"))
		if (len(rpF) > 0) and (os.path.isfile(rpF)==True):
				self.RepoFanart.setImage(rpF); self.RepoFanart.setVisible(True)
				#self.LabTitle.setLabel(rpF)
		#elif (len(rpF) > 0):
		#		self.RepoFanart.setImage(rpF); self.RepoFanart.setVisible(True)
		else: self.RepoFanart.setImage(self.b1); #self.RepoFanart.setVisible(False)
		#except: self.RepoThumbnail.setImage(self.background)
		#debob(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
		
	def onControl(self,control):
		#Display Button control
		if   control==self.button[0]: self.close()
		#elif control==self.button0: freeze_install(Main)
		#elif control==self.button1: freeze_uninstall(Main)
		#elif control==self.button3: xml_mod(Main)
		#elif control==self.button2: self.close()
		elif control==self.CtrlList: 
			#t2=self.CtrlList.getSelectedItem().getPath()
			t1=self.CtrlList.getSelectedItem()
			t2=str(t1.getProperty("repository.id"))
			#note("Repository's ID",t2)
			#deb("path",t2)
			self.FillInRepoCatList(self.CtrlList.getSelectedItem())
			##
		
		##

def deb(s,t): ### for Writing Debug Data to log file ###
	#if (_debugging==True): 
	print s+':  '+t
def debob(t): ### for Writing Debug Object to log file ###
	#if (_debugging==True): 
	print t
def nolines(t):
	it=t.splitlines(); t=''
	for L in it: t=t+L
	t=((t.replace("\r","")).replace("\n",""))
	return t
def art(f,fe=''): return xbmc.translatePath(os.path.join(Config.artPath,f+fe))
def artp(f,fe='.png'): return art(f,fe)
def artj(f,fe='.jpg'): return art(f,fe)
def note(title='',msg='',delay=5000,image='http://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/US_99_%281961%29.svg/40px-US_99_%281961%29.svg.png'): xbmc.executebuiltin('XBMC.Notification("%s","%s",%d,"%s")' % (title,msg,delay,image))
def repo(repository,filename='',h="special://home",a="addons"): 
	if len(filename)==0: return xbmc.validatePath(xbmc.translatePath(os.path.join(h,a,repository)))
	else: return xbmc.validatePath(xbmc.translatePath(os.path.join(h,a,repository,filename)))
def repox(repository,filename='',h="special://xbmc",a="addons"): 
	if len(filename)==0: return xbmc.validatePath(xbmc.translatePath(os.path.join(h,a,repository)))
	else: return xbmc.validatePath(xbmc.translatePath(os.path.join(h,a,repository,filename)))
def _SaveFile(path,data):
	file=open(path,'w')
	file.write(data)
	file.close()
def _OpenFile(path):
	deb('File',path)
	if os.path.isfile(path): ## File found.
		deb('Found',path)
		file = open(path, 'r')
		contents=file.read()
		file.close()
		return contents
	else: return '' ## File not found.
def _CreateDirectory(dir_path):
	dir_path = dir_path.strip()
	if not os.path.exists(dir_path): os.makedirs(dir_path)
def _get_dir(mypath, dirname): #...creates sub-directories if they are not found.
	subpath = os.path.join(mypath, dirname)
	if not os.path.exists(subpath): os.makedirs(subpath)
	return subpath
def getURL(url):
	try:
		req=urllib2.Request(url)
		req.add_header(MyBrowser[0],MyBrowser[1]) 
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return(link)
	except: return ''


## Start of program
TempWindow=MyWindow()
TempWindow.doModal()
del TempWindow

