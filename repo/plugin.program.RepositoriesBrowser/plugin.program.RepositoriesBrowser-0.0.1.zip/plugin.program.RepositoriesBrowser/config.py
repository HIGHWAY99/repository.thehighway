## from config import Config as Config

import xbmc,xbmcaddon,xbmcplugin,os
_addon_id="plugin.program.RepositoriesBrowser"
_addon_name="XBMCHUB Repositories Browser"
_addon=xbmcaddon.Addon(id=_addon_id)
#_addon=xbmcaddon.Addon()
def gAI(t):
	try: return _addon.getAddonInfo(t)
	except: 
		#if t=="name": return _addon_name
		#else: return ""
		return ""

class Config:
	addon_id=_addon_id
	#name='Repositories Browser'
	addon=_addon
	handle=0
	name=gAI('name'); 
	#name="XBMCHUB Repositories Browser"; 
	path=gAI('path'); 
	#profile=xbmc.translatePath(gAI('profile'))
	disclaimer=gAI('disclaimer'); description=gAI('description'); summary=gAI('summary'); 
	icon=gAI('icon'); fanart=gAI('fanart'); 
	addon_type=gAI('type'); author=gAI('author'); version=gAI('version'); stars=gAI('stars'); changelog=gAI('changelog'); 
	
	artPath=xbmc.translatePath(os.path.join(path,'art'))
	
	
	def gSetting(self,setting):
		try: return self.addon.getSetting(setting)
		except: return ""
	def set_setting(self,setting,value):
		self.addon.setSetting(id=setting,value=value)
	def get_string(self, string_id):
		try: return self.addon.getLocalizedString(string_id)
		except: return ""
	def get_id(self):
		try: return self.addon.getAddonInfo('id')
		except: return self.addon_id
	def note(self,title='',msg='',delay=5000,image='http://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/US_99_%281961%29.svg/40px-US_99_%281961%29.svg.png'):
		xbmc.executebuiltin('XBMC.Notification("%s","%s",%d,"%s")' % (title,msg,delay,image))
	def show_settings(self): self.addon.openSettings()
	def eod(self):
		xbmcplugin.endOfDirectory(self.handle)
	
	
	
	
	