import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,htmllib
import shutil
#import fileinput
##import elementtree as ET2
#import elementtree.ElementTree as ET1
##import elementtree.ElementTree as ET
#from elementtree.ElementTree import parse

from config import Config as Config
import downloader
import extract

try: from sqlite3 import dbapi2 as orm
except: from pysqlite2 import dbapi2 as orm
DB='sqlite'; 
DB_File='Addons15.db'; DB_DIR =os.path.join(xbmc.translatePath("special://database"),DB_File); 
DB_File2='Addons.db';  DB_DIR2=os.path.join(xbmc.translatePath("special://database"),DB_File2); 
#if    os.path.isfile(DB_DIR )==True: print "Database Found: "+DB_DIR;  DB_Located=DB_DIR; 
#elif  os.path.isfile(DB_DIR2)==True: print "Database Found: "+DB_DIR2; DB_Located=DB_DIR2; 
#else: print "Unable to locate Database"

yy=['20','19','18','17','16','15','14','13','12','11','10','9','8','7','6','5','4','3','2','1','']
DB_Located=''
for z in yy:
	if len(DB_Located)==0:
		testZ=os.path.join(xbmc.translatePath("special://database"),'Addons'+z+'.db')
		if    os.path.isfile(testZ)==True: print "Database Found: "+testZ;  DB_Located=testZ; 
if len(DB_Located)==0: print "Unable to locate Database"

MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

#def unCacheAnImage(url):
#	if os.path.isfile(DB_DIR)==True: 
#		db=orm.connect(DB_DIR); 
#		#g='Select cachedurl FROM texture WHERE url = "'+url+'";'; print g; 
#		#a=db.execute(g); print str(a); 
#		s='DELETE FROM texture WHERE url = "'+url+'";'; print s; 
#		db.execute(s); 
#		db.commit(); db.close(); 
#	##

def getITEMS(table='repo',where='',what='*'):
	if os.path.isfile(DB_Located)==True: 
		db=orm.connect(DB_Located); 
		dbc = db.cursor()
		s='SELECT '+what+' FROM '+table+where; debob(s); 
		dbc.execute(s); 
		return dbc.fetchall()
		#r0=dbc.fetchall()
		db.close(); 
		return r0 #db.fetchall()
		#db.commit(); db.close(); 
	
def getITEM(table='repo',where='',what='*'):
	if os.path.isfile(DB_Located)==True: 
		db=orm.connect(DB_Located); 
		dbc = db.cursor()
		s='SELECT '+what+' FROM '+table+where; debob(s); 
		dbc.execute(s); 
		db.close(); 
		return dbc.fetchone()
		#db.commit(); db.close(); 


ACTION_PREVIOUS_MENU = 10	## ESC action
ACTION_NAV_BACK = 92	## Backspace action
ACTION_MOVE_LEFT = 1	## Left arrow key
ACTION_MOVE_RIGHT = 2	## Right arrow key
ACTION_MOVE_UP = 3	## Up arrow key
ACTION_MOVE_DOWN = 4	## Down arrow key
ACTION_MOUSE_WHEEL_UP = 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN = 105	## Mouse wheel down
ACTION_MOUSE_DRAG = 106	## Mouse drag
ACTION_MOUSE_MOVE = 107	## Mouse move

class MyWindow(xbmcgui.Window):
	#
	#
	InstallToPath=xbmc.validatePath(xbmc.translatePath(os.path.join("special://home","addons")))
	DownloadToPath=xbmc.validatePath(xbmc.translatePath(os.path.join("special://home","addons","packages")))
	DotOrgRepo_XML='http://mirrors.xbmc.org/addons/frodo/addons.xml'
	DotOrgRepo_XMLInfoCompressed=True
	DotOrgRepo_Checksum='http://mirrors.xbmc.org/addons/frodo/addons.xml.md5'
	DotOrgRepo_DataDirPath='http://mirrors.xbmc.org/addons/frodo'
	DotOrgRepo_DataDirZIP=True
	##
	button={}
	def __init__(self):
		self.background=(xbmc.translatePath(Config.fanart))
		#if len(self.background)==0: self.background="0x00000000"
		#if len(self.background)==0: self.background="0x00FFFFFF"
		self.background=artp("XBMCHUB_D5")
		self.backgroundB=artp("XBMCHUB_D5T")
		self.b1=artp("black1")
		#deb("BG",self.background)
		self.BGB=xbmcgui.ControlImage(0,0,1280,720,self.b1,aspectRatio=1); self.addControl(self.BGB)
		self.TVSBGB=xbmcgui.ControlImage(800,12,280,190,self.b1,aspectRatio=1); self.addControl(self.TVSBGB)
		self.TVS=xbmcgui.ControlImage(800,12,280,190,self.b1,aspectRatio=1); self.addControl(self.TVS)
		#self.TVS.setAnimations([('WindowOpen','effect=rotatex time=0 end=30'),('WindowOpen','effect=rotatey time=0 end=60')])
		self.TVSBGB.setAnimations([('WindowOpen','effect=rotatey time=0 end=10 center=1040,120')])
		self.TVS.setAnimations([('WindowOpen','effect=rotatey time=0 end=10 center=1040,120')])
		self.BG=xbmcgui.ControlImage(0,0,1280,720,self.backgroundB,aspectRatio=1); self.addControl(self.BG)
		focus=artp("button-focus2"); nofocus=artp("button-nofocus"); 
		self.RepoFanart2=xbmcgui.ControlImage(30,120,400,520,self.b1,aspectRatio=1); self.addControl(self.RepoFanart2); 
		self.RepoFanart=xbmcgui.ControlImage(30,120,330,460,self.b1,aspectRatio=1); self.addControl(self.RepoFanart); 
		self.RepoThumbnail=xbmcgui.ControlImage(330,120,100,100,self.background,aspectRatio=1); self.addControl(self.RepoThumbnail); 
		#self.AddonFanart2=xbmcgui.ControlImage(440,120,400,460,self.b1,aspectRatio=1); self.addControl(self.AddonFanart2); 
		#self.AddonFanart=xbmcgui.ControlImage(440,120,330,460,self.b1,aspectRatio=1); self.addControl(self.AddonFanart); 
		#self.AddonThumbnail=xbmcgui.ControlImage(740,120,100,100,self.b1,aspectRatio=1); self.addControl(self.AddonThumbnail); 
		
		self.LabTitle=xbmcgui.ControlLabel(30,20,1000,50,'','font30','0xFFFF0000'); self.addControl(self.LabTitle)
		self.LabTitleText=Config.name.replace("XBMCHUB ","[COLOR deepskyblue][B][I]XBMCHUB[/I][/B][/COLOR]  ")
		self.LabTitle.setLabel(self.LabTitleText)
		#self.button[0]=xbmcgui.ControlButton(30, 70, 135, 30, "Exit")
		self.button[0]=xbmcgui.ControlButton(30, 70, 135, 30, "Exit",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus)
		self.addControl(self.button[0])
		#time.sleep(2); 
		self.CtrlList=xbmcgui.ControlList(30,120,400,500,font='font12',textColor="0xFFFF0000",selectedColor="0xFF00FF00",buttonFocusTexture=focus,buttonTexture=nofocus); self.CtrlList.setSpace(2); self.addControl(self.CtrlList); 
		self.LabCurrentRepo=xbmcgui.ControlLabel(400,80,400,30,'','font12','0xFF00BFFF',alignment=1); self.addControl(self.LabCurrentRepo)
		#self.RepoCatList=xbmcgui.ControlList(440,120,400,480,font='font12',textColor="0xFFFF0000",selectedColor="0xFF00FF00",buttonFocusTexture=focus,buttonTexture=nofocus); self.RepoCatList.setSpace(5); self.addControl(self.RepoCatList); 
		#self.AddonsList=xbmcgui.ControlList(440,120,400,480,font='font12',textColor="0xFFFF0000",selectedColor="0xFF00FF00",buttonFocusTexture=focus,buttonTexture=nofocus); self.AddonsList.setSpace(5); self.addControl(self.AddonsList); 
		
		#leftA=850; widA=235; hiB=30; 
		#topA=10; 		hiA=700-topA; self.AddonFanart3=xbmcgui.ControlImage(leftA,topA,400,hiA,self.b1,aspectRatio=1); self.addControl(self.AddonFanart3); 
		#topA=topA+0; 		 hiA= 20; self.AddonsTitle=xbmcgui.ControlLabel(leftA,topA,400,hiA,'',font='font12',textColor="0xFF00BFFF"); self.addControl(self.AddonsTitle); 
		#self.btnInstall=xbmcgui.ControlButton(leftA-5-widA,topA,widA,hiB, "Install",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.btnInstall)
		#self.btnUninstall=xbmcgui.ControlButton(leftA-5-widA,topA+2+hiB,widA,hiB, "Uninstall",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.btnUninstall)
		#self.btnInstall.setVisible(False); self.btnUninstall.setVisible(False); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsId=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFF0000"); self.addControl(self.AddonsId); 
		#topA=			 topA; hiA= 20; self.AddonsVer=xbmcgui.ControlLabel(leftA+400,topA,100,hiA,'',font='font12',textColor="0xFFFFFFFF",alignment=1); self.addControl(self.AddonsVer); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsAuthor=xbmcgui.ControlLabel(leftA,topA,400,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsAuthor); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsPlatform=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsPlatform); 
		#topA=			 topA; hiA= 20; self.AddonsLanguage=xbmcgui.ControlLabel(leftA+400,topA,200,hiA,'',font='font12',textColor="0xFFFFFFFF",alignment=1); self.addControl(self.AddonsLanguage); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsProvides=xbmcgui.ControlLabel(leftA,topA,400,hiA,'',font='font12',textColor="0xFFFF00FF"); self.addControl(self.AddonsProvides); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsRepoName=xbmcgui.ControlLabel(leftA,topA,400,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsRepoName); 
		#topA=topA+2+hiA; hiA= 60; self.AddonsSummary=xbmcgui.ControlTextBox(leftA,topA,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsSummary); 
		#topA=topA+2+hiA; hiA=150; self.AddonsDescription=xbmcgui.ControlTextBox(leftA,255,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsDescription); 
		#topA=topA+2+hiA; hiA= 30; self.AddonsBroken=xbmcgui.ControlTextBox(leftA,410,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsBroken); 
		#topA=topA+2+hiA; hiA=150; self.AddonsRequirements=xbmcgui.ControlTextBox(leftA,445,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsRequirements); 
		
		self.ItemsA=getITEMS(table='addon',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); #debob(self.ItemsA); 
		self.ItemsR=getITEMS(table='repo',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); #debob(self.ItemsR); 
		
		Items=getITEMS(table='repo',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)'); debob(Items); 
		Items=sorted(Items, key=lambda item: item[1], reverse=False)
		for (i_id,i_addonID,i_checksumb,i_lastcheck) in Items:
			debob((i_id,i_addonID))
			addon_path="special://home"; addon_file=repo(i_addonID,"addon.xml")
			if os.path.isfile(addon_file)==False: addon_path="special://xbmc"; addon_file=repox(i_addonID,"addon.xml"); 
			if os.path.isfile(addon_file)==True:
				pleaseSkip=False
				try: addon_xml=nolines(_OpenFile(addon_file))
				except: pleaseSkip=True
				#addon_xml_addon=addon_xml.split("<addon",re.IGNORECASE)[1].split(">")[0]
				try: addon_xml_addon=re.compile("<addon(.*?)>",re.IGNORECASE).findall(addon_xml)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_inner=re.compile("<addon.*?>(.*?)</addon>",re.IGNORECASE).findall(addon_xml)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_name=re.compile('\s+name="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_version=re.compile('\s+version="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_author=re.compile('\s+provider-name="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
				except:
					try: addon_xml_addon_author=re.compile("\s+provider-name='(.*?)'",re.IGNORECASE).findall(addon_xml_addon)[0]
					except: addon_xml_addon_author="[UNKNOWN]"
				try: addon_xml_addon_url=re.compile('<info.*?>(.*?)</info>',re.IGNORECASE).findall(addon_xml_addon_inner)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_urlmd5=re.compile('<checksum.*?>(.*?)</checksum>',re.IGNORECASE).findall(addon_xml_addon_inner)[0]
				except: pleaseSkip=True
				try: addon_xml_addon_urlpath=re.compile('<datadir.*?>(.*?)</datadir>',re.IGNORECASE).findall(addon_xml_addon_inner)[0]
				except: pleaseSkip=True
				debob((i_addonID,addon_xml_addon_url,addon_xml_addon_urlmd5,addon_xml_addon_urlpath))
				if pleaseSkip==False:
					self.AddRepo(RepoID=str(i_addonID),RepoName=str(addon_xml_addon_name),RepoVersion=str(addon_xml_addon_version),RepoNumber=str(i_id),RepoLastCheck=str(i_lastcheck),RepoChecksum=str(i_checksumb),RepoSummary="",RepoDescription="",RepoDisclaimer="",RepoAuthor=str(addon_xml_addon_author),InstalledPath=addon_path,RepoURL=addon_xml_addon_url,RepoURLMD5=addon_xml_addon_urlmd5,RepoURLPath=addon_xml_addon_urlpath)
				#self.AddRepo(RepoID=str(i_addonID),RepoName=str(i_addonID),RepoVersion="0.0.4",RepoNumber=str(i_id),RepoLastCheck=str(i_lastcheck),RepoChecksum=str(i_checksumb))
			##
		##
		self.button[0].controlDown(self.CtrlList); self.button[0].controlUp(self.CtrlList); 
		self.CtrlList.controlDown(self.button[0]); self.CtrlList.controlUp(self.button[0]); 
		self.CtrlList.controlLeft(self.button[0]); self.CtrlList.controlRight(self.button[0]); 
		
		
		
		self.setFocus(self.button[0])
		##
		#self.DotOrgREPO=getURL(self.DotOrgRepo_XML)
		#if len(self.DotOrgREPO) > 0: self.DotOrgREPO_Addons=re.compile('<addon\s+(.+?)>(.+?)</addon',re.IGNORECASE).findall(self.DotOrgREPO)
		#else: self.DotOrgREPO=[]
		##
	def AddRepo(self,RepoID="",RepoName="",RepoVersion="",RepoNumber="",RepoLastCheck="",RepoChecksum="",RepoSummary="",RepoDescription="",RepoDisclaimer="",RepoAuthor="",InstalledPath="special://home",RepoURL="",RepoURLMD5="",RepoURLPath=""):
		r1=repo(RepoID,"icon.png",h=InstalledPath)
		r2=repo(RepoID,"fanart.jpg",h=InstalledPath)
		#deb("icon",r1)
		c1=xbmcgui.ListItem(RepoName,RepoVersion,iconImage=r1,thumbnailImage=r1)
		c1.setProperty("repository.id",RepoID)
		c1.setProperty("repository.number",RepoNumber)
		c1.setProperty("repository.lastcheck",RepoLastCheck)
		c1.setProperty("repository.checksum",RepoChecksum)
		c1.setProperty("repository.icon",r1)
		c1.setProperty("repository.fanart",r2)
		c1.setProperty("repository.summary",RepoSummary)
		c1.setProperty("repository.description",RepoDescription)
		c1.setProperty("repository.disclaimer",RepoDisclaimer)
		c1.setProperty("repository.version",RepoVersion)
		c1.setProperty("repository.name",RepoName)
		c1.setProperty("repository.author",RepoAuthor)
		c1.setProperty("repository.installedpath",InstalledPath)
		c1.setProperty("repository.url",RepoURL)
		c1.setProperty("repository.urlmd5",RepoURLMD5)
		c1.setProperty("repository.urlpath",RepoURLPath)
		c1.setProperty("repository.category","")
		self.CtrlList.addItem(c1)
		
	def AddRepoCat(self,RepoID="",RepoName="",RepoVersion="",RepoCategory="",RepoSummary="",RepoDescription="",RepoDisclaimer="",RepoAuthor="",InstalledPath="special://home"):
		r1=repo(RepoID,"icon.png",h=InstalledPath)
		r2=repo(RepoID,"fanart.jpg",h=InstalledPath)
		#deb("icon",r1)
		c1=xbmcgui.ListItem(RepoCategory,"",iconImage=r1,thumbnailImage=r1)
		c1.setProperty("repository.id",RepoID)
		c1.setProperty("repository.icon",r1)
		c1.setProperty("repository.fanart",r2)
		c1.setProperty("repository.summary",RepoSummary)
		c1.setProperty("repository.description",RepoDescription)
		c1.setProperty("repository.disclaimer",RepoDisclaimer)
		c1.setProperty("repository.version",RepoVersion)
		c1.setProperty("repository.name",RepoName)
		c1.setProperty("repository.category","")
		#cMI=[]; 
		#cMI.append(( 'Show Info','XBMC.Action(Info)' ))
		#c1.addContextMenuItems(cMI)
		
		self.RepoCatList.addItem(c1)
		##
	def FillInRepoCatList(self,SelectedRepo):
		#SelectedRepo.getProperty("repository.icon")
		RepoID=SelectedRepo.getProperty("repository.id")
		RepoName=SelectedRepo.getProperty("repository.name")
		RepoVersion=SelectedRepo.getProperty("repository.version")
		RepoURL=SelectedRepo.getProperty("repository.url")
		RepoURLMD5=SelectedRepo.getProperty("repository.urlmd5")
		RepoURLPath=SelectedRepo.getProperty("repository.urlpath")
		self.LabCurrentRepo.setLabel(RepoName)
		self.RepoCatList.reset()
		RepoDATA=getURL(RepoURL)
		#AddRepoCat(RepoID,RepoName,RepoVersion,"")
		setContent("repositories"); 
		
		zz=["Video Addons","Music Addons","Program Addons",str(len(RepoDATA))]
		for z in zz:
			self.AddRepoCat(RepoID,RepoName,RepoVersion,z)
		
		self.setFocus(self.RepoCatList)
	def getCurrentVerOfAddon(self,TheAddonXmlFile):
		if os.path.isfile(TheAddonXmlFile)==False: return ''
		try: addon_xml=nolines(_OpenFile(TheAddonXmlFile))
		except: return ''
		try: addon_xml_addon=re.compile("<addon(.*?)>",re.IGNORECASE).findall(addon_xml)[0]
		except: return ''
		#try: addon_xml_addon_name=re.compile('\s+name="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
		#except: return ''
		try: addon_xml_addon_version=re.compile('\s+version="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
		except: return ''
		try: return addon_xml_addon_version
		except: return ''
	def onAction(self,action):
		#non Display Button control
		if   action == ACTION_PREVIOUS_MENU: self.close()
		elif action == ACTION_NAV_BACK: self.close()
		try:
			#try: 
			rpI=str(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
			if (len(rpI) > 0) and (os.path.isfile(rpI)==True):
					#self.RepoThumbnail.setImage(rpI); self.RepoThumbnail.setVisible(True)
					self.TVS.setImage(rpI); self.TVS.setVisible(True)
			#elif (len(rpI) > 0):
			#		self.RepoThumbnail.setImage(rpI); self.RepoThumbnail.setVisible(True)
			else: self.RepoThumbnail.setImage(self.b1); self.RepoThumbnail.setVisible(False)
			rpF=str(self.CtrlList.getSelectedItem().getProperty("repository.fanart"))
			if (len(rpF) > 0) and (os.path.isfile(rpF)==True):
					#self.RepoFanart.setImage(rpF); self.RepoFanart.setVisible(True)
					#self.TVS.setImage(rpF); self.TVS.setVisible(True)
					self.BGB.setImage(rpF); self.BGB.setVisible(True)
					#self.LabTitle.setLabel(rpF)
			#elif (len(rpF) > 0):
			#		self.RepoFanart.setImage(rpF); self.RepoFanart.setVisible(True)
			else: self.RepoFanart.setImage(self.b1); #self.RepoFanart.setVisible(False)
			#except: self.RepoThumbnail.setImage(self.background)
			#debob(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
		except: pass
		try:
			addonI=str(self.AddonsList.getSelectedItem().getProperty("addon.icon"))
			#if (len(addonI) > 0) and (os.path.isfile(addonI)==True):
			if (len(addonI) > 0):
					self.AddonThumbnail.setImage(addonI); self.AddonThumbnail.setVisible(True)
			else: self.AddonThumbnail.setImage(self.b1); self.AddonThumbnail.setVisible(False)
			addonF=str(self.AddonsList.getSelectedItem().getProperty("addon.fanart"))
			if (len(addonF) > 0):
					self.AddonFanart.setImage(addonF); self.AddonFanart.setVisible(True)
					#self.LabTitle.setLabel(rpF)
			else: self.AddonFanart.setImage(self.b1); #self.RepoFanart.setVisible(False)
		except: pass
		#if addonI==addonI:
		try:
			addonFsi=self.AddonsList.getSelectedItem()
			#debob(addonFsi.getLabel())
			#debob(addonFsi.getProperty("addon.id"))
			try: self.AddonsId.setLabel("[COLOR mediumpurple]ID: [/COLOR]"+str(addonFsi.getProperty("addon.id")))
			except: self.AddonsId.setLabel('')
			aLatestVersion=str(addonFsi.getProperty("addon.version")); 
			try: self.AddonsVer.setLabel("[COLOR mediumpurple]ver: [/COLOR]"+aLatestVersion)
			except: self.AddonsVer.setLabel('')
			try: self.AddonsTitle.setLabel("[COLOR mediumpurple]Name: [/COLOR]"+str(addonFsi.getProperty("addon.name")))
			except: self.AddonsTitle.setLabel('')
			try: self.AddonsRepoName.setLabel("[COLOR mediumpurple]Repo: [/COLOR]"+str(addonFsi.getProperty("repository.name")))
			except: self.AddonsRepoName.setLabel('')
			try: self.AddonsAuthor.setLabel("[COLOR mediumpurple]Author(s): [/COLOR]"+str(addonFsi.getProperty("addon.provider-name")))
			except: self.AddonsAuthor.setLabel('')
			try: self.AddonsProvides.setLabel("[COLOR mediumpurple]Type: [/COLOR]"+str(addonFsi.getProperty("addon.provides")))
			except: self.AddonsProvides.setLabel('')
			try: self.AddonsSummary.setText("[COLOR mediumpurple]Summary: [/COLOR]"+str(addonFsi.getProperty("addon.summary")))
			except: self.AddonsSummary.setText('')
			try: self.AddonsDescription.setText("[COLOR mediumpurple]Description: [/COLOR]"+str(addonFsi.getProperty("addon.description")))
			except: self.AddonsDescription.setText('')
			try: self.AddonsRequirements.setText("[COLOR mediumpurple]Requires: [/COLOR][CR]"+str(addonFsi.getProperty("addon.requires").replace('addon=','').replace('version=','').replace('/>','>').replace(' <','<')))
			except: self.AddonsRequirements.setText('')
			try: 
				if len(str(addonFsi.getProperty("addon.language"))) > 0:
					self.AddonsLanguage.setLabel("[COLOR mediumpurple]Language: [/COLOR]"+str(addonFsi.getProperty("addon.language")))
				else: self.AddonsLanguage.setLabel('')
			except: self.AddonsLanguage.setLabel('')
			try: 
				if len(str(addonFsi.getProperty("addon.platform"))) > 0:
					self.AddonsPlatform.setLabel("[COLOR mediumpurple]Platform: [/COLOR]"+str(addonFsi.getProperty("addon.platform")))
				else: self.AddonsPlatform.setLabel('')
			except: self.AddonsPlatform.setLabel('')
			try: 
				if len(str(addonFsi.getProperty("addon.broken"))) > 0:
					self.AddonsBroken.setText("[COLOR mediumpurple]Broken: [/COLOR]"+str(addonFsi.getProperty("addon.broken")))
				else: self.AddonsBroken.setText('')
			except: self.AddonsBroken.setText('')
			##
			#addon.currentinstalledversion
			#addon.installed
			try: 
				if 'tru' in addonFsi.getProperty("addon.installed"):
					try: 		AciVerA=str(addonFsi.getProperty("addon.currentinstalledversion")); AciVer=' ['+AciVerA+']'
					except: AciVerA=''; AciVer=''
					#debob((AciVerA,aLatestVersion)); 
					#try: 
					AciE=str(addonFsi.getProperty("addon.ebabled")); 
					#except: AciE='false'
					deb('AciE',AciE); 
					if AciE=='true':
						if AciVerA==aLatestVersion:
							self.btnInstall.setLabel('['+AciVerA+']'); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(False); 
						else:
							self.btnInstall.setLabel('Update'+AciVer); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(True); 
					else:
							self.btnInstall.setLabel('Disabled'+AciVer); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(False); 
				else: 
					self.btnInstall.setLabel('Install'); 
					self.btnInstall.setVisible(True); 
					self.btnInstall.setEnabled(True); 
			except: self.btnInstall.setEnabled(False); self.btnInstall.setLabel('')
			try: 
				if 'tru' in addonFsi.getProperty("addon.installed"):
					self.btnUninstall.setLabel('Uninstall'); 
					self.btnUninstall.setVisible(True); 
					self.btnUninstall.setEnabled(True); 
				#else: self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
				else: self.btnUninstall.setVisible(False); self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			#except: self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			except: self.btnUninstall.setVisible(False); self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			##
		except: pass
		
	def onControl(self,control):
		#Display Button control
		if   control==self.button[0]: self.close()
		#elif control==self.button0: freeze_install(Main)
		#elif control==self.button1: freeze_uninstall(Main)
		#elif control==self.button3: xml_mod(Main)
		#elif control==self.button2: self.close()
		elif control==self.CtrlList: 
			#t2=self.CtrlList.getSelectedItem().getPath()
			t1=self.CtrlList.getSelectedItem()
			t2=str(t1.getProperty("repository.id"))
			#note("Repository's ID",t2)
			#deb("path",t2)
			#self.FillInRepoCatList(self.CtrlList.getSelectedItem())
			#self.FillInAddonsList(self.CtrlList.getSelectedItem())
			self.CurrentRepoSelected=self.CtrlList.getSelectedItem()
			TempWindow2=MyWindowAddons(owner=self); TempWindow2.doModal(); 
			del TempWindow2
			##
		elif control==self.AddonsList:
			self.CurSelAddon=self.AddonsList.getSelectedItem()
			self.setFocus(self.btnInstall)
			try: bTxt=self.btnInstall.getLabel()
			except: bTxt=''
			#deb("Install-Button's Text",bTxt); 
			if len(bTxt) > 0:
				if   ('Install' in bTxt): self.btnInstall.setVisible(True); self.btnInstall.setEnabled(True); self.setFocus(self.btnInstall)
				elif ('Update' in bTxt): self.btnInstall.setVisible(True); self.btnInstall.setEnabled(True); self.setFocus(self.btnInstall)
				elif ('Disabled [' in bTxt): self.setFocus(self.btnUninstall)
				elif ('[' in bTxt) and (']' in bTxt): self.setFocus(self.btnUninstall)
				else: self.setFocus(self.btnUninstall)
			else: self.setFocus(self.btnUninstall)
		elif control==self.btnInstall: self.doAddonInstall(control); 
		elif control==self.btnUninstall: self.doAddonUninstall(control); 
		
		##
	##
## ################################################## ##
## ################################################## ##

class MyWindowAddons(xbmcgui.Window):
	#
	#
	InstallToPath=xbmc.validatePath(xbmc.translatePath(os.path.join("special://home","addons")))
	DownloadToPath=xbmc.validatePath(xbmc.translatePath(os.path.join("special://home","addons","packages")))
	DotOrgRepo_XML='http://mirrors.xbmc.org/addons/frodo/addons.xml'
	DotOrgRepo_XMLInfoCompressed=True
	DotOrgRepo_Checksum='http://mirrors.xbmc.org/addons/frodo/addons.xml.md5'
	DotOrgRepo_DataDirPath='http://mirrors.xbmc.org/addons/frodo'
	DotOrgRepo_DataDirZIP=True
	##
	button={}
	def __init__(self,owner):
		self.ow=owner
		self.BGB=xbmcgui.ControlImage(0,0,1280,720,self.ow.b1,aspectRatio=1); self.addControl(self.BGB)
		self.TVSBGB=xbmcgui.ControlImage(800,12,280,190,self.ow.b1,aspectRatio=1); self.addControl(self.TVSBGB)
		self.TVS=xbmcgui.ControlImage(800,12,280,190,self.ow.b1,aspectRatio=1); self.addControl(self.TVS)
		#self.TVS.setAnimations([('WindowOpen','effect=rotatex time=0 end=30'),('WindowOpen','effect=rotatey time=0 end=60')])
		self.TVSBGB.setAnimations([('WindowOpen','effect=rotatey time=0 end=10 center=1040,120')])
		self.TVS.setAnimations([('WindowOpen','effect=rotatey time=0 end=10 center=1040,120')])
		BG=xbmcgui.ControlImage(0,0,1280,720,self.ow.backgroundB,aspectRatio=1); self.addControl(BG)
		focus=artp("button-focus2"); nofocus=artp("button-nofocus"); 
		self.AddonFanart2=xbmcgui.ControlImage(30,120,400,460,self.ow.b1,aspectRatio=1); self.addControl(self.AddonFanart2); 
		self.AddonFanart=xbmcgui.ControlImage(30,120,330,460,self.ow.b1,aspectRatio=1); self.addControl(self.AddonFanart); 
		self.AddonThumbnail=xbmcgui.ControlImage(330,120,100,100,self.ow.b1,aspectRatio=1); self.addControl(self.AddonThumbnail); 
		
		self.LabTitle=xbmcgui.ControlLabel(30,20,1000,50,'','font30','0xFFFF0000'); self.addControl(self.LabTitle)
		self.LabTitle.setLabel(self.ow.LabTitleText)
		self.button[0]=xbmcgui.ControlButton(30, 70, 135, 30, "Back",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[0])
		#time.sleep(2); 
		self.LabCurrentRepo=xbmcgui.ControlLabel(400,80,400,30,'','font12','0xFF00BFFF',alignment=1); self.addControl(self.LabCurrentRepo)
		self.AddonsList=xbmcgui.ControlList(30,120,400,480,font='font12',textColor="0xFFFF0000",selectedColor="0xFF00FF00",buttonFocusTexture=focus,buttonTexture=nofocus); self.AddonsList.setSpace(5); self.addControl(self.AddonsList); 
		
		leftA=760; widA=235; hiB=30; topA=4; 
		self.btnInstall=xbmcgui.ControlButton(leftA-5-widA,topA,widA,hiB, "Install",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.btnInstall)
		self.btnUninstall=xbmcgui.ControlButton(leftA-5-widA,topA+2+hiB,widA,hiB, "Uninstall",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.btnUninstall)
		self.btnInstall.setVisible(False); self.btnUninstall.setVisible(False); 
		leftA=435; widA=235; hiB=30; 
		topA=75; 		hiA=200-topA+5; self.AddonFanart3=xbmcgui.ControlImage(leftA-10,topA,300+20,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.AddonFanart3); 
		topA=topA+0; 		 hiA= 20; self.AddonsTitle=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFF00BFFF"); self.addControl(self.AddonsTitle); 
		topA=topA+2+hiA; hiA= 20; self.AddonsId=xbmcgui.ControlLabel(leftA,topA,200,hiA,'',font='font12',textColor="0xFFFF0000"); self.addControl(self.AddonsId); 
		topA=			 topA; hiA= 20; self.AddonsVer=xbmcgui.ControlLabel(leftA+300,topA,100,hiA,'',font='font12',textColor="0xFFFFFFFF",alignment=1); self.addControl(self.AddonsVer); 
		topA=topA+2+hiA; hiA= 20; self.AddonsAuthor=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsAuthor); 
		topA=topA+2+hiA; hiA= 20; self.AddonsPlatform=xbmcgui.ControlLabel(leftA,topA,200,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsPlatform); 
		topA=			 topA; hiA= 20; self.AddonsLanguage=xbmcgui.ControlLabel(leftA+300,topA,200,hiA,'',font='font12',textColor="0xFFFFFFFF",alignment=1); self.addControl(self.AddonsLanguage); 
		topA=topA+2+hiA; hiA= 20; self.AddonsProvides=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFF00FF"); self.addControl(self.AddonsProvides); 
		topA=topA+2+hiA; hiA= 20; self.AddonsRepoName=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsRepoName); 
		
		#topA=topA+2+hiA; hiA= 60; self.AddonsSummary=xbmcgui.ControlTextBox(leftA,topA,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsSummary); 
		widA=400; 
		leftA=30; topA=580; hiA= 120; self.bgSummary=xbmcgui.ControlImage(leftA-2,topA,widA+4,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.bgSummary); self.AddonsSummary=xbmcgui.ControlTextBox(leftA,topA,widA,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsSummary); 
		leftA=leftA+2+400; topA=520; hiA=180; self.bgDescription=xbmcgui.ControlImage(leftA-2,topA,widA+4,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.bgDescription); self.AddonsDescription=xbmcgui.ControlTextBox(leftA,topA,widA,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsDescription); 
		leftA=leftA+2+400; topA=topA; hiA=180; self.bgRequirements=xbmcgui.ControlImage(leftA-2,topA,widA+4,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.bgRequirements); self.AddonsRequirements=xbmcgui.ControlTextBox(leftA,topA,widA,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsRequirements); 
		widA=440; leftA=770; topA=4; hiA= 60; self.bgBroken=xbmcgui.ControlImage(leftA-2,topA,widA+4,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.bgBroken); self.AddonsBroken=xbmcgui.ControlTextBox(leftA,topA,widA,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsBroken); 
		
		self.ItemsA=getITEMS(table='addon',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); #debob(self.ItemsA); 
		self.ItemsR=getITEMS(table='repo',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); #debob(self.ItemsR); 
		
		#Items=getITEMS(table='repo',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)'); debob(Items); 
		#Items=sorted(Items, key=lambda item: item[1], reverse=False)
		##
		
		#self.AddRepo("","")
		
		self.button[0].controlDown(self.AddonsList); self.button[0].controlUp(self.AddonsList); 
		self.button[0].controlLeft(self.AddonsList); self.button[0].controlRight(self.AddonsList); 
		#self.CtrlList.controlUp(self.button[0])
		#self.RepoCatList.controlUp(self.button[0])
		#self.AddonsList.controlUp(self.button[0])
		#self.CtrlList.controlRight(self.RepoCatList)
		#self.RepoCatList.controlRight(self.AddonsList)
		#self.AddonsList.controlLeft(self.RepoCatList)
		#self.RepoCatList.controlLeft(self.CtrlList)
		
		#self.AddonsList.controlRight(self.btnInstall)
		self.AddonsList.controlRight(self.button[0])
		self.AddonsList.controlLeft(self.button[0])
		self.AddonsList.controlUp(self.button[0])
		self.AddonsList.controlDown(self.button[0])
		
		self.btnInstall.controlRight(self.AddonsList)
		self.btnInstall.controlLeft(self.AddonsList)
		self.btnInstall.controlUp(self.AddonsList)
		self.btnInstall.controlDown(self.btnUninstall)
		
		self.btnUninstall.controlRight(self.AddonsList)
		self.btnUninstall.controlLeft(self.AddonsList)
		self.btnUninstall.controlUp(self.btnInstall)
		self.btnUninstall.controlDown(self.AddonsList)
		
		self.btnInstall.setEnabled(False); self.btnUninstall.setEnabled(False); 
		
		self.setFocus(self.button[0])
		##
		#self.DotOrgREPO=getURL(self.DotOrgRepo_XML)
		#if len(self.DotOrgREPO) > 0: self.DotOrgREPO_Addons=re.compile('<addon\s+(.+?)>(.+?)</addon',re.IGNORECASE).findall(self.DotOrgREPO)
		#else: self.DotOrgREPO=[]
		##
		
		self.FillInAddonsList(self.ow.CurrentRepoSelected)
		
		##
	def getCurrentVerOfAddon(self,TheAddonXmlFile):
		if os.path.isfile(TheAddonXmlFile)==False: return ''
		try: addon_xml=nolines(_OpenFile(TheAddonXmlFile))
		except: return ''
		try: addon_xml_addon=re.compile("<addon(.*?)>",re.IGNORECASE).findall(addon_xml)[0]
		except: return ''
		#try: addon_xml_addon_name=re.compile('\s+name="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
		#except: return ''
		try: addon_xml_addon_version=re.compile('\s+version="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
		except: return ''
		try: return addon_xml_addon_version
		except: return ''
	def AddAddon(self,ItemsD,AddonInner,AddonOutter,RepoID="",RepoName="",RepoVersion="",RepoURLPath="",RepoCategory="",RepoSummary="",RepoDescription="",RepoDisclaimer="",RepoAuthor="",InstalledPath="special://home"):
		m={}; m2={}; AddonInner=" "+AddonInner; AddonOutter=" "+AddonOutter; 
		zz=['id','version','name','provider-name']
		for z in zz:
			mv=''+z; mu=''+z; #debob(z); debob(AddonInner); 
			try:			m[mv]=re.compile('\s+'+mu+'="(.+?)"',re.IGNORECASE).findall(AddonInner)[0]
			except:		
				try: 		m[mv]=re.compile("\s+"+mu+"='(.+?)'",re.IGNORECASE).findall(AddonInner)[0]
				except: m[mv]=''
			m[mv]=re.compile('\s+'+mu+'="(.+?)"',re.IGNORECASE).findall(AddonInner)[0]
		zz2=['provides','requires','extension point="xbmc.addon.metadata"','language','platform','forum','website','source','broken']
		for z in zz2:
			mv=''+z; mu=''+z;
			try:			m2[mv]=re.compile('<'+mu+'\s*>(.+?)</'+mu+'',re.IGNORECASE).findall(AddonOutter)[0]
			except:		m2[mv]=''
		m2['requires']=m2['requires'].replace('	',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('> <','>[CR]<').replace('><','>[CR]<')
		zz3=['summary','description','disclaimer']
		for z in zz3:
			mv=''+z; mu=''+z;
			try:			m2[mv]=re.compile('<'+mu+'\s+lang="en"\s*>(.+?)</'+mu+'',re.IGNORECASE).findall(AddonOutter)[0]
			except:		
				try:		m2[mv]=re.compile('<'+mu+'\s*>(.+?)</'+mu+'',re.IGNORECASE).findall(AddonOutter)[0]
				except:	m2[mv]=''
		##
		#r1=repo(RepoID,"icon.png",h=InstalledPath)
		#r2=repo(RepoID,"fanart.jpg",h=InstalledPath)
		if (len(RepoURLPath) > 4):
			if (RepoURLPath[0:1:-1] not in '/'): 
				RepoURLPath+='/'
		r1=RepoURLPath+"/"+m['id']+"/icon.png"
		r2=RepoURLPath+"/"+m['id']+"/fanart.jpg"
		#deb("icon",r1)
		c1NameTag=''
		if len(m2['broken']) > 0: c1NameTag=' [Broken]'
		
		c1=xbmcgui.ListItem(m['name']+c1NameTag,m['version'],iconImage=r1,thumbnailImage=r1)
		inst1=str(repo(m['id'],"addon.xml")); inst2=str(repox(m['id'],"addon.xml")); debob(inst1); 
		if   os.path.isfile(inst1)==True: c1.setProperty("addon.installed",'true'); CurInstVer=self.getCurrentVerOfAddon(inst1); 
		elif os.path.isfile(inst2)==True: c1.setProperty("addon.installed",'trux'); CurInstVer=self.getCurrentVerOfAddon(inst2); 
		else: c1.setProperty("addon.installed",'false'); CurInstVer=''; 
		c1.setProperty("addon.currentinstalledversion",str(CurInstVer)); 
		##
		for z in zz: 
			#c1.setProperty("addon."+z,m[z])
			try: c1.setProperty("addon."+z,m[z])
			except: pass
		for z in zz2: 
			c1.setProperty("addon."+z,m2[z])
			#try: c1.setProperty("addon."+z,m2[z])
			#except: pass
		for z in zz3: 
			try: c1.setProperty("addon."+z,m2[z])
			except: pass
		##
		c1.setProperty("repository.id",RepoID)
		c1.setProperty("addon.icon",r1)
		c1.setProperty("addon.fanart",r2)
		#c1.setProperty("repository.icon",r1)
		#c1.setProperty("repository.fanart",r2)
		c1.setProperty("repository.summary",RepoSummary)
		c1.setProperty("repository.description",RepoDescription)
		c1.setProperty("repository.disclaimer",RepoDisclaimer)
		c1.setProperty("repository.version",RepoVersion)
		c1.setProperty("repository.name",RepoName)
		c1.setProperty("repository.urlpath",RepoURLPath)
		##
		#c1.setProperty("repository.categories",RepoCategory)
		#c1.setProperty("repository.category",RepoCategory)
		
		#ItemsD=getITEMS(table='addon',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); debob(ItemsD); 
		isE=False
		ZrZ=[self.ItemsA,self.ItemsR]
		for zZ in ZrZ:
			for z in zZ:
				if m['id'] in z: isE=True
		if isE==True: c1.setProperty("addon.ebabled",'true')
		#if m['id'] in ItemsD: c1.setProperty("addon.ebabled",'true')
		else: c1.setProperty("addon.ebabled",'false')
		
		self.AddonsList.addItem(c1)
		##
	def FillInAddonsList(self,SelectedRepo):
		##
		self.RepoID=SelectedRepo.getProperty("repository.id")
		self.RepoName=SelectedRepo.getProperty("repository.name")
		self.RepoVersion=SelectedRepo.getProperty("repository.version")
		self.RepoURL=SelectedRepo.getProperty("repository.url")
		self.RepoURLMD5=SelectedRepo.getProperty("repository.urlmd5")
		self.RepoURLPath=SelectedRepo.getProperty("repository.urlpath")
		self.LabCurrentRepo.setLabel(self.RepoName)
		self.AddonsList.reset()
		
		self.CurrentREPO=nolines(getURL(self.RepoURL)); 
		deb("Current Repository's URL",self.RepoURL); 
		if len(self.CurrentREPO)==0: note("Repo Error","Problem catching the Respository's .xml list of addons."); deb("Repo Error","Problem catching the Respository's .xml list of addons."); return
		try: 		self.CurrentREPO_Addons=re.compile('<addon\s+(.+?)>(.+?)</addon',re.IGNORECASE).findall(self.CurrentREPO)
		except: self.CurrentREPO_Addons=[]
		if (len(self.CurrentREPO_Addons)==0): note("Repo Error","No addons found in the current Respository's .xml list of addons."); deb("Repo Error","No addons found in the current Respository's .xml list of addons."); return
		deb("number of addons found",str(len(self.CurrentREPO_Addons))); 
		setContent("addons"); 
		self.ItemsA=getITEMS(table='addon',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); #debob(self.ItemsA); 
		#self.ItemsR=getITEMS(table='repo',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); #debob(self.ItemsR); 
		for Zi,Zo in self.CurrentREPO_Addons: self.AddAddon(self.ItemsA,Zi,Zo,self.RepoID,self.RepoName,self.RepoVersion,self.RepoURLPath)
		
		self.setFocus(self.AddonsList)
		##
		#self.DotOrgREPO=getURL(self.DotOrgRepo_XML)
		#if len(self.DotOrgREPO) > 0: self.DotOrgREPO_Addons=re.compile('<addon\s+(.+?)>(*+?)</addon',re.IGNORECASE).findall(self.DotOrgREPO)
		##
	def onAction(self,action):
		#non Display Button control
		if   action == ACTION_PREVIOUS_MENU: self.close()
		elif action == ACTION_NAV_BACK: self.close()
		#try:
		#	#try: 
		#	rpI=str(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
		#	if (len(rpI) > 0) and (os.path.isfile(rpI)==True):
		#			self.RepoThumbnail.setImage(rpI); self.RepoThumbnail.setVisible(True)
		#	#elif (len(rpI) > 0):
		#	#		self.RepoThumbnail.setImage(rpI); self.RepoThumbnail.setVisible(True)
		#	else: self.RepoThumbnail.setImage(self.ow.b1); self.RepoThumbnail.setVisible(False)
		#	rpF=str(self.CtrlList.getSelectedItem().getProperty("repository.fanart"))
		#	if (len(rpF) > 0) and (os.path.isfile(rpF)==True):
		#			self.RepoFanart.setImage(rpF); self.RepoFanart.setVisible(True)
		#			#self.LabTitle.setLabel(rpF)
		#	#elif (len(rpF) > 0):
		#	#		self.RepoFanart.setImage(rpF); self.RepoFanart.setVisible(True)
		#	else: self.RepoFanart.setImage(self.ow.b1); #self.RepoFanart.setVisible(False)
		#	#except: self.RepoThumbnail.setImage(self.background)
		#	#debob(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
		#except: pass
		try:
			addonI=str(self.AddonsList.getSelectedItem().getProperty("addon.icon")); debob(addonI); 
			#if (len(addonI) > 0) and (os.path.isfile(addonI)==True):
			if (len(addonI) > 0):
					self.AddonThumbnail.setImage(addonI); self.AddonThumbnail.setVisible(True)
			else: self.AddonThumbnail.setImage(self.ow.b1); self.AddonThumbnail.setVisible(False)
			addonF=str(self.AddonsList.getSelectedItem().getProperty("addon.fanart"))
			if (len(addonF) > 0):
					self.AddonFanart.setImage(addonF); self.AddonFanart.setVisible(True)
					#self.LabTitle.setLabel(rpF)
			else: self.AddonFanart.setImage(self.ow.b1); #self.RepoFanart.setVisible(False)
			self.TVS.setImage(addonI); self.TVS.setVisible(True)
			self.BGB.setImage(addonF); self.BGB.setVisible(True)
		except: pass
		#if addonI==addonI:
		try:
			addonFsi=self.AddonsList.getSelectedItem()
			#debob(addonFsi.getLabel())
			#debob(addonFsi.getProperty("addon.id"))
			try: self.AddonsId.setLabel("[COLOR mediumpurple]ID: [/COLOR]"+str(addonFsi.getProperty("addon.id")))
			except: self.AddonsId.setLabel('')
			aLatestVersion=str(addonFsi.getProperty("addon.version")); 
			try: self.AddonsVer.setLabel("[COLOR mediumpurple]ver: [/COLOR]"+aLatestVersion)
			except: self.AddonsVer.setLabel('')
			try: self.AddonsTitle.setLabel("[COLOR mediumpurple]Name: [/COLOR]"+str(addonFsi.getProperty("addon.name")))
			except: self.AddonsTitle.setLabel('')
			try: self.AddonsRepoName.setLabel("[COLOR mediumpurple]Repo: [/COLOR]"+str(addonFsi.getProperty("repository.name")))
			except: self.AddonsRepoName.setLabel('')
			try: self.AddonsAuthor.setLabel("[COLOR mediumpurple]Author(s): [/COLOR]"+str(addonFsi.getProperty("addon.provider-name")))
			except: self.AddonsAuthor.setLabel('')
			try: self.AddonsProvides.setLabel("[COLOR mediumpurple]Type: [/COLOR]"+str(addonFsi.getProperty("addon.provides")))
			except: self.AddonsProvides.setLabel('')
			try: self.AddonsSummary.setText("[COLOR mediumpurple]Summary: [/COLOR]"+str(addonFsi.getProperty("addon.summary"))); self.bgSummary.setVisible(True); 
			except: self.AddonsSummary.setText(''); self.bgSummary.setVisible(False); 
			try: self.AddonsDescription.setText("[COLOR mediumpurple]Description: [/COLOR]"+str(addonFsi.getProperty("addon.description")))
			except: self.AddonsDescription.setText('')
			try: self.AddonsRequirements.setText("[COLOR mediumpurple]Requires: [/COLOR][CR]"+str(addonFsi.getProperty("addon.requires").replace('addon=','').replace('version=','').replace('/>','>').replace(' <','<')))
			except: self.AddonsRequirements.setText('')
			try: 
				if len(str(addonFsi.getProperty("addon.language"))) > 0:
					self.AddonsLanguage.setLabel("[COLOR mediumpurple]Language: [/COLOR]"+str(addonFsi.getProperty("addon.language")))
				else: self.AddonsLanguage.setLabel('')
			except: self.AddonsLanguage.setLabel('')
			try: 
				if len(str(addonFsi.getProperty("addon.platform"))) > 0:
					self.AddonsPlatform.setLabel("[COLOR mediumpurple]Platform: [/COLOR]"+str(addonFsi.getProperty("addon.platform")))
				else: self.AddonsPlatform.setLabel('')
			except: self.AddonsPlatform.setLabel('')
			try: 
				if len(str(addonFsi.getProperty("addon.broken"))) > 0:
					self.AddonsBroken.setText("[COLOR mediumpurple]Broken: [/COLOR]"+str(addonFsi.getProperty("addon.broken"))); self.bgBroken.setVisible(True); 
				else: self.AddonsBroken.setText(''); self.bgBroken.setVisible(False); 
			except: self.AddonsBroken.setText(''); self.bgBroken.setVisible(False); 
			##
			#addon.currentinstalledversion
			#addon.installed
			try: 
				if 'tru' in addonFsi.getProperty("addon.installed"):
					try: 		AciVerA=str(addonFsi.getProperty("addon.currentinstalledversion")); AciVer=' ['+AciVerA+']'
					except: AciVerA=''; AciVer=''
					#debob((AciVerA,aLatestVersion)); 
					#try: 
					AciE=str(addonFsi.getProperty("addon.ebabled")); 
					#except: AciE='false'
					#deb('AciE',AciE); 
					if AciE=='true':
						if AciVerA==aLatestVersion:
							self.btnInstall.setLabel('['+AciVerA+']'); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(False); 
						else:
							self.btnInstall.setLabel('Update'+AciVer); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(True); 
					else:
							self.btnInstall.setLabel('Disabled'+AciVer); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(False); 
				else: 
					self.btnInstall.setLabel('Install'); 
					self.btnInstall.setVisible(True); 
					self.btnInstall.setEnabled(True); 
			except: self.btnInstall.setEnabled(False); self.btnInstall.setLabel('')
			#self.btnInstall.setEnabled(False); 
			try: 
				if 'tru' in addonFsi.getProperty("addon.installed"):
					self.btnUninstall.setLabel('Uninstall'); 
					self.btnUninstall.setVisible(True); 
					self.btnUninstall.setEnabled(True); 
				#else: self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
				else: self.btnUninstall.setVisible(False); self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			#except: self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			except: self.btnUninstall.setVisible(False); self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			#self.btnUninstall.setEnabled(False); 
			##
		except: pass
		self.btnInstall.setEnabled(False); 
		self.btnUninstall.setEnabled(False); 
	def onControl(self,control):
		#Display Button control
		if   control==self.button[0]: self.close()
		#elif control==self.button0: freeze_install(Main)
		#elif control==self.button1: freeze_uninstall(Main)
		#elif control==self.button3: xml_mod(Main)
		#elif control==self.button2: self.close()
		elif control==self.AddonsList:
			self.CurSelAddon=self.AddonsList.getSelectedItem()
			TempWindow3=MyWindowWorks(owner=self); TempWindow3.doModal(); 
			del TempWindow3; 
			return
			self.setFocus(self.btnInstall)
			try: bTxt=self.btnInstall.getLabel()
			except: bTxt=''
			#deb("Install-Button's Text",bTxt); 
			if len(bTxt) > 0:
				if   ('Install' in bTxt): self.btnInstall.setVisible(True); self.btnInstall.setEnabled(True); self.setFocus(self.btnInstall)
				elif ('Update' in bTxt): self.btnInstall.setVisible(True); self.btnInstall.setEnabled(True); self.setFocus(self.btnInstall)
				elif ('Disabled [' in bTxt): self.setFocus(self.btnUninstall)
				elif ('[' in bTxt) and (']' in bTxt): self.setFocus(self.btnUninstall)
				else: self.setFocus(self.btnUninstall)
			else: self.setFocus(self.btnUninstall)
		elif control==self.btnInstall: self.doAddonInstall(control); 
		elif control==self.btnUninstall: self.doAddonUninstall(control); 
		
		##
	##


## ################################################## ##
## ################################################## ##
class MyWindowWorks(xbmcgui.Window):
	#
	#
	InstallToPath=xbmc.validatePath(xbmc.translatePath(os.path.join("special://home","addons")))
	DownloadToPath=xbmc.validatePath(xbmc.translatePath(os.path.join("special://home","addons","packages")))
	DotOrgRepo_XML='http://mirrors.xbmc.org/addons/frodo/addons.xml'
	DotOrgRepo_XMLInfoCompressed=True
	DotOrgRepo_Checksum='http://mirrors.xbmc.org/addons/frodo/addons.xml.md5'
	DotOrgRepo_DataDirPath='http://mirrors.xbmc.org/addons/frodo'
	DotOrgRepo_DataDirZIP=True
	##
	button={}
	def __init__(self,owner):
		self.ow=owner.ow
		self.ow2=owner
		self.BGB=xbmcgui.ControlImage(0,0,1280,720,self.ow.b1,aspectRatio=1); self.addControl(self.BGB)
		self.TVSBGB=xbmcgui.ControlImage(800,12,280,190,self.ow.b1,aspectRatio=1); self.addControl(self.TVSBGB)
		self.TVS=xbmcgui.ControlImage(800,12,280,190,self.ow.b1,aspectRatio=1); self.addControl(self.TVS)
		#self.TVS.setAnimations([('WindowOpen','effect=rotatex time=0 end=30'),('WindowOpen','effect=rotatey time=0 end=60')])
		self.TVSBGB.setAnimations([('WindowOpen','effect=rotatey time=0 end=10 center=1040,120')])
		self.TVS.setAnimations([('WindowOpen','effect=rotatey time=0 end=10 center=1040,120')])
		self.BG=xbmcgui.ControlImage(0,0,1280,720,self.ow.backgroundB,aspectRatio=1); self.addControl(self.BG)
		focus=artp("button-focus2"); nofocus=artp("button-nofocus"); 
		
		#self.AddonFanart2=xbmcgui.ControlImage(30,120,400,460,self.ow.b1,aspectRatio=1); self.addControl(self.AddonFanart2); 
		#self.AddonFanart=xbmcgui.ControlImage(30,120,330,460,self.ow.b1,aspectRatio=1); self.addControl(self.AddonFanart); 
		#self.AddonThumbnail=xbmcgui.ControlImage(740,120,100,100,self.ow.b1,aspectRatio=1); self.addControl(self.AddonThumbnail); 
		
		self.LabTitle=xbmcgui.ControlLabel(30,20,1000,50,'','font30','0xFFFF0000'); self.addControl(self.LabTitle)
		self.LabTitle.setLabel(self.ow.LabTitleText)
		self.button[0]=xbmcgui.ControlButton(30, 70, 135, 30, "Back",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[0])
		#time.sleep(2); 
		self.LabCurrentRepo=xbmcgui.ControlLabel(330,80,400,30,'','font12','0xFF00BFFF',alignment=1); self.addControl(self.LabCurrentRepo)
		#self.AddonsList=xbmcgui.ControlList(30,120,400,480,font='font12',textColor="0xFFFF0000",selectedColor="0xFF00FF00",buttonFocusTexture=focus,buttonTexture=nofocus); self.AddonsList.setSpace(5); self.addControl(self.AddonsList); 
		
		leftA=760; widA=235; hiB=30; topA=4; 
		self.btnInstall=xbmcgui.ControlButton(leftA-5-widA,topA,widA,hiB, "Install",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.btnInstall)
		self.btnUninstall=xbmcgui.ControlButton(leftA-5-widA,topA+2+hiB,widA,hiB, "Uninstall",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.btnUninstall)
		self.btnInstall.setVisible(False); self.btnUninstall.setVisible(False); 
		leftA=435; widA=235; hiB=30; 
		topA=75; 		hiA=200-topA+5; self.AddonFanart3=xbmcgui.ControlImage(leftA-10,topA,300+20,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.AddonFanart3); 
		topA=topA+0; 		 hiA= 20; self.AddonsTitle=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFF00BFFF"); self.addControl(self.AddonsTitle); 
		topA=topA+2+hiA; hiA= 20; self.AddonsId=xbmcgui.ControlLabel(leftA,topA,200,hiA,'',font='font12',textColor="0xFFFF0000"); self.addControl(self.AddonsId); 
		topA=			 topA; hiA= 20; self.AddonsVer=xbmcgui.ControlLabel(leftA+300,topA,100,hiA,'',font='font12',textColor="0xFFFFFFFF",alignment=1); self.addControl(self.AddonsVer); 
		topA=topA+2+hiA; hiA= 20; self.AddonsAuthor=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsAuthor); 
		topA=topA+2+hiA; hiA= 20; self.AddonsPlatform=xbmcgui.ControlLabel(leftA,topA,200,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsPlatform); 
		topA=			 topA; hiA= 20; self.AddonsLanguage=xbmcgui.ControlLabel(leftA+300,topA,200,hiA,'',font='font12',textColor="0xFFFFFFFF",alignment=1); self.addControl(self.AddonsLanguage); 
		topA=topA+2+hiA; hiA= 20; self.AddonsProvides=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFF00FF"); self.addControl(self.AddonsProvides); 
		topA=topA+2+hiA; hiA= 20; self.AddonsRepoName=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsRepoName); 
		
		#topA=topA+2+hiA; hiA= 60; self.AddonsSummary=xbmcgui.ControlTextBox(leftA,topA,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsSummary); 
		widA=400; 
		leftA=30; topA=580; hiA= 120; self.bgSummary=xbmcgui.ControlImage(leftA,topA,widA,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.bgSummary); self.AddonsSummary=xbmcgui.ControlTextBox(leftA,topA,widA,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsSummary); 
		leftA=leftA+2+400; topA=520; hiA=180; self.bgDescription=xbmcgui.ControlImage(leftA-2,topA,widA+4,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.bgDescription); self.AddonsDescription=xbmcgui.ControlTextBox(leftA,topA,widA,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsDescription); 
		leftA=leftA+2+400; topA=topA; hiA=180; self.bgRequirements=xbmcgui.ControlImage(leftA-2,topA,widA+4,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.bgRequirements); self.AddonsRequirements=xbmcgui.ControlTextBox(leftA,topA,widA,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsRequirements); 
		widA=440; leftA=770; topA=4; hiA= 60; self.bgBroken=xbmcgui.ControlImage(leftA-2,topA,widA+4,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.bgBroken); self.AddonsBroken=xbmcgui.ControlTextBox(leftA,topA,widA,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsBroken); 
		
		##
		#leftA=850; widA=235; hiB=30; 
		#topA=10; 		hiA=700-topA; self.AddonFanart3=xbmcgui.ControlImage(leftA-10,topA,400+20,hiA,self.ow.b1,aspectRatio=1); self.addControl(self.AddonFanart3); 
		#topA=topA+0; 		 hiA= 20; self.AddonsTitle=xbmcgui.ControlLabel(leftA,topA,400,hiA,'',font='font12',textColor="0xFF00BFFF"); self.addControl(self.AddonsTitle); 
		#self.btnInstall=xbmcgui.ControlButton(leftA-5-widA,topA,widA,hiB, "Install",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.btnInstall)
		#self.btnUninstall=xbmcgui.ControlButton(leftA-5-widA,topA+2+hiB,widA,hiB, "Uninstall",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.btnUninstall)
		#self.btnInstall.setVisible(False); self.btnUninstall.setVisible(False); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsId=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFF0000"); self.addControl(self.AddonsId); 
		#topA=			 topA; hiA= 20; self.AddonsVer=xbmcgui.ControlLabel(leftA+400,topA,100,hiA,'',font='font12',textColor="0xFFFFFFFF",alignment=1); self.addControl(self.AddonsVer); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsAuthor=xbmcgui.ControlLabel(leftA,topA,400,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsAuthor); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsPlatform=xbmcgui.ControlLabel(leftA,topA,300,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsPlatform); 
		#topA=			 topA; hiA= 20; self.AddonsLanguage=xbmcgui.ControlLabel(leftA+400,topA,200,hiA,'',font='font12',textColor="0xFFFFFFFF",alignment=1); self.addControl(self.AddonsLanguage); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsProvides=xbmcgui.ControlLabel(leftA,topA,400,hiA,'',font='font12',textColor="0xFFFF00FF"); self.addControl(self.AddonsProvides); 
		#topA=topA+2+hiA; hiA= 20; self.AddonsRepoName=xbmcgui.ControlLabel(leftA,topA,400,hiA,'',font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsRepoName); 
		#topA=topA+2+hiA; hiA= 60; self.AddonsSummary=xbmcgui.ControlTextBox(leftA,topA,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsSummary); 
		#topA=topA+2+hiA; hiA=150; self.AddonsDescription=xbmcgui.ControlTextBox(leftA,255,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsDescription); 
		#topA=topA+2+hiA; hiA= 30; self.AddonsBroken=xbmcgui.ControlTextBox(leftA,410,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsBroken); 
		#topA=topA+2+hiA; hiA=150; self.AddonsRequirements=xbmcgui.ControlTextBox(leftA,445,400,hiA,font='font12',textColor="0xFFFFFFFF"); self.addControl(self.AddonsRequirements); 
		
		self.ItemsA=getITEMS(table='addon',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); #debob(self.ItemsA); 
		self.ItemsR=getITEMS(table='repo',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)',what='addonID'); #debob(self.ItemsR); 
		
		#Items=getITEMS(table='repo',where=' WHERE addonID NOT IN (SELECT addonID FROM disabled)'); debob(Items); 
		#Items=sorted(Items, key=lambda item: item[1], reverse=False)
		##
		
		self.button[0].controlDown(self.btnInstall); self.button[0].controlUp(self.btnUninstall); 
		self.button[0].controlLeft(self.btnInstall); self.button[0].controlRight(self.btnUninstall); 
		##self.CtrlList.controlUp(self.button[0])
		##self.RepoCatList.controlUp(self.button[0])
		##self.AddonsList.controlUp(self.button[0])
		##self.CtrlList.controlRight(self.RepoCatList)
		##self.RepoCatList.controlRight(self.AddonsList)
		##self.AddonsList.controlLeft(self.RepoCatList)
		##self.RepoCatList.controlLeft(self.CtrlList)
		
		##self.AddonsList.controlRight(self.btnInstall)
		#self.AddonsList.controlRight(self.button[0])
		#self.AddonsList.controlLeft(self.button[0])
		#self.AddonsList.controlUp(self.button[0])
		#self.AddonsList.controlDown(self.button[0])
		
		self.btnInstall.controlRight(self.button[0])
		self.btnInstall.controlLeft(self.button[0])
		self.btnInstall.controlUp(self.btnUninstall)
		self.btnInstall.controlDown(self.btnUninstall)
		
		self.btnUninstall.controlRight(self.button[0])
		self.btnUninstall.controlLeft(self.button[0])
		self.btnUninstall.controlUp(self.btnInstall)
		self.btnUninstall.controlDown(self.btnInstall)
		
		
		self.setFocus(self.button[0])
		##
		#self.DotOrgREPO=getURL(self.DotOrgRepo_XML)
		#if len(self.DotOrgREPO) > 0: self.DotOrgREPO_Addons=re.compile('<addon\s+(.+?)>(.+?)</addon',re.IGNORECASE).findall(self.DotOrgREPO)
		#else: self.DotOrgREPO=[]
		##
		
		#self.FillInAddonsList(self.ow.CurrentRepoSelected)
		self.CurSelAddon=self.ow2.CurSelAddon
		self.WindowStarted(self.ow2.CurSelAddon)
		
		##
	def WindowStarted(self,c):
		try:
			addonFsi=c
			#addonFsi=self.ow2.AddonsList.getSelectedItem()
			#debob(addonFsi.getLabel())
			#debob(addonFsi.getProperty("addon.id"))
			self.BGB.setImage(str(addonFsi.getProperty("addon.fanart"))); self.BGB.setVisible(True)
			self.TVS.setImage(str(addonFsi.getProperty("addon.icon"))); self.TVS.setVisible(True)
			try: self.AddonsId.setLabel("[COLOR mediumpurple]ID: [/COLOR]"+str(addonFsi.getProperty("addon.id")))
			except: self.AddonsId.setLabel('')
			aLatestVersion=str(addonFsi.getProperty("addon.version")); 
			try: self.AddonsVer.setLabel("[COLOR mediumpurple]ver: [/COLOR]"+aLatestVersion)
			except: self.AddonsVer.setLabel('')
			try: self.AddonsTitle.setLabel("[COLOR mediumpurple]Name: [/COLOR]"+str(addonFsi.getProperty("addon.name")))
			except: self.AddonsTitle.setLabel('')
			try: self.AddonsRepoName.setLabel("[COLOR mediumpurple]Repo: [/COLOR]"+str(addonFsi.getProperty("repository.name")))
			except: self.AddonsRepoName.setLabel('')
			try: self.AddonsAuthor.setLabel("[COLOR mediumpurple]Author(s): [/COLOR]"+str(addonFsi.getProperty("addon.provider-name")))
			except: self.AddonsAuthor.setLabel('')
			try: self.AddonsProvides.setLabel("[COLOR mediumpurple]Type: [/COLOR]"+str(addonFsi.getProperty("addon.provides")))
			except: self.AddonsProvides.setLabel('')
			try: self.AddonsSummary.setText("[COLOR mediumpurple]Summary: [/COLOR]"+str(addonFsi.getProperty("addon.summary"))); self.bgSummary.setVisible(True); 
			except: self.AddonsSummary.setText(''); self.bgSummary.setVisible(False); 
			try: self.AddonsDescription.setText("[COLOR mediumpurple]Description: [/COLOR]"+str(addonFsi.getProperty("addon.description")))
			except: self.AddonsDescription.setText('')
			try: self.AddonsRequirements.setText("[COLOR mediumpurple]Requires: [/COLOR][CR]"+str(addonFsi.getProperty("addon.requires").replace('addon=','').replace('version=','').replace('/>','>').replace(' <','<')))
			except: self.AddonsRequirements.setText('')
			try: 
				if len(str(addonFsi.getProperty("addon.language"))) > 0:
					self.AddonsLanguage.setLabel("[COLOR mediumpurple]Language: [/COLOR]"+str(addonFsi.getProperty("addon.language")))
				else: self.AddonsLanguage.setLabel('')
			except: self.AddonsLanguage.setLabel('')
			try: 
				if len(str(addonFsi.getProperty("addon.platform"))) > 0:
					self.AddonsPlatform.setLabel("[COLOR mediumpurple]Platform: [/COLOR]"+str(addonFsi.getProperty("addon.platform")))
				else: self.AddonsPlatform.setLabel('')
			except: self.AddonsPlatform.setLabel('')
			try: 
				if len(str(addonFsi.getProperty("addon.broken"))) > 0:
					self.AddonsBroken.setText("[COLOR mediumpurple]Broken: [/COLOR]"+str(addonFsi.getProperty("addon.broken"))); self.bgBroken.setVisible(True); 
				else: self.AddonsBroken.setText(''); self.bgBroken.setVisible(False); 
			except: self.AddonsBroken.setText(''); self.bgBroken.setVisible(False); 
			##
			#addon.currentinstalledversion
			#addon.installed
			try: 
				if 'tru' in addonFsi.getProperty("addon.installed"):
					try: 		AciVerA=str(addonFsi.getProperty("addon.currentinstalledversion")); AciVer=' ['+AciVerA+']'
					except: AciVerA=''; AciVer=''
					#debob((AciVerA,aLatestVersion)); 
					#try: 
					AciE=str(addonFsi.getProperty("addon.ebabled")); 
					#except: AciE='false'
					#deb('AciE',AciE); 
					if AciE=='true':
						if AciVerA==aLatestVersion:
							self.btnInstall.setLabel('['+AciVerA+']'); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(False); 
						else:
							self.btnInstall.setLabel('Update'+AciVer); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(True); 
					else:
							self.btnInstall.setLabel('Disabled'+AciVer); 
							self.btnInstall.setVisible(True); 
							self.btnInstall.setEnabled(False); 
				else: 
					self.btnInstall.setLabel('Install'); 
					self.btnInstall.setVisible(True); 
					self.btnInstall.setEnabled(True); 
			except: self.btnInstall.setEnabled(False); self.btnInstall.setLabel('')
			try: 
				if 'tru' in addonFsi.getProperty("addon.installed"):
					self.btnUninstall.setLabel('Uninstall'); 
					self.btnUninstall.setVisible(True); 
					self.btnUninstall.setEnabled(True); 
				#else: self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
				else: self.btnUninstall.setVisible(False); self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			#except: self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			except: self.btnUninstall.setVisible(False); self.btnUninstall.setEnabled(False); self.btnUninstall.setLabel(''); 
			##
		except: pass
		##
		self.setFocus(self.btnInstall)
		try: bTxt=self.btnInstall.getLabel()
		except: bTxt=''
		#deb("Install-Button's Text",bTxt); 
		if len(bTxt) > 0:
			if   ('Install' in bTxt): self.btnInstall.setVisible(True); self.btnInstall.setEnabled(True); self.setFocus(self.btnInstall)
			elif ('Update' in bTxt): self.btnInstall.setVisible(True); self.btnInstall.setEnabled(True); self.setFocus(self.btnInstall)
			elif ('Disabled [' in bTxt): self.setFocus(self.btnUninstall)
			elif ('[' in bTxt) and (']' in bTxt): self.setFocus(self.btnUninstall)
			else: self.setFocus(self.btnUninstall)
		
	def getCurrentVerOfAddon(self,TheAddonXmlFile):
		if os.path.isfile(TheAddonXmlFile)==False: return ''
		try: addon_xml=nolines(_OpenFile(TheAddonXmlFile))
		except: return ''
		try: addon_xml_addon=re.compile("<addon(.*?)>",re.IGNORECASE).findall(addon_xml)[0]
		except: return ''
		#try: addon_xml_addon_name=re.compile('\s+name="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
		#except: return ''
		try: addon_xml_addon_version=re.compile('\s+version="(.*?)"',re.IGNORECASE).findall(addon_xml_addon)[0]
		except: return ''
		try: return addon_xml_addon_version
		except: return ''
	def onAction(self,action):
		#non Display Button control
		if   action == ACTION_PREVIOUS_MENU: self.close()
		elif action == ACTION_NAV_BACK: self.close()
		#try:
		#	#try: 
		#	rpI=str(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
		#	if (len(rpI) > 0) and (os.path.isfile(rpI)==True):
		#			self.RepoThumbnail.setImage(rpI); self.RepoThumbnail.setVisible(True)
		#	#elif (len(rpI) > 0):
		#	#		self.RepoThumbnail.setImage(rpI); self.RepoThumbnail.setVisible(True)
		#	else: self.RepoThumbnail.setImage(self.ow.b1); self.RepoThumbnail.setVisible(False)
		#	rpF=str(self.CtrlList.getSelectedItem().getProperty("repository.fanart"))
		#	if (len(rpF) > 0) and (os.path.isfile(rpF)==True):
		#			self.RepoFanart.setImage(rpF); self.RepoFanart.setVisible(True)
		#			#self.LabTitle.setLabel(rpF)
		#	#elif (len(rpF) > 0):
		#	#		self.RepoFanart.setImage(rpF); self.RepoFanart.setVisible(True)
		#	else: self.RepoFanart.setImage(self.ow.b1); #self.RepoFanart.setVisible(False)
		#	#except: self.RepoThumbnail.setImage(self.background)
		#	#debob(self.CtrlList.getSelectedItem().getProperty("repository.icon"))
		#except: pass
		#try:
		#	addonI=str(self.AddonsList.getSelectedItem().getProperty("addon.icon"))
		#	#if (len(addonI) > 0) and (os.path.isfile(addonI)==True):
		#	if (len(addonI) > 0):
		#			self.AddonThumbnail.setImage(addonI); self.AddonThumbnail.setVisible(True)
		#	else: self.AddonThumbnail.setImage(self.ow.b1); self.AddonThumbnail.setVisible(False)
		#	addonF=str(self.AddonsList.getSelectedItem().getProperty("addon.fanart"))
		#	if (len(addonF) > 0):
		#			self.AddonFanart.setImage(addonF); self.AddonFanart.setVisible(True)
		#			#self.LabTitle.setLabel(rpF)
		#	else: self.AddonFanart.setImage(self.ow.b1); #self.RepoFanart.setVisible(False)
		#except: pass
		#if addonI==addonI:
		
	def onControl(self,control):
		#Display Button control
		if   control==self.button[0]: self.close()
		#elif control==self.button0: freeze_install(Main)
		#elif control==self.button1: freeze_uninstall(Main)
		#elif control==self.button3: xml_mod(Main)
		#elif control==self.button2: self.close()
		#elif control==self.AddonsList:
		#	self.CurSelAddon=self.AddonsList.getSelectedItem()
		#	self.setFocus(self.btnInstall)
		#	try: bTxt=self.btnInstall.getLabel()
		#	except: bTxt=''
		#	#deb("Install-Button's Text",bTxt); 
		#	if len(bTxt) > 0:
		#		if   ('Install' in bTxt): self.btnInstall.setVisible(True); self.btnInstall.setEnabled(True); self.setFocus(self.btnInstall)
		#		elif ('Update' in bTxt): self.btnInstall.setVisible(True); self.btnInstall.setEnabled(True); self.setFocus(self.btnInstall)
		#		elif ('Disabled [' in bTxt): self.setFocus(self.btnUninstall)
		#		elif ('[' in bTxt) and (']' in bTxt): self.setFocus(self.btnUninstall)
		#		else: self.setFocus(self.btnUninstall)
		#	else: self.setFocus(self.btnUninstall)
		elif control==self.btnInstall: self.doAddonInstall(control); 
		elif control==self.btnUninstall: self.doAddonUninstall(control); 
		
		##
	def doAddonActualInstall(self,control):
		bTxt=control.getLabel()
		#addonFsi=self.AddonsList.getSelectedItem()
		addonFsi=self.CurSelAddon
		aId=str(addonFsi.getProperty("addon.id"))
		aVer=str(addonFsi.getProperty("addon.version"))
		aUrlpath=str(addonFsi.getProperty("repository.urlpath"))
		if len(bTxt) > 0:
			msg="Do you want to install this?"; 
			ansr=popYN(title=aId,line1=msg); deb("answer",str(ansr)); 
			if ansr==True:
				msg="Prepairing to install..."; deb(aId,msg); #note(aId,msg); 
				dp=xbmcgui.DialogProgress(); dp.create(Config.name,"Downloading ",'','Please Wait')
				lib=xbmc.validatePath(xbmc.translatePath(os.path.join(self.DownloadToPath,aId+"-"+aVer+".zip"))); deb("downloaded file location",lib); 
				url=aUrlpath+"/"+aId+"/"+aId+"-"+aVer+".zip"; deb("url",url); 
				try: downloader.download(url,lib,dp,title=Config.name)
				except: deb(aId,"error on download"); return
				time.sleep(2); 
				dp.update(0,"","Extracting Zip Please Wait")
				try: extract.all(lib,self.InstallToPath,dp)
				except Exception, e: deb(aId,"error on extraction"); debob(e); return
				except: deb(aId,"error on extraction"); return
				self.UpdateLocalAddons(); 
				msg="Install Completed."; deb(aId,msg); 
				popOK(msg=msg,title=aId); 
				#return
			else: msg="Install canceled."; deb(aId,msg); note(aId,msg); 
			##
		##
	def UpdateLocalAddons(self):
		xbmc.executebuiltin("XBMC.UpdateLocalAddons()"); 
	def doAddonInstall(self,control):
		bTxt=control.getLabel()
		#addonFsi=self.AddonsList.getSelectedItem()
		addonFsi=self.CurSelAddon
		aId=str(addonFsi.getProperty("addon.id"))
		if len(bTxt) > 0:
			if   ('Install' in bTxt):
				msg="Attempting to Install Addon/Repository."; deb(aId,msg); 
				self.doAddonActualInstall(control); 
			elif ('Update [' in bTxt):
				msg="Attempting to Update Addon/Repository."; deb(aId,msg); 
				self.doAddonActualInstall(control); 
			elif ('Disabled [' in bTxt): 
				msg="The addon / repository is currently disabled."; deb(aId,msg); 
				popOK(msg=msg,title=aId)
				#ansr=popYN(title=aId,line1=msg); 
				#note(aId,msg); 
				return
			elif ('[' in bTxt) and (']' in bTxt): 
				msg="The current version is already installed."; deb(aId,msg); 
				popOK(msg=msg,title=aId)
				#ansr=popYN(title=aId,line1=msg); 
				#note(aId,msg); 
				return
			
		return
		##
	def doAddonUninstall(self,control):
		
		return
		##
	def doAddonEnable(self,control):
		
		return
		##
	def doAddonDisable(self,control):
		
		return
		##
	##


## ################################################## ##
## ################################################## ##
def deb(s,t): ### for Writing Debug Data to log file ###
	#if (_debugging==True): 
	print s+':  '+t
def debob(t): ### for Writing Debug Object to log file ###
	#if (_debugging==True): 
	print t
def nolines(t):
	it=t.splitlines(); t=''
	for L in it: t=t+L
	t=((t.replace("\r","")).replace("\n",""))
	return t
def art(f,fe=''): return xbmc.translatePath(os.path.join(Config.artPath,f+fe))
def artp(f,fe='.png'): return art(f,fe)
def artj(f,fe='.jpg'): return art(f,fe)
def BusyAnimationShow(): 				xbmc.executebuiltin('ActivateWindow(busydialog)')
def BusyAnimationHide(): 				xbmc.executebuiltin('Dialog.Close(busydialog,true)')
def closeAllDialogs():   				xbmc.executebuiltin('Dialog.Close(all, true)') 
def popYN(title='',line1='',line2='',line3='',n='',y=''):
	diag=xbmcgui.Dialog()
	r=diag.yesno(title,line1,line2,line3,n,y)
	if r: return r
	else: return False
	#del diag
def popOK(msg="",title="",line2="",line3=""):
	dialog=xbmcgui.Dialog()
	#ok=dialog.ok(title, msg, line2, line3)
	dialog.ok(title, msg, line2, line3)
def note(title='',msg='',delay=5000,image='http://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/US_99_%281961%29.svg/40px-US_99_%281961%29.svg.png'): xbmc.executebuiltin('XBMC.Notification("%s","%s",%d,"%s")' % (title,msg,delay,image))
def repo(repository,filename='',h="special://home",a="addons"): 
	if len(filename)==0: return xbmc.validatePath(xbmc.translatePath(os.path.join(h,a,repository)))
	else: return xbmc.validatePath(xbmc.translatePath(os.path.join(h,a,repository,filename)))
def repox(repository,filename='',h="special://xbmc",a="addons"): 
	if len(filename)==0: return xbmc.validatePath(xbmc.translatePath(os.path.join(h,a,repository)))
	else: return xbmc.validatePath(xbmc.translatePath(os.path.join(h,a,repository,filename)))
def _SaveFile(path,data):
	file=open(path,'w')
	file.write(data)
	file.close()
def _OpenFile(path):
	#deb('File',path)
	if os.path.isfile(path): ## File found.
		#deb('Found',path)
		file = open(path, 'r')
		contents=file.read()
		file.close()
		return contents
	else: return '' ## File not found.
def _CreateDirectory(dir_path):
	dir_path = dir_path.strip()
	if not os.path.exists(dir_path): os.makedirs(dir_path)
def _get_dir(mypath, dirname): #...creates sub-directories if they are not found.
	subpath = os.path.join(mypath, dirname)
	if not os.path.exists(subpath): os.makedirs(subpath)
	return subpath
def getURL(url):
	try:
		req=urllib2.Request(url)
		req.add_header(MyBrowser[0],MyBrowser[1]) 
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return(link)
	except: deb('Failed to fetch url',url); return ''
def setContent(content,h=0):
	h=Config.handle
	try: 		xbmcplugin.setContent(h,content)
	except: pass



## Start of program
TempWindow=MyWindow()
TempWindow.doModal()
del TempWindow


