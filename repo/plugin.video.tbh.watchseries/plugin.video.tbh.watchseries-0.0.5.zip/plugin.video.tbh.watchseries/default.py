### ############################################################################################################
###	#	
### # Site: 				#		
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
try: import copy
except: pass
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui
from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath)
### ############################################################################################################
### ############################################################################################################
SiteName=ps('__plugin__')
SiteTag=ps('__plugin__').replace(' ','')
mainSite=addst("site-domain")
mainSite2='http://www.'+(mainSite.replace('http://',''))
iconSite=_artIcon #'http://watchseries.lt/images/logo.png'
fanartSite=_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan','13':'firebrick','14':'mediumpurple'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyGenres=['Action','Adventure','Animation','Comedy','Drama','Family','Fantasy','Thriller','Reality TV','Sport','Sci-Fi','Documentary','Mystery','Talk Show','War','History','Crime','Music','Horror']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
ww6='[COLOR black]@[/COLOR]'; 
ww7='[COLOR mediumpurple]@[/COLOR]'; 
colorA='FF0092B6'; colorB='FF00CCFF'; 
workingUrl=mainSite+'ram.pls'
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'* TrollVid'
		#m+=CR+'* UploadCrazy'
		m+=CR+CR+'Features:  '
		m+=CR+'* Browse Shows'
		m+=CR+'* Browse Episodes'
		m+=CR+'* Browse Host Links'
		m+=CR+'* Play Videos with UrlResolver'
		#m+=CR+'* Download Videos with UrlResolver'
		m+=CR+'* Optional MetaData where available.'
		#m+=CR+'* MetaData for Shows and 1st Season Episodes where data is available.'
		#m+=CR+'* MetaData auto-disabled for Anime List - ALL.  This is to prevent hammering with the huge list of nearly 400 shows.'
		m+=CR+CR+'Handled Sites:  '
		m+=CR+'* http://watchseries.lt'
		m+=CR+'* http://watchseries.sx'
		m+=CR+'* http://watchseries.ag'
		m+=CR+'* http://spainseries.lt (SPANISH)'
		m+=CR+'* http://watchseries.to'
		m+=CR+CR+'Notes:  '
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	import splash_highway as splash; splash.do_My_Splash(_addon.get_fanart(),5,False); 
	#splash.do_My_Splash(HowLong=5,resize=False); 
	#splash.do_My_Splash('http://i.imgur.com/tMKjZ6j.png',HowLong=5,resize=False); 
	
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
def FixImage(img):
	try: r1,r2=re.compile('(http://www.animefate.com/images/.+?)-\d+x\d+(\.[jpg|png|gif]+)').findall(img)[0]; img=r1+r2; 
	except: pass
	return img
def AFColoring(t): 
	if len(t)==0: return t
	elif len(t)==1: return cFL(t,colorA) #colorA)
	else: return cFL(cFL_(t,colorA),colorB) #colorA),colorB)
def wwA(t,ww): #for Watched State Display
	if   ww==7: t=ww7+t
	elif ww==6: t=ww6+t
	return t

### ############################################################################################################
### ############################################################################################################
def psgn(x,t=".png"):
	s="http://i.imgur.com/"; 
	try:
		return {
			'action': 					s+"Q12cars"+t
			,' action': 				s+"Q12cars"+t
			,'adventure': 			s+"wq3rlj8"+t
			,'animation': 			s+"0Dy8M70"+t
			,'cars': 						s+"e9n9Hih"+t
			#,'cartoon': 				s+"yrrvbzw"+t
			,'comedy': 					s+"FU3VJGg"+t
			,'dementia': 				s+"trimFik"+t
			,'demons': 					s+"NHLTav4"+t
			,'drama': 					s+"w7R77Dj"+t
			#,'dub': 						s+"3nc4UkN"+t
			,'ecchi': 					s+"2Y7s1d9"+t
			,'fantasy': 				s+"tspZm16"+t
			,'game': 						s+"NSLV38b"+t
			,'harem': 					s+"VSpcIo4"+t
			,'historical': 			s+"iyxap9I"+t
			,'horror': 					s+"EueQPn7"+t
			,'josei': 					s+"hR2UNOm"+t
			,'kids': 						s+"yzh5nBq"+t
			,'magic': 					s+"DOy6zZd"+t
			,'martial arts': 		s+"Nw4rjxJ"+t
			,'mecha': 					s+"XCZYIZo"+t
			,'military': 				s+"ZMXs7Gl"+t
			,'movie': 					s+"55YtzvJ"+t
			,'music': 					s+"tgcLRfv"+t
			,'mutants': 				s+"yrj3tDt"+t
			,'mystery': 				s+"37MUY4c"+t
			#,'ona': 						s+"WvIeCaj"+t
			#,'ova': 						s+"6GPcrWB"+t
			,'parody': 					s+"3hBYM4k"+t
			,'police': 					s+"zl4qBvk"+t
			,'psychological': 	s+"75bP7sP"+t
			,'romance': 				s+"ko0OKE4"+t
			,'samurai': 				s+"DDoZmKP"+t
			,'school': 					s+"FlS7hEm"+t
			,'sci-fi': 					s+"3B0dkvt"+t
			,'seinen': 					s+"6vc6cwB"+t
			,'shoujo': 					s+"JAsp9PL"+t
			,'shoujo ai': 			s+"PaLhEhj"+t
			,'shounen': 				s+"PeXK8An"+t
			,'shounen ai': 			s+"uvaepAZ"+t
			,'slice of life': 	s+"rh4voyt"+t
			,'space': 					s+"QReD8P3"+t
			#,'special': 				s+"lph1IaX"+t
			,'sports': 					s+"Ji1o6uG"+t
			,'super power': 		s+"6mHg5s6"+t
			,'supernatural': 		s+"8mAz2dT"+t
			,'thriller': 				s+"ZbW3BKy"+t
			,'vampire': 				s+"Kn9Yi7C"+t
			#,'yuri': 						s+"VylolyV"+t
			,'a': 		s+"OvFHLK2"+t
			,'b': 		s+"ezem9mn"+t
			,'c': 		s+"707ILz1"+t
			,'d': 		s+"BUT7dUz"+t
			,'e': 		s+"mzNtW2U"+t
			,'f': 		s+"11cykaC"+t
			,'g': 		s+"l0CvvHo"+t
			,'h': 		s+"VOupMGK"+t
			,'i': 		s+"ps3YPHq"+t
			,'j': 		s+"oNHwZWv"+t
			,'k': 		s+"TwHANG6"+t
			,'l': 		s+"xiuR2WX"+t
			,'m': 		s+"GDEAPud"+t
			,'n': 		s+"9FjSiMu"+t
			,'o': 		s+"TcR1pa0"+t
			,'p': 		s+"OGc4VBR"+t
			,'q': 		s+"hL9tEkx"+t
			,'r': 		s+"37NNHm8"+t
			,'s': 		s+"mFQswUE"+t
			,'t': 		s+"4DBQVrd"+t
			,'u': 		s+"qpovLUW"+t
			,'v': 		s+"bnu5ByY"+t
			,'w': 		s+"0IHoHV2"+t
			,'x': 		s+"ic81iKY"+t
			,'y': 		s+"46IlmRH"+t
			,'z': 		s+"PWUSCsE"+t
			,'0': 		s+"7an2n4W"+t # 0RJOmkw
			,'all': 	s+"hrWVT21"+t
			#,'search': 										s+"mDSHRJX"+t
			,'plugin settings': 					s+"K4OuZcD"+t
			,'local change log': 					s+"f1nvgAM"+t
			#,'last': 											s+"FelUdDz"+t
			#,'favorites': 								s+"lUAS5AU"+t
			#,'favorites 2': 							s+"EA49Lt3"+t
			#,'favorites 3': 							s+"lwJoUqT"+t
			#,'favorites 4': 							s+"Wr7GPTf"+t
			,'latest update': 						s+"dNCxQbg"+t
			,'completed': 								s+"xcqaTKI"+t
			#,'most popular': 							s+"T9LUsM2"+t
			#,'new anime': 								s+"BGZnMf5"+t
			#,'genre': 										s+"AmQHPvY"+t
			,'ongoing': 									s+"mBqFW3r"+t #EUak0Sg #ozEg86L
			,'anime list all': 						s+"t8b1hSX"+t
			,'anime list alphabet': 			s+"R0w0BAM"+t
			,'anime list latest update': 	s+"XG0LGQH"+t
			,'anime list newest': 				s+"eWAeuLG"+t
			,'anime list popularity': 		s+"eTrguP1"+t
			,'urlresolver settings': 			s+"PlROfSs"+t
			,'online bookmarks': 					s+"68ih1sx"+t
			#,'alphabetical': 							s+"sddCXQo"+t
			,'genre select': 							s+"MhNenb6"+t
#			,'': 								s+""+t
#			,'': 								s+""+t
			,'about': 										s+"8BLYGft"+t
			,'alphabetical': 							s+"aLKvpQD"+t
			,'favorites': 								s+"mVxogXL"+t #
			,'favorites 1': 							s+"cyDyVuh"+t #
			,'favorites 2': 							s+"GxH6BbM"+t #yRtrel2
			,'favorites 3': 							s+"Z9zKGJU"+t #
			,'favorites 4': 							s+"ovjBVu3"+t #
			,'favorites 5': 							s+"n8LUh2R"+t #
			,'favorites 6': 							s+"qN6FEit"+t #
			,'favorites 7': 							s+"3yQYXNh"+t #
			,'genre': 										s+"ObKUcJT"+t #XEIr4Cz
			,'icon': 											s+"VshtskV"+t
			,'fanart': 										s+"OSv7S2u"+t
			,'last': 											s+"3g6S9UH"+t
			,'latest episodes': 					s+"Skoe3Fm"+t #r19ycox
			,'latest updates': 						s+"E86Rnq5"+t
			,'most popular': 							s+"DzFexnz"+t #N69lo3G
			,'new anime': 								s+"wZN1olE"+t
			,'search': 										s+"L8Ifj8L"+t #MTnRQJ3
			,'random anime': 							s+"Rjag7b3"+t
			,'_': 												s+"bGMWifZ"+t
			,'anime 2013': 								s+"4SgqERs"+t
			,'anime 2014': 								s+"ijvRzvJ"+t
			,'anime 2015': 								s+"IYPai5I"+t
			,'anime 2016': 								s+"UqAYilt"+t
			,'anime list': 								s+"NTPFfwQ"+t
			,'a-z': 											s+"Br4ltnl"+t
			,'hot this season': 					s+"KcymQWL"+t
			,'latest animes': 						s+"mDFKTFN"+t
			,'movies': 										s+"hDYdtIr"+t
			,'random': 										s+"5uYkgTx"+t
			,'today': 										s+"GPxwlE8"+t
			,'tomorrow': 									s+"YX2EKk8"+t
			,'yesterday': 								s+"shqgyif"+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
			,'img_next':									'http://kissanime.com/Content/images/next.png'
			,'img_prev':									'http://kissanime.com/Content/images/previous.png'
			###
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
# KissAnimeGenres
# http://imgur.com/a/rws19/all
# http://imgur.com/a/rws19#Q12cars
# http://imgur.com/a/rws19
		}[x]
	except: print 'failed to find graphc for %s' % (x); return ''
### ############################################################################################################
### ############################################################################################################
def PlayMedia(Url,title,imdb_id,img,fimg,stitle,etitle,enumber,snumber,enumber2,wwT=''):
	if len(Url)==0: return
	if (mainSite not in Url) and (mainSite2 not in Url): Url=mainSite+Url; 
	deb('imdb_id',imdb_id); deb('title',title); deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	###
	#s='<a class="myButton" href="(\D+://.*?)">Click Here to Play</a>\s*</div'
	#s='<a class="myButton" href="(\D+://.*?)">(?:Click Here to Play|Clic Aqu\D para Jugar)?</a>\s*</div'
	s='<a class="myButton" href="(\D+://.*?)">.+?</a>\s*</div'
	html=html.replace('</div>','</div\n>')
	try: matches=re.compile(s).findall(html)[0]; debob(matches); #deb('# of matches found',str(len(matches))); 
	except: matches=''; 
	if len(matches) > 0:
		#if 'videoweed.' in matches: matches=matches.replace('/file/','/video/')
		PlayFromHost(matches)
def GetMedia(Url,title,imdb_id,img,fimg,stitle,etitle,enumber,snumber,enumber2,wwT=''):
	if len(snumber)==0: snumber='0'; 
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('imdb_id',imdb_id); deb('title',title); deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	###
	_addon.addon.setSetting(id="LastEpisodeListedURL", value=Url)
	_addon.addon.setSetting(id="LastEpisodeListedNAME", value=title)
	_addon.addon.setSetting(id="LastEpisodeListedIMG", value=img)
	_addon.addon.setSetting(id="LastEpisodeListedFANART", value=fimg)
	_addon.addon.setSetting(id="LastEpisodeListedIMDBID", value=imdb_id)
	_addon.addon.setSetting(id="LastEpisodeListedSTITLE", value=str(stitle))
	_addon.addon.setSetting(id="LastEpisodeListedETITLE", value=str(etitle))
	_addon.addon.setSetting(id="LastEpisodeListedEpNo", value=str(enumber))
	_addon.addon.setSetting(id="LastEpisodeListedSNo", value=str(snumber))
	_addon.addon.setSetting(id="LastEpisodeListedEpNo2", value=str(enumber2))
	###
	s='<tr\s*><td><span>\s*([A-Za-z0-9\-_/\.]+)\s*</span></td><td>\s*<a target="_blank" href="(.+?)" class="buttonlink"'; 
	html=html.replace('</tr>','</tr\n>'); 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); debob(matches); 
	except: matches=''; 
	if len(matches) > 0:
		aSortMeth(xbmcplugin.SORT_METHOD_TITLE); 
		#for (url,img,name,genres,status,NoEps,year) in matches:
		iC=len(matches); 
		try: import urlresolver
		except: pass
		for d,m in matches:
			###
			cMI=[]; labs={'title':d}; 
			pars={'mode':'PlayMedia','url':m,'studio':stitle+' - '+str(enumber)+' - '+etitle,'title':title,'etitle':etitle,'stitle':title,'imdb_id':imdb_id,'img':img,'fimg':fimg,'site':site,'section':section,'wwT':wwT,'MarkAsWatched':'true'}; 
			destfile=str(stitle)+' - s'+str(snumber)+'e'+str(enumber)+' - '+str(enumber)+' - '+str(etitle)+'.mp4'
			if (int(snumber) > 1) and (int(enumber) is not enumber2):
				destfile=str(stitle)+' - s'+str(snumber)+'e'+str(enumber2)+' - '+str(enumber)+' - '+str(etitle)+'.mp4'
			destfile=destfile.replace(':','').replace('"','').replace("'","").replace("?","")
			Clabs={'title':title,'year':'','url':m,'destfile':destfile,'img':img,'fanart':fimg,'plot':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			cMI=ContextMenu_Hosts(Clabs); 
			if (d in ['firedrive','180upload','daclips','gorillavid','movpod','clicktoview','movreel','videoweed','vidxden','nosvideo','movshare','movzap','flashx','filenuke','vodlocker','played','vidbull','nowvideo','novamov','divxstage','videoweed','bestreams']) or (urlresolver.HostedMediaFile(host=d,media_id='xxx').valid_url()): # or (urlresolver.HostedMediaFile(d).valid_url()) or (urlresolver.HostedMediaFile(m).valid_url()): 
				labs[u'title']='[B]'+cFL(d,'blue')+'[/B]'; 
			else: labs[u'title']=cFL(d,'red'); 
			try: _addon.add_directory(pars,labs,is_folder=False,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
	# <iframe id="video" src="
	#html=messupText(nURL('http://metaframe.digitalsmiths.tv/v2/WBtv/assets/'+VideoID+'/partner/11?format=json'),True)
	#s='"length": (\d+), "bitrate": "(.+?)", "uri": "(.+?://.+?)"'; matches=re.compile(s).findall(nolines(html)); deb('# of matches found',str(len(matches))); #debob(matches)
	#for (_length,_name,_url) in matches:
	#	labs={'title':title+' - ['+_name+']'}
	#	try: _addon.add_directory({'mode':'PlayVideo','img':img,'studio':'['+_name+']','url':_url,'title':title,'site':site},labs,is_folder=False,fanart=fanartSite,img=img)
	#	except: pass
	set_view('list',view_mode=addst('links-view')); eod()

def ListEpisodes(Url,title,imdb_id,img,fimg):
	debob([Url,title,imdb_id,img,fimg])
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('imdb_id',imdb_id); deb('title',title); deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if imdb_id=='0': imdb_id=''; 
	if len(html)==0: return
	###
	_addon.addon.setSetting(id="LastShowListedURL", value=Url)
	_addon.addon.setSetting(id="LastShowListedNAME", value=title)
	_addon.addon.setSetting(id="LastShowListedIMG", value=img)
	_addon.addon.setSetting(id="LastShowListedFANART", value=fimg)
	_addon.addon.setSetting(id="LastShowListedIMDBID", value=imdb_id)
	###
	#s='<li>\s*\n*\s*<a href="(http://www.animefate.com/.+?/)" rel="bookmark" title=".+?">\s*\n*\s*<p class="episode_number">\s*(.+?)\s*</p>\s*\n*\s*<p title="Added on .+?" class="date_published">(.+?)</p>\s*\n*\s*</a>\s*\n*\s*<div class="clear"></div>\s*\n*\s*</li>'; 
	s='<li><a title="(.*?)" href="(.+?)">\s*<span class="" .*?>\s*(.+?)\s*</span>\s*<span class="epnum">\s*(.*?)\s*</span>\s*</a></li'; 
	html=html.replace('</li>','</li\n>'); 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		s='1'; enMeta=tfalse(addst("enableMeta","false")); 
		#for (url,img,name,genres,status,NoEps,year) in matches:
		iC=len(matches); n=False; e3='0'
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
			#ShowLabs=grab.get_seasons(tvshowtitle=title,imdb_id=imdb_id,seasons=s,overlay=6); debob(ShowLabs); 
			#labsZ=grab.get_episode_meta(tvshowtitle=title,imdb_id=imdb_id,season=s,episode='1',air_date='',episode_title='',overlay=6); debob(labsZ); 
		#matches=sorted(matches,key=lambda nn: (nn[1]),reverse=True)
		if 'Movie ' in title: s='0'; enMeta=False; 
		for (tname,url,name,datestamp) in matches: #[::-1]:
			debob([tname,url,name,datestamp]); 
			cMI=[]; labs={}; #labs['plot']=''; labs['plotoutline']=''; labs['showtitle']=''; labs['episodetitle']=''; labs['videoid']=''; 
			if '- Season ' in tname: 
				try: s=re.compile("- Season (\d+)").findall(tname)[0]
				except: pass
			elif ' Temporada ' in tname: 
				try: s=re.compile(" Temporada (\d+)").findall(tname)[0]
				except: pass
			if '- Episode ' in tname: 
				try: e=re.compile("- Episode (\d+)").findall(tname)[0]
				except: pass
			elif ' Capitulo ' in tname: 
				try: e=re.compile(" Capitulo (\d+)").findall(tname)[0]
				except: pass
			#if "Episode " in name: 
			#	try: e=re.compile("Episode\s*(\d+)").findall(name)[0]; 
			#	except: e=""; 
			#	if len(str(e))==0:
			#		try: e=re.compile("Movie\s*(\d+)").findall(name)[0]; 
			#		except: e=""; 
			else: e=""; 
			name=name.replace(title,''); e2=copy.deepcopy(e); e4=''+str(e); 
			#name=name.replace(title+" Episode","Episode")
			wwT=title+" ~~ "+name
			try:
				if visited_check(wwT)==True: ww=7
				else: ww=6
			except: ww=6
			if (enMeta==True) and (len(imdb_id) > 1):
				#s='1'; 
				if len(e) > 0:
					###
					#if int(s) > 1:
					#	e2=str(int(e)-int(e3))
					###
					#try: labs=grab.get_episode_meta(tvshowtitle=title,imdb_id=imdb_id,season=s,episode=e2,air_date='',episode_title='',overlay=6); 
					try: labs=grab.get_episode_meta(tvshowtitle=title,imdb_id=imdb_id,season=s,episode=e,air_date='',episode_title='',overlay=6); 
					except: n=True;
					###
					#debob(labs); 
					#try:
					#	if (len(labs['title'])==0) and (len(labs['plot'])==0) and (len(labs['episode_id'])==0):
					#		s=str(int(s)+1); e3=str(int(e)-1)
					#		e2=str(int(e)-int(e3))
					#		try: labs=grab.get_episode_meta(tvshowtitle=title,imdb_id=imdb_id,season=s,episode=e2,air_date='',episode_title='',overlay=6); 
					#		except: n=True;
					#except: pass
					
					###
					try:
						if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
					except: pass
					try:
						if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
					except: pass
					#try: tt=labs[u'title']; 
					#except: n=True; 
					#if len(labs[u'title'])==0: n=True; 
				else: n=True; 
			else: n=True; 
			if n==True: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			if len(labs[u'title'])==0: labs[u'title']=name; 
			if len(labs[u'title'])==0: labs[u'title']=title; 
			#elif labs[u'title']==" ": labs[u'title']=name; 
			#labs[u'title']=labs[u'title'].replace(title+" Episode","Episode")
			etitle=labs[u'title']; 
			#labs[u'title']=cFL(str(e)+') ','blue')+AFColoring(labs[u'title']); 
			if len(e) > 0: labs[u'title']=cFL(str(e4)+') ','blue')+AFColoring(labs[u'title']); 
			else: labs[u'title']=AFColoring(labs[u'title'])
			labs[u'plot']=CR+cFL(labs[u'plot'],'mediumpurple'); 
			if len(datestamp) > 0: labs[u'title']+=CR+cFL("["+datestamp+"]",colorA)+" "+cFL("s"+s,colorA)+""+cFL("e"+e,colorA); 
			else: labs[u'title']+=CR+" "+cFL("s"+s,colorA)+""+cFL("e"+e,colorA); 
			labs[u'plot']+=CR+cFL(str(e)+")",'blue')+cFL(" Season "+cFL(str(s),colorA)+" Episode "+cFL(str(e2),colorA)+"",'mediumpurple')
			labs[u'title']=wwA(labs[u'title'],ww); 
			debob(labs); 
			pars={'mode':'GetMedia','url':url,'title':title+' Season '+s+' '+name,'etitle':etitle,'stitle':title,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site,'section':section,'e':str(e),'s':str(s),'e2':str(e2),'e3':str(e3),'wwT':wwT}; 
			Clabs={'title':name,'year':'','url':url,'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Episodes(Clabs); 
			except: pass
			try: cMI=wwCMI(cMI,ww,wwT); 
			except: pass
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC)
			except: pass
	set_view('episodes',view_mode=addst('episode-view')); eod()

def ListShows(Url):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	##s='<div class=\'anime_list_info\'>\s*<a href="(http://www.animefate.com/series/.+?/)" title=".+? English Dubbed Anime">\s*\n*\s*<div class="info_list_cover">\s*\n*\s*'; #s+='<img src="(http://www.animefate.com/images/.+?-\d+x\d+.[jpg|png|gif]+)" alt=".+?" title=".+?" />\s*\n*\s*</div>\s*\n*\s*<div class="info_list_description">\s*\n*\s*'; #s+='<p class=\'anime_list_title\'><strong>(.+?)</strong></p></a><p><strong>Genres: </strong>(.+?)</p>'; #s+='<p><strong>Status: </strong><span class=\'.+?\'>\s*(\D+)\s*</span></p>'; #s+='<p><strong>No. of Episodes: </strong>\s*(\d*)\s*</p><p><strong>Released: </strong>\s*(\d*)\s*</p>\s*\n*\s*</div>\s*\n*\s*</div>'; 
	#s='<li\s*(?:class=".*?")?><a title=".*?" href="(.+?)">\s*(?:<span class=".*?" style=".*?"></span>)?\s*(.+?\s*(?:<span class="epnum">\s*\D+\s*</span>)?)\s*</a></li'; 
	s='<li\s*(?:class=".*?")?><a (?:class=".*?" )?title=".*?" href="(.+?)">\s*'
	s+='(?:<span class=".*?" style=".*?">\s*</span>)?\s*'
	s+='(.+?\s*(?:<span class="epnum">\s*\D+\s*</span>)?)\s*</a></li'; 
	
	html=html.replace('</li>','</li\n>'); 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		#for (url,img,name,genres,status,NoEps,year) in matches:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for (url,name) in matches: #(img,url,name,genres)
			name=name.replace('<span class="epnum">',' (').replace('</span>',')')
			genres=''; img=iconSite; #img=FixImage(img); 
			cMI=[]; img=img.replace(' ','%20'); fimg=fanartSite; deb('img',img); Genres2=""; g="<a href='http://www.animefate.com/.genre=.+?'>\s*(.+?)\s*</a>"; plot=""; labs={}; 
			#try: Genres1=re.compile(g).findall(genres); debob(Genres1); 
			#except: Genres1=""; 
			#for g in Genres1: Genres2+="["+g+"] "; 
			##Genres2=str(Genres1); 
			if enMeta==True: 
				try: 
					if ' Seas. ' in name: labs=grab.get_meta('tvshow',name.split(' Seas. ')[0]); 
					elif (' (19' in name) or (' (20' in name) or (' (21' in name): labs=grab.get_meta('tvshow',name.split(' (')[0]); 
					else: labs=grab.get_meta('tvshow',name); 
					debob(labs); 
				except: labs={}; labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			#plot+=CR+"Genres:  [COLOR purple]"+Genres2+"[/COLOR]"; #plot+="[CR]Year: [COLOR purple]"+year+"[/COLOR]"; #plot+="[CR]Status: [COLOR purple]"+status+"[/COLOR]"; #plot+="[CR]Number of Episodes: [COLOR purple]"+NoEps+"[/COLOR]"; 
			pars={'mode':'ListEpisodes','url':url,'title':name,'imdb_id':labs['imdb_id'],'img':img,'fimg':fimg,'site':site,'section':section}; 
			if '/episode/' in url: pars[u'mode']='GetMedia'
			#zz=[ [0xc3,0x80,'A'],[0xc3,0x81,'A'],[0xc3,0x82,'A'],[0xc3,0x83,'A'],[0xc3,0x84,'A'],[0xc3,0x85,'A'],[0xc3,0x86,'AE'],[0xc3,0x87,'C'],[0xc3,0x88,'E'],[0xc3,0x89,'E'],[0xc3,0x8A,'E'],[0xc3,0x8B,'E'],[0xc3,0xa9,'e'],[0xc3,0xa0,'a'],[0xc2,0xb4,"'"],[0xc3,0xb4,"o"],[0xc3,0xb9,"u"],[0xc2,0xb9,"1"],[0xc2,0xba,"0"],[0xc2,0xa2,"c"],[0xc3,0xa2,"a"] ]
			#for z,z2,z3 in zz: plot=plot.replace(chr(int(z))+chr(int(z2)),z3); 
			#zz=[0xc2,0xc3,0xa9,0xaa,0xa7,0xa0,0xa8,0xe2,0x99,0xae,0x80]
			#for z in zz: plot=plot.replace(chr(int(z)),''); 
			labs[u'plot']=plot+CR+CR+cFL(labs[u'plot'],'mediumpurple'); labs[u'title']=AFColoring(name); 
			#Clabs=labs; 
			Clabs={'title':name,'year':labs[u'year'],'url':url,'commonid':labs[u'imdb_id'],'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs); 
			except: pass
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC,context_replace=False)
			except: pass
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()

def ListShowsSR(Url):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	##s='<div class=\'anime_list_info\'>\s*<a href="(http://www.animefate.com/series/.+?/)" title=".+? English Dubbed Anime">\s*\n*\s*<div class="info_list_cover">\s*\n*\s*'; #s+='<img src="(http://www.animefate.com/images/.+?-\d+x\d+.[jpg|png|gif]+)" alt=".+?" title=".+?" />\s*\n*\s*</div>\s*\n*\s*<div class="info_list_description">\s*\n*\s*'; #s+='<p class=\'anime_list_title\'><strong>(.+?)</strong></p></a><p><strong>Genres: </strong>(.+?)</p>'; #s+='<p><strong>Status: </strong><span class=\'.+?\'>\s*(\D+)\s*</span></p>'; #s+='<p><strong>No. of Episodes: </strong>\s*(\d*)\s*</p><p><strong>Released: </strong>\s*(\d*)\s*</p>\s*\n*\s*</div>\s*\n*\s*</div>'; 
	#s='<li><a title=".*?" href="(.+?)">\s*(.+?\s*(?:<span class="epnum">\s*\D+\s*</span>)?)\s*</a></li'; 
	s='<tr><td valign="top">\s*<a title=".*?" href=".+?">\s*<img src="(.+?)">\s*</a>\s*</td>\s*<td valign="top">\s*<a title=".*?" href="(.+?)">\s*<b>\s*(.+?)\s*</b>\s*</a>\s*<br>\s*<b>\s*\D+:\s*</b>\s*(.+?)\s*</td></tr'; 
	html=html.replace('</tr>','</tr\n>'); 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		#for (url,img,name,genres,status,NoEps,year) in matches:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for (img,url,name,plot) in matches: #(img,url,name,genres)
			name=name.replace('<span class="epnum">',' (').replace('</span>',')')
			genres=''; #img=iconSite; #img=FixImage(img); 
			cMI=[]; img=img.replace(' ','%20'); fimg=fanartSite; deb('img',img); Genres2=""; g="<a href='http://www.animefate.com/.genre=.+?'>\s*(.+?)\s*</a>"; labs={}; #plot=""; 
			#try: Genres1=re.compile(g).findall(genres); debob(Genres1); 
			#except: Genres1=""; 
			#for g in Genres1: Genres2+="["+g+"] "; 
			##Genres2=str(Genres1); 
			if enMeta==True: 
				try: 
					if ' Seas. ' in name: labs=grab.get_meta('tvshow',name.split(' Seas. ')[0]); 
					elif (' (19' in name) or (' (20' in name) or (' (21' in name): labs=grab.get_meta('tvshow',name.split(' (')[0]); 
					else: labs=grab.get_meta('tvshow',name); 
					debob(labs); 
				except: labs={}; labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=name; labs[u'year']=''; 
			#plot+=CR+"Genres:  [COLOR purple]"+Genres2+"[/COLOR]"; #plot+="[CR]Year: [COLOR purple]"+year+"[/COLOR]"; #plot+="[CR]Status: [COLOR purple]"+status+"[/COLOR]"; #plot+="[CR]Number of Episodes: [COLOR purple]"+NoEps+"[/COLOR]"; 
			pars={'mode':'ListEpisodes','url':url,'title':name,'imdb_id':labs['imdb_id'],'img':img,'fimg':fimg,'site':site,'section':section}; 
			if '/episode/' in url: pars[u'mode']='GetMedia'
			zz=[ [0xc3,0x80,'A'],[0xc3,0x81,'A'],[0xc3,0x82,'A'],[0xc3,0x83,'A'],[0xc3,0x84,'A'],[0xc3,0x85,'A'],[0xc3,0x86,'AE'],[0xc3,0x87,'C'],[0xc3,0x88,'E'],[0xc3,0x89,'E'],[0xc3,0x8A,'E'],[0xc3,0x8B,'E'],[0xc3,0xa9,'e'],[0xc3,0xa0,'a'],[0xc2,0xb4,"'"],[0xc3,0xb4,"o"],[0xc3,0xb9,"u"],[0xc2,0xb9,"1"],[0xc2,0xba,"0"],[0xc2,0xa2,"c"],[0xc3,0xa2,"a"] ]
			for z,z2,z3 in zz: plot=plot.replace(chr(int(z))+chr(int(z2)),z3); 
			zz=[0xc2,0xc3,0xa9,0xaa,0xa7,0xa0,0xa8,0xe2,0x99,0xae,0x80]
			for z in zz: plot=plot.replace(chr(int(z)),''); 
			labs[u'plot']=plot+CR+CR+cFL(labs[u'plot'],'mediumpurple'); labs[u'title']=AFColoring(name); 
			#Clabs=labs; 
			Clabs={'title':name,'year':labs[u'year'],'url':url,'commonid':labs[u'imdb_id'],'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs); 
			except: pass
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC,context_replace=False)
			except: pass
	s='<td><a href="(.+?/page/\d+)"> (\d+) </a></td'; 
	html=html.replace('</td>','</td\n>'); 
	try: matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	except: matches=''; 
	if len(matches) > 0:
		for (url,name) in matches: #(img,url,name,genres)
			cMI=[]; labs={}; 
			pars={'mode':'ListShowsSR','url':url,'title':name,'site':site,'section':section}; 
			labs['title']=cFL("Page: ",colorA)+cFL(name,colorB)
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fanartSite,img=psgn('img_next'),contextmenu_items=cMI,total_items=iC,context_replace=False)
			except: pass
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()

def Fav_List(site='',section='',subfav=''):
	debob(['test1',site,section,subfav]); 
	favs=fav__COMMON__list_fetcher(site=site,section=section,subfav=subfav); 
	ItemCount=len(favs); 
	debob('test2 - '+str(ItemCount)); 
	if len(favs)==0: myNote('Favorites','None Found'); eod(); return
	debob(favs); 
	favs=sorted(favs,key=lambda item: (item[0],item[1]),reverse=False); 
	for (_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2) in favs:
		if _img > 0: img=_img
		else: img=iconSite
		if _fanart > 0: fimg=_fanart
		else: fimg=fanartSite
		debob('_ToDoParams'); debob(_ToDoParams)
		pars=_addon.parse_query(_ToDoParams)
		pars[u'fimg']=_fanart; pars[u'img']=_img; 
		#if len(_commonID) > 0: pars['imdb_id']=_commonID
		debob('pars'); debob(pars)
		_title=AFColoring(_name)
		if (len(_year) > 0) and (not _year=='0000'): _title+=cFL('  ('+cFL(_year,'mediumpurple')+')',colorA)
		if len(_Country) > 0: _title+=cFL('  ['+cFL(_Country,'mediumpurple')+']',colorA)
		wwT=_name+" ~~ "; 
		try:
			if visited_check2(wwT)==True: ww=7
			else: ww=6
		except: ww=6
		#try:
		if ww > 1:
			contextLabs={'title':_name,'year':_year,'img':_img,'fanart':_fanart,'country':_Country,'url':_Url,'plot':_plot,'genres':_Genres,'site':_site,'subfav':_subfav,'section':_section,'todoparams':_ToDoParams,'commonid':_commonID,'commonid2':_commonID2}
			##contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}
			contextMenuItems=ContextMenu_Favorites(contextLabs)
			contextMenuItems.append( ('Empty List','XBMC.RunPlugin(%s)' % _addon.build_plugin_url({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':subfav}) ) )
			#contextMenuItems=[]
			_title=wwA(_title,ww); 
			_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#except: pass
		#
	#
	if 'movie' in section.lower(): content='movies'
	else: content='tvshows'
	set_view(content,view_mode=int(addst('tvshows-view'))); eod()


### ############################################################################################################
### ############################################################################################################
def DoSearch_Post(title='',Url='/search/results.php'):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	if len(title)==0: title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	#deb('Searching for',title); title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','+'); 
	deb('Searching for',title); #ListShows( Url+( title.replace(' ','+') ) ); 
	deb('Url',Url); html=messupText(nolines(nURL(Url,method='post',form_data={'search':title,'page':'','hidden_page':'','valider':'GO'})),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	ListShowsH(Url,html)
	##

def DoSearch(title='',Url='/search/'):
	if len(Url)==0: return
	if mainSite not in Url: Url=mainSite+Url; 
	if len(title)==0: title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title); title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','+'); 
	deb('Searching for',title); 
	ListShowsSR( Url+( title.replace(' ','+') ) ); 
	##deb('Url',Url); html=messupText(nolines(nURL(Url,method='post',form_data={'search':title,'page':'','hidden_page':'','valider':'GO'})),True,True); deb('length of html',str(len(html))); #debob(html); 
	##if len(html)==0: return
	##ListShowsH(Url,html)
	##

def MenuYear():
	EarliestYear=(2011-1); RangeBy=0-1; 
	try: thisyear=int(datetime.date.today().strftime("%Y"))
	except: thisyear=2014
	#browsebyImg=checkImgLocal(art('year','.gif'))
	ItemCount=len(range(thisyear,EarliestYear,RangeBy)) * 12 - 12 + 3 # ,total_items=ItemCount
	for year in range(thisyear,EarliestYear,RangeBy):
		_addon.add_directory({'mode':'ListLatestEpisodes2','url':'/'+str(year)+'/','site':site,'section':section},{'title':('/'+cFL(str(year),'mediumpurple')+'/')},is_folder=True,fanart=fanartSite,img=iconSite,total_items=ItemCount); 
		if year==2011: EarliestMonth=10
		else: EarliestMonth=1
		for month in range(12,(EarliestMonth-1),-1):
			_addon.add_directory({'mode':'ListLatestEpisodes2','url':'/'+str(year)+'/'+str(month)+'/','site':site,'section':section},{'title':('/'+str(year)+'/'+cFL(str(month),'firebrick')+'/')},is_folder=True,fanart=fanartSite,img=iconSite,total_items=ItemCount); 
	set_view('list',view_mode=addst('default-view')); eod()

def MenuAZ():
	_addon.add_directory({'mode':'ListShows','url':'/latest','site':site,'section':section},{'title':AFColoring('NEW')},is_folder=True,fanart=fanartSite,img=psgn('all')); 
	_addon.add_directory({'mode':'ListShows','url':'/letters/09','site':site,'section':section},{'title':AFColoring('09')},is_folder=True,fanart=fanartSite,img=psgn('0')); 
	for az in MyAlphabet:
		az=az.upper(); _addon.add_directory({'mode':'ListShows','url':'/letters/'+az,'site':site,'section':section},{'title':AFColoring(az)},is_folder=True,fanart=fanartSite,img=psgn(az.lower())); 
	###
	# http://www.animefate.com/anime-list/?starting_char=all
	# http://www.animefate.com/anime-list/
	# http://www.animefate.com/anime-list/?starting_char=A
	###
	set_view('list',view_mode=addst('default-view')); eod()

def MenuGenre():
	for az in MyGenres: 
		i=psgn(az.lower())
		if len(i)==0: i=iconSite
		_addon.add_directory({'mode':'ListShows','url':'/genres/'+az.lower().replace(' ','-'),'site':site,'section':section},{'title':AFColoring(az)},is_folder=True,fanart=fanartSite,img=i); 
	###
	# http://www.animefate.com/?genre=Slice%20of%20Life
	###
	set_view('list',view_mode=addst('default-view')); eod()

def SectionMenu():
	#import splash_highway as splash; #splash.do_My_Splash(_addon.get_fanart(),2,False); 
	#splash.do_My_Splash(HowLong=5,resize=False); 
	
	#_addon.add_directory({'mode':'GetMedia','site':site,'url':'/episode/californication_s7_e7.html'},{'title':AFColoring('Testing')},is_folder=True,fanart=fanartSite,img=psgn('latest episodes'))
	
	_addon.add_directory({'mode':'ListShows','site':site,'url':'/tvschedule/-1'},{'title':AFColoring('Yesterday')},is_folder=True,fanart=fanartSite,img=psgn('yesterday'))
	_addon.add_directory({'mode':'ListShows','site':site,'url':'/tvschedule/0'},{'title':AFColoring('Today')},is_folder=True,fanart=fanartSite,img=psgn('today'))
	_addon.add_directory({'mode':'ListShows','site':site,'url':'/tvschedule/1'},{'title':AFColoring('Tomorrow')},is_folder=True,fanart=fanartSite,img=psgn('tomorrow'))
	
	_addon.add_directory({'mode':'ListShows','site':site,'url':'/latest'},{'title':AFColoring('Latest Episodes')},is_folder=True,fanart=fanartSite,img=psgn('latest episodes'))
	_addon.add_directory({'mode':'ListShows','site':site,'url':'/new'},{'title':AFColoring('Popular')},is_folder=True,fanart=fanartSite,img=psgn('most popular'))
	#_addon.add_directory({'mode':'ListLatestShows','site':site},{'title':AFColoring('Latest Series')},is_folder=True,fanart=fanartSite,img=psgn('new anime'))
	#_addon.add_directory({'mode':'MenuYear','site':site},{'title':AFColoring('Archived By Date')},is_folder=True,fanart=fanartSite,img=psgn('icon'))
	#
	
	_addon.add_directory({'mode':'MenuAZ','site':site},{'title':AFColoring('List')},is_folder=True,fanart=fanartSite,img=psgn('a-z'))
	_addon.add_directory({'mode':'MenuGenre','site':site},{'title':AFColoring('Genres')},is_folder=True,fanart=fanartSite,img=psgn('genre'))
	_addon.add_directory({'mode':'Search','site':site,'url':'/search/'},{'title':AFColoring('Search')},is_folder=True,fanart=fanartSite,img=psgn('search'))
	
	#
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.1.name'),colorB)},fanart=fanartSite,img=psgn('favorites 1'))
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.2.name'),colorB)},fanart=fanartSite,img=psgn('favorites 2'))
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'3'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.3.name'),colorB)},fanart=fanartSite,img=psgn('favorites 3'))
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'4'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.4.name'),colorB)},fanart=fanartSite,img=psgn('favorites 4'))
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'5'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.5.name'),colorB)},fanart=fanartSite,img=psgn('favorites 5'))
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'6'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.6.name'),colorB)},fanart=fanartSite,img=psgn('favorites 6'))
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'7'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.7.name'),colorB)},fanart=fanartSite,img=psgn('favorites 7'))
	###
	if (len(addst("LastShowListedURL")) > 0): 
		pars={'site':site,'section':section,'mode':'ListEpisodes','url':addst("LastShowListedURL"),'title':addst("LastShowListedNAME"),'imdb_id':addst("LastShowListedIMDBID"),'img':addst("LastShowListedIMG"),'fimg':addst("LastShowListedFANART")}; 
		title=AFColoring(addst("LastShowListedNAME"))+CR+cFL('[Last Show]',colorA); 
		_addon.add_directory(pars,{'title':title},fanart=addst("LastShowListedFANART"),img=addst("LastShowListedIMG"),is_folder=True); 
	if (len(addst("LastEpisodeListedURL")) > 0): 
		pars={'site':site,'section':section,'mode':'GetMedia','url':addst("LastEpisodeListedURL"),'title':addst("LastEpisodeListedNAME"),'imdb_id':addst("LastEpisodeListedIMDBID"),'img':addst("LastEpisodeListedIMG"),'fimg':addst("LastEpisodeListedFANART"),'stitle':addst("LastEpisodeListedSTITLE"),'etitle':addst("LastEpisodeListedETITLE"),'e':addst("LastEpisodeListedEpNo"),'s':addst("LastEpisodeListedSNo"),'e2':addst("LastEpisodeListedEpNo2")}; 
		title=AFColoring(addst("LastEpisodeListedNAME"))+CR+cFL('[Last Episode]',colorA); 
		_addon.add_directory(pars,{'title':title},fanart=addst("LastEpisodeListedFANART"),img=addst("LastEpisodeListedIMG"),is_folder=True); 
	###
	_addon.add_directory({'mode':'About','site':site,'section':section},{'title':AFColoring('About')},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	###
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='') or (mode=='main') or (mode=='MainMenu'): SectionMenu()
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='ListShows'): 		ListShows(url)
	elif (mode=='ListShowsSR'): 	ListShowsSR(url)
	elif (mode=='ListShows2'): 		ListShows2(url)
	elif (mode=='Search'):				DoSearch(addpr('title',''),url)
	elif (mode=='ListEpisodes'): 	ListEpisodes(url,addpr('title',''),addpr('imdb_id',''),addpr('img',''),addpr('fimg',''))
	elif (mode=='ListLatestEpisodes'): ListLatestEpisodes()
	elif (mode=='ListLatestEpisodes2'): ListLatestEpisodes(url)
	elif (mode=='ListLatestShows'): ListLatestShows()
	elif (mode=='ListPopularShows'): ListPopularShows()
	elif (mode=='GetMedia'): 			GetMedia(url,addpr('title',''),addpr('imdb_id',''),addpr('img',''),addpr('fimg',''),addpr('stitle',''),addpr('etitle',''),addpr('e',''),addpr('s',''),addpr('e2',''),addpr('wwT',''))
	elif (mode=='PlayMedia'): 		PlayMedia(url,addpr('title',''),addpr('imdb_id',''),addpr('img',''),addpr('fimg',''),addpr('stitle',''),addpr('etitle',''),addpr('e',''),addpr('s',''),addpr('e2',''),addpr('wwT',''))
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	#elif (mode=='Search'): 			Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	#elif (mode=='SearchLast'): 	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				eod(); About()
	#elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='MenuAZ'): 				MenuAZ()
	elif (mode=='MenuGenre'): 		MenuGenre()
	elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='PlayURL'): 						PlayURL(url)
	elif (mode=='PlayURLs'): 						PlayURLs(url)
	elif (mode=='PlayURLstrm'): 				PlayURLstrm(url)
	elif (mode=='PlayFromHost'): 				PlayFromHost(url)
	elif (mode=='PlayVideo'): 					PlayVideo(url)
	elif (mode=='PlayItCustom'): 				PlayItCustom(url,addpr('streamurl',''),addpr('img',''),addpr('title',''))
	elif (mode=='PlayItCustomL2A'): 		PlayItCustomL2A(url,addpr('streamurl',''),addpr('img',''),addpr('title',''))
	elif (mode=='Settings'): 						_addon.addon.openSettings() # Another method: _plugin.openSettings() ## Settings for this addon.
	elif (mode=='ResolverSettings'): 		import urlresolver; urlresolver.display_settings()  ## Settings for UrlResolver script.module.
	elif (mode=='ResolverUpdateHostFiles'):	import urlresolver; urlresolver.display_settings()  ## Settings for UrlResolver script.module.
	elif (mode=='TextBoxFile'): 				TextBox2().load_file(url,addpr('title','')); #eod()
	elif (mode=='TextBoxUrl'):  				TextBox2().load_url(url,addpr('title','')); #eod()
	elif (mode=='MenuYear'): 						MenuYear()
	elif (mode=='Download'): 						
		try: _addon.resolve_url(url)
		except: pass
		debob([url,addpr('destfile',''),addpr('destpath',''),str(tfalse(addpr('useResolver','true')))])
		DownloadThis(url,addpr('destfile',''),addpr('destpath',''),tfalse(addpr('useResolver','true')))
	elif (mode=='toJDownloader'): 			SendTo_JDownloader(url,tfalse(addpr('useResolver','true')))
	elif (mode=='cFavoritesEmpty'):  	fav__COMMON__empty( site=site,section=section,subfav=addpr('subfav','') ); xbmc.executebuiltin("XBMC.Container.Refresh"); 
	elif (mode=='cFavoritesRemove'):  fav__COMMON__remove( site=site,section=section,subfav=addpr('subfav',''),name=addpr('title',''),year=addpr('year','') )
	elif (mode=='cFavoritesAdd'):  		fav__COMMON__add( site=site,section=section,subfav=addpr('subfav',''),name=addpr('title',''),year=addpr('year',''),img=addpr('img',''),fanart=addpr('fanart',''),plot=addpr('plot',''),commonID=addpr('commonID',''),commonID2=addpr('commonID2',''),ToDoParams=addpr('todoparams',''),Country=addpr('country',''),Genres=addpr('genres',''),Url=url ) #,=addpr('',''),=addpr('','')
	elif (mode=='AddVisit'):							
		try: visited_add(addpr('title')); RefreshList(); 
		except: pass
	elif (mode=='RemoveVisit'):							
		try: visited_remove(addpr('title')); RefreshList(); 
		except: pass
	elif (mode=='EmptyVisit'):						
		try: visited_empty(); RefreshList(); 
		except: pass
	elif (mode=='refresh_meta'):			refresh_meta(addpr('video_type',''),addpr('title',''),addpr('imdb_id',''),addpr('alt_id',''),addpr('year',''))
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
