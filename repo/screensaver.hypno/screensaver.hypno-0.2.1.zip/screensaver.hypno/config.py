def FetchDefault():
        return 'hypno_02_neonspin'
def FetchList():
        return [
            ['Hypno 01 Black and White','hypno_01','http://i.imgur.com/v7W0LcS.gif'],
            ['Hypno 02 Neon Spin','hypno_02_neonspin','http://i.imgur.com/eBCLC7a.gif'],
            #['Hypno 03 Fox Troll','hypno_03',''],
            ['Hypno 04','hypno_04b','http://i.imgur.com/R3vSZLF.gif'],
            ['Hypno 05 Wavy Landscape','hypno_05_wavy','http://i.imgur.com/xYv4yUz.gif'],
            #['','',''],
            #['','',''],
            ['Testing'        ,'',''],
            #['','',''],
            ['Black','Black1.png',''],['Blank','Blank1.png',''] ]
