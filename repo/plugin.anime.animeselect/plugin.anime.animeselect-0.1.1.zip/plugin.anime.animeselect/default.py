#############################################################################
#############################################################################
import common
from common import *
from common import (addon_id,addon_name,addon_path)
NextPageImg=art('nextpage.png'); NextPageImg=''


#############################################################################
#############################################################################
def Menu0(): ## Main Menu ##
	cMI=[]
	#cMI.append(('Information','XBMC.Action(Info)'))
	
	ADDON.add_directory({'mode':'LatestEpisodes','url':'http://m.animeselect.net/?paged=1'},{'title':'Latest Episodes'},fanart=addonFanart,img=addonIcon)
	#ADDON.add_directory({'mode':'LatestVideos','url':'/page/1/?filtre=date&cat=0'},{'title':'Latest Videos'},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'NewAddedSeries'},{'title':'New Added Series'},fanart=addonFanart,img=addonIcon)
	
	ADDON.add_directory({'mode':'Genres'},{'title':cFL('Genres','lawngreen')},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'Search','q':''},{'title':cFL('Search...','lavender')},fanart=addonFanart,img=addonIcon)
	
	ADDON.add_directory({'mode':'HotAnime'},{'title':cFL('Hot Anime','deeppink')},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'SuggestedAnime'},{'title':'Suggested Anime'},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'OngoingAnime'},{'title':'Ongoing Anime'},fanart=addonFanart,img=addonIcon)
	
	ADDON.add_directory({'mode':'AtoZ'},{'title':cFL('Anime List','orange')},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'Movies','url':'/anime-movie-list/'},{'title':cFL('Anime Movie List','orange')},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'AnimeOfTheWeek'},{'title':cFL('Anime Of The Week','red')},fanart=addonFanart,img=addonIcon)
	
	ADDON.add_directory({'mode':'BrowserUrl','url':'http://m.animeselect.net/'},{'title':'Anime Select - Mobile'},fanart=addonFanart,img=art('anim6.png'),is_folder=True)
	ADDON.add_directory({'mode':'BrowserUrl','url':'http://www.animeselect.net/'},{'title':'Anime Select - www'},fanart=addonFanart,img=art('anim6.png'),is_folder=True)
	ADDON.add_directory({'mode':'BrowserUrl','url':'http://tinyurl.com/o52ar6c'},{'title':'#The_Projects @ irc.snoonet.org:6667'},fanart=addonFanart,img='http://i.imgur.com/7YS28Z5.jpg',is_folder=True)
	
	setView('movies',getSet("front-view")); eod()

def Browse_AtoZ():
	for a in ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']:
	  try:
	  	ADDON.add_directory({'mode':'Animes','url':'/index/'+a.lower()},{'title':a.upper()},fanart='',img='')
	  except: pass
	setView('movies',getSet("atoz-view")); eod()
def Browse_Genres():
	html=nolines(BrowseURL('http://www.animeselect.net/?genre=')); 
	html=html.replace('</li>','</li\n>')
	r=re.compile('<li style=\s*"float:right; width:100px;"\s*>\s*<a href=\s*\'([^\']+)\' >\s*([^<]+)</a>\s*</li').findall(html)
	if r:
		if len(r) > 0:
			iC=len(r)
			for a,b in r:
				try:
					ADDON.add_directory({'mode':'Genre','url':a},{'title':b},fanart='',img='')
				except: pass
	setView('movies',getSet("genres-view")); eod()
#############################################################################
#############################################################################

#############################################################################
#############################################################################

#############################################################################
#############################################################################

def BrowseURL(UrL=''):
		DoMAIN=zCoDeSz('domain')
		if len(UrL)==0: UrL=DoMAIN
		elif UrL.startswith('/'): UrL=DoMAIN+UrL
		return nURL(UrL)

def BrowseURLm(UrL=''):
		DoMAIN=zCoDeSz('domainm')
		wwwDoMAIN=zCoDeSz('domain')
		UrL=UrL.replace(wwwDoMAIN,DoMAIN)
		if len(UrL)==0: UrL=DoMAIN
		elif UrL.startswith('/'): UrL=DoMAIN+UrL
		return nURL(UrL)

def Browse_Episodes(UrL=''):
		html=nolines(BrowseURLm(UrL)); DoMAIN=zCoDeSz('domainm')
		debob([len(html),UrL])
		html.replace('</li>','</li\n>')
		r=re.compile('<li class="column-three">\s*<div class="contentbox">\s*<div class="contentboxin">\s*<a href="([^"]+)">\s*()<div style="[^"]+">\s*([^<]+)</div>\s*<div style="[^"]+">\s*([^<]+)</div>\s*</a>\s*</div>\s*</div>\s*</li').findall(html)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)
							for url,img,name,ename in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Playback','url':url,'title':name,'studio':ename,'thumb':img}
									rTitle=''+name+' - '+ename+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									debob(pars)
									#try: ADDON.add_video_item(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		#print html
		if '"><strong>Next ' in html:
			try:
				nextUrl=re.compile('<a style="" href="([^"]+)"><strong>Next ').findall(html)[0]
				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domainm')+nextUrl
				if nextUrl.startswith('?'): 
					if '?' in UrL:
						nextUrl=UrL.split('?')[0]+nextUrl
					else:
						nextUrl=UrL+nextUrl
				pars={'mode':'Episodes','url':nextUrl}
				debob(pars)
				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
			except: pass
		setView('movies',getSet("episodes-view")); eod()

def Browse_Animes(UrL=''):
		html=nolines(BrowseURLm(UrL)); DoMAIN=zCoDeSz('domainm')
		html.replace('</li>','</li\n>')
		r=re.compile('<li class="column-three">\s*<div class="contentbox">\s*<div class="contentboxin">\s*<a href="([^"]+)" title="[^"]+">\s*()<div style="[^"]+">\s*([^<]+)</div>\s*</a>\s*</div>\s*</div>\s*</li').findall(html)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)
							for url,img,name in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Episodes','url':url,'title':name,'thumb':img}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									#debob(pars)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		#debob(html)
		if '"><strong>Next ' in html:
			try:
				nextUrl=re.compile('<a style="" href="([^"]+)"><strong>Next ').findall(html)[0]
				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domainm')+nextUrl
				if nextUrl.startswith('?'): 
					if '?' in UrL:
						nextUrl=UrL.split('?')[0]+nextUrl
					else:
						nextUrl=UrL+nextUrl
				pars={'mode':'Episodes','url':nextUrl}
				debob(pars)
				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
			except: pass
		setView('movies',getSet("animes-view")); eod()

def Browse_Genre(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domainm'); debob([len(html),UrL]); 
		html=html.replace('<div class="cont_anime">','<\ndiv class="cont_anime">').replace('<div class= "cont_anime" >','<\ndiv class="cont_anime">').replace('= "','="').replace(' >','>').replace(' />','/>')
		r=re.compile('div class=\s*"cont_anime"\s*>\s*<div class=\s*"anime_box"\s*>\s*<a href=\s*"(http://[^/]+/anime/[^/]+/" title=\s*"[^"]+)"\s*><img src=\s*"([^"]+)" alt=\s*"[^"]+"[^>]*>\s*</a>\s*<div>\s*</div>\s*<span><a href=\s*"http://[^/]+/anime/[^/]+/" title=\s*"[^"]*"\s*>([^<]+)</a>\s*</span>\s*</div>\s*</div').findall(html)
		debob(r)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)
							#debob(['r',r])
							for url,img,name in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									img=img.replace('http://www.animespeed.net/dub/cover/','http://cdn2.chia-anime.com/content/cache2/')
									if 'chia-anime.com' in img: img=img.replace('!','')
									fimg=img; pars={'mode':'Episodes','url':url,'title':name,'thumb':img}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									#debob(pars)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		#debob(html)
		if '"><strong>Next ' in html:
			try:
				nextUrl=re.compile('<a style="" href="([^"]+)"><strong>Next ').findall(html)[0]
				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domainm')+nextUrl
				if nextUrl.startswith('?'): 
					if '?' in UrL:
						nextUrl=UrL.split('?')[0]+nextUrl
					else:
						nextUrl=UrL+nextUrl
				pars={'mode':'Episodes','url':nextUrl}
				debob(pars)
				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
			except: pass
		setView('movies',getSet("genre-view")); eod()

def Browse_Movies(UrL=''):
		html=nolines(BrowseURL('http://www.animeselect.net/anime-movie-list/')); DoMAIN=zCoDeSz('domainm')
		debob(len(html))
		html+=nolines(BrowseURL('http://www.animeselect.net/anime-movie-list/?lcp_page1=2')); 
		html.replace('</li>','</li\n>')
		debob(len(html))
		r=re.compile('<li>\s*<a href="(http://[^/]+/watch/[^"]+)"() title="[^"]*">\s*([^<]+)</a>\s*</li').findall(html)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)
							for url,img,name in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Playback','url':url,'title':name,'thumb':img}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									#debob(pars)
									#try: ADDON.add_video_item(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		#debob(html)
		if '"><strong>Next ' in html:
			try:
				nextUrl=re.compile('<a style="" href="([^"]+)"><strong>Next ').findall(html)[0]
				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domainm')+nextUrl
				if nextUrl.startswith('?'): 
					if '?' in UrL:
						nextUrl=UrL.split('?')[0]+nextUrl
					else:
						nextUrl=UrL+nextUrl
				pars={'mode':'Episodes','url':nextUrl}
				debob(pars)
				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
			except: pass
		setView('movies',getSet("movies-view")); eod()

def Browse_Suggested_Anime(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		if not '<div class="footer_column">' in html: eod(); return
		rhtml=html.split('<div class="footer_column">')
		for rhtmla in rhtml:
			if '<span>Suggested Anime!</span>' in rhtmla:
				try:
					rhtmla=rhtmla.replace('</a>','</a\n>')
					r=re.compile('<a href="([^"]+)"()>\s*<h\d+>([^<]+)</h\d+>\s*</a').findall(rhtmla)
					if r:
						if len(r) > 0:
							iC=len(r)
							for url,img,name in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Episodes','url':url,'title':name}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('movies',getSet("suggested-view")); eod()

def Browse_Hot_Anime(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		if not '<div class="footer_column">' in html: eod(); return
		rhtml=html.split('<div class="footer_column">')
		for rhtmla in rhtml:
			if '<span>Hot Anime!</span>' in rhtmla:
				try:
					rhtmla=rhtmla.replace('</a>','</a\n>')
					r=re.compile('<a href="([^"]+)"()>\s*</p>\s*<h\d+>([^<]+)</h\d+').findall(rhtmla)
					if r:
						if len(r) > 0:
							iC=len(r)
							for url,img,name in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Episodes','url':url,'title':name}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('movies',getSet("hot-view")); eod()

def Browse_New_Added_Series(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain'); debob(len(html)); 
		if not '<div class="widget-title">' in html: eod(); return
		rhtml=html.split('<div class="widget-title">')
		for rhtmla in rhtml:
			if '<span>New Added Series' in rhtmla:
				try:
					rhtmla=rhtmla.replace('</a>','</a\n>')
					r=re.compile('<a\s*href=(?:")?(http://[^/]+/anime/([^/]+)/)">\s*<img height="[^"]+" width="[^"]+" src="([^"]+)">\s*</a').findall(rhtmla)
					if r:
						if len(r) > 0:
							iC=len(r)
							for url,name,img in r:
								cMI=[]; name=uqP(name.replace('-',' '))
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Episodes','url':url,'title':name}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('movies',getSet("new-added-series-view")); eod()

def Browse_Anime_of_the_Week(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		if not '<div class="widget-title">' in html: eod(); return
		rhtml=html.split('<div class="widget-title">')
		for rhtmla in rhtml:
			if '<span>Anime Of The Week' in rhtmla:
				try:
					rhtmla=rhtmla.replace('</a>','</a\n>')
					r=re.compile('<a\s*href=(?:")?(http://[^/]+/anime/([^/]+)/)">\s*<img height="[^"]+" width="[^"]+" src="([^"]+)">\s*</a').findall(rhtmla)
					if r:
						if len(r) > 0:
							iC=len(r)
							for url,name,img in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Episodes','url':url,'title':name}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('movies',getSet("anime-of-the-week-view")); eod()

def Browse_Ongoing_Anime(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		if not '<div class="sidebar-widget">' in html: eod(); return
		rhtml=html.split('<div class="sidebar-widget">')
		for rhtmla in rhtml:
			if '<span>Ongoing Anime' in rhtmla:
				try:
					rhtmla=rhtmla.replace('</a>','</a\n>')
					r=re.compile('<a href="([^"]+)"()>\s*<h\d+>([^<]+)</h\d+>\s*</a').findall(rhtmla)
					if r:
						if len(r) > 0:
							iC=len(r)
							for url,img,name in r:
								cMI=[]; 
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Episodes','url':url,'title':name}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('movies',getSet("ongoing-anime-view")); eod()

def Browse_Latest_Videos(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		if not '<div class="footer_column">' in html: eod(); return
		rhtml=html.split('<div class="footer_column">')
		for rhtmla in rhtml:
			if '<span>Suggested Anime!</span>' in rhtmla:
				try:
					rhtmla=rhtmla.replace('</a>','</a\n>')
					r=re.compile('<a href="([^"]+)"()>\s*<h\d+>([^<]+)</h\d+>\s*</a').findall(rhtmla)
					if r:
						if len(r) > 0:
							iC=len(r)
							for url,img,name in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Episodes','url':url,'title':name}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('movies',getSet("latest-videos-view")); eod()

def Browse_Latest_Episodes(UrL=''):
		html=nolines(BrowseURLm(UrL)); DoMAIN=zCoDeSz('domainm')
		html.replace('</li>','</li\n>')
		r=re.compile('<li class="column-three">\s*<div class="contentbox">\s*<div class="contentboxin">\s*<a href="([^"]+)" title="Portfolio Item">\s*<img src="([^"]+)" alt="">\s*</a>\s*<div class="pdesc acenter"><div style="height:15px;overflow:hidden;">\s*([^<]+)</div>\s*([^<]+)</div>\s*</div>\s*</div>\s*</li').findall(html)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)
							for url,img,name,ename in r:
								cMI=[]; img=img.replace('&amp;','&'); debob([name,ename,img,url]); 
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									if 'animeselect.net/thumbnail/' in img:
										img=img.replace('://www.animeselect.net','://animeselect.net')
										if '?' in img:
											img=img.split('?')[0]
										img+=''+'|User-Agent='+ps('User-Agent')
									fimg=img; pars={'mode':'Playback','url':url,'title':name,'studio':ename,'thumb':img}
									rTitle=''+name+' - '+ename+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									debob(pars)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		#debob(html)
		if '"><strong>Next ' in html:
			try:
				nextUrl=re.compile('<a style="" href="([^"]+)"><strong>Next ').findall(html)[0]
				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domainm')+nextUrl
				if nextUrl.startswith('?'): 
					if '?' in UrL:
						nextUrl=UrL.split('?')[0]+nextUrl
					else:
						nextUrl=UrL+nextUrl
				pars={'mode':'LatestEpisodes','url':nextUrl}
				debob(pars)
				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
			except: pass
		setView('movies',getSet("latest-episodes-view")); eod()

def Search(UrL='',q=''):
		DoMAIN=zCoDeSz('domain')
		if len(UrL)==0:
			try:
				if len(q)==0:
					q=qP(str(showkeyboard("","Search...")))
				UrL=DoMAIN+'/?s='+q
			except: pass
		deb('url',str(UrL))
		if len(UrL)==0: eod(); return
		## Note:  Device(s) using Android OS seem to return 0 length for html.
		html=nolines(BrowseURL(UrL)); debob(len(html)); 
		if not '>Search results for ' in html: eod(); return
		html=html.replace('= "','="')
		r=re.compile('<div\s*class="cont_anime"\s*>\s*<div\s*class="anime_box"\s*>\s*<a\s*href="([^"]+)"\s*title="[^"]+"\s*>\s*<img\s*src="([^"]+)" alt="[^"]+"\s*/>\s*</a\s*\n*\s*>\s*<div>\s*</div>\s*<span style="[^"]+">\s*<a href="[^"]+" title="[^"]+">\s*([^<]+)</a').findall(html.replace('</a>','</a\n>'))
		if r:
			if len(r) > 0:
				iC=len(r); #debob(r); 
				for url,img,name in r:
					cMI=[]; cMI.append(('Information','XBMC.Action(Info)'))
					try:
						if img.startswith('/'): img=DoMAIN+img
						img=img.replace('http://www.animespeed.net/dub/cover/','http://cdn.chia-anime.com/content/cache2/')
						#img=img.replace('http://animeget.net/dub/cover/','http://cdn2.chia-anime.tv/thumbnail/')
						img=img.replace('http://animeget.net/dub/cover/','http://cdn.chia-anime.tv/content/cache2/')
						img=img.replace('!','').replace(':','-').replace('-//','://')
						fimg=img; pars={'mode':'Episodes','url':url,'title':name}
						debob([url,img,name]); 
						rTitle=''+name+''
						if img=='': img=addonIcon
						if fimg=='': fimg=addonFanart
						try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
						except: pass
					except: pass
		html=html.replace('</li>','</li\n>')
		r=re.compile('<li class="border-radius-\d+ box-shadow">\s*<img src="([^"]+)" alt="[^"]+"\s*/>\s*<a href="([^"]+)" title="[^"]+">\s*<span>\s*([^<]+)</span></a').findall(html)
		if r:
			if len(r) > 0:
				iC=len(r); #debob(r); 
				for img,url,name in r:
					cMI=[]; cMI.append(('Information','XBMC.Action(Info)'))
					try:
						if img.startswith('/'): img=DoMAIN+img
						img=img.replace('&amp;','&')
						debob([url,img,name]); 
						fimg=img; pars={'mode':'Playback','url':url,'title':name}
						rTitle=''+name+''
						if img=='': img=addonIcon
						if fimg=='': fimg=addonFanart
						try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
						except: pass
					except: pass
		if '"nextLink":"' in html:
			try:
				nextUrl=re.compile('"nextLink":"([^"]+)"').findall(html)[0]
				nextUrl=uqP(nextUrl).replace('\\/','/')
				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domain')+nextUrl
				if nextUrl.startswith('?'): 
					if '?' in UrL:
						nextUrl=UrL.split('?')[0]+nextUrl
					else:
						nextUrl=UrL+nextUrl
				pars={'mode':'Search','url':nextUrl}
				debob(pars)
				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
			except: pass
		setView('movies',getSet("search-view")); eod()

def Browse(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		if not '<div class="footer_column">' in html: eod(); return
		rhtml=html.split('<div class="footer_column">')
		for rhtmla in rhtml:
			if '<span>Suggested Anime!</span>' in rhtmla:
				try:
					rhtmla=rhtmla.replace('</a>','</a\n>')
					r=re.compile('<a href="([^"]+)"()>\s*<h\d+>([^<]+)</h\d+>\s*</a').findall(rhtmla)
					if r:
						if len(r) > 0:
							iC=len(r)
							for url,img,name in r:
								cMI=[]
								cMI.append(('Information','XBMC.Action(Info)'))
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Episodes','url':url,'title':name}
									rTitle=''+name+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('movies',getSet("browse-view")); eod()
#############################################################################
#############################################################################

#############################################################################
#############################################################################

#############################################################################
#############################################################################
def GetPlayerCore():
	try:
		PlayerMethod=getSet("core-player")
		if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER
		elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER
		elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER
		else: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	except: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	return PlayerMeth
def PlayStreamWithResolver(url):
		play=xbmc.Player(GetPlayerCore())
		try:
			import urlresolver
			url=urlresolver.HostedMediaFile(url).resolve()
			try: ADDON.resolve_url(url)
			except: pass
			try: play.play(url)
			except: pass
		except: pass
def PlayStream(url):
		play=xbmc.Player(GetPlayerCore())
		try: ADDON.resolve_url(url)
		except: pass
		try: play.play(url)
		except: pass
def PlayURL(url):
		play=xbmc.Player(GetPlayerCore())
		try: play.play(url)
		except: pass
def Playback(url):
		play=xbmc.Player(GetPlayerCore())
		url=url.replace(zCoDeSz('domain'),zCoDeSz('domainm'))
		debob({'page':url})
		#eod()
		html=nolines(BrowseURLm(url))
		#print html
		if "'file'" in html:
			vid_url=re.compile("'file'\s*:\s*'([^']+)'").findall(html)[0]
			#vid_img=re.compile("'image'\s*:\s*'([^']+)'").findall(html)[0]
		else:
			link_url=re.compile('<iframe id="video" src="([^"]+)"').findall(html)[0]
			html2=nolines(BrowseURLm(link_url))
			debob({'2nd page':link_url})
			vid_url=re.compile("'file'\s*:\s*'([^']+)'").findall(html2)[0]
			#vid_img=re.compile("'image'\s*:\s*'([^']+)'").findall(html2)[0]
		try: play.play(vid_url)
		except: pass
#############################################################################
#############################################################################
def zModeCheck(mode='',url=''):
	deb('mode',mode); 
	if (mode=='') or (mode=='main'): Menu0()
	elif mode=='SuggestedAnime': Browse_Suggested_Anime()
	elif mode=='HotAnime': Browse_Hot_Anime()
	elif mode=='NewAddedSeries': Browse_New_Added_Series()
	elif mode=='AnimeOfTheWeek': Browse_Anime_of_the_Week()
	elif mode=='OngoingAnime': Browse_Ongoing_Anime()
	elif mode=='LatestVideos': Browse_Latest_Videos()
	elif mode=='LatestEpisodes': Browse_Latest_Episodes(url)
	#elif mode=='SuggestedAnime': Browse_Hot_Anime()
	#
	elif mode=='Genres': Browse_Genres()
	elif mode=='Genre': Browse_Genre(url)
	elif mode=='AtoZ': Browse_AtoZ()
	elif mode=='Movies': Browse_Movies(url)
	elif mode=='Animes': Browse_Animes(url)
	elif mode=='Episodes': Browse_Episodes(url)
	elif mode=='Search': Search(url,addpr('q'))
	elif mode=='Browse': Browse(url)
	elif mode=='Playback': Playback(url)
	elif mode=='Play': PlayStream(url)
	elif mode=='PlayR': PlayStreamWithResolver(url)
	elif mode=='BrowserUrl':
		url=addpr('url')
		if '://' in url:
			XBMC_System_Exec('"%s"'%url)
	else: eod()
	
	
	##
zModeCheck(addpr('mode'),addpr('url'))
#############################################################################
#############################################################################
