### ############################################################################################################
### ############################################################################################################
### # ## ### ## Imports ## ### ## 
import os,sys,xbmc,logging,re,string,array,random,time,datetime,StringIO

### ############################################################################################################
### ############################################################################################################
def psgn(x,t=".png"):
	s="http://i.imgur.com/"; 
	Domain='http://kissanime.com'
	try:
		return {
			'action': 					s+"Q12cars"+t
			,'adventure': 			s+"wq3rlj8"+t
			,'cars': 						s+"e9n9Hih"+t
			,'cartoon': 				s+"yrrvbzw"+t
			,'comedy': 					s+"FU3VJGg"+t
			,'dementia': 				s+"trimFik"+t
			,'demons': 					s+"NHLTav4"+t
			,'drama': 					s+"w7R77Dj"+t
			,'dub': 						s+"3nc4UkN"+t
			,'ecchi': 					s+"2Y7s1d9"+t
			,'fantasy': 				s+"tspZm16"+t
			,'game': 						s+"NSLV38b"+t
			,'harem': 					s+"VSpcIo4"+t
			,'historical': 			s+"iyxap9I"+t
			,'horror': 					s+"EueQPn7"+t
			,'josei': 					s+"hR2UNOm"+t
			,'kids': 						s+"yzh5nBq"+t
			,'magic': 					s+"DOy6zZd"+t
			,'martial arts': 		s+"Nw4rjxJ"+t
			,'mecha': 					s+"XCZYIZo"+t
			,'military': 				s+"ZMXs7Gl"+t
			,'movie': 					s+"55YtzvJ"+t
			,'music': 					s+"tgcLRfv"+t
			,'mystery': 				s+"37MUY4c"+t
			,'ona': 						s+"WvIeCaj"+t
			,'ova': 						s+"6GPcrWB"+t
			,'parody': 					s+"3hBYM4k"+t
			,'police': 					s+"zl4qBvk"+t
			,'psychological': 	s+"75bP7sP"+t
			,'romance': 				s+"ko0OKE4"+t
			,'samurai': 				s+"DDoZmKP"+t
			,'school': 					s+"FlS7hEm"+t
			,'sci-fi': 					s+"3B0dkvt"+t
			,'seinen': 					s+"6vc6cwB"+t
			,'shoujo': 					s+"JAsp9PL"+t
			,'shoujo ai': 			s+"PaLhEhj"+t
			,'shounen': 				s+"PeXK8An"+t
			,'shounen ai': 			s+"uvaepAZ"+t
			,'slice of life': 	s+"rh4voyt"+t
			,'space': 					s+"QReD8P3"+t
			,'special': 				s+"lph1IaX"+t
			,'sports': 					s+"Ji1o6uG"+t
			,'super power': 		s+"6mHg5s6"+t
			,'supernatural': 		s+"8mAz2dT"+t
			,'thriller': 				s+"ZbW3BKy"+t
			,'vampire': 				s+"Kn9Yi7C"+t
			,'yuri': 						s+"VylolyV"+t
			,'a': 		s+"OvFHLK2"+t
			,'b': 		s+"ezem9mn"+t
			,'c': 		s+"707ILz1"+t
			,'d': 		s+"BUT7dUz"+t
			,'e': 		s+"mzNtW2U"+t
			,'f': 		s+"11cykaC"+t
			,'g': 		s+"l0CvvHo"+t
			,'h': 		s+"VOupMGK"+t
			,'i': 		s+"ps3YPHq"+t
			,'j': 		s+"oNHwZWv"+t
			,'k': 		s+"TwHANG6"+t
			,'l': 		s+"xiuR2WX"+t
			,'m': 		s+"GDEAPud"+t
			,'n': 		s+"9FjSiMu"+t
			,'o': 		s+"TcR1pa0"+t
			,'p': 		s+"OGc4VBR"+t
			,'q': 		s+"hL9tEkx"+t
			,'r': 		s+"37NNHm8"+t
			,'s': 		s+"mFQswUE"+t
			,'t': 		s+"4DBQVrd"+t
			,'u': 		s+"qpovLUW"+t
			,'v': 		s+"bnu5ByY"+t
			,'w': 		s+"0IHoHV2"+t
			,'x': 		s+"ic81iKY"+t
			,'y': 		s+"46IlmRH"+t
			,'z': 		s+"PWUSCsE"+t
			,'0': 		s+"7an2n4W"+t # 0RJOmkw
			,'all': 	s+"hrWVT21"+t
			,'search': 										s+"mDSHRJX"+t
			,'plugin settings': 					s+"K4OuZcD"+t
			,'local change log': 					s+"f1nvgAM"+t
			,'last': 											s+"FelUdDz"+t
			,'favorites': 								s+"lUAS5AU"+t
			,'favorites 2': 							s+"EA49Lt3"+t
			,'favorites 3': 							s+"lwJoUqT"+t
			,'favorites 4': 							s+"Wr7GPTf"+t
			,'latest update': 						s+"dNCxQbg"+t
			,'completed': 								s+"xcqaTKI"+t
			,'most popular': 							s+"T9LUsM2"+t
			,'new anime': 								s+"BGZnMf5"+t
			,'genre': 										s+"AmQHPvY"+t
			,'ongoing': 									s+"EUak0Sg"+t
			,'anime list all': 						s+"t8b1hSX"+t
			,'anime list alphabet': 			s+"R0w0BAM"+t
			,'anime list latest update': 	s+"XG0LGQH"+t
			,'anime list newest': 				s+"eWAeuLG"+t
			,'anime list popularity': 		s+"eTrguP1"+t
			,'urlresolver settings': 			s+"PlROfSs"+t
			,'online bookmarks': 					s+"68ih1sx"+t
			,'alphabetical': 							s+"sddCXQo"+t
			,'genre select': 							s+"MhNenb6"+t
			,'upcoming anime': 						s+"4v2dThp"+t
			,'site shortcuts': 						s+"w8aszrQ"+t
			,'visited101': 								s+"dYOpFmD"+t
			,'history101': 								s+"yQVdUcc"+t
			,'history201': 								s+"fVuCkXg"+t
			,'menu history': 							s+"Kf32XmV"+t
			,'my list': 									s+"pdMAaFb"+t
			,'my list add': 							s+"oeMOOKx"+t
			,'my list remove': 						s+"XBembzH"+t
			,'my list empty': 						s+"ZUQIDXk"+t
			,'my list list': 							s+"Eagu6rf"+t
			,'my list user': 							s+"MDDPS0G"+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
			,'ext 3gp': 								s+"srI8Ja6"+t
			,'ext flv': 								s+"R6rYMIq"+t
			,'ext mkv': 								s+"7fmBNnc"+t
			,'ext mp4': 								s+"Krt5Pxs"+t
			,'list genres': 						s+"VzE0vjU"+t
			,'changelog 01': 						s+"g47ObWG"+t
			,'trash 01': 								s+"gNTU1v3"+t
			,'turtle': 									s+"cK1ZH2x"+t
			,'green lips 01': 					s+"GY1aIbp"+t
			,'warning': 								s+"HKkbLyM"+t
			,'img prev': 								Domain+'/Content/images/previous.png' #s+""+t
			,'img next': 								Domain+'/Content/images/next.png' #s+""+t
			,'img hot': 								Domain+'/Content/images/hot.png' #s+""+t
			,'img kisslogo': 						Domain+'/Content/images/logo.png' #s+""+t
			,'img updated': 						Domain+'/Content/images/newupdate.png' #s+""+t
			,'img search': 							Domain+'/Content/images/read.png' #s+""+t
			,'img logout': 							Domain+'/Content/images/logout.png' #s+""+t
			,'img usersmall': 					Domain+'/Content/images/user-small.png' #s+""+t
			,'img kpoints': 						Domain+'/Content/images/user-small.png' #s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
# KissAnimeGenres
# http://imgur.com/a/rws19/all
# http://imgur.com/a/rws19#Q12cars
# http://imgur.com/a/rws19
		}[x]
	except: print 'failed to find graphc for %s' % (x); return ''
### ############################################################################################################
### ############################################################################################################
