# -*- coding: utf-8 -*-
##import AntiDDOSProtectcion

import urllib2,urlparse,re,cookielib
def decryptCFDDOSProtection(url):
    try:
        class NoRedirection(urllib2.HTTPErrorProcessor):    
            def http_response(self,request,response):
                return response
        ##
        agent='Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'
        cj=cookielib.CookieJar()
        ##
        opener=urllib2.build_opener(NoRedirection, urllib2.HTTPCookieProcessor(cj))
        opener.addheaders=[('User-Agent', agent)]
        response=opener.open(url)
        result=response.read()
        ##
        jschl=re.compile('name="jschl_vc" value="(.+?)"/>').findall(result)[0]
        ##
        init=re.compile('setTimeout\(function\(\){\s*.*?.*:(.*?)};').findall(result)[0]
        builder=re.compile(r"challenge-form\'\);\s*(.*)a.v").findall(result)[0]
        decryptVal=parseJSString(init)
        lines=builder.split(';')
        ##
        for line in lines:
            if len(line)>0 and '=' in line:
                sections=line.split('=')
                ##
                line_val=parseJSString(sections[1])
                decryptVal=int(eval(str(decryptVal)+sections[0][-1]+str(line_val)))
        ##
        answer=decryptVal+len(urlparse.urlparse(url).netloc)
        ##
        query='%s/cdn-cgi/l/chk_jschl?jschl_vc=%s&jschl_answer=%s'%(url,jschl,answer)
        ##
        opener=urllib2.build_opener(NoRedirection,urllib2.HTTPCookieProcessor(cj))
        opener.addheaders=[('User-Agent',agent)]
        response=opener.open(query)
        cookie=str(response.headers.get('Set-Cookie'))
        response.close()
        ##
        return cookie
    except:
        return
def parseJSString(s):
    try:
        offset=1 if s[0]=='+' else 0
        return int(eval(s.replace('!+[]','1').replace('!![]','1').replace('[]','0').replace('(','str(')[offset:]))
    except:
        return
