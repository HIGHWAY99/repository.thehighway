### ############################################################################################################
### ############################################################################################################
### # ## ### ## Imports ## ### ## 
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,urllib,urllib2,re,os,sys,htmllib,string,StringIO,logging,random,array,time,datetime,HTMLParser,htmlentitydefs
try: import copy
except: pass
import config as cfg
from config import *
import commonb as CommonB
from commonb import *
#try: import sqlite
#except: print "error importing sqlite"
#try: import sqlite3
#except: print "error importing sqlite3"
try:
	try: import StorageServer as StorageServer
	except: 
		try: import z_StorageServer as StorageServer
		except:
			try: import storageserverdummy as StorageServer
			except:
				try: import z_storageserverdummy as StorageServer
				except: pass
	cache=StorageServer.StorageServer(plugin_id)
except: pass
#try: 			   from addon.common.addon 			import Addon
#except:
#	try: 		   from t0mm0.common.addon 			import Addon
#	except: 
#		try:   from z_addon_common_addon 			import Addon
#		except: 
#			try: from z_t0mm0_common_addon 			import Addon
#			except: pass
try: 			   from addon.common.net 				import Net
except:
	try: 		   from t0mm0.common.net 				import Net
	except: 
		try:   from z_addon_common_net 				import Net
		except: 
			try: from z_t0mm0_common_net 				import Net
			except: pass
net=Net(); 
import y_splash_highway as splash
from metahandler import metahandlers
PrepareZip=False
MetaGet=metahandlers.MetaData(preparezip=PrepareZip)
### # ## ### ## 
### ############################################################################################################
### ############################################################################################################
## ### ## Settings
def setts(id,value):
	try: cfg.cAddon.addon.setSetting(id=id,value=value)
	except: pass
def settg(Id,defaultvalue=''):
	try: return cfg.cAddon.get_setting(Id)
	except: return defaultvalue
def settgb(Id,defaultvalue=False):
	try: return tfalse(cfg.cAddon.get_setting(Id))
	except: return defaultvalue
## ### ## Variables
#isDebuggingActive=ps('settingb','debug-enable'); isDebuggingShown=ps('settingb','debug-show'); 
isDebuggingActive=settgb('debug-enable'); isDebuggingShown=settgb('debug-show'); 
#
### ############################################################################################################
### ############################################################################################################
## ### ## Params
def Par(Id='',defaultvalue=''):
	try: 
		if len(str(Id))==0: return cAddon.queries
		else: return cfg.cAddon.queries.get(str(Id),defaultvalue)
	except: return defaultvalue
def ParB(Id='',defaultvalue=''):
	try:  return tfalse(cfg.cAddon.queries.get(str(Id),defaultvalue))
	except: return defaultvalue
def ParQ(Id='',defaultvalue=''):
	try:  return urllib.unquote_plus(cfg.cAddon.queries.get(str(Id),defaultvalue))
	except: return defaultvalue
## ### ## Dictional Url Stuff
def Dict2Url(a,defaultvalue=''):
	try: return cfg.cAddon.build_plugin_url(a)
	except: return defaultvalue
def Url2Dict(a,defaultvalue=''):
	try: return cfg.cAddon.parse_query(a)
	except: return defaultvalue
## ### ## Text Coding
def cFL( t,c=ps('default color1')): return '[COLOR %s]%s[/COLOR]'%(c,t) ### For Coloring Text ###
def cFL_(t,c=ps('default color1'),n=1): ### For Coloring Text (First Letter-Only) ###
	try: return '[COLOR %s]%s[/COLOR]%s'%(c,t[0:int(n)],t[int(n):])
	except: return t
def messupText(t,_html=False,_ende=False,_a=False,Slashes=False):
	if (_html==True): 
		try: t=HTMLParser.HTMLParser().unescape(t)
		except: pass
		try: t=ParseDescription(t)
		except: pass
	if (_ende==True): 
		try: 
			#t=t.encode('ascii', 'ignore'); t=t.decode('iso-8859-1')
			t=t.encode('utf8'); 
			#for z in [0xc2,0xc3]: t=t.replace(chr(int(z)),'')
		except:
			try: t=t.encode('ascii','ignore'); t=t.decode('iso-8859-1')
			except: pass
	if (_a==True): 
		try: t=cfg.cAddon.decode(t); t=cfg.cAddon.unescape(t)
		except: pass
	if (Slashes==True): 
		try: t=t.replace('_',' ')
		except: pass
	#t=t.replace("text:u","")
	return t
def filename_filter_colorcodes(name=''):
	if ('[/color]' 				in name): name=name.replace('[/color]','')
	if ('[/COLOR]' 				in name): name=name.replace('[/COLOR]','')
	if ('[color lime]' 		in name): name=name.replace('[color lime]','')
	if ('[COLOR lime]' 		in name): name=name.replace('[COLOR lime]','')
	if ('[COLOR green]' 	in name): name=name.replace('[COLOR green]','')
	if ('[COLOR yellow]' 	in name): name=name.replace('[COLOR yellow]','')
	if ('[COLOR red]' 		in name): name=name.replace('[COLOR red]','')
	if ('[COLOR deeppink]' 	in name): name=name.replace('[COLOR deeppink]','')
	if ('[COLOR firebrick]' in name): name=name.replace('[COLOR firebrick]','')
	if ('[COLOR %s]'%ps('default color1') in name): name=name.replace('[COLOR %s]'%ps('default color1'),'')
	if ('[COLOR %s]'%ps('default color2') in name): name=name.replace('[COLOR %s]'%ps('default color2'),'')
	if ('[COLOR %s]'%ps('default color3') in name): name=name.replace('[COLOR %s]'%ps('default color3'),'')
	MyColors=['red','blue','darkblue','grey','maroon','teal','cornflowerblue','cornflowerblue','deeppink','grey','gray','tan']
	for MyColor in MyColors:
		if ('[COLOR %s]'%MyColor in name): name=name.replace('[COLOR %s]'%MyColor,'')
		if ('[color %s]'%MyColor in name): name=name.replace('[color %s]'%MyColor,'')
	if ('[b]' 						in name): name=name.replace('[b]','')
	if ('[B]' 						in name): name=name.replace('[B]','')
	if ('[/b]' 						in name): name=name.replace('[/b]','')
	if ('[/B]' 						in name): name=name.replace('[/B]','')
	if ('[cr]' 						in name): name=name.replace('[cr]','')
	if ('[CR]' 						in name): name=name.replace('[CR]','')
	if ('[i]' 						in name): name=name.replace('[i]','')
	if ('[I]' 						in name): name=name.replace('[I]','')
	if ('[/i]' 						in name): name=name.replace('[/i]','')
	if ('[/I]' 						in name): name=name.replace('[/I]','')
	if ('[uppercase]' 		in name): name=name.replace('[uppercase]','')
	if ('[UPPERCASE]' 		in name): name=name.replace('[UPPERCASE]','')
	if ('[lowercase]' 		in name): name=name.replace('[lowercase]','')
	if ('[LOWERCASE]' 		in name): name=name.replace('[LOWERCASE]','')
	name=name.replace('\n','').replace('\r','').replace('\a','').replace('\t','').strip()
	#if ('' in name): name=name.replace('','')
	#if ('' in name): name=name.replace('','')
	#if ('' in name): name=name.replace('','')
	return name


## ### ## On-Screen Prompts and Dialogs
def myNote(header='',msg='',delay=5000,image='http://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/US_99_%281961%29.svg/40px-US_99_%281961%29.svg.png'): cfg.cAddon.show_small_popup(title=header,msg=msg,delay=delay,image=image)
## ### ## Printing / Debugging / Logging
def deb(s,t): ### for Writing Debug Data to log file ###
	if (isDebuggingActive==True): print str(s)+':  '+str(t)
def debob(t): ### for Writing Debug Object to log file ###
	if (isDebuggingActive==True): print t
def WhereAmI(t): ### for Writing Location Data to log file ###
	if (isDebuggingActive==True): print 'Where am I:  '+str(t)
def debshow(msg,header='Debug Information',delay=5000,image=''): ### for Writing Debug Data to log file ###
	if (isDebuggingShown==True): 
		if len(image)==0:myNote(header=str(header),msg=str(t),delay=delay)
		else: myNote(header=str(header),msg=str(t),delay=delay,image=image)
## ### ## File / Folder / Path
def findInSubdirectory(filename,subdirectory=''):
	if subdirectory: path=subdirectory
	else: path=ps('addon path')
	for root,z,names in os.walk(path):
		if filename in names: return os.path.join(root,filename)
	#raise 'File not found'
	return ''
## ### ## On-Screen Folder View Lists
def sPluginFanart(i=cfg.cAddon.get_fanart(),c1='',c2='',c3='',h=int(sys.argv[1])): i=xbmc.translatePath(i); debob({'PluginFanart':i,'h':h}); xbmcplugin.setPluginFanart(handle=h,image=i)
def sView(ViewMode=50,h=int(sys.argv[1])):
	if settgb('auto-view')==True: xbmc.executebuiltin("Container.SetViewMode(%s)"%str(ViewMode))
def eod(succeeded=True,updateListing=False,cacheToDisc=True,h=int(sys.argv[1])): 
	#cfg.cAddon.end_of_directory()
	xbmcplugin.endOfDirectory(h,succeeded=succeeded,updateListing=updateListing,cacheToDisc=cacheToDisc)
def sCVE(content='none',ViewMode=50,h=int(sys.argv[1])):
	sContent(content); sView(ViewMode); eod(); 
class TextBox2: ## Usage Example: TextBox_FromUrl().load('https://raw.github.com/HIGHWAY99/plugin.video.theanimehighway/master/README.md')
	WINDOW 						=	10147; CONTROL_LABEL 		=	1; CONTROL_TEXTBOX 	=	5; HEADER_MESSAGE		=	"%s - ( v%s )" % (ps('addon name'),cfg.cAddon.get_version()); # set heading
	def load_url(self, URL_PATH, HEADER_MESSAGE2=''):
		deb('text window from url: ',URL_PATH) #self.URL_PATH
		try: 			text=nURL(URL_PATH)#(self.URL_PATH)
		except: 	text=''
		self.load_window(); self.set_header(HEADER_MESSAGE2); self.set_text(text)
	def load_file(self,FILE_NAME='changelog.txt',HEADER_MESSAGE2='',FILE_PATH=ps('addon path')):
		txt_path=os.path.join(FILE_PATH,FILE_NAME); deb('text window from file: ',txt_path); 
		f=open(txt_path); text=f.read(); 
		self.load_window(); self.set_header(HEADER_MESSAGE2); self.set_text(text); 
	def load_string(self,text_string='',HEADER_MESSAGE2=''):
		self.load_window(); self.set_header(HEADER_MESSAGE2); self.set_text(text_string)
	def load_window(self,sleeptime=500):
		xbmc.executebuiltin("ActivateWindow(%d)"%( self.WINDOW, ))				# activate the text viewer window
		self.win=xbmcgui.Window(self.WINDOW)															# get window
		xbmc.sleep(sleeptime)																							# give window time to initialize
	def set_header(self,HEADER_MESSAGE2=''):
		if (HEADER_MESSAGE2==''): HEADER_MESSAGE2=self.HEADER_MESSAGE
		self.win.getControl(self.CONTROL_LABEL).setLabel(HEADER_MESSAGE2)
	def set_text(self,text=''):
		self.win.getControl(self.CONTROL_TEXTBOX).setText(text)
def String2TextBox(message='',HeaderMessage=''): TextBox2().load_string(message,HeaderMessage); #RefreshList()
## ### ## HTML / URL
def nURL(url,method='get',form_data={},headers={},html='',proxy='',User_Agent='',cookie_file='',load_cookie=False,save_cookie=False,compression=True):
	if url=='': return ''
	dhtml=''+html; AntiTag='<iframe style="display:none;visibility:hidden;" src="http://my.incapsula.com/public/ga/jsTest.html" id="gaIframe"></iframe>'
	html=' '+AntiTag+' '
	if len(User_Agent) > 0: net.set_user_agent(User_Agent)
	else: net.set_user_agent(ps('User-Agent'))
	if len(proxy) > 9: net.set_proxy(proxy)
	if (len(cookie_file) > 0) and (load_cookie==True): net.set_cookies(cookie_file)
	xTimes=0
	while (AntiTag in html):
		xTimes=xTimes+1
		if   method.lower()=='get':
			try: html=net.http_GET(url,headers=headers,compression=compression).content
			except urllib2.HTTPError,e: debob({'code':e.code,'reason':e.reason,'url':url}); html=dhtml
			except Exception,e: debob(['Exception',e]); html=dhtml
			except: html=dhtml
		elif method.lower()=='post':
			try: html=net.http_POST(url,form_data=form_data,headers=headers,compression=compression).content #,compression=False
			except urllib2.HTTPError,e: debob({'code':e.code,'reason':e.reason,'url':url}); html=dhtml
			except Exception,e: debob(['Exception',e]); html=dhtml
			except: html=dhtml
		elif method.lower()=='head':
			try: html=net.http_HEAD(url,headers=headers).content
			except urllib2.HTTPError,e: debob({'code':e.code,'reason':e.reason,'url':url}); html=dhtml
			except Exception,e: debob(['Exception',e]); html=dhtml
			except: html=dhtml
		if (isDebuggingActive==True) and (isTesting==True):
			try: FileSave(ps('addon path1','temp.html.--.txt'),html)
			except: pass
		if xTimes > 5: html=html.replace(AntiTag,'')
		#elif AntiTag in html: xbmc.sleep(8000)
		elif AntiTag in html: xbmc.sleep(int(ps('setting','AntiTag','4000')))
	if (len(html) > 0) and (len(cookie_file) > 0) and (save_cookie==True): net.save_cookies(cookie_file)
	if "You're browsing too fast! Please slow down." in html: myNote("KissAnime","You're browsing too fast! Please slow down.")
	return html


## ### ## Player Functions
def GetPlayerCore(): ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	try:
		PlayerMethod=ps('setting',"core-player").upper()
		if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER
		elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER
		elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER
		else: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	except: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	return PlayerMeth


## ### ## 
def SendTo_JDownloader(url,useResolver=True):
	myNote('Download','sending to jDownloader plugin',15000)
	if useResolver==True:
		try: import urlresolver; link=urlresolver.HostedMediaFile(url).resolve()
		except: link=url
	else: link=url
	xbmc.executebuiltin("XBMC.RunPlugin(plugin://plugin.program.jdownloader/?action=addlink&url=%s)"%link)
	try: cfg.cAddon.resolve_url(url)
	except: pass

#import y_Extract as extract #extract.all(lib,addonfolder,dp)
#import y_HiddenDownloader as downloader #downloader.download(url,destfile,destpath,useResolver=True)
def ExtractThis(filename,destpath): import y_Extract as extract; return extract.allNoProgress(filename,destpath)
def DownloadThis(url,destfile,destpath,useResolver=True):
	destpath=xbmc.translatePath(destpath)
	import y_HiddenDownloader as downloader
	debob(str(useResolver))
	if useResolver==True:
		try: 
			import urlresolver
			#debob(urlresolver.HostedMediaFile(url))
			link=urlresolver.HostedMediaFile(url).resolve()
		except: link=url
	else: link=url
	deb('downloadable url',link)
	downloader.download(link,destfile,destpath,useResolver)
	#downloader.download(url,destfile,destpath,useResolver)

def Download_PrepExt(url,ext='.flv'):
	if    '.zip' in url: ext='.zip' #Compressed Files
	elif  '.rar' in url: ext='.rar'
	elif   '.z7' in url: ext='.z7'
	elif  '.png' in url: ext='.png' #images
	elif  '.jpg' in url: ext='.jpg'
	elif  '.gif' in url: ext='.gif'
	elif  '.bmp' in url: ext='.bmp'
	elif '.jpeg' in url: ext='.jpeg'
	elif  '.mp4' in url: ext='.mp4' #Videos
	elif '.mpeg' in url: ext='.mpeg'
	elif  '.avi' in url: ext='.avi'
	elif  '.flv' in url: ext='.flv'
	elif  '.wmv' in url: ext='.wmv'
	elif  '.3gp' in url: ext='.3gp'
	elif  '.mp3' in url: ext='.mp3' #others
	elif  '.txt' in url: ext='.txt'
	elif  '.xml' in url: ext='.xml'
	#else: 							 ext='.flv' #Default File Extention ('.flv')
	return ext



## ### ## 
def refresh_meta(video_type,old_title,imdb,alt_id,year,new_title=''):
	try: from metahandler import metahandlers
	except: return
	__metaget__=metahandlers.MetaData()
	if new_title: search_title=new_title
	else: search_title=old_title
	if video_type=='tvshow':
		api=metahandlers.TheTVDB(); results=api.get_matching_shows(search_title); search_meta=[]
		for item in results: option={'tvdb_id':item[0],'title':item[1],'imdb_id':item[2],'year':year}; search_meta.append(option)
	else: search_meta=__metaget__.search_movies(search_title)
	debob(search_meta); #deb('search_meta',search_meta); 
	option_list=['Manual Search...']
	for option in search_meta:
		if 'year' in option: disptitle='%s (%s)' % (option['title'],option['year'])
		else: disptitle=option['title']
		option_list.append(disptitle)
	dialog=xbmcgui.Dialog(); index=dialog.select('Choose',option_list)
	if index==0: refresh_meta_manual(video_type,old_title,imdb,alt_id,year)
	elif index > -1:
		new_imdb_id=search_meta[index-1]['imdb_id']
		#Temporary workaround for metahandlers problem:
		#Error attempting to delete from cache table: no such column: year
		if video_type=='tvshow': year=''
		try: _1CH.log(search_meta[index-1])
		except: pass
		__metaget__.update_meta(video_type,old_title,imdb,year=year); xbmc.executebuiltin('Container.Refresh')
def refresh_meta_manual(video_type,old_title,imdb,alt_id,year):
	keyboard=xbmc.Keyboard()
	if year: disptitle='%s (%s)' % (old_title,year)
	else: disptitle=old_title
	keyboard.setHeading('Enter a title'); keyboard.setDefault(disptitle); keyboard.doModal()
	if keyboard.isConfirmed():
		search_string=keyboard.getText()
		refresh_meta(video_type,old_title,imdb,alt_id,year,search_string)

## ### ## SQL
try:    from sqlite3   import dbapi2 as orm; dbMethod="sqlite3";   deb("SQL Method","sqlite3"); 
except: 
	try:	from pysqlite2 import dbapi2 as orm; dbMethod="pysqlite2"; deb("SQL Method","pysqlite2"); 
	except: dbMethod=""; deb("SQL Method","not found"); 
DB_DIR=xbmc.translatePath(os.path.join('special://database',ps('db filename')+'.db')); 
CorrectValueForInitDatabase="4"; 
def database_init():
	try:
		if len(dbMethod)==0: return
		deb('Building Database',DB_DIR); s=[]; db=orm.connect(DB_DIR); 
		s.append('CREATE TABLE IF NOT EXISTS shows (url VARCHAR(255) UNIQUE, title TEXT, year VARCHAR(10), img TEXT, fanart TEXT, imdbnum TEXT, plot BLOB, timestampyear TEXT, timestampmonth TEXT, timestampday TEXT, visited BOOLEAN, isfav TEXT, fav1 BOOLEAN, fav2 BOOLEAN, fav3 BOOLEAN, fav4 BOOLEAN, showid VARCHAR(10))')
		s.append('CREATE TABLE IF NOT EXISTS watched (url VARCHAR(255) UNIQUE, title TEXT, episode TEXT, timestampyear TEXT, timestampmonth TEXT, timestampday TEXT)')
		s.append('CREATE TABLE IF NOT EXISTS visited (url VARCHAR(255) UNIQUE, title TEXT, episode TEXT, timestampyear TEXT, timestampmonth TEXT, timestampday TEXT, img TEXT, fanart TEXT)')
		s.append('CREATE TABLE IF NOT EXISTS favs1 (url VARCHAR(255) UNIQUE)')
		s.append('CREATE TABLE IF NOT EXISTS favs2 (url VARCHAR(255) UNIQUE)')
		s.append('CREATE TABLE IF NOT EXISTS favs3 (url VARCHAR(255) UNIQUE)')
		s.append('CREATE TABLE IF NOT EXISTS favs4 (url VARCHAR(255) UNIQUE)')
		s.append('CREATE TABLE IF NOT EXISTS mylist (id VARCHAR(10) UNIQUE, title TEXT)')
		#s.append('ALTER TABLE shows ADD showid VARCHAR(10)')
		for t in s:
			try:
				deb("db command",t); 
				db.execute(t); 
			except: pass
		#
	except: pass
	try:
		db.commit(); db.close(); 
	except: pass
	setts("init_database",CorrectValueForInitDatabase); 
def database_CheckDB():
	if os.path.isfile(DB_DIR)==True: 
		debob(["Database File Found",DB_DIR]); 
		if not settg("init_database")==CorrectValueForInitDatabase:
			try: database_init(); 
			except: pass
	else: 
		debob("Unable to locate Database File"); 
		try: database_init(); 
		except: pass
def database_do_test(CoMMaNDS):
	#try:
		db=orm.connect(DB_DIR); 
		for t in CoMMaNDS:
			#try:
				db.execute(t)
			#except: pass
	#except: pass
	#try:
		db.commit(); db.close(); 
	#except: pass
def database_do(CoMMaNDS):
	try:
		db=orm.connect(DB_DIR); 
		for t in CoMMaNDS:
			try:
				db.execute(t)
			except: pass
	except: pass
	try: db.commit(); db.close(); 
	except: pass
def database_do2(CoMMaNDS): # [ ["",(..., ..., ...)],["",""] ]
	try:
		db=orm.connect(DB_DIR); 
		for t,s in CoMMaNDS:
			try:
				db.execute(t.replace('?','%s'),s)
			except: pass
	except: pass
	try: db.commit(); db.close(); 
	except: pass
##sql = 'INSERT INTO subscriptions (url, title, img, year, imdbnum, day) VALUES (?,?,?,?,?,?)' 
##sql = 'INSERT INTO subscriptions (url, title, img, year, imdbnum) VALUES (?,?,?,?,?)'
## "INSERT INTO (url,title,episode,timestamp) VALUES (?,?,?,?)"
## do_database2("INSERT INTO visited (url,title,episode,timestamp,img,fanart) VALUES (?,?,?,?,?,?)",())
## 
def database_get_all(CoMMaND):
	try:
		db=orm.connect(DB_DIR); 
		db.execute(CoMMaND)
		results=db.execute(CoMMaND).fetchall()
	except: pass
	try:
		#db.commit(); 
		db.close(); 
		try:
			if not result: return []
			if result==None: return []
		except: pass
		return results
	except: return []
def database_get_1st(CoMMaND):
	try:
		db=orm.connect(DB_DIR); 
		result=db.execute(CoMMaND).fetchone()
	except: pass
	try:
		#db.commit(); 
		db.close(); 
		try:
			if not result: return []
			if result==None: return []
		except: pass
		return result
	except: return []
def database_get_1st_s(CoMMaND):
	try:
		db=orm.connect(DB_DIR); 
		result=db.execute(CoMMaND).fetchone()
	except: pass
	try:
		#db.commit(); 
		db.close(); 
		try:
			if not result: return ""
			if result==None: return ""
		except: pass
		return result
	except: return ""
#def unCacheAnImage(url):
#	if os.path.isfile(DB_DIR)==True: 
#		db=orm.connect(DB_DIR); 
#		#g='Select cachedurl FROM texture WHERE url = "'+url+'";'; print g; 
#		#a=db.execute(g); print str(a); 
#		s='DELETE FROM texture WHERE url = "'+url+'";'; print s; 
#		db.execute(s); 
#		db.commit(); db.close(); 




## ### ## 
def showurl(name,url,scr=ps('icon'),imgfan=ps('fanart'),type2=0,mode=0):
	#copy_to_clipboard(url)
	debob([url,name,scr,imgfan])
	kmsg=showkeyboard(url,name)
def CleanFilename(filename):
	#filename=_1CH.unescape(filename)
	return re.sub('[/:"*?<>|]+', ' ', filename)
#class TextBox_FromFile:
#	WINDOW=10147; CONTROL_LABEL=1; CONTROL_TEXTBOX=5; # constants
#	def __init__(self,*args,**kwargs):
#		xbmc.executebuiltin("ActivateWindow(%d)"%(self.WINDOW, ))				# activate the text viewer window
#		self.win=xbmcgui.Window(self.WINDOW)															# get window
#		xbmc.sleep(1000)																										# give window time to initialize
#		self.setControls()
#	def setControls(self,txtFilepath=__home__,txtFilename='changelog.txt'):
#		HeaderMsg="%s - ( v%s )"%(__plugin__,addon.get_version())										# set heading
#		self.win.getControl(self.CONTROL_LABEL).setLabel(HeaderMsg)
#		#root=addon.get_path()																							# set text
#		txt_path=os.path.join(txtFilepath,txtFilename)
#		#txt_path=os.path.join(__home__,'news.txt')
#		f=open(txt_path)
#		text=f.read()
#		self.win.getControl(self.CONTROL_TEXTBOX).setText(text)
#class TextBox_FromUrl: ## Usage Example: TextBox_FromUrl().load('https://raw.github.com/HIGHWAY99/plugin.video.theanimehighway/master/README.md')
#	WINDOW 						=	10147; CONTROL_LABEL 		=	1; CONTROL_TEXTBOX 	=	5; HEADER_MESSAGE		=	"%s - ( v%s )" % (__plugin__,addon.get_version())										# set heading
#	def load(self, URL_PATH, HEADER_MESSAGE2=''):
#		if (HEADER_MESSAGE2==''): HEADER_MESSAGE2=self.HEADER_MESSAGE
#		print 'text window from url: ',URL_PATH #self.URL_PATH
#		try: 			text=getURL(URL_PATH)#(self.URL_PATH)
#		except: 	text=''
#		xbmc.executebuiltin("ActivateWindow(%d)"%(self.WINDOW, ))				# activate the text viewer window
#		self.win=xbmcgui.Window(self.WINDOW)															# get window
#		xbmc.sleep(500)																											# give window time to initialize
#		self.win.getControl(self.CONTROL_LABEL).setLabel(HEADER_MESSAGE2)
#		self.win.getControl(self.CONTROL_TEXTBOX).setText(text)
#class TextBox2: ## Usage Example: TextBox_FromUrl().load('https://raw.github.com/HIGHWAY99/plugin.video.theanimehighway/master/README.md')
#	WINDOW 						=	10147
#	CONTROL_LABEL 		=	1
#	CONTROL_TEXTBOX 	=	5
#	HEADER_MESSAGE		=	"%s - ( v%s )" % (__plugin__,addon.get_version())										# set heading
#	def load_url(self, URL_PATH, HEADER_MESSAGE2=''):
#		if (debugging==True): print 'text window from url: ',URL_PATH #self.URL_PATH
#		try: 			text=getURL(URL_PATH)#(self.URL_PATH)
#		except: 	text=''
#		self.load_window()
#		self.set_header(HEADER_MESSAGE2)
#		self.set_text(text)
#	def load_file(self, FILE_NAME='changelog.txt', HEADER_MESSAGE2='', FILE_PATH=__home__):
#		txt_path = os.path.join(FILE_PATH,FILE_NAME)
#		if (debugging==True): print 'text window from file: ',txt_path
#		f = open(txt_path)
#		text = f.read()
#		self.load_window()
#		self.set_header(HEADER_MESSAGE2)
#		self.set_text(text)
#	def load_string(self, text_string='', HEADER_MESSAGE2=''):
#		self.load_window()
#		self.set_header(HEADER_MESSAGE2)
#		self.set_text(text_string)
#	def load_window(self, sleeptime=500):
#		xbmc.executebuiltin("ActivateWindow(%d)" % ( self.WINDOW, ))				# activate the text viewer window
#		self.win = xbmcgui.Window(self.WINDOW)															# get window
#		xbmc.sleep(sleeptime)																											# give window time to initialize
#	def set_header(self, HEADER_MESSAGE2=''):
#		if (HEADER_MESSAGE2==''): HEADER_MESSAGE2=self.HEADER_MESSAGE
#		self.win.getControl(self.CONTROL_LABEL).setLabel(HEADER_MESSAGE2)
#	def set_text(self, text=''):
#		self.win.getControl(self.CONTROL_TEXTBOX).setText(text)
#def checkImgUrl(img):
#	img=xbmc.translatePath(img)#; deb('Local Image',img)
#	if (check_ifUrl_isHTML(img)==True): return img
#	else: return ''
def checkImgLocal(img):
	img=xbmc.translatePath(img)#; deb('Local Image',img)
	if (os.path.isfile(img)): return img
	else: return ''
#def Library_SaveTo_Movies(url,iconimage,name,year):
#  library=xbmc.translatePath(_addon.get_profile())
#  foldername=xbmc.translatePath(os.path.join(library, 'Movies'))
#  if os.path.exists(foldername)==False: os.mkdir(os.path.join(library, 'Movies'))
#  strm='%s?mode=%s&section=%s&url=%s&iconimage=%s&title=%s&showtitle=%s&year=%s&showyear=%s'% (sys.argv[0],'PlayLibrary',ps('section.movie'),urllib.quote_plus(url),urllib.quote_plus(iconimage),urllib.quote_plus(name),urllib.quote_plus(name),year,year)
#  filename=name+'  ('+year+')'
#  filename=clean_filename(filename+'.strm')
#  file    =xbmc.translatePath(os.path.join(foldername,filename))
#  ##print file
#  a=open(file, "w"); a.write(strm); a.close()
#  myNote('Library Movie:',filename)
#def Library_SaveTo_Episode(url,iconimage,name,year,country,season_number,episode_number,episode_title):
#  library=xbmc.translatePath(_addon.get_profile())
#  foldermain=xbmc.translatePath(os.path.join(library, 'TV'))
#  if os.path.exists(foldermain)==False: os.mkdir(foldermain)
#  foldername=xbmc.translatePath(os.path.join(foldermain,name+'  ('+year+')'))
#  if os.path.exists(foldername)==False: os.mkdir(foldername)
#  folderseason=xbmc.translatePath(os.path.join(foldername, 'Season '+season_number))
#  if os.path.exists(folderseason)==False: os.mkdir(folderseason)
#  strm='%s?mode=%s&section=%s&url=%s&iconimage=%s&title=%s&showtitle=%s&year=%s&showyear=%s&country=%s&season=%s&episode=%s&episodetitle=%s'% (sys.argv[0],'PlayLibrary',ps('section.tv'),urllib.quote_plus(url),urllib.quote_plus(iconimage),urllib.quote_plus(name),urllib.quote_plus(name),year,year,country,season_number,episode_number,episode_title)
#  #
#  #
#  filename=name+'  ('+year+')  S'+season_number+'E'+episode_number
#  filename=clean_filename(filename+'.strm')
#  file    =xbmc.translatePath(os.path.join(folderseason,filename))
#  ##print file
#  a=open(file, "w"); a.write(strm); a.close()
#  myNote('Library TV:',filename)
#def twitter_timeline(person): HTML=getURL('http://mobile.twitter.com/'+person) ### HTML=getURL('http://twitter.com/'+person)


## ### ## 
def CleanupLabelFormatting(t): 
	try: return t.replace('[COLOR ]@[/COLOR]','').replace('[COLOR ]*[/COLOR]','').replace('[COLOR ][][/COLOR]','').replace('][][/COLOR]','][/COLOR]').replace('[COLOR ][/COLOR]','').replace('     ','  ').replace('    ','  ').replace('   ','  ').strip()
	except: return t
def DoEpisodesLabelFormatting(LabelFormat='',DefaultT='',LInfo='',Title='',name='',animename='',animetype='',labs={},pars={}):
	try:
		UseLabelFormat=tfalse(settg("use-episodes-labels-formatting","false"))
		if UseLabelFormat==False: return DefaultT
		else:
			#debob(['LabelFormat',LabelFormat,'DefaultT',DefaultT,'LInfo',LInfo,'LInfo2',LInfo2,'imInfo',imInfo,'FoundItK',FoundItK,'Title',Title,'name',name,'animename',animename,'animetype',animetype,'labs',labs,'pars',pars])
			if len(LabelFormat)==0: LabelFormat=settg("text-series-labels-format","[COLOR %Watched%]@[/COLOR]  %EpisodeTitle%")
			if len(LabelFormat)==0: LabelFormat="[COLOR %Watched%]@[/COLOR]  %EpisodeTitle%"
			LInfo=str(LInfo); 
			
			
			## ### ## 
			NewTitle=CleanupLabelFormatting(NewTitle); return NewTitle
			## ### ## 
	except: return DefaultT
def DoSeriesLabelFormatting(LabelFormat='',DefaultT='',LInfo='',LInfo2='',imInfo='',FoundItK=False,Title='',name='',animename='',animetype='',labs={},pars={}):
	try:
		UseLabelFormat=tfalse(settg("use-series-labels-formatting","false"))
		if UseLabelFormat==False: return DefaultT
		else:
			debob(['LabelFormat',LabelFormat,'DefaultT',DefaultT,'LInfo',LInfo,'LInfo2',LInfo2,'imInfo',imInfo,'FoundItK',FoundItK,'Title',Title,'name',name,'animename',animename,'animetype',animetype,'labs',labs,'pars',pars])
			if len(LabelFormat)==0: LabelFormat=settg("text-series-labels-format","[COLOR %Watched%]@[/COLOR]  %SeriesTitle%")
			if len(LabelFormat)==0: LabelFormat="[COLOR %Watched%]@[/COLOR]  %SeriesTitle%"
			LInfo=str(LInfo); imInfo=str(imInfo); LInfo2=str(LInfo2); 
			if FoundItK==True: clrWatched='deeppink'
			else: clrWatched='black'
			if '/Content/images/hot.png' in imInfo: txtHot=' [COLOR fuchsia][[I]HOT [/I]][/COLOR]'
			else: txtHot=''
			if   ('</a>' in LInfo): 
				try: (LatestUrl,LatestName,LatestNumber)=re.compile('<a href="(/'+ps('common_word')+'/.+?)">\s*(.+?(\d*))\s*</a>').findall(nolines(LInfo))[0]; LatestUrl=ps('domain')+LatestUrl
				except: (LatestUrl,LatestName,LatestNumber)=('','','')
			elif ('</a>' in LInfo2): 
				try: (LatestUrl,LatestName,LatestNumber)=re.compile('<a href="(/'+ps('common_word')+'/.+?)">\s*(.+?(\d*))\s*</a>').findall(nolines(LInfo2))[0]; LatestUrl=ps('domain')+LatestUrl
 				except: (LatestUrl,LatestName,LatestNumber)=('','','')
			else: (LatestUrl,LatestName,LatestNumber)=('','','')
			if (LInfo=='Not yet aired'): clrLInfo='red'; LeftItNow=settg("text-not-yet-aired","[COLOR red]*[/COLOR]")
			elif (LInfo=='Completed'): clrLInfo='lime'; LeftItNow=settg("text-is-completed","[COLOR lime]*[/COLOR]")
			elif ('</a>' in LInfo): clrLInfo='cornflowerblue'; LeftItNow=settg("text-has-latest-episode","[COLOR cornflowerblue]*[/COLOR]").replace('%LatestName%',LatestName).replace('%LatestNumber%',LatestNumber)
			else: clrLInfo=''; LeftItNow=''
			try:		
							Year1,Year2=re.compile('(\s*\((\d\d\d\d)\))').findall(name)[0]; 
							Year=' [COLOR %s](%s)[/COLOR]'%('mediumpurple',Year2)
			except:	Year=''; Year1=''; Year2=''; 
			animetype2=''
			if '2nd season' in name.lower(): 	animetype2+=' [COLOR %s][s2][/COLOR]'%ps('default color7')
			if '3rd season' in name.lower(): 	animetype2+=' [COLOR %s][s3][/COLOR]'%ps('default color7')
			if '4th season' in name.lower(): 	animetype2+=' [COLOR %s][s4][/COLOR]'%ps('default color7')
			if '(dub)' in name.lower(): 			animetype2+=' [COLOR green][DUB][/COLOR]'
			if '(sub)' in name.lower(): 			animetype2+=' [COLOR purple][SUB][/COLOR]'
			if '(tv)' in name.lower(): 				animetype2+=' [COLOR %s][TV][/COLOR]'%ps('default color7')
			if '(movie)' in name.lower(): 		animetype2+=' [COLOR %s][Movie][/COLOR]'%ps('default color8')
			if '(ova)' in name.lower(): 			animetype2+=' [COLOR pink][OVA][/COLOR]'
			if '(special)' in name.lower(): 	animetype2+=' [COLOR red][Special][/COLOR]'
			#elif '' in name.lower(): animetype2=' [COLOR ][][/COLOR]'; 
			#elif '' in name.lower(): animetype2=' [COLOR ][][/COLOR]'; 
			#elif '' in name.lower(): animetype2=' [COLOR ][][/COLOR]'; 
			#elif '' in name.lower(): animetype2=' [COLOR ][][/COLOR]'; 
			
			## ### ## 
			if '%Year%' in LabelFormat: Title=Title.replace(Year1,'')
			NewTitle=(''+LabelFormat+'').replace('%SeriesTitle%',Title).replace('%Watched%',clrWatched).replace('%Hot%',txtHot).replace('%LInfo%',clrLInfo)
			NewTitle=NewTitle.replace('%Name%',name)
			NewTitle=NewTitle.replace('%AnimeName%',animename)
			NewTitle=NewTitle.replace('%Year%',Year)
			if animetype.lower()=='tvshow':clrAnimeType='cornflowerblue'; txtAnimeType='Series'
			else: clrAnimeType='maroon'; txtAnimeType='Movie'
			NewTitle=NewTitle.replace('%AnimeType%',animetype)
			NewTitle=NewTitle.replace('%AnimeType2%',animetype2)
			NewTitle=NewTitle.replace('%AnimeTypeText%',txtAnimeType)
			NewTitle=NewTitle.replace('%AnimeTypeColor%',clrAnimeType)
			if len(LatestName) > 0 and ('%LatestName%' in NewTitle):
					NewTitle=NewTitle.replace('%LatestEpisodeColor%','cornflowerblue')
			elif (len(LatestNumber) > 0) and ('%LatestNumber%' in NewTitle):
					NewTitle=NewTitle.replace('%LatestEpisodeColor%','cornflowerblue')
			NewTitle=NewTitle.replace('%LatestName%',LatestName)
			NewTitle=NewTitle.replace('%LatestNumber%',LatestNumber)
			if (len(LatestName)==0) and (len(LatestNumber)==0):
					NewTitle=NewTitle.replace('[COLOR %LatestEpisodeColor%][/COLOR] ','')
					NewTitle=NewTitle.replace(' [COLOR %LatestEpisodeColor%][/COLOR]','')
					NewTitle=NewTitle.replace('[COLOR %LatestEpisodeColor%][/COLOR]','')
					NewTitle=NewTitle.replace('%LatestEpisodeColor%','')
			elif (not '%LatestName%' in NewTitle) and (not '%LatestNumber%' in NewTitle):
					NewTitle=NewTitle.replace('[COLOR %LatestEpisodeColor%][/COLOR] ','')
					NewTitle=NewTitle.replace(' [COLOR %LatestEpisodeColor%][/COLOR]','')
					NewTitle=NewTitle.replace('[COLOR %LatestEpisodeColor%][/COLOR]','')
					NewTitle=NewTitle.replace('%LatestEpisodeColor%','')
			## ### ## 
			NewTitle=CleanupLabelFormatting(NewTitle)
			return NewTitle
			## ### ## 
	except: return DefaultT
## ### ## 
def getGitMsg(user="HIGHWAY99",project="repository.thehighway"):
	#https://api.github.com/repos/HIGHWAY99/repository.thehighway/commits?per_page=1&sha=master
	html=nolines(nURL('https://api.github.com/repos/'+user+'/'+project+'/commits?per_page=1&sha=master')); r={}; 
	r['sha']=re.compile('"sha":\s*"([0-9a-z]+)"').findall(html)[0]; 
	r['date']=re.compile('"date":\s*"(\d\d\d\d-\d\d-\d\dT\d\d:\d\d:\d\d\D)"').findall(html)[0]; 
	r['message']=re.compile('"message":\s*"(.+?)"').findall(html)[0]; 
	r['user']=re.compile('"author":\s*{\s*"name":\s*"([0-9a-zA-Z\-_]+)"').findall(html)[0]; 
	#r['']=re.compile('').findall(html)[0]; 
	debob(r); 
	return r
def checkGitMsg(GitData={},LastData={},s1='git-'):
	if len(GitData)==0: GitData=getGitMsg()
	debob("Checking GitMsg information."); s='sha'; LastData[s]=settg(s1+s,''); s='date'; LastData[s]=settg(s1+s,''); s='message'; LastData[s]=settg(s1+s,''); s='user'; LastData[s]=settg(s1+s,''); s='last'; LastData[s]=settg(s1+s,''); debob(GitData); debob(LastData); 
	CurDate=time.strftime("%Y-%m-%d"); s='last'; setts(s1+s,CurDate); 
	if not GitData['date']==LastData['date']:
		if not GitData['message']==LastData['message']:
			if not GitData['message']=='-': 
				zz=['KA ','KissAnime ','Kiss Anime ','Anime ','HUB-HUG ','HUBHUG ','HUB HUG ']; zzz=0
				for z in zz:
					if (z==0) and (z.lower() in GitData['message'].lower()):
						z=z+1; myNote(header=""+GitData['user']+" [COLOR orange]"+GitData['date']+"[/COLOR]",msg=""+GitData['message']+"")
		s='sha'; setts(s1+s,GitData[s]); s='date'; setts(s1+s,GitData[s]); s='message'; setts(s1+s,GitData[s]); s='user'; setts(s1+s,GitData[s]); 
## ### ## 
def KALogin():
	CookieFile=ps('addon profile 1',ps('cookie filename')); 
	if isFile(CookieFile)==True: UseCookieFile=True
	else: UseCookieFile=False
	if (len(settg('username',''))==0) or (len(settg('password',''))==0) or (settgb('enable-accountinfo')==False): return False,''
	if (settgb('customproxy')==True) and (len(settg('proxy','')) > 9): Proxy=settg('proxy','')
	else: Proxy=''
	html=nURL(ps('domain')+'/Login',method='post',form_data={'username':settg('username',''),'password':settg('password',''),'chkRemember':'1'},headers={'Referer':ps('domain')},cookie_file=CookieFile,load_cookie=UseCookieFile,save_cookie=True)
	#temp_file=xbmc.translatePath(os.path.join(addonPath,'temp.html.login.txt'))
	#if (debugging==True) and (_testing==True):
	#	try: _SaveFile(temp_file,html)
	#	except: pass
	if len(html) > 20: return True,html
	#return True
	return False,html


## ### ## 
def getURLr(url,dReferer,d=''):
	try:
		req=urllib2.Request(url,dReferer)
		req.add_header('User-Agent',ps('user-agent')) 
		req.add_header('Referer',dReferer)
		response=urllib2.urlopen(req)
		link=response.read(); response.close(); return(link)
	except: return d
def getURL(url,d=''):
	try:
		req=urllib2.Request(url)
		req.add_header('User-Agent',ps('user-agent')) 
		response=urllib2.urlopen(req)
		link=response.read(); response.close(); return(link)
	except: return d
def postURL(url,postStr,d=''):
	try:
		postData=urllib.urlencode(postStr)
		req=urllib2.Request(url,postData)
		req.add_header('User-Agent',ps('user-agent')) 
		response=urllib2.urlopen(req)
		link=response.read(); response.close(); return(link)
	except: return d
## ### ## 
def AFColoring(t): 
	if len(t)==0: return t
	elif len(t)==1: return cFL(t,'firebrick')
	else: return cFL(cFL_(t,'firebrick'),'mediumpurple')
ww6='[COLOR black]@[/COLOR]'; 
ww7='[COLOR mediumpurple]@[/COLOR]'; 
def wwA(t,ww): #for Watched State Display
	if   ww==7: t=ww7+t
	elif ww==6: t=ww6+t
	return t


## ### ## 
def CheckAcount(html):
	html=nolines(html).replace('&nbsp;',' ')
	try: actUserName=re.compile('<span style=".*?">Hi</span>\s*<a id="aDropDown" class="boxDropDown" style=".*?"><span>\s*(.+?)\s*\(\!\)\s*<').findall(html)[0].strip()
	except: actUserName=''
	if len(actUserName) > 0: LoggedIn=True
	else: LoggedIn=False
	return LoggedIn,actUserName
def GetKPoints(html):
	try:		actKPoints=int(re.compile('<img src="http://kissanime.com/Content/images/kpoint.png"/>\s*KPoint:\s*(\d+)\s*</a>').findall(html.replace('&nbsp;',' '))[0].strip())
	except:	actKPoints=0
	return	actKPoints
def GetTotalAEs(html):
	try: html=nolines(html); r1,r2=re.compile('<p>\s*<span class="\D+">Total anime:</span> <b>\s*(\d+)\s*</b>\s*<br/>\s*<span class="\D+">Total episodes:</span> <b>\s*(\d+)\s*</b>\s*</p>').findall(html)[0]
	except: r1,r2=['','']
	return r1,r2


## ### ## 
def PlayURL(url):
	play=xbmc.Player(GetPlayerCore())
	try: addon.resolve_url(url)
	except: pass
	try: play.play(url)
	except: pass
#def PlayVideo(url,title='',studio='',img='',showtitle='',plot='',autoplay=False,pageUrl=''): #PlayVideo(url, infoLabels, listitem)
#	WhereAmI('@ PlayVideo -- Getting ID From:  %s' % url)
#	if (img==''): img=_artIcon
#	ShowTitle=addpr('showtitle'); epnameo=addpr('epnameo'); eptitle=addpr('title'); fimg=addpr('fanart'); 
#	if len(fimg)==0: fimg=addpr('fimg'); 
#	if len(fimg)==0: fimg=""+img; 
#	do_database(['INSERT OR REPLACE INTO visited (url,title,episode,timestampyear,timestampmonth,timestampday,img,fanart) VALUES ("%s","%s","%s","%s","%s","%s","%s","%s")' % (  url,ShowTitle,epnameo,str(datetime.date.today().year),str(datetime.date.today().month),str(datetime.date.today().day),img,fimg  )])
#	try: visited_add(studio); visited_add(title)
#	except: pass
#	infoLabels={"studio":studio,"ShowTitle":showtitle,"Title":title,"Plot":plot}; debob(infoLabels); 
#	if autoplay==True:
#		addon.addon.setSetting(id="LastAutoPlayItemUrl", value=url)
#		addon.addon.setSetting(id="LastAutoPlayItemName", value=title)
#		addon.addon.setSetting(id="LastAutoPlayItemImg", value=img)
#		addon.addon.setSetting(id="LastAutoPlayItemStudio", value=studio)
#	else:
#		addon.addon.setSetting(id="LastVideoPlayItemUrl", value=url)
#		addon.addon.setSetting(id="LastVideoPlayItemName", value=title)
#		addon.addon.setSetting(id="LastVideoPlayItemImg", value=img)
#		addon.addon.setSetting(id="LastVideoPlayItemStudio", value=studio)
#	if (autoplay==False): eod()
#	## ### ## 
#	deb('Device Option',sDevice); 
#	if sDevice=="OUYA(Gotham)": debob("Using Alternative Play Method for "+str(sDevice)); PlayURL(url); return
#	## ### ## 
#	li=xbmcgui.ListItem(title,iconImage=img,thumbnailImage=img)
#	li.setInfo(type="Video", infoLabels=infoLabels ); li.setProperty('IsPlayable', 'true')
#	play=xbmc.Player(GetPlayerCore()) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
#	url2=url
#	deb('url2',url2)
#	try:
#		play.play(url2, li); 
#		xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
#	except: pass


## ### ## 
def ListAdvertisements(html="",pageUrl="",url=""):
	html=nolines(html)
	try:    Advertisements=re.compile('<div id="divFloat((?:Left|Right)?)" style="position: absolute; visibility:visible">\s*<a target="_blank" href="(\D+://.+?)">\s*<img border="0" src="(\D+://kissanime.com/ads/.+?)"/>\s*</a>\s*</div').findall(html.replace('</div>','</div\n\r\a>')); ### , re.MULTILINE | re.IGNORECASE | re.DOTALL
	except: Advertisements=[]
	deb("Number of Advertisements",str(len(Advertisements))); 
	## ### ## 
	#deb("Number of Advertisements*",str(len(Advertisements))); #debob(html); 
	if len(Advertisements) > 0:
		for AdvertisementName,AdvertisementUrl,AdvertisementImage in Advertisements:
			try: cfg.cAddon.add_directory({'mode':'BrowseUrl','url':AdvertisementUrl},{'title':"Advertisement [ [I]"+AdvertisementName+"[/I] ]"}, img=AdvertisementImage)
			except: pass
			try:
				if not pageUrl: pageUrl=url
				if len(pageUrl)==0: pageUrl=url
				if len(pageUrl)==0: pageUrl=_domain_url
				if isFile(cookie_file)==True: 
					html=nURL(AdvertisementImage,headers={'Referer':pageUrl},proxy=Proxy,cookie_file=cookie_file,load_cookie=True,save_cookie=True)
					html=nURL(AdvertisementUrl,headers={'Referer':pageUrl},proxy=Proxy,cookie_file=cookie_file,load_cookie=True,save_cookie=True)
				else: 
					html=nURL(AdvertisementImage,headers={'Referer':pageUrl},proxy=Proxy,cookie_file=cookie_file,save_cookie=True)
					html=nURL(AdvertisementUrl,headers={'Referer':pageUrl},proxy=Proxy,cookie_file=cookie_file,save_cookie=True)
			except: pass
	## ### ## 



## ### ## 

### # ## ### ## 



### ############################################################################################################
### ############################################################################################################








### ############################################################################################################
### ############################################################################################################