### ############################################################################################################
### ############################################################################################################
### # ## ### ## Imports ## ### ## 
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,urllib,urllib2,re,os,sys,htmllib,string,StringIO,logging,random,array,time,datetime,HTMLParser,htmlentitydefs
try: import copy
except: pass
### # ## ### ## My Common Functions ## ### ## 
## ### ## Object Type Stuff
def tfalse(r,d=False): ## Get True / False
	try:
		r=str(r).lower()
		if   r in ['true' ,'t','y','1','all' ,'yes']: return True
		elif r in ['false','f','n','0','none','no' ]: return False
		elif (r=='true' ) or (r=='t') or (r=='y') or (r=='1') or (r=='yes'): return True
		elif (r=='false') or (r=='f') or (r=='n') or (r=='0') or (r=='no'): return False
		else: return d
	except: return d
## ### ## Text Coding
def nolines(t):
	it=t.splitlines(); t=''
	for L in it: t=t+L
	t=((t.replace("\r","")).replace("\n","").replace("\a",""))
	return t
def TextCode(t,c):
	try: return '[%s]%s[/%s]'%(str(c).upper(),str(t),str(c).upper())
	except: return t
def iFL(t): return TextCode(t,'I') # Text - Italics
def bFL(t): return TextCode(t,'B') # Text - Bold
def sFL(t,c,e=''): ### For Custom Text Tags ###
	if (e==''): d=''
	else: d=' '+e
	return '['+c.upper()+d+']'+t+'[/'+c.upper()+']'
def ParseDescription(plot,Fixers=[]):
	#try:
		F=Fixers
		F.append(['&amp;','&'])
		F.append(['&nbsp;',' '])
		F.append(['&rsquo;',"'"])
		if ('&#' in plot) and (';' in plot):
			F.append(['&#8211;','-'])
			F.append(['&#8216;',"'"])
			F.append(['&#8217;',"'"])
			F.append(['&#8220;','"'])
			F.append(['&#8221;','"'])
			F.append(['&#215;','x'])
			F.append(['&#x27;',"'"])
			F.append(['&#xF4;','o'])
			F.append(['&#xb7;','-'])
			F.append(['&#xFB;','u'])
			F.append(['&#xE0;','a'])
			F.append(['&#0421;',''])
			F.append(['&#xE9;','e'])
			F.append(['&#xE2;','a'])
			F.append(['&#038;','&'])
		#F.append(['&#;',''])
		#F.append(['',''])
		for F1,F2 in F: plot.replace(F1,F2)
		if ('&#' in plot) and (';' in plot):
			try:		matches=re.compile('&#(.+?);').findall(plot)
			except:	matches=''
			if (not len(matches)==0):
				for match in matches:
					if (not len(match)==0) and (not match==' ') and ("&#"+match+";" in plot):
						try: plot=plot.replace("&#"+match+";" ,"")
						except: pass
		for i in xrange(127,256):
			try: plot=plot.replace(chr(i),"")
			except: pass
		return plot
	#except: return plot
def unescape_(s): p=htmllib.HTMLParser(None); p.save_bgn(); p.feed(s); return p.save_end()
def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
def filename_filter_out_year(name=''):
	years=re.compile(' \((\d+)\)').findall('__'+name+'__')
	for year in years:
		name=name.replace(' ('+year+')','')
	name=name.strip()
	return name

## ### ## File / Folder / Path
def TP(s): return xbmc.translatePath(s)
def TPj2(s1,s2): return xbmc.translatePath(os.path.join(s1,s2))
def TPj3(s1,s2,s3): return xbmc.translatePath(os.path.join(s1,s2,s3))
def TPj4(s1,s2,s4): return xbmc.translatePath(os.path.join(s1,s2,s3,s4))
def FileOpen(path,Default=''):
	if os.path.isfile(path): file=open(path,'r'); contents=file.read(); file.close(); return contents ## File found.
	else: return Default ## File not found.
def FileSave(path,data): file=open(path,'w'); file.write(data); file.close()
def DirMake(path):
	path=xbmc.translatePath(path.strip())
	if not os.path.exists(path): os.makedirs(path)
def isPath(path): return os.path.exists(path)
def isFile(filename): return os.path.isfile(filename)
def getFileExtension(filename):
	try:
		ext_pos=filename.rfind('.')
		if ext_pos != -1: return filename[ext_pos+1:]
		else: return ''
	except: return ''
def getImmediateSubDirectories(directory): return [name for name in os.listdir(directory) if os.path.isdir(os.path.join(directory,name))]
def getDir(mypath,dirname): #...creates sub-directories if they are not found.
	subpath=os.path.join(mypath,dirname)
	if not os.path.exists(subpath): os.makedirs(subpath)
	return subpath
def CopyAFile(tFrom,tTo):
	try:
		import shutil
		shutil.copy(tFrom,tTo)
	except: pass

## ### ## On-Screen Folder View Lists
def aSortMeth(sM,h=int(sys.argv[1])):
	xbmcplugin.addSortMethod(handle=h, sortMethod=sM)
def sContent(content='none',h=int(sys.argv[1])):
	if (not str(content).lower()=='none') and (not len(str(content))==0): xbmcplugin.setContent(h,str(content))
def RefreshList(): xbmc.executebuiltin("XBMC.Container.Refresh")
def XBMC_RunPlugin(plugId,plugParams,plugFile=''): xbmc.executebuiltin("XBMC.RunPlugin(plugin://%s/%s?%s)"%(plugId,plugFile,plugParams) )
def XBMC_ContainerUpdate(plugId,plugParams,plugFile=''): xbmc.executebuiltin("XBMC.Container.Update(plugin://%s/%s?%s)"%(plugId,plugFile,plugParams) )
def sProperty(key,value,h=int(sys.argv[1])): xbmcplugin.setProperty(h,str(key),value)
def sResolvedUrl(li,succeeded=True,h=int(sys.argv[1])): xbmcplugin.setResolvedUrl(handle=h,succeeded=succeeded,listitem=li)
def sPluginCategory(category,h=int(sys.argv[1])): xbmcplugin.setPluginCategory(handle=h,category=category)
## ### ## Params
def get_params(paramstring=sys.argv[2],param=[]):
	if len(paramstring)>=2:
		params=sys.argv[2]; cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&'); param={}
		for i in range(len(pairsofparams)):
			splitparams={}; splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
	return param
## ### ## On-Screen Prompts and Dialogs
def notification(header="", message="", sleep=5000 ): xbmc.executebuiltin( "XBMC.Notification(%s,%s,%i)"%( header, message, sleep ) )
def askSelection(option_list=[],txtHeader=''):
	if (option_list==[]): return None #debob('askSelection() >> option_list is empty')
	dialogSelect=xbmcgui.Dialog();
	index=dialogSelect.select(txtHeader,option_list)
	return index
def showkeyboard(txtMessage="",txtHeader="",passwordField=False,Default=False):
	if str(txtMessage).lower()=='none': txtMessage=''
	keyboard=xbmc.Keyboard(txtMessage,txtHeader,passwordField)#("text to show","header text", True="password field"/False="show text")
	keyboard.doModal()
	if keyboard.isConfirmed(): return keyboard.getText()
	else: return Default #return False # return ''
def BusyAnimationShow(): 				xbmc.executebuiltin('ActivateWindow(busydialog)')
def BusyAnimationHide(): 				xbmc.executebuiltin('Dialog.Close(busydialog,true)')
def closeAllDialogs():   				xbmc.executebuiltin('Dialog.Close(all, true)') 
def popYN(title='',line1='',line2='',line3='',n='',y=''):
	diag=xbmcgui.Dialog()
	r=diag.yesno(title,line1,line2,line3,n,y)
	if r: return r
	else: return False
	#del diag
def popOK(msg="",title="",line2="",line3=""): dialog=xbmcgui.Dialog(); dialog.ok(title,msg,line2,line3)
## ### ## 
def get_xbmc_os():
	try: xbmc_os=os.environ.get('OS')
	except: xbmc_os="unknown"
	return xbmc_os
def get_xbmc_version():
	rev_re=re.compile('r(\d+)')
	try: xbmc_version=xbmc.getInfoLabel('System.BuildVersion')
	except: xbmc_version='Unknown'
	return xbmc_version
def get_xbmc_revision():
	rev_re=re.compile('r(\d+)')
	try: xbmc_version=xbmc.getInfoLabel('System.BuildVersion')
	except: xbmc_version='Unknown'
	try: xbmc_rev=int(rev_re.search(xbmc_version).group(1)); deb("addoncompat.py: XBMC Revision",xbmc_rev)
	except: xbmc_rev=0; deb("addoncompat.py: XBMC Revision not available - Version String",xbmc_version)
	return xbmc_rev

## ### ## HTML / URL
def QP(v): return urllib.quote_plus(v)

## ### ## 
def XBMC_RefreshRSS(): 					xbmc.executebuiltin("XBMC.RefreshRSS()")
def XBMC_EjectTray(): 					xbmc.executebuiltin("XBMC.EjectTray()")
def XBMC_Mute(): 								xbmc.executebuiltin("XBMC.Mute()")
def XBMC_System_Exec(url): 			xbmc.executebuiltin("XBMC.System.Exec(%s)"%url)
def XBMC_System_ExecWait(url): 	xbmc.executebuiltin("XBMC.System.ExecWait(%s)"%url)
def XBMC_PlayDVD(): 						xbmc.executebuiltin("XBMC.PlayDVD()")
def XBMC_ReloadSkin(): 					xbmc.executebuiltin("XBMC.ReloadSkin()")
def XBMC_UpdateAddonRepos(): 		xbmc.executebuiltin("XBMC.UpdateAddonRepos()")
def XBMC_UpdateLocalAddons(): 	xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
def XBMC_Weather_Refresh(): 		xbmc.executebuiltin("XBMC.Weather.Refresh()")
def XBMC_ToggleDebug(): 				xbmc.executebuiltin("XBMC.ToggleDebug()")
def XBMC_Minimize(): 						xbmc.executebuiltin("XBMC.Minimize()")
def XBMC_ActivateScreensaver(): xbmc.executebuiltin("XBMC.ActivateScreensaver()")
## ### ## 
def DoE(e): 								xbmc.executebuiltin(e)
def DoAW(e): 								xbmc.executebuiltin("ActivateWindow(%s)"%str(e))
def DoRW(e): 								xbmc.executebuiltin("ReplaceWindow(%s)"%str(e))
def DoRA(e): 								xbmc.executebuiltin("RunAddon(%s)"%str(e))
def DoRA2(e,e2="1",e3=""): 	xbmc.executebuiltin('RunAddon(%s,"%s","%s")'%(str(e),str(e2),e3)); 
def DoA(a): 								xbmc.executebuiltin("Action(%s)"%str(a))
def DoCM(a): 								xbmc.executebuiltin("Control.Message(windowid=%s)"%(str(a)))
def DoSC(a): 								xbmc.executebuiltin("SendClick(%s)"%(str(a)))
def DoSC2(a,Id): 						xbmc.executebuiltin("SendClick(%s,%s)"%(str(a),str(Id)))
def DoStopScript(e): 				xbmc.executebuiltin("StopScript(%s)"%str(e))
def DoTD(): 								xbmc.executebuiltin("ToggleDebug")

## ### ## 
def qp_get(n): ## Deals with errors in using None type within a urllib.quote_plus().
	#print n
	if (n==''): return ''
	elif (n==None): return ''
	else: return urllib.quote_plus(n)
def st_get(n): ## Deals with errors in using None type within a str().
	#print n
	if (n==None): return ''
	else: return str(n)
def format_eta(seconds):
	minutes,seconds=divmod(seconds,60)
	if minutes > 60:
		hours,minutes=divmod(minutes,60)
		return "ETA: %02d:%02d:%02d "%(hours,minutes,seconds)
	else:  return "ETA: %02d:%02d "%(minutes,seconds)
def format_time(seconds):
	minutes,seconds=divmod(seconds,60)
	if minutes > 60:
		hours,minutes=divmod(minutes,60)
		return "%02d:%02d:%02d"%(hours,minutes,seconds)
	else:  return "%02d:%02d"%(minutes,seconds)
def time2ms(Time):
	hour,minute,seconds=Time.split(';')[0].split(':')
	frame=int((float(Time.split(';')[1])/24)*1000)
	milliseconds=(((int(hour)*60*60)+(int(minute)*60)+int(seconds))*1000)+frame
	return milliseconds
def _convert_time(milliseconds):
	seconds=int(float(milliseconds)/1000)
	milliseconds-=(seconds*1000)
	hours=seconds/3600
	seconds-=3600*hours
	minutes=seconds/60
	seconds-=60*minutes
	return "%02d:%02d:%02d,%3d"%(hours,minutes,seconds,milliseconds)
## ### ## XBMC Functions
def getContainerFolderPath(): 	return xbmc.getInfoLabel('Container.FolderPath')
def getListItemPath(): 					return xbmc.getInfoLabel('ListItem.Path')
def getCurrentWindow(): 				return xbmc.getInfoLabel('System.CurrentWindow')
def getCurrentControl(): 				return xbmc.getInfoLabel('System.CurrentControl')
def getCurrentWindowXmlFile(): 	return xbmc.getInfoLabel('Window.Property(xmlfile)')
## ### ## Dialog Functions
def BusyAnimationShow(): 				xbmc.executebuiltin('ActivateWindow(busydialog)')
def BusyAnimationHide(): 				xbmc.executebuiltin('Dialog.Close(busydialog,true)')
def closeAllDialogs():   				xbmc.executebuiltin('Dialog.Close(all, true)') 
def BrowseForImage(title,ext='.jpg|.png|.gif|.jpeg|.bmp'): dialog=xbmcgui.Dialog(); image=dialog.browse(1,title,'pictures',ext,True); return image

## ### ## 

## ### ## 

## ### ## 

## ### ## 

## ### ## 

## ### ## 



### ############################################################################################################
### ############################################################################################################
