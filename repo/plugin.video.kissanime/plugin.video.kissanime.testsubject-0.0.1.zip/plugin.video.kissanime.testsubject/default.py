### ############################################################################################################
### ############################################################################################################
###	#	
### # Project: 			#		KissAnime.com - Addon by The Highway 2013-2014.
### # Author: 			#		The Highway
### # Version:			#		vX.X.X
### # Description: 	#		http://www.KissAnime.com
###	#	
### ############################################################################################################
### ############################################################################################################
### # ## ### ## Imports ## ### ## 
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,urllib,urllib2,re,os,sys,htmllib,string,StringIO,logging,random,array,time,datetime,HTMLParser,htmlentitydefs
try: import copy
except: pass
import common as Common
from common import *
#from common import (_addon,_artIcon,ps('fanart'),_addonPath)
import commonb as CommonB
from commonb import *
#from commonb import (_addon,_artIcon,ps('fanart'),_addonPath)
import graphicsfetcher as GraphicsFetcher
from graphicsfetcher import *
### # ## ### ## 
addon=cfg.cAddon; _addon=cfg.cAddon; 
### ############################################################################################################
### ############################################################################################################


### ############################################################################################################
### ############################################################################################################
def menu_Login():
	WhereAmI('@ %s'%(Mode))
	_T__F_,html=KALogin()
	#print [_T__F_,html]
	if _T__F_==True:	LoggedIn,actUserName=CheckAcount(nolines(html)); 
	else:							LoggedIn,actUserName=False,''
	if (_T__F_==True) and (LoggedIn==True):	
										addon.add_directory({'mode':''},{'title':cFL('Login: ',ps('default color2'))+cFL(''+actUserName,ps('default color1'))},fanart=ps('fanart'),img=psgn('img usersmall','.png'))
	elif (_T__F_==True) and ("<label class='error'>You have entered an invalid username or password</label>" in html):
										addon.add_directory({'mode':''},{'title':cFL('Login: ',ps('default color2'))+cFL('Invalid Username or Password',ps('default color3'))},fanart=ps('fanart'),img=psgn('img logout','.png'))
	elif _T__F_==True:	addon.add_directory({'mode':''},{'title':cFL('Login: ',ps('default color2'))+cFL('Failed*',ps('default color3'))},fanart=ps('fanart'),img=psgn('img logout','.png'))
	else:							addon.add_directory({'mode':''},{'title':cFL('Login: ',ps('default color2'))+cFL('Failed',ps('default color3'))},fanart=ps('fanart'),img=psgn('img logout','.png'))
	#if LoggedIn==True:	addon.add_directory({'mode':'','url':url,'page':str(page)},{'title':cFL('User: ',ps('default color2'))+cFL(actUserName,ps('default color1'))},fanart=ps('fanart'),img=psgn('img usersmall'))
	#else:								addon.add_directory({'mode':'','url':url,'page':str(page)},{'title':cFL('Logged Out',ps('default color3'))},fanart=ps('fanart'),img=psgn('warning'))
	actKPoints=GetKPoints(html)
	if int(actKPoints) > 0: addon.add_directory({'mode':''},{'title':cFL('KPoints: ',ps('default color2'))+cFL(''+str(actKPoints),ps('default color1'))},fanart=ps('fanart'),img=psgn('img kpoints','.png'))
	sCVE('list',settg('default-view',50)); 
def menu_Logout():
	WhereAmI('@ %s'%(Mode))
	if (settgb('customproxy')==True) and (len(settg('proxy')) > 9): Proxy=settg('proxy')
	else: Proxy=''
	CookieFile=ps('addon profile 1',ps('cookie filename')); 
	if isFile(CookieFile)==True: UseCookieFile=True
	else: UseCookieFile=False
	#_T__F_=KALogin()
	#if _T__F_==True:	addon.add_directory({'mode':'attemptlogin'},{'title':cFL('Login: ',ps('default color2'))+cFL('Sucessful',ps('default color1'))},fanart=ps('fanart'),img=psgn('img usersmall','.png'))
	#else:							addon.add_directory({'mode':'attemptlogin'},{'title':cFL('Login: ',ps('default color2'))+cFL('Failed',ps('default color3'))},fanart=ps('fanart'),img=psgn('warning','.png'))
	html=nolines(nURL(ps('domain')+'/Logout','get',headers={'Referer':ps('domain')},proxy=Proxy,cookie_file=CookieFile,load_cookie=UseCookieFile,save_cookie=True))
	LoggedIn,actUserName=CheckAcount(html); 
	if LoggedIn==True:	addon.add_directory({'mode':''},{'title':cFL('User: ',ps('default color2'))+cFL(actUserName,ps('default color1'))},fanart=ps('fanart'),img=psgn('img usersmall'))
	else:								addon.add_directory({'mode':''},{'title':cFL('Logged Out',ps('default color3'))},fanart=ps('fanart'),img=psgn('img logout'))
	actKPoints=GetKPoints(html)
	if int(actKPoints) > 0: addon.add_directory({'mode':''},{'title':cFL('KPoints: ',ps('default color2'))+cFL(''+str(actKPoints),ps('default color1'))},fanart=ps('fanart'),img=psgn('img kpoints','.png'))
	sCVE('list',settg('default-view',50)); 
### ############################################################################################################
### ############################################################################################################
def SearchDO(title):
	WhereAmI('@ %s'%(Mode))
	SearchPrefix=ps('domain')+'/Search/'+ps('common_word')+'?keyword=%s'
	if len(title)==0:
		title=showkeyboard(txtMessage=title,txtHeader="Search For:  ")
		if (title=='') or (title=='none') or (title==None) or (title==False): return
	title=title.replace(' ','+'); 
	url=SearchPrefix%title; deb('url',url); menu_Series(url)
def menu_Series(url,page=''):
	if len(url)==0: return
	if not '://' in url: url=ps('domain')+url
	WhereAmI('@ %s -- url: %s'%(Mode,url))
	if (settgb('customproxy')==True) and (len(settg('proxy')) > 9): Proxy=settg('proxy')
	else: Proxy=''
	if len(str(page)) > 0: 
		page=int(page); 
		if '?' in url: PageUrl=url+'&page='+str(page)
		else: PageUrl=url+'?page='+str(page)
		NextPage=str(int(page)+1)
	else: PageUrl=url; NextPage='2'
	## ### ## 
	CookieFile=ps('addon profile 1',ps('cookie filename')); 
	if isFile(CookieFile)==True: UseCookieFile=True
	else: UseCookieFile=False
	html=nURL(PageUrl,'get',headers={'Referer':ps('domain')},proxy=Proxy,cookie_file=CookieFile,load_cookie=UseCookieFile,save_cookie=True); deb('lenth of html',str(len(html))); 
	#html=FileOpen(ps('addon path 1','testing_series.html')); 
	html=ParseDescription(html); 
	html=messupText(html,_html=True,_ende=True,_a=False,Slashes=False); 
	html=nolines(html); 
	#FileSave(ps('addon path 1','testing_series.html'),html); 
	## ### ## 
	LoggedIn,actUserName=CheckAcount(html); 
	if LoggedIn==True:	addon.add_directory({'mode':''},{'title':cFL('User: ',ps('default color2'))+cFL(actUserName,ps('default color1'))},fanart=ps('fanart'),img=psgn('img usersmall'))
	else:								addon.add_directory({'mode':''},{'title':cFL('Logged Out',ps('default color3'))},fanart=ps('fanart'),img=psgn('img logout'))
	actKPoints=GetKPoints(html)
	if int(actKPoints) > 0: addon.add_directory({'mode':''},{'title':cFL('KPoints: ',ps('default color2'))+cFL(''+str(actKPoints),ps('default color1'))},fanart=ps('fanart'),img=psgn('img kpoints','.png'))
	## ### ## 
	if ' Last </a></li>' in html:
		try: LPurl=html.replace('&raquo;','').split(' Last </a></li>')[0].split('<li><a href="')[-1].split('"')[0]; LPnum=LPurl.split('page=')[-1]; LPnum=LPnum.split('&')[0]; 
		except: LPurl=''; LPnum=str(page); 
	else: LPurl=''; LPnum=str(page); 
	### First and Previous Pages
	if (len(str(page))==0) or (not str(page)=='1'): pass
	elif (not str(page)=='2'):
		addon.add_directory({'mode':'menuseries','url':url,'page':'1'},{'title':'<< First Page'},fanart=ps('fanart'),img=psgn('img_prev'))
	else:
		addon.add_directory({'mode':'menuseries','url':url,'page':'1'},{'title':'<< First Page'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 11: addon.add_directory({'mode':'menuseries','url':url,'page':'10'},{'title':'<< Page 10'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 21: addon.add_directory({'mode':'menuseries','url':url,'page':'20'},{'title':'<< Page 20'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 31: addon.add_directory({'mode':'menuseries','url':url,'page':'30'},{'title':'<< Page 30'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 41: addon.add_directory({'mode':'menuseries','url':url,'page':'40'},{'title':'<< Page 40'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 51: addon.add_directory({'mode':'menuseries','url':url,'page':'50'},{'title':'<< Page 50'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 61: addon.add_directory({'mode':'menuseries','url':url,'page':'60'},{'title':'<< Page 60'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 71: addon.add_directory({'mode':'menuseries','url':url,'page':'70'},{'title':'<< Page 70'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 81: addon.add_directory({'mode':'menuseries','url':url,'page':'80'},{'title':'<< Page 80'},fanart=ps('fanart'),img=psgn('img_prev'))
		if int(page) > 91: addon.add_directory({'mode':'menuseries','url':url,'page':'90'},{'title':'<< Page 90'},fanart=ps('fanart'),img=psgn('img_prev'))
		addon.add_directory({'mode':'menuseries','url':url,'page':str(page-1)},{'title':'<< Page '+str(int(page)-1)},fanart=ps('fanart'),img=psgn('img_prev'))
	### ...
	#print html
	#sCVE('tvshows',settg('anime-view',515)); return
	### 
	s='<td title=\'(.*?)\'\s*[/]*>\s*<a(?:\s+class="a'+ps('common_word')+'")?\s+href="(/'+ps('common_word')+'/[A-Za-z0-9\-/_]+)"\s*>\s*(.+?)\s*</a>\s*(.*?)\s*</td>\s*<td>\s*(.*?)\s*</td>((?:\s*<td>\s*.*?\s*</td>)?)\s*</tr'; 
	try:		iitems=re.compile(s).findall(html.replace('</tr>','</tr\n\r\a>')) ### , re.MULTILINE | re.IGNORECASE | re.DOTALL
	except:	iitems=[]
	htmlForAdvertisements=''+html; 
	ItemCount=len(iitems); 
	if ItemCount > 0:
		LabelFormat=settg("text-series-labels-format","[COLOR %Watched%]@[/COLOR]  %SeriesTitle%")
		if len(LabelFormat)==0: LabelFormat="[COLOR %Watched%]@[/COLOR]  %SeriesTitle%"
		EnableMeta=settgb("enableMeta"); 
		EnableSiteArt=settgb("enable-site-art"); 
		EnableGenresInPlot=settgb("enable-genres-in-plot"); 
		for tInfo,item_url,name,imInfo,LInfo,LInfo2 in iitems:
			contextMenuItems=[]; animetype='tvshow'; vtype='episode'; FoundItK=False; CCtoSQL=False; r2=False; 
			animename=''+name; animename=animename.replace(' (Dub)','').replace(' (Sub)','').replace(' (TV)','').replace(' OVA','').replace(' Movies','').replace(' Movie','').replace(' Specials','').replace(' New','').replace(' 2nd Season','').replace(' 3rd Season','').replace(' 4th Season','')
			try:		year=re.compile('\((\d\d\d\d)\)').findall(html)[0]
			except:	year=''
			if not '://' in item_url: item_url=ps('domain')+item_url
			try: LInfo=LInfo.strip(); imInfo=imInfo.strip(); tInfo=tInfo.strip(); LInfo2=LInfo2.strip()
			except: pass
			if '</td>' in LInfo: LInfo=LInfo.split('</td>')[0].strip()
			for z in [' (Movie)',' Specials',' OVA',' movie']:
				if z.lower() in name.lower(): animetype='movie'; vtype='movie'
			r=database_get_1st('SELECT * FROM visited WHERE (episode == "" AND title == "%s" AND url LIKE "%s")'%(name,ps('domain')+"/%")); 
			if r:
				if len(r) > 0:
					if r[1]==name: FoundItK=True
			r=database_get_1st('SELECT * FROM shows WHERE url == "%s"'%item_url); 
			if r2==True:
				debob("resusing data from SQL for metadata."); 
				overlay_p=6; img=r[3]; fimg=r[4]; 
				labs={'title':r[1],'year':r[2],'imdb_id':r[5],'imdbid':r[5],'cover_url':r[4],'poster_url':r[4],'backdrop_url':r[4],'plot':urllib.unquote_plus(r[6]),'genre':''}
			else:
				#animename=animename.replace('+','%2B')
				#if animename=='Golden Time': animename+=' (2013)'
				##if animename=='Witch Craft Works': animename='Witch Craft Works (2014)'
				#if animename=='Perfect Blue': animename+=' (1997)'
				#if animename=='Kingdom': animename+=' (2012)'
				#if animename=='Kingdom 2': animename='Kingdom (2012)'
				#if animename=='Weiss Survive R': animename='Weiss Survive'
				
				debob(['to .get_meta',animetype,animename,str(year)]); 
				try:			labs=MetaGet.get_meta(animetype,animename,year=str(year))
				except:
					try:		labs=MetaGet.get_meta(animetype,animename)
					except:	labs={'imdb_id':'','cover_url':'','backdrop_url':'','plot':'','title':animename,'year':''}
				debob(["labs",labs]); 
				#if not meta['imdb_id'] and not meta['tvdb_id']:
				try:		labs[u'plot']='[COLOR gray]'+labs['plot']+'[/COLOR]'
				except:	labs[u'plot']=''
				if ('<p>' in tInfo) and ('</p>' in tInfo):
					try: labs[u'plot']='[COLOR tan]'+re.compile('<p>\s*\n*\s*(.+?)\s*\n*\s*</p>').findall(tInfo)[0].strip()+'[/COLOR][CR][CR]'+labs['plot']
					except: pass
				labs[u'plot']=messupText(labs['plot'],_html=True,_ende=True,_a=False,Slashes=False).replace('<em>','').replace('</em>','')
				if   (LInfo =='Completed'):			labs[u'plot']='['+cFL(LInfo ,'lime')+'][CR]'+labs['plot']
				elif (LInfo2=='Completed'):			labs[u'plot']='['+cFL(LInfo2,'lime')+'][CR]'+labs['plot']
				if   (LInfo =='Not yet aired'):	labs[u'plot']='['+cFL(LInfo ,'red') +'][CR]'+labs['plot']
				elif (LInfo2=='Not yet aired'):	labs[u'plot']='['+cFL(LInfo2,'red') +'][CR]'+labs['plot']
				##
			## ### ## 
			try:		 img=labs['cover_url']
			except:	 img=''
			try:		fimg=labs['backdrop_url']
			except:	fimg=''
			try: 
				if len(img)==0: img=re.compile('"(http://.+?\.jpg)"').findall(tInfo)[0].replace(' ','%20')
			except: pass
			## ### ## 
			pars={'mode':'menuepisodes','url':item_url,'img':img,'title':labs[u'title'],'type':vtype,'fanart':fimg}
			try:		pars[u'imdb_id']=labs['imdb_id']
			except:	pars[u'imdb_id']='0'
			if len(fimg)==0: fimg=ps('fanart')
			if len( img)==0:  img=ps('icon')
			sDB=[]; 
			try: imdbid=pars[u'imdbid']
			except: 
				try: imdbid=labs['imdbid']
				except: imdbid="0"
			if len(imdbid)==0: imdbid="0"
			try: PloT=labs['plot']
			except: PloT=""
			if '[COLOR cornflowerblue]Episode ' in PloT:
				try: PloTtesttt=re.compile('([COLOR cornflowerblue]Episode \d+[/COLOR]\n*\r*\a*)').findall(PloT)[0]
				except: PloTtesttt=''
				if len(PloTtesttt) > 0: PloT=PloT.replace(PloTtesttt,'')
			sDB.append( 'INSERT OR REPLACE INTO shows (url,title,year,img,fanart,imdbnum,plot,timestampyear,timestampmonth,timestampday) VALUES ("%s","%s","%s","%s","%s","%s","%s","%s","%s","%s")' % (  str(item_url),str(pars['title']),str(""),str(img),str(fimg),str(imdbid),urllib.quote_plus(PloT),str(datetime.date.today().year),str(datetime.date.today().month),str(datetime.date.today().day)  ) )
			if len(sDB) > 0:
					debob(sDB); 
					database_do(sDB); 
			#		database_do_test(sDB); 
			if ('</a>' in LInfo):
				deb('LInfo',LInfo)
				try:
					(LatestUrl,LatestName,LatestNumber)=re.compile('<a href="(/'+ps('common_word')+'/.+?)">\s*(.+?(\d*))\s*</a>').findall(nolines(LInfo))[0]
					LatestUrl=ps('domain')+LatestUrl
					LatestPar={'url':LatestUrl,'mode':'GetLinks','img':img,'fanart':fimg,'title':labs[u'title'].replace('[CR]','')+' - '+LatestName}
					try: contextMenuItems.append(('Latest:  '+LatestName,'XBMC.Container.Update(%s)' % addon.build_plugin_url(LatestPar) ))
					except: pass
					labs[u'plot']='['+cFL(LatestName,'cornflowerblue')+'][CR]'+labs[u'plot']
				except: (LatestUrl,LatestName,LatestNumber)=('','','')
			elif ('</a>' in LInfo2):
				deb('LInfo2',LInfo2)
				try:
					(LatestUrl,LatestName,LatestNumber)=re.compile('<a href="(/'+ps('common_word')+'/.+?)">\s*\n*\s*(.+?(\d*))\s*\n*\s*</a>').findall(LInfo2)[0]
					LatestUrl=ps('domain')+LatestUrl
					LatestPar={'url':LatestUrl,'mode':'GetLinks','img':img,'fanart':fimg,'title':labs[u'title'].replace('[CR]','')+' - '+LatestName}
					try: contextMenuItems.append(('Latest:  '+LatestName,'XBMC.Container.Update(%s)' % addon.build_plugin_url(LatestPar) ))
					except: pass
					labs[u'plot']='['+cFL(LatestName,'cornflowerblue')+'][CR]'+labs[u'plot']
				except: (LatestUrl,LatestName,LatestNumber)=('','','')
			else: (LatestUrl,LatestName,LatestNumber)=('','','')
			contextMenuItems.append((ps('cmi.showinfo.name'),ps('cmi.showinfo.url')))
			#if fav__COMMON__check_SQL(item_url,'1')==True:
			#	try: contextMenuItems.append((ps('cMI.favorites.tv.remove.name')+' '+settg('fav.movies.1.name'),ps('cMI.favorites.tv.remove.url') % (sys.argv[0],ps('cMI.favorites.tv.remove.mode'),section,urllib.quote_plus(name),'',urllib.quote_plus(img),urllib.quote_plus(fimg),'',urllib.quote_plus(labs['plot']),urllib.quote_plus(labs['genre']),urllib.quote_plus(item_url),urllib.quote_plus(str(labs['imdb_id'])),'' )))
			#	except: pass
			#else: 
			#	try: contextMenuItems.append((ps('cMI.favorites.tv.add.name')+' '+settg('fav.movies.1.name'),ps('cMI.favorites.tv.add.url') % (sys.argv[0],ps('cMI.favorites.tv.add.mode'),section,urllib.quote_plus(name),'',urllib.quote_plus(img),urllib.quote_plus(fimg),'',urllib.quote_plus(labs['plot']),'',urllib.quote_plus(item_url),urllib.quote_plus(str(labs['imdb_id'])), '' )))
			#	except: pass
			#if (tfalse(settg("enable-fav-movies-2"))==True): 
			#	if fav__COMMON__check_SQL(item_url,'2')==True:
			#		try: contextMenuItems.append((ps('cMI.favorites.tv.remove.name')+' '+settg('fav.movies.2.name'),ps('cMI.favorites.tv.remove.url') % (sys.argv[0],ps('cMI.favorites.tv.remove.mode'),section,urllib.quote_plus(name),'',urllib.quote_plus(img),urllib.quote_plus(fimg),'',urllib.quote_plus(labs['plot']),urllib.quote_plus(labs['genre']),urllib.quote_plus(item_url),urllib.quote_plus(str(labs['imdb_id'])),'2' )))
			#		except: pass
			#	else: 
			#		try: contextMenuItems.append((ps('cMI.favorites.tv.add.name')+' '+settg('fav.movies.2.name'),ps('cMI.favorites.tv.add.url') % (sys.argv[0],ps('cMI.favorites.tv.add.mode'),section,urllib.quote_plus(name),'',urllib.quote_plus(img),urllib.quote_plus(fimg),'',urllib.quote_plus(labs['plot']),'',urllib.quote_plus(item_url),urllib.quote_plus(str(labs['imdb_id'])),'2' )))
			#		except: pass
			#if (tfalse(settg("enable-fav-movies-3"))==True): 
			#	if fav__COMMON__check_SQL(item_url,'3')==True:
			#		try: contextMenuItems.append((ps('cMI.favorites.tv.remove.name')+' '+settg('fav.movies.3.name'),ps('cMI.favorites.tv.remove.url') % (sys.argv[0],ps('cMI.favorites.tv.remove.mode'),section,urllib.quote_plus(name),'',urllib.quote_plus(img),urllib.quote_plus(fimg),'',urllib.quote_plus(labs['plot']),urllib.quote_plus(labs['genre']),urllib.quote_plus(item_url),urllib.quote_plus(str(labs['imdb_id'])),'3' )))
			#		except: pass
			#	else: 
			#		try: contextMenuItems.append((ps('cMI.favorites.tv.add.name')+' '+settg('fav.movies.3.name'),ps('cMI.favorites.tv.add.url') % (sys.argv[0],ps('cMI.favorites.tv.add.mode'),section,urllib.quote_plus(name),'',urllib.quote_plus(img),urllib.quote_plus(fimg),'',urllib.quote_plus(labs['plot']),'',urllib.quote_plus(item_url),urllib.quote_plus(str(labs['imdb_id'])),'3' )))
			#		except: pass
			#if (tfalse(settg("enable-fav-movies-4"))==True): 
			#	if fav__COMMON__check_SQL(item_url,'4')==True:
			#		try: contextMenuItems.append((ps('cMI.favorites.tv.remove.name')+' '+settg('fav.movies.4.name'),ps('cMI.favorites.tv.remove.url') % (sys.argv[0],ps('cMI.favorites.tv.remove.mode'),section,urllib.quote_plus(name),'',urllib.quote_plus(img),urllib.quote_plus(fimg),'',urllib.quote_plus(labs['plot']),urllib.quote_plus(labs['genre']),urllib.quote_plus(item_url),urllib.quote_plus(str(labs['imdb_id'])),'4' )))
			#		except: pass
			#	else: 
			#		try: contextMenuItems.append((ps('cMI.favorites.tv.add.name')+' '+settg('fav.movies.4.name'),ps('cMI.favorites.tv.add.url') % (sys.argv[0],ps('cMI.favorites.tv.add.mode'),section,urllib.quote_plus(name),'',urllib.quote_plus(img),urllib.quote_plus(fimg),'',urllib.quote_plus(labs['plot']),'',urllib.quote_plus(item_url),urllib.quote_plus(str(labs['imdb_id'])),'4' )))
			#		except: pass
			#try: contextMenuItems.append(("Refresh MetaData", "XBMC.RunPlugin(%s)" % addon.build_plugin_url({'mode':'refresh_meta','imdb_id':str(labs['imdb_id']),'video_type':animetype,'title':animename,'alt_id':'imdbnum','year':''}) ))
			#except: pass
			if (len(settg('download_folder_wallpapers')) > 0) and (not len(fimg)==0) and (not fimg==ps('fanart')): 
				try: contextMenuItems.append(('Download Wallpaper', 'XBMC.RunPlugin(%s)'%addon.build_plugin_url({'mode':'Download','studio':name,'img':img,'url':fimg}) ))
				except: pass
			contextMenuItems.append(('Use Browser','XBMC.RunPlugin(%s)'%addon.build_plugin_url({'mode':'BrowseUrl','url':item_url}) ))
			clrLInfo='black'; LeftItNow=''; 
			if (LInfo=='Not yet aired'): clrLInfo='red'; LeftItNow=settg("text-not-yet-aired","[COLOR red]*[/COLOR]")
			elif (LInfo=='Completed'): clrLInfo='lime'; LeftItNow=settg("text-is-completed","[COLOR lime]*[/COLOR]")
			elif ('</a>' in LInfo): clrLInfo='cornflowerblue'; LeftItNow=settg("text-has-latest-episode","[COLOR cornflowerblue]*[/COLOR]").replace('%LatestName%',LatestName).replace('%LatestNumber%',LatestNumber)
			else: clrLInfo='black'; LeftItNow=''
			#if UseLabelFormat==True:
			labs[u'title']=DoSeriesLabelFormatting(LabelFormat='',DefaultT=labs[u'title'],LInfo=LInfo,LInfo2=LInfo2,imInfo=imInfo,FoundItK=FoundItK,Title=labs[u'title'],name=name,animename=animename,animetype=animetype,labs=labs,pars=pars)
			#else:
			#	if EnableLinfoStarMarking==False: clrLInfo='black'; LeftItNow=''
			#	if EnableVisitedLeft==True:
			#		if len(LeftItNow) > 0: LeftItNow+=' '
			#		if FoundItK==True: 
			#			labs[u'title']=settg("text-series-left-watched","[COLOR deeppink]@  [/COLOR]")+LeftItNow+labs[u'title']
			#		else: labs[u'title']=settg("text-series-left-unwatched","[COLOR black]@  [/COLOR]")+LeftItNow+labs[u'title']
			#	else:
			#		if len(LeftItNow) > 0: LeftItNow=' '+LeftItNow
			#		if FoundItK==True: labs[u'title']+=settg("text-series-right-watched","[COLOR deeppink]  @[/COLOR]")+LeftItNow
			#	#deb('imInfo',imInfo); deb("mark-hot",str(settg("mark-hot","false"))); deb("hot in imInfo",str('/Content/images/hot.png' in imInfo)); 
			#	if (settgb("mark-hot","false")==True) and ('/Content/images/hot.png' in imInfo):
			#		labs[u'title']+=" "+settg("text-hot","[COLOR fuchsia][[I]HOT [/I]][/COLOR]"); #debob(labs[u'title']); 
			
			
			
			
			
			
			if (settgb("Notyetaired")==False) and (LInfo=='Not yet aired'): deb(LInfo,name)
			else: 
				if settgb("singleline")==True: labs[u'title']=labs[u'title'].replace('[CR]',' ')
				ppp={}
				#ppp={'TotalSeasons':'1','TotalEpisodes':'1','WatchedEpisodes':'12','UnWatchedEpisodes':'0','NumEpisodes':'12'}
				try: addon.add_directory(pars,labs,ppp,img=img,fanart=fimg,contextmenu_items=contextMenuItems,total_items=ItemCount,is_folder=True,context_replace=False)
				except: pass
			
			
			##
		##
	##
	### Next and Last Pages
	if   (len(LPurl)==0) or (len(page)==0) or (int(LPnum)==int(page)): pass
	elif int(LPnum) > (int(page)+1):
		addon.add_directory({'mode':'menuseries','url':url,'page':str(page+1)},{'title':'>> Page '+str(NextPage)},fanart=ps('fanart'),img=psgn('img_next'))
		addon.add_directory({'mode':'menuseries','url':url,'page':str(LPnum)},{'title':'>> Last Page'},fanart=ps('fanart'),img=psgn('img_next'))
	elif int(LPnum) > int(page):
		addon.add_directory({'mode':'menuseries','url':url,'page':str(LPnum)},{'title':'>> Last Page'},fanart=ps('fanart'),img=psgn('img_next'))
	### Ads
	ListAdvertisements(htmlForAdvertisements,PageUrl,url)
	### End of List
	sCVE('tvshows',settg('anime-view',515)); 
def menu_Episodes(url): 
	if len(url)==0: return
	if not '://' in url: url=ps('domain')+url
	WhereAmI('@ %s -- url: %s'%(Mode,url))
	if (settgb('customproxy')==True) and (len(settg('proxy')) > 9): Proxy=settg('proxy')
	else: Proxy=''
	## ### ## 
	CookieFile=ps('addon profile 1',ps('cookie filename')); 
	if isFile(CookieFile)==True: UseCookieFile=True
	else: UseCookieFile=False
	html=nURL(url,'get',headers={'Referer':ps('domain')},proxy=Proxy,cookie_file=CookieFile,load_cookie=UseCookieFile,save_cookie=True); deb('lenth of html',str(len(html))); 
	html=ParseDescription(html); 
	html=messupText(html,_html=True,_ende=True,_a=False,Slashes=False); 
	html=nolines(html); 
	## ### ## 
	LoggedIn,actUserName=CheckAcount(html); 
	if LoggedIn==True:	addon.add_directory({'mode':''},{'title':cFL('User: ',ps('default color2'))+cFL(actUserName,ps('default color1'))},fanart=ps('fanart'),img=psgn('img usersmall'))
	else:								addon.add_directory({'mode':''},{'title':cFL('Logged Out',ps('default color3'))},fanart=ps('fanart'),img=psgn('img logout'))
	actKPoints=GetKPoints(html)
	if int(actKPoints) > 0: addon.add_directory({'mode':''},{'title':cFL('KPoints: ',ps('default color2'))+cFL(''+str(actKPoints),ps('default color1'))},fanart=ps('fanart'),img=psgn('img kpoints','.png'))
	## ### ## 
	#s='<td title=\'(.*?)\'\s*[/]*>\s*<a(?:\s+class="a'+ps('common_word')+'")?\s+href="(/'+ps('common_word')+'/[A-Za-z0-9\-/_]+)"\s*>\s*(.+?)\s*</a>\s*(.*?)\s*</td>\s*<td>\s*(.*?)\s*</td>((?:\s*<td>\s*.*?\s*</td>)?)\s*</tr'; 
	s=''
	try:		iitems=re.compile(s).findall(html.replace('</tr>','</tr\n\r>')) ### , re.MULTILINE | re.IGNORECASE | re.DOTALL
	except:	iitems=[]
	htmlForAdvertisements=''+html; 
	ItemCount=len(iitems); 
	if ItemCount > 0:
		LabelFormat=settg("text-series-labels-format","[COLOR %Watched%]@[/COLOR]  %SeriesTitle%")
		if len(LabelFormat)==0: LabelFormat="[COLOR %Watched%]@[/COLOR]  %SeriesTitle%"
	## ### ## 
	tab1rows='url,title,year,timestampyear,timestampmonth,timestampday,img,fanart,imdbnum,plot'; 
	sDB='SELECT %s FROM shows WHERE (url == "%s")' % (tab1rows,url); debob(sDB); 
	iFound=False; r=get_database_1st(sDB); 
	if r:
		if len(r) > 0:
			if r[0]==url: iFound=True
	if iFound==True:
		SeriesTitle=r[1]
		SeriesYear=r[2]
		SeriesThumb=r[6]
		SeriesFanart=r[7]
		SeriesImdbnum=r[8]
		SeriesPlot=r[9]
	else: 
		SeriesTitle=re.compile('<a Class="bigChar" href="/Anime/.+?">(.+?)</a').findall(html.replace('</a>','</a\n\r>'))[0]
		SeriesYear=''
		try: SeriesThumb=re.compile('<div class="barTitle">\s*Cover</div>\s*<div class="barContent">\s*<div class="arrow-general">\s*</div>\s*<div style="text-align: center">\s*<img width="\d+px" height="\d+px" src="(.+?)"/>').findall(nolines(html).replace('&nbsp;',' ').replace('\n','').replace('\r','').replace('\a','').replace('\t','').replace('<div class="clear2">','<div class="clear2"\n\r\a>').replace('<div class="rightBox">','<div class="rightBox"\n\r\a>'))[0]
		except: SeriesThumb=ps('icon')
		SeriesFanart=ps('fanart')
		SeriesImdbnum=''
		SeriesPlot=''
		#sDB ='INSERT OR REPLACE INTO shows (url,title,year,img,fanart,imdbnum,plot,timestampyear,timestampmonth,timestampday)'; 
		#sDB+=' VALUES ("%s","%s","%s","%s","%s","%s","%s","%s","%s","%s")' % (  str(url),str(SeriesTitle),str(SeriesYear),str(SeriesThumb),str(SeriesFanart),str(SeriesImdbnum),str(urllib.quote_plus(SeriesPlot)),str(datetime.date.today().year),str(datetime.date.today().month),str(datetime.date.today().day)  ); 
		#debob(""+sDB); 
		#do_database([sDB]); 
		pass
	## ### ## 
	database_do(['INSERT OR REPLACE INTO visited (url,title,episode,timestampyear,timestampmonth,timestampday,img,fanart) VALUES ("%s","%s","%s","%s","%s","%s","%s","%s")'%(url,'%s (%s)'%(str(SeriesTitle),str(SeriesYear)),"",str(datetime.date.today().year),str(datetime.date.today().month),str(datetime.date.today().day),SeriesThumb,SeriesFanart)])
	
	## ### ## 
	#	EnableMeta=settgb("enableMeta"); 
	#	EnableSiteArt=settgb("enable-site-art"); 
	#	EnableGenresInPlot=settgb("enable-genres-in-plot"); 
	#	for tInfo,item_url,name,imInfo,LInfo,LInfo2 in iitems:
	#		contextMenuItems=[]; animetype='tvshow'; vtype='episode'; FoundItK=False; CCtoSQL=False; r2=False; 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	### Ads
	ListAdvertisements(htmlForAdvertisements,url,url)
	### End of List
	sCVE('episodes',settg('episode-view',515)); 


### ############################################################################################################
### ############################################################################################################
def menu_SiteShortcuts():
	WhereAmI('@ the Main Menu'); 
	if settgb("singleline")==True: CR2=' '
	else: CR2='[CR]'
	addon.add_directory({'mode':'System.Exec','url':'http://kissanime.com/'},{'title': cFL_('KissAnime.com',ps('default color3'))},is_folder=True,fanart=ps('fanart'),img='http://kissanime.com/Content/images/logo.png'); 
	#addon.add_directory({'mode':'System.Exec','url':'http://kissanime.com/M'},{'title': cFL_('KissAnime Mobile',ps('default color3'))},is_folder=True,fanart=ps('fanart'),img='http://kissanime.com/Content/images/logo.png'); 
	#addon.add_directory({'mode':'System.Exec','url':'http://kissanime.com/Message/ReportError'},{'title': cFL_('Report Errors',ps('default color3'))},is_folder=True,fanart=ps('fanart'),img='http://kissanime.com/Content/images/logo.png'); 
	#addon.add_directory({'mode':'System.Exec','url':''},{'title': cFL_('KissAnime',ps('default color3'))},is_folder=True,fanart=ps('fanart'),img='http://kissanime.com/Content/images/logo.png'); 
	addon.add_directory({'mode':'System.Exec','url':'http://kissanime.com/AdvanceSearch'},{'title': cFL_('Advanced Search',ps('default color3'))},is_folder=True,fanart=ps('fanart'),img='http://kissanime.com/Content/images/logo.png'); 
	addon.add_directory({'mode':'System.Exec','url':'https://www.facebook.com/groups/kisscommunity'},{'title': cFL_('Discussion',ps('default color3'))},is_folder=True,fanart='https://fbcdn-sphotos-b-a.akamaihd.net/hphotos-ak-prn2/t1/954767_686622534684507_1720354290_n.jpg',img='http://i.imgur.com/ImsT2tb.png'); 
	addon.add_directory({'mode':'System.Exec','url':'https://www.facebook.com/messages/kissanimeweb'},{'title': cFL_('Request Anime',ps('default color3'))},is_folder=True,fanart='https://scontent-b-ord.xx.fbcdn.net/hphotos-frc3/t1/483600_372465079535066_686333025_n.jpg',img='http://i.imgur.com/S568G7Q.jpg'); 
	addon.add_directory({'mode':'System.Exec','url':'http://kissmanga.com/'},{'title': cFL_('KissManga.com',ps('default color3'))},is_folder=True,fanart='https://scontent-b-ord.xx.fbcdn.net/hphotos-frc3/t1/1538852_511236602306952_774531197_n.jpg',img='http://kissmanga.com/Content/images/logo.png'); 
	addon.add_directory({'mode':'System.Exec','url':'https://www.facebook.com/kissanimeweb'},{'title': cFL_('FaceBook',ps('default color3'))},is_folder=True,fanart='https://scontent-b-ord.xx.fbcdn.net/hphotos-frc3/t1/483600_372465079535066_686333025_n.jpg',img='http://www.marketingpilgrim.com/wp-content/uploads/2012/01/facebook-icon-1.png'); 
	
	
	sCVE('list',settg('default-view',50)); 
def menu_Main():
	#database_CheckDB()
	WhereAmI('@ the Main Menu'); 
	#WhereAmI('@ %s -- url: %s'%(Mode,url)); 
	#sPluginFanart(); 
	#debob(['word1',ps('common_word'),'domain',ps('domain')])
	
	if settgb("singleline")==True: CR2=' '
	else: CR2='[CR]'
	#if tfalse(settg("splash-screen"))==True: do_My_Splash(); 
	
	if (len(settg("LastShowListedURL")) > 0) and (settgb("enable-autoplay-lsv")==True): addon.add_directory({'mode':'GetEpisodes','url':settg("LastShowListedURL"),'imdbid':settg("LastShowListedImdbID"),'img':settg("LastShowListedIMG"),'title':settg("LastShowListedNAME")},{'title':cFL_('Last '+ps('common_word')+' Visited:'+CR2+cFL(settg("LastShowListedNAME"),'blue'),ps('default color1'))},fanart=settg("LastShowListedIMG"),img=settg("LastShowListedIMG"))
	
	addon.add_directory({'mode':'SelectAZ','url':ps('domain')+'/'+ps('common_word')+'List'},{'title':cFL_(ps('common_word')+' List ( All | # | A-Z )',ps('default color1'))},fanart=ps('fanart'),img=psgn(ps('common_word').lower()+' list all','.jpg'))
	addon.add_directory({'mode':'menuseries','url':ps('domain')+'/Status/Ongoing'},{'title':cFL_('Ongoing',ps('default color1'))},fanart=ps('fanart'),img=psgn('ongoing','.jpg'))
	addon.add_directory({'mode':'menuseries','url':ps('domain')+'/Status/Completed'},{'title':cFL_('Completed',ps('default color1'))},fanart=ps('fanart'),img=psgn('completed','.jpg'))
	addon.add_directory({'mode':'BrowseGenre','url':ps('domain')+'/'},{'title':cFL_('Genre',ps('default color1'))},fanart=ps('fanart'),img=psgn('genre','.jpg'))
	addon.add_directory({'mode':'menuseries','url':ps('domain')+'/'+ps('common_word')+'List/Newest'},{'title':cFL_(ps('common_word')+' List [Newest]',ps('default color1'))},fanart=ps('fanart'),img=psgn(ps('common_word').lower()+' list newest','.jpg'))
	addon.add_directory({'mode':'menuseries','url':ps('domain')+'/'+ps('common_word')+'List/LatestUpdate'},{'title':cFL_(ps('common_word')+' List [Latest Update]',ps('default color1'))},fanart=ps('fanart'),img=psgn(ps('common_word').lower()+' list latest update','.jpg'))
	addon.add_directory({'mode':'menuseries','url':ps('domain')+'/'+ps('common_word')+'List/MostPopular'},{'title':cFL_(ps('common_word')+' List [Popularity]',ps('default color1'))},fanart=ps('fanart'),img=psgn(ps('common_word').lower()+' list popularity','.jpg'))
	
	addon.add_directory({'mode':'menuseries','url':ps('domain')+'/'+ps('common_word')+'List'},{'title':cFL_(ps('common_word')+' List [Alphabet]',ps('default color1'))},fanart=ps('fanart'),img=psgn(ps('common_word').lower()+' list alphabet','.jpg')) #img=ps('img_kisslogo'))
	
	addon.add_directory({'mode':'Search','pageno': '1', 'pagecount': settg('pages')},{'title':cFL_('Search',ps('default color1'))},fanart=ps('fanart'),img=psgn('search','.jpg')) #ps('img_search'))
	
	addon.add_directory({'mode':'MenuHistory'},{'title':cFL(cFL_('History',ps('default color1')),'tan')+''},fanart=ps('fanart'),img=psgn('menu history','.jpg')) #ps('img_kisslogo'))
	
	for genre in ['OVA','Movie']:
		img=psgn(genre.lower(),'.jpg'); addon.add_directory({'mode': 'SelectSort','url': ps('domain')+'/Genre/'+genre.replace(' ','-')},{'title':genre},img=img,fanart=ps('fanart'))
	
	#if (tfalse(settg("oldmenu"))==True):
	#	addon.add_directory({'mode':'SelectGenre','url':ps('domain')+'/'},{'title':cFL_('Genre (Select)',ps('default color1'))},fanart=ps('fanart'),img=psgn('genre select','.jpg')) #art('genre','.jpg'))
	#	addon.add_directory({'mode':'BrowseLast'},{'title':cFL_('Last',ps('default color2'))},fanart=ps('fanart'),img=psgn('last','.jpg')) #ps('img_kisslogo'))
	
	#if (len(settg('username','')) > 0) and (len(settg('password','')) > 0) and (tfalse(settg('enable-accountinfo','false'))==True): 
	#	addon.add_directory({'mode':'listBookmarks','url':ps('domain')+'/BookmarkList'},{'title':cFL('Online Bookmarks',ps('default color1'))+' [Account]'},fanart=ps('fanart'),img=psgn('online bookmarks','.jpg')) #ps('img_kisslogo'))
	
	MyListNumber=str(settg("mylist-number",''))
	if len(str(MyListNumber)) > 0:
		addon.add_directory({'mode':'menuseries','url':ps('domain')+'/MyList/'+MyListNumber},{'title':cFL('My List',ps('default color1'))+' ['+cFL(str(MyListNumber),'white')+']'},fanart=ps('fanart'),img=psgn('my list','.jpg')) #ps('img_kisslogo'))
	addon.add_directory({'mode':'MenuMyListLIST','url':ps('domain')+'/MyList/'+MyListNumber},{'title':cFL('My List',ps('default color1'))+''},fanart=ps('fanart'),img=psgn('my list list','.jpg')) #ps('img_kisslogo'))
	
	#FavoritesListSQL
	addon.add_directory({'mode': 'FavoritesListSQL'},{'title':  cFL_('Favorites '+settg('fav.movies.1.name'),ps('default color3'))},fanart=ps('fanart'),img=psgn('favorites','.jpg')) #_art404)
	if (tfalse(settg("enable-fav-movies-2"))==True): addon.add_directory({'mode': 'FavoritesListSQL','subfav': '2'},{'title':  cFL_('Favorites '+settg('fav.movies.2.name'),ps('default color3'))},fanart=ps('fanart'),img=psgn('favorites 2','.jpg')) #_art404)
	if (tfalse(settg("enable-fav-movies-3"))==True): addon.add_directory({'mode': 'FavoritesListSQL','subfav': '3'},{'title':  cFL_('Favorites '+settg('fav.movies.3.name'),ps('default color3'))},fanart=ps('fanart'),img=psgn('favorites 3','.jpg')) #_art404)
	if (tfalse(settg("enable-fav-movies-4"))==True): addon.add_directory({'mode': 'FavoritesListSQL','subfav': '4'},{'title':  cFL_('Favorites '+settg('fav.movies.4.name'),ps('default color3'))},fanart=ps('fanart'),img=psgn('favorites 4','.jpg')) #_art404)
	#
	
	addon.add_directory({'mode': 'GetTitlesUpcoming','url':ps('domain')+'/Upcoming'+ps('common_word')+''},{'title': cFL_('Upcoming '+ps('common_word'),ps('default color3'))},is_folder=True,fanart=ps('fanart'),img=psgn('upcoming anime','.jpg'))
	
	#if (len(settg("LastVideoPlayItemUrl")) > 0) and (tfalse(settg("enable-autoplay-lvp"))==True): addon.add_directory({'mode':'PlayVideoB','url':settg("LastVideoPlayItemUrl"),'title':settg('LastVideoPlayItemName'),'studio':settg('LastVideoPlayItemStudio'),'img':settg("LastVideoPlayItemImg")},{'title':cFL_('Last Video [Played]: '+cFL(settg('LastVideoPlayItemName'),ps('default color3'))+CR2+cFL(settg('LastVideoPlayItemStudio'),'blue'),ps('default color1'))},fanart=settg("LastVideoPlayItemImg"),img=settg("LastVideoPlayItemImg"),is_folder=False)
	##if (len(settg("LastAutoPlayItemUrl")) > 0) and (tfalse(settg("enable-autoplay-lvap"))==True): addon.add_directory({'mode':'PlayVideo','url':settg("LastAutoPlayItemUrl"),'title':settg('LastAutoPlayItemName')},{'title':cFL_('Last Video [AutoPlay]:'+CR2+cFL(settg('LastAutoPlayItemName'),'blue'),ps('default color1'))},fanart=settg("LastShowListedIMG"),img=settg("LastShowListedIMG"))
	#if (len(settg("LastAutoPlayItemUrl")) > 0) and (tfalse(settg("enable-autoplay-lvap"))==True): addon.add_directory({'mode':'PlayVideoA','url':settg("LastAutoPlayItemUrl"),'title':settg('LastAutoPlayItemName'),'img':settg("LastAutoPlayItemImg")},{'title':cFL_('Last Video [AutoPlay]:'+CR2+cFL(settg('LastAutoPlayItemName'),'blue'),ps('default color1'))},fanart=settg("LastAutoPlayItemImg"),img=settg("LastAutoPlayItemImg"),is_folder=False)
	
	#if (tfalse(settg("label-empty-favorites"))==True):
	#	addon.add_directory({'section': '', 'mode': 'FavoritesEmpty', 'subfav':  ''},	 		{'title':  cFL('E',ps('default color1'))+'mpty Favorites '+settg('fav.movies.1.name')},fanart=ps('fanart'),img=art('trash','.gif'),is_folder=False)
	#	if (tfalse(settg("enable-fav-movies-2"))==True): addon.add_directory({'section': '', 'mode': 'FavoritesEmpty', 'subfav': '2'},	 		{'title':  cFL('E',ps('default color1'))+'mpty Favorites '+settg('fav.movies.2.name')},fanart=ps('fanart'),img=art('trash','.gif'),is_folder=False)
	#	if (tfalse(settg("enable-fav-movies-3"))==True): addon.add_directory({'section': '', 'mode': 'FavoritesEmpty', 'subfav': '3'},	 		{'title':  cFL('E',ps('default color1'))+'mpty Favorites '+settg('fav.movies.3.name')},fanart=ps('fanart'),img=art('trash','.gif'),is_folder=False)
	#	if (tfalse(settg("enable-fav-movies-4"))==True): addon.add_directory({'section': '', 'mode': 'FavoritesEmpty', 'subfav': '4'},	 		{'title':  cFL('E',ps('default color1'))+'mpty Favorites '+settg('fav.movies.4.name')},fanart=ps('fanart'),img=art('trash','.gif'),is_folder=False)
	
	##addon.add_directory({'mode': 'TextBoxUrl',   'title': "[COLOR cornflowerblue]Latest Change Log:[/COLOR]  %s" % (ps('addon name')), 'url': ps('changelog.url')}, 		{'title': cFL('L',ps('default color1'))+'atest Online Change Log'},	img=art('thechangelog','.jpg'), is_folder=False ,fanart=ps('fanart'))
	##addon.add_directory({'mode': 'TextBoxUrl',   'title': "[COLOR cornflowerblue]Latest News:[/COLOR]  %s"       % (ps('addon name')), 'url': ps('news.url')}, 				{'title': cFL('L',ps('default color1'))+'atest Online News'},				img=_art404										, is_folder=False ,fanart=ps('fanart'))
	##addon.add_directory({'mode': 'LatestThreads','title': "[COLOR cornflowerblue]Latest Threads[/COLOR]", 'url': ps('LatestThreads.url')}, 											{'title': cFL('L',ps('default color1'))+'atest Threads'},						img=_art404										, is_folder=False ,fanart=ps('fanart'))
	##addon.add_directory({'mode': 'PrivacyPolicy','title': "", 'url': ''}, 																																												{'title': cFL('P',ps('default color1'))+'rivacy Policy'},						img=_art404										, is_folder=False ,fanart=ps('fanart'))
	##addon.add_directory({'mode': 'TermsOfService','title': "", 'url': ''}, 																																											{'title': cFL('T',ps('default color1'))+'erms of Service'},					img=_art404										, is_folder=False ,fanart=ps('fanart'))
	
	
	addon.add_directory({'mode':'attemptlogin'},{'title':cFL_('Login',ps('default color2'))},fanart=ps('fanart'),img=psgn('img usersmall','.png'))
	addon.add_directory({'mode':'attemptlogout'},{'title':cFL_('Logout',ps('default color2'))},fanart=ps('fanart'),img=psgn('img logout','.png'))
	addon.add_directory({'mode': 'Settings'}, 				 {'title':  cFL('P',ps('default color2'))+'lugin Settings'}			,is_folder=False,fanart=ps('fanart'),img=psgn('plugin settings','.jpg')) #,img=art('kiss')
	addon.add_directory({'mode': 'TextBoxFile',  'title': "[COLOR cornflowerblue]Local Change Log:[/COLOR]  %s"  % (ps('addon name')), 'url': ps('changelog.local')}, 	{'title': cFL_('Local Change Log',ps('default color2'))}, is_folder=False ,fanart=ps('fanart'),img=psgn('local change log','.jpg')) #,img=art('thechangelog','.jpg')
	addon.add_directory({'mode': 'siteshortcuts'},{'title': cFL_('KissAnime '+CR2+'Site Shortcuts',ps('default color2'))},is_folder=True,fanart=ps('fanart'),img=psgn('site shortcuts','.jpg')) #_artIcon) #'http://kissanime.com/Content/images/logo.png') #,img=art('thechangelog','.jpg')
	
	
	
	if settgb("splash-screen")==True: 
		import splash_highway as splash
		splash.do_My_Splash('http://kissanime.com/Content/images/logo.png',5); 
		#splash.do_My_Splash('https://scontent-b-ord.xx.fbcdn.net/hphotos-frc3/t1.0-9/483600_372465079535066_686333025_n.jpg',5); 
	
	sCVE('list',settg('default-view',50)); 
	#sContent('list'); sView(settg('default-view',50)); eod(); 
	
	#if tfalse(settg("check-github-messages","false"))==True:
	#	LastDate=settg('git-last',''); deb('CurDate ',CurDate); deb('LastDate',LastDate); #myNote("-","="); ## for testing ##
	#	if not CurDate==LastDate: GitData=getGitMsg(); checkGitMsg(); 
	## ### ## 
### ############################################################################################################
### ############################################################################################################
def zToMode(mode=Par('mode'),url=ParQ('url'),img=ParQ('img'),fimg=ParQ('fimg'),title=ParQ('title'),name=ParQ('name'),stitle=ParQ('stitle'),etitle=ParQ('etitle'),plot=ParQ('plot'),page=Par('page')):
	mode=mode.lower(); debob({'mode':mode,'url':url,'name':name,'title':title}); 
	#print ['mode',mode]
	#eod()
	if   (mode=='') or (mode=='main'):	menu_Main()
	elif mode=='menuseries':						menu_Series(url,page)
	elif mode=='attemptlogin':					menu_Login()
	elif mode=='attemptlogout':					menu_Logout()
	elif mode=='playurl':								PlayURL(ParQ('url'))
	elif mode=='playvideo':							PlayVideo(ParQ('url'),title=ParQ('title'),studio=ParQ('studio'),img=ParQ('img'),showtitle=ParQ('showtitle'),plot=ParQ('plot'),pageUrl=ParQ('pageurl'))
	elif mode=='search':								SearchDO(title)
	elif (mode=='browseurl'): 						
		url=ParQ('url')
		if (len(url) > 0) and ('://' in url): 
			XBMC_System_Exec('"%s"' % url)
	elif (mode=='settings'):						addon.addon.openSettings() #_plugin.openSettings()
	elif mode=='siteshortcuts':					menu_SiteShortcuts()
	#elif mode=='menuepisodes':	menu_Episodes()
	#elif mode=='':	menu_()
	#elif mode=='':	menu_()
	#elif mode=='':	menu_()
	#elif mode=='':	menu_()
	#elif mode=='':	menu_()
	## ### ## 
	elif (mode=='refresh_meta'):				refresh_meta(ParQ('video_type'),ParQ('title'),ParQ('imdb_id'),ParQ('alt_id'),ParQ('year'))
	elif (mode=='System.Exec'):					eod(); xbmc.executebuiltin("XBMC.System.Exec(%s)" % url); xbmc.sleep(3000); DoA("Back"); 
	elif (mode=='System.ExecWait'):			eod(); xbmc.executebuiltin("XBMC.System.ExecWait(%s)" % url); xbmc.sleep(1000); DoA("Back"); 
	else: myNote(header='Mode:  "'+mode+'"',msg='[ mode ] not found.'); eod()
Mode=Par('mode')
zToMode()
### ############################################################################################################
### ############################################################################################################
