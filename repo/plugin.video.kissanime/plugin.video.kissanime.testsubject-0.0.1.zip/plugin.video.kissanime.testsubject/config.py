### ############################################################################################################
### ############################################################################################################
### # ## ### ## Imports ## ### ## 
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,urllib,urllib2,re,os,sys,htmllib,string,StringIO,logging,random,array,time,datetime,HTMLParser,htmlentitydefs
try: import copy
except: pass
try: 			   from addon.common.addon 			import Addon
except:
	try: 		   from t0mm0.common.addon 			import Addon
	except: 
		try:   from z_addon_common_addon 			import Addon
		except: 
			try: from z_t0mm0_common_addon 			import Addon
			except: pass
import commonb as CommonB
from commonb import *
### # ## ### ## Required Functions ## ### ## 
#
#
### # ## ### ## Plugin Settings ## ### ## 
#AddonXML=FileOpen('addon.xml'); #print AddonXML; 
isTesting=False; #isTesting=True; 
AddonID='plugin.video.kissanime.testsubject'
cAddon=Addon(AddonID,sys.argv)
xAddon=xbmcaddon.Addon(id=AddonID)
def setSetting(id,value):
	try: cAddon.addon.setSetting(id=id,value=value)
	except: pass
def getSetting(Id,defaultvalue=''):
	try: return cAddon.get_setting(Id)
	except: return defaultvalue
def getParam(r='',defaultvalue=''):
	try: 
		if len(str(r))==0: return cAddon.queries
		else: return cAddon.queries.get(str(r),defaultvalue)
	except: return defaultvalue
def buildUrlFromParams(a,defaultvalue=''):
	try: return cAddon.build_plugin_url(a)
	except: return defaultvalue
def parseQuery(a,defaultvalue=''):
	try: return cAddon.parse_query(a)
	except: return defaultvalue
def ps(x,y='',z='',n=1):
	#if (x.lower()=='addon id') or (x.lower()=='plugin id'): return AddonID
	#try: 
		x=x.lower()
		if   x=='addon path 1': return xbmc.translatePath(os.path.join(cAddon.get_path(),y))
		elif x=='addon path 2': return xbmc.translatePath(os.path.join(cAddon.get_path(),y,z))
		elif x=='addon profile 1': return xbmc.translatePath(os.path.join(cAddon.get_profile(),y))
		elif x=='addon profile 2': return xbmc.translatePath(os.path.join(cAddon.get_profile(),y,z))
		elif x=='get setting': return cAddon.get_setting(str(y))
		elif x=='unquote': return urllib.unquote_plus(y)
		elif x=='quote': return urllib.quote_plus(y)
		elif x=='pars': return getParam('',{})
		elif x=='par': return getParam(y,z)
		elif x=='paramq': return urllib.unquote_plus(getParam(y,z))
		elif x=='parami': return int(getParam(y,z))
		elif x=='paramb': return tfalse(getParam(y,z))
		elif x=='setting': return getSetting(y,z)
		elif x=='settingb': return tfalse(getSetting(y,z))
		elif x=='caddon': return cAddon
		elif x=='xaddon': return xAddon
		elif x=='art path': return xbmc.translatePath(os.path.join(cAddon.get_path(),'art'))
		elif x=='art path 1': return xbmc.translatePath(os.path.join(cAddon.get_path(),'art',y))
		elif x=='art path 2': return xbmc.translatePath(os.path.join(cAddon.get_path(),'art',y,z))
		elif x=='media path': return xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','media'))
		elif x=='media path 1': return xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','media',y))
		elif x=='media path 2': return xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','media',y,z))
		elif x=='skin path': return xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default',y))
		elif x=='skin path 720': return xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','720p'))
		elif x=='skin path 1080': return xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','1080i'))
		elif x=='skin path pal': return xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','PAL'))
		elif x=='skin path pal16x9': return xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','PAL16x9'))
		elif x=='icon': return xbmc.translatePath(cAddon.get_icon())
		elif x=='fanart': return xbmc.translatePath(cAddon.get_fanart())
		elif x=='': return 
		elif x=='tf': return tfalse(y)
		return {
			'addon id':							AddonID
			,'plugin id':						AddonID
			,'db filename':					'kissanime'
			,'cookie filename':			'kissanime.cookie.txt'
			,'common_word': 				"Anime"
			,'common_word2': 				"Watch"
			,'domain': 							"http://kissanime.com"
			,'addon name':					cAddon.get_name()
			,'addon author':				cAddon.get_author()
			,'addon changelog':			cAddon.get_changelog()
			,'addon plot':					cAddon.get_description()
			,'addon desc':					cAddon.get_description()
			,'addon description':		cAddon.get_description()
			,'addon disc':					cAddon.get_disclaimer()
			,'addon disclaimer':		cAddon.get_disclaimer()
			,'addon summary':				cAddon.get_summary()
			,'addon sum':						cAddon.get_summary()
			,'addon path':					xbmc.translatePath(cAddon.get_path())
			#,'addon path 1':				xbmc.translatePath(os.path.join(cAddon.get_path(),y))
			#,'addon path 2':				xbmc.translatePath(os.path.join(cAddon.get_path(),y,z))
			,'addon profile':				xbmc.translatePath(cAddon.get_profile())
			#,'addon profile 1':			xbmc.translatePath(os.path.join(cAddon.get_profile(),y))
			#,'addon profile 2':			xbmc.translatePath(os.path.join(cAddon.get_profile(),y,z))
			,'addon stars':					cAddon.get_stars()
			,'addon type':					cAddon.get_type()
			,'addon version':				cAddon.get_version()
			#,'get setting':					cAddon.get_setting(str(y))
			#,'set setting':					cAddon.set_setting(str(y),str(z))
			#,'get string':					cAddon.get_string(int(y))
			#,'string':							cAddon.get_string(int(y))
			#,'unquote':							urllib.unquote_plus(y)
			#,'quote':								urllib.quote_plus(y)
			,'c':										'[COLOR '+z+']'+y+'[/COLOR]'
			,'c1':									'[COLOR '+z+']'+y[0:int(n)]+'[/COLOR]'+y[int(n):]
			,'b':										'[B '+z+']'+y+'[/B]'
			,'i':										'[I '+z+']'+y+'[/I]'
			#,'tf':									tfalse(y)
			#,'pars':								getParam('',{})
			#,'par':									getParam(y,z)
			#,'param':								getParam(y,z)
			#,'paramq':							urllib.unquote_plus(getParam(y,z))
			#,'parami':							int(getParam(y,z))
			#,'paramb':							tfalse(getParam(y,z))
			#,'setting':							getSetting(y,z)
			#,'settingb':						tfalse(getSetting(y,z))
			#,'caddon':							cAddon
			#,'xaddon':							xAddon
			#,'art path':						xbmc.translatePath(os.path.join(cAddon.get_path(),'art'))
			#,'media path':					xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','media'))
			#,'skin path':						xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default',y))
			#,'skin path 720':				xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','720p'))
			#,'skin path 1080':			xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','1080i'))
			#,'skin path pal':				xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','PAL'))
			#,'skin path pal16x9':		xbmc.translatePath(os.path.join(cAddon.get_path(),'resources','skins','Default','PAL16x9'))
			,'authors': 						"[COLOR white]The[COLOR tan]Highway[/COLOR][/COLOR]"
			,'domain url': 					""
			,'sep':									os.sep
			,'user-agent':					'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'cmi.showinfo.url':		'XBMC.Action(Info)'
			,'cmi.jdownloader.addlink.url':		'XBMC.RunPlugin(plugin://plugin.program.jdownloader/?action=addlink&url=%s)'
			,'mode':								getParam('mode','')
			,'par mode':						getParam('mode','')
			#,'par name':						urllib.unquote_plus(getParam('name'))
			#,'par title':						urllib.unquote_plus(getParam('title'))
			#,'par url':							urllib.unquote_plus(getParam('url'))
			#,'par img':							urllib.unquote_plus(getParam('img'))
			#,'par fimg':						urllib.unquote_plus(getParam('fimg'))
			#,'par icon':						urllib.unquote_plus(getParam('icon'))
			#,'par fanart':					urllib.unquote_plus(getParam('fanart'))
			#,'par studio':					urllib.unquote_plus(getParam('studio'))
			#,'par stitle':					urllib.unquote_plus(getParam('showtitle'))
			#,'par etitle':					urllib.unquote_plus(getParam('episodetitle'))
			#,'par eno':							urllib.unquote_plus(getParam('eno'))
			#,'par plotoutline':			urllib.unquote_plus(getParam('plotoutline'))
			#,'par plot':						urllib.unquote_plus(getParam('plot'))
			#,'par desc':						urllib.unquote_plus(getParam('desc'))
			#,'par description':			urllib.unquote_plus(getParam('description'))
			#,'par ext':							urllib.unquote_plus(getParam('ext'))
			#,'par res':							urllib.unquote_plus(getParam('res'))
			#,'build url':						buildUrlFromParams(y,z)
			#,'parse query':					parseQuery(y,z)
			,'default color0':			'tan'
			,'default color1':			'lime'
			,'default color2':			'yellow'
			,'default color3':			'red'
			,'default color4':			'grey'
			,'default color5':			'white'
			,'default color6':			'blanchedalmond'
			,'default color7':			'cornflowerblue'
			,'default color8':			'maroon'
			,'default color9':			'deeppink'
			,'default color10':			'green'
			,'default color11':			'purple'
			,'default color12':			'pink'
			,'default color13':			'mediumpurple'
			,'default color14':			''
			,'os': 									get_xbmc_os()
			,'changelog.local': 		'changelog.txt'
			,'GENRES_Notes': 				{'Dub':"English voices, no subtitle.",
															'Movie':"Movie",
															'Special':"Special",
															'OVA':"Original Animation Video & Original Video Animation (OAV / OVA) are interchangeable terms used in Japan to refer to animation that is released directly to the video market without first going through a theatrical release or television broadcast.\n\nFurthermore, OVA are supposed to have original scripts, although there are exceptions. They can be based on a Manga or TV series, but the particular episode should be original.",
															'Music':"Anime whose central theme revolves around singers/idols or people playing instruments. This category is not intended for finding AMVs (Animated Music Videos).",
															'Action':"Plays out mainly through a clash of physical forces. Frequently these stories have fast cuts, tough characters making quick decisions and usually a beautiful girl nearby. Anything quick and most likely a thin storyline.",
															'Adventure':"Exploring new places, environments or situations. This is often associated with people on long journeys to places far away encountering amazing things, usually not in an epic but in a rather gripping and interesting way.",
															'Cars':"Anime whose central theme revolves around cars and probably car races. A single character's obsession for cars does not mean that it should belong to this genre. Most of these stories also are in the action genre.",
															'Cartoon':"Not anime",
															'Comedy':"Multiple characters and/or events causing hilarious results. These stories are built upon funny characters, situations and events.",
															'Dementia':"Anime that have mind-twisting plots.",
															'Demons':"Anime that are set in a world where demons and other dark creatures play a significant role - the main character may even be one.",
															'Drama':"Anime that often show life or characters through conflict and emotions. In general, the different parts of the story tend to form a whole that is greater than the sum of the parts. In other words, the story has a message that is bigger than just the story line itself.",
															'Ecchi':"Anime that contain a lot of sexual innuendo. The translation of this letter (Ecchi is the letter 'H' in Japanese) is pervert. Ecchi is about panties (pantsu) and bra/breast showing, situations with \"sudden nudity\" and of course, subtle hints or sexual thoughts. Ecchi does not describe actual sex acts or show any intimate body parts except for bare breasts and buttocks. Ecchi is almost always used for humor.",
															'Fantasy':"Anime that are set in a mythical world quite different from modern-day Earth. Frequently this world has magic and/or mythical creatures such as dragons and unicorns. These stories are sometimes based on real world legends and myths. Frequently fantasies describe tales featuring magic, brave knights, damsels in distress, and/or quests.",
															'Game':"Anime whose central theme is based on a non-violent, non-sports game, like go, chess, trading card games or computer/video games.",
															'Harem':"Anime that involves one lead male character and many cute/pretty female support characters. Typically, the male lead ends up living with many female support characters within the same household. The lead male typically represents the average guy who is shy, awkward, and girlfriendless. While each female character surround the lead male possesses distinct physical and personality traits, those traits nevertheless represent different stereotypical roles that play on popular Japanese fetishes; i.e. the librarian/genius, tomboy, little sister, and older woman. Some anime that are under the harem genre are: Love Hina, Girls Bravo, Maburaho, and Sister Princess.",
															'Historical':"Anime whose setting is in the past. Frequently these follow historical tales, sagas or facts.",
															'Horror':"Anime whose focus is to scare the audience.",
															'Josei':"Josei",
															'Kids':"Anime whose target audience is children. This does not necessarily mean that the character(s) are children or that an anime whose main character(s) are children is appropriate for this genre.",
															'Magic':"Anime whose central theme revolves around magic. Things that are \"out of this world\" happen - incidents that cannot be explained by the laws of nature or science. Usually wizards/witches indicate that it is of the \"Magic\" type. This is a sub-genre of fantasy.",
															'Martial Arts':"Anime whose central theme revolves around martial arts. This includes all hand-to-hand fighting styles, including Karate, Tae-Kwon-Do and even Boxing. Weapons use, like Nunchaku and Shuriken are also indications of this genre. This is a sub-genre of action.",
															'Mecha':"Anime whose central theme involves mechanical things. This genre is mainly used to point out when there are giant robots. Human size androids are in general not considered \"Mecha\" but \"SciFi\".",
															'Military':"An anime series/movie that has a heavy militaristic feel behind it.",
															'Mystery':"Anime where characters reveal secrets that may lead a solution for a great mystery. This is not necessarily solving a crime, but can be a realization after a quest.",
															'ONA':"ONA",
															'Parody':"Anime that imitate other stories (can be from TV, film, books, historical events, ...) for comic effect by exaggerating the style and changing the content of the original. Also known as spoofs. This is a sub-genre of comedy.",
															'Police':"Anime where a police organization are a major part of the story.",
															'Psychological':"Often when two or more characters prey each others' minds, either by playing deceptive games with the other or by merely trying to demolish the other's mental state.",
															'Romance':"Anime whose story is about two people who each want [sometimes unconciously] to win or keep the love of the other. This kind of anime might also fall in the \"Ecchi\" category, while \"Romance\" and \"Hentai\" generally contradict each other.",
															'Samurai':"Anime whose main character(s) are samurai, the old, but not forgotten, warrior cast of medieval Japan.",
															'School':"Anime which are mainly set in a school environment.",
															'Sci-Fi':"Anime where the setting is based on the technology and tools of a scientifically imaginable world. The majority of technologies presented are not available in the present day and therefore the Science is Fiction. This incorporates any possible place (planets, space, underwater, you name it).",
															'Seinen':"Seinen",
															'Shoujo':"Anime that are targeted towards the \"young girl\" market. Usually the story is from the point of view of a girl and deals with romance, drama or magic.",
															'Shoujo Ai':"Anime whose central theme is about a relationship (or strong affection, not usually sexual) between two girls or women. Shoujo Ai literally means \"girl love\".",
															'Shounen':"In the context of manga and associated media, the word shounen refers to a male audience roughly between the ages of 10 and 18. In Japanese, the word means simply \"young male\", and has no anime/manga-related connotations at all. It does not comprise a style or a genre per se, but rather indicates the publisher`s intended target demographic. Still, while not mandatory, some easily identifiable traits are generally common to shounen works, such as: high-action, often humorous plots featuring male protagonists; camaraderie between male friends; sports teams and fighting squads (usually coupled with the aforementioned camaraderie); unrealistically attractive female characters (see fanservice). Additionally, the art style of shounen tends to be less flowery than that of shoujo and the plots tend to be less complex than seinen, but neither of those is a requirement.\nAnime that are targeted towards the \"young boy\" market. The usual topics for this involve fighting, friendship and sometimes super powers.",
															'Shounen Ai':"Anime whose central theme is about a relationship (or strong affection, not usually sexual) between two boys or men. Shounen Ai literally means \"boy love\", but could be expressed as \"male bonding\".",
															'Slice of Life':"Anime with no clear central plot. This type of anime tends to be naturalistic and mainly focuses around the main characters and their everyday lives. Often there will be some philosophical perspectives regarding love, relationships, life etc. tied into the anime. The overall typical moods for this type of anime are cheery and carefree, in other words, it is your \"feel-good\" kind of anime. Some anime that are under the slice of life genre are: Ichigo Mashimaro, Fruits Basket, Aria the Natural, Honey and Clover, and Piano.",
															'Space':"Anime whose setting is in outer space, not on another planet, nor in another dimension, but space. This is a sub-genre of scifi.",
															'Sports':"Anime whose central theme revolves around sports, examples are tennis, boxing and basketball.",
															'Super Power':"Anime whose main character(s) have powers beyond normal humans. Often it looks like magic, but can't really be considered magic; usually ki-attacks, flying or superhuman strength.",
															'Supernatural':"Anime of the paranormal stature. Demons, vampires, ghosts, undead, etc.",
															'Thriller':"Thriller",
															'Vampire':"Anime whose main character(s) are vampires or at least vampires play a significant role in the story.",
															'Yuri':"Anime whose central theme is a sexual relationship between two girls or women. This implies Hentai."}
			,'GENRES': 							['Dub','Movie','Special','OVA','Music','Action','Adventure','Cars','Cartoon','Comedy','Dementia','Demons','Drama','Ecchi','Fantasy','Game','Harem','Historical','Horror','Josei','Kids','Magic','Martial Arts','Mecha','Military','Mystery','ONA','Parody','Police','Psychological','Romance','Samurai','School','Sci-Fi','Seinen','Shoujo','Shoujo Ai','Shounen','Shounen Ai','Slice of Life','Space','Sports','Super Power','Supernatural','Thriller','Vampire','Yuri']
			,'cmi.showinfo.name':		'Information'
			,'cmi.showinfo.url':		'XBMC.Action(Info)'
			#,'': ''
			#,'': ''
			#,'': ''
			#,'': ''
		}[x.lower()]
	#except: return ''
### # ## ### ## Plugin Variables ## ### ## 
CurDate=time.strftime("%Y-%m-%d"); 
CurTime24=time.strftime("%H:%M"); 
CurTime12=time.strftime("%I:%M"); 
xBuildDate=xbmc.getInfoLabel("System.BuildDate"); #print ['xBuildDate',xBuildDate]; 			#ie: 'Apr 27 2014'
xBuildVersionWithGit=xbmc.getInfoLabel("System.BuildVersion"); #print ['xBuildVersion',xBuildVersion]; #ie: '13.0-RC1 Git:20140427-2372235'
try:		xBuildVersion=xBuildVersionWithGit.split('Git:')[0].strip(); print ['xBuildVersion',xBuildVersion]; #ie: '13.0-RC1'
except:	xBuildVersion='0.0.0-Unknown'
try:		xBuildVersionNumber=xBuildVersion.split('-')[0].strip()
except:	xBuildVersionNumber='0'
try:		xBuildVersionName=xBuildVersion.split('-')[1].strip()
except:	xBuildVersionName=''
try:		xBuildVersionNumberBIG=int(xBuildVersionNumber.split('.')[0].strip())
except:	xBuildVersionNumberBIG=0
try:		xBuildVersionNumberMEDIUM=int(xBuildVersionNumber.split('.')[1].strip())
except:	xBuildVersionNumberMEDIUM=0
try:		xBuildVersionNumberLITTLE=int(xBuildVersionNumber.split('.')[2].strip())
except:	xBuildVersionNumberLITTLE=0
#print ['XBMC Version',xBuildVersionNumberBIG,xBuildVersionNumberMEDIUM,xBuildVersionName]
#xBuildFriendlyName=xbmc.getInfoLabel("System.FriendlyName "); print ['xBuildFriendlyName',xBuildFriendlyName]; #ie: 'XBMC (...)'






### # ## ### ## --- ## ### ## 





### ############################################################################################################
### ############################################################################################################