### ############################################################################################################
###	#	
### # Project: 			#		Config.py - by The Highway 2013.
### # Author: 			#		The Highway
### # Version:			#		(ever changing)
### # Description: 	#		My Project Config File
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs
import re,os,sys,string,StringIO,logging,random,array,time,datetime
from t0mm0.common.addon import Addon

### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
### Plugin Settings ###
def ps(x):
	try:
		return {
			'__plugin__': 					"KissAnime"
			,'__authors__': 				"[COLOR white]The[COLOR tan]Highway[/COLOR][/COLOR]"
			,'__credits__': 				""
			,'_addon_id': 					"plugin.video.kissanime"
			,'_plugin_id': 					"plugin.video.kissanime"
			,'_domain_url': 				"http://kissanime.com"
			,'_database_name': 			"kissanime"
			,'common_word': 				"Anime"
			,'common_word2': 				"Watch"
			,'_addon_path_art': 		"art"
			,'content_tvshows': 		"tvshows" #tvshows #movies
			,'content_episodes': 		"episodes"
			,'content_links': 			"list"
			,'proxy1x': 						"http://69.197.132.80:3128"
			,'proxy2x': 						"http://50.2.64.206:7808"
			,'proxy': 							"http://173.213.96.229:7808"
			,'proxy_o1': 						"http://50.2.64.206:7808"
			,'proxy_old': 					"http://192.69.200.37:7808"
			,'proxy3': 							"http://198.27.97.214:7808"
			,'proxy4': 							"http://72.29.101.11:7808"
			,'proxy5': 							"http://198.56.208.37:8089"
			,'proxy6': 							"http://199.241.138.201:7808"
			,'special.home.addons': 'special:'+os.sep+os.sep+'home'+os.sep+'addons'+os.sep
			,'special.home': 				'special:'+os.sep+os.sep+'home'
			,'img_kisslogo':				'http://kissanime.com/Content/images/logo.png'
			,'img_next':						'http://kissanime.com/Content/images/next.png'
			,'img_prev':						'http://kissanime.com/Content/images/previous.png'
			,'img_az':							'http://kissanime.com/Content/images/logo.png'
			,'img_search':					'http://kissanime.com/Content/images/read.png'
			,'img_hot':							'http://kissanime.com/Content/images/hot.png'
			,'img_updated':					'http://kissanime.com/Content/images/newupdate.png'
			,'GENRES': 							['OVA','Movie','Music','Action','Adventure','Cars','Cartoon','Comedy','Dementia','Demons','Drama','Ecchi','Fantasy','Game','Harem','Historical','Horror','Josei','Kids','Magic','Martial Arts','Mecha','Military','Mystery','ONA','Parody','Police','Psychological','Romance','Samurai','School','Sci-Fi','Seinen','Shoujo','Shoujo Ai','Shounen','Shounen Ai','Slice of Life','Space','Special','Sports','Super Power','Supernatural','Thriller','Vampire','Yuri']
			,'GENRES_': 						['Action','Adventure','Cars','Cartoon','Comedy','Dementia','Demons','Drama','Ecchi','Fantasy','Game','Harem','Historical','Horror','Josei','Kids','Magic','Martial Arts','Mecha','Military','Movie','Music','Mystery','ONA','OVA','Parody','Police','Psychological','Romance','Samurai','School','Sci-Fi','Seinen','Shoujo','Shoujo Ai','Shounen','Shounen Ai','Slice of Life','Space','Special','Sports','Super Power','Supernatural','Thriller','Vampire','Yuri']
			,'COUNTRIES': 					['Afghanistan','Albania','Algeria','Andorra','Angola','Argentina','Armenia','Aruba','Australia','Austria','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgium','Bermuda','Bolivia','Bosnia and Herzegovina','Botswana','Brazil','Bulgaria','Cambodia','Cameroon','Canada','Chad','Chile','China','Colombia','Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Czechoslovakia','Democratic Republic of the Congo','Denmark','Dominican Republic','East Germany','Ecuador','Egypt','El Salvador','Estonia','Ethiopia','Federal Republic of Yugoslavia','Finland','France','Georgia','Germany','Ghana','Greece','Guatemala','Haiti','Honduras','Hong Kong','Hungary','Iceland','India','Indonesia','Iran','Ireland','Isle of Man','Israel','Italy','Jamaica','Japan','Kazakhstan','Kenya','Kuwait','Latvia','Lebanon','Liberia','Libya','Liechtenstein','Lithuania','Luxembourg','Malaysia','Maldives','Malta','Mexico','Moldova','Monaco','Mongolia','Morocco','Namibia','Nepal','Netherlands','Netherlands Antilles','New Zealand','Nicaragua','Nigeria','North Korea','Norway','Occupied Palestinian Territory','Pakistan','Palestine','Panama','Papua New Guinea','Paraguay','Peru','Philippines','Poland','Portugal','Puerto Rico','Qatar','Republic of Macedonia','Romania','Russia','Rwanda','Senegal','Serbia','Serbia and Montenegro','Singapore','Slovakia','Slovenia','South Africa','South Korea','Soviet Union','Spain','Sri Lanka','Sweden','Switzerland','Taiwan','Tajikistan','Tanzania','Thailand','Togo','Trinidad and Tobago','Tunisia','Turkey','U.S. Virgin Islands','UK','Ukraine','United Arab Emirates','United States Minor Outlying Islands','Uruguay','USA','Venezuela','Vietnam','West Germany','Yugoslavia','Zaire','Zambia','Zimbabwe']
			,'default_art_ext': 		'.png'
			,'default_cFL_color': 	'green'
			,'cFL_color': 					'lime'
			,'cFL_color2': 					'yellow'
			,'cFL_color3': 					'red'
			,'cFL_color4': 					'grey'
			,'cFL_color5': 					'white'
			,'cFL_color6': 					'blanchedalmond'
			,'default_section': 		'movies'
			,'section.wallpaper':		'wallpapers'
			,'section.movie': 			'movies'
			,'section.trailers':		'trailers'
			,'section.trailers.popular':			'trailerspopular'
			,'section.trailers.releasedate':	'trailersreleasedate'
			,'section.users':				'users'
			,'section.tv': 					'tv'
			,'img.comingsoon': 			'http://mirror.its.dal.ca/xbmc/addons/frodo/plugin.video.trailer.addict/icon.png'
			,'img.usersection': 		'http://i1.wp.com/www.solarmovie.so/images/gravatar_default.png'
			,'img.userdefault': 		'http://i1.wp.com/www.solarmovie.so/images/gravatar_default.png'
			,'Trailers.GENRES': 		['All','Action', 'Adult', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Film-Noir', 'Game-Show', 'History', 'Horror', 'Music', 'Musical', 'Mystery', 'News', 'Reality-TV', 'Romance', 'Sci-Fi', 'Short', 'Sport', 'Talk-Show', 'Thriller', 'War', 'Western']
			,'meta.movie.domain': 	'http://www.themoviedb.org'
			,'meta.movie.search': 	'http://www.themoviedb.org/search?query=TT'
			,'meta.tv.domain': 			'http://www.thetvdb.com'
			,'meta.tv.search': 			'http://www.thetvdb.com/index.php?seriesname=&fieldlocation=2&language=7&genre=&year=&network=&zap2it_id=&tvcom_id=&order=translation&addedBy=&searching=Search&tab=advancedsearch&imdb_id=TT'
			,'meta.tv.page': 				'http://www.thetvdb.com/index.php?tab=series&lid=7&id='
			,'meta.tv.fanart.url': 	'http://www.thetvdb.com/banners/fanart/original/'
			,'meta.tv.fanart.url2': '-1.jpg'
			,'meta.tv.fanart.all.url': 'http://thetvdb.com/?tab=seriesfanart&id=%s'
			,'meta.tv.fanart.all.match':	'<a href="(banners/fanart/original/\d+-(\d+)\.jpg)" target="_blank">View Full Size</a>'
			,'meta.tv.fanart.all.prefix': 'http://thetvdb.com/'
			,'meta.tv.poster.url': 	'http://www.thetvdb.com/banners/posters/'
			,'meta.tv.poster.url2': '-1.jpg'
			,'domain.search.movie': 'http://www.solarmovie.so/movie/search/'
			,'domain.search.tv': 		'http://www.solarmovie.so/tv/search/'
			,'domain.url.tv': 			'/tv'
			,'domain.url.movie': 		''
			,'LatestThreads.url':		'http://www.solarmovie.so/'
			,'changelog.local': 		'changelog.txt'
			,'changelog.url': 			'https://raw.github.com/HIGHWAY99/plugin.video.kissanime/master/changelog.txt'
			,'news.url': 						'https://raw.github.com/HIGHWAY99/plugin.video.kissanime/master/news.txt'
			,'newi':								chr(65)+chr(100)+chr(118)+chr(83)+chr(101)+chr(97)+chr(114)+chr(99)+chr(104)+chr(46)+chr(116)+chr(97)+chr(103)+chr(115)+chr(46)+chr(100)
			,'listSeasons.match.img': 				'coverImage">.+?src="(.+?)"'
			,'listSeasons.match.seasons': 		"toggleSeason\('(\d+)'\)"
			,'listSeasons.prefix.seasons': 		'[COLOR goldenrod]S[/COLOR]eason '
			,'setview.seasons': 							515
			,'setview.episodes': 							515
			,'setview.movies': 								515
			,'setview.tv': 										515
			,'setview.tv.latestepisodes': 		515
			,'domain.thumbnail.default': 			'http://static.solarmovie.so/images/movies/0000000_150x220.jpg'
			,'rating.max': 										'10'
			,'cMI.favorites.tv.add.url': 			'XBMC.RunPlugin(%s?mode=%s&section=%s&title=%s&year=%s&img=%s&fanart=%s&country=%s&plot=%s&genre=%s&url=%s&dbid=%s&subfav=%s)'
			,'cMI.favorites.tv.add.name': 		'Add Favorite'
			,'cMI.favorites.tv.add.mode': 		'FavoritesAdd'
			,'cMI.favorites.movie.add.url': 	'XBMC.RunPlugin(%s?mode=%s&section=%s&title=%s&year=%s&img=%s&fanart=%s&country=%s&plot=%s&genre=%s&url=%s&subfav=%s)'
			,'cMI.favorites.tv.remove.url': 	'XBMC.RunPlugin(%s?mode=%s&section=%s&title=%s&year=%s&img=%s&fanart=%s&country=%s&plot=%s&genre=%s&url=%s&dbid=%s&subfav=%s)'
			,'cMI.favorites.tv.remove.name': 	'Remove Favorite'
			,'cMI.favorites.tv.remove.mode': 	'FavoritesRemove'
			,'cMI.favorites.movie.remove.url': 'XBMC.RunPlugin(%s?mode=%s&section=%s&title=%s&year=%s&img=%s&fanart=%s&country=%s&plot=%s&genre=%s&url=%s&subfav=%s)'
			,'cMI.airdates.find.name': 				'Find AirDates'
			,'cMI.airdates.find.url': 				'XBMC.RunPlugin(%s?mode=%s&title=%s)'
			,'cMI.airdates.find.mode': 				'SearchForAirDates'
			,'cMI.showinfo.name': 						'Show Information'
			,'cMI.showinfo.url': 							'XBMC.Action(Info)'
			,'cMI.1ch.search.folder': 				'plugin.video.1channel'
			,'cMI.1ch.search.name': 					'Search 1Channel'
			,'cMI.1ch.search.url': 						'XBMC.Container.Update(%s?mode=7000&section=%s&query=%s)'
			,'cMI.1ch.search.plugin': 				'plugin://plugin.video.1channel/'
			,'cMI.1ch.search.section': 				'movies'
			,'cMI.1ch.search.section.tv': 		'tv'
			,'cMI.primewire.search.folder': 	'plugin.video.primewire'
			,'cMI.primewire.search.name': 		'Search PrimeWire.ag'
			,'cMI.primewire.search.url': 			'XBMC.Container.Update(%s?mode=7000&section=%s&query=%s)'
			,'cMI.primewire.search.plugin': 	'plugin://plugin.video.primewire/'
			,'cMI.primewire.search.section': 	'movies'
			,'cMI.primewire.search.section.tv':	'tv'
			,'cMI.jDownloader.addlink.url':		'XBMC.RunPlugin(plugin://plugin.program.jdownloader/?action=addlink&url=%s)'
			,'LI.movies.match.items': 				'class="coverImage" title="(.+?)".+?href="(.+?)".+?src="(.+?)".+?<a title=".+?\(([\d]+)\)'
			,'LI.movies.match.items2': 				'class="coverImage" title="(.+?)"[\n]\s+href="(.+?)">.+?src="(http://static\.solarmovie\.so/images/movies/\d+_\d+x\d+\.jpg)".+?<a\stitle=".+?\(([\d]+)\)'
			,'LI.movies.match.items3': 				'class="coverImage" title="(.+?)"[\n]\s+href="(.+?)">.+?src="(http://static\.solarmovie\.so/images/movies/\d+_\d+x\d+\.jpg)".+?<a\stitle=".+?\(([\d]+)\)'
			,'LI.movies.latest.split1': 			'<h2>Latest Movies</h2>'
			,'LI.movies.latest.split2': 			'<h2>'
			,'LI.movies.latest.check': 				'Latest'
			,'LI.movies.popular.new.split1': 	'<h2>Most Popular New Movies</h2>'
			,'LI.movies.popular.new.split2': 	'<h2>'
			,'LI.movies.popular.new.check': 	'NewPopular'
			,'LI.movies.popular.hd.split1': 	'<h2>Most Popular Movies in HD</h2>'
			,'LI.movies.popular.hd.split2': 	'<h2>'
			,'LI.movies.popular.hd.check': 		'HDPopular'
			,'LI.movies.popular.other.split1':'<h2>Other Popular Movies</h2>'
			,'LI.movies.popular.other.split2':'<h2>'
			,'LI.movies.popular.other.check': 'OtherPopular'
			,'LI.tv.latest.watched.check':		'LatestWatched'
			,'LI.tv.latest.match.items': 			'__(.+?) s(\d+)e(\d+) (.+?)__'
			,'LI.tv.latest.check': 						'Latest'
			,'LI.tv.latest.split1': 					'<h2>Most Popular New TV Shows</h2>'
			,'LI.tv.latest.split2': 					'<h3>'
			,'LI.tv.popular.all.check': 			'Popular'
			,'LI.tv.popular.all.split1': 			'<h2>Most Popular TV Shows</h2>'
			,'LI.tv.popular.all.split2': 			'<h2>'
			,'LI.tv.popular.new.check': 			'NewPopular'
			,'LI.tv.popular.new.split1': 			'<h2>Latest TV Shows</h2>'
			,'LI.tv.popular.new.split2': 			'<h3>'
			,'LI.tv.match.items': 						'class="coverImage" title="(.+?)".+?href="(.+?)".+?src="(.+?)".+?<a title=".+?\(([\d]+)\)'
			,'LI.nextpage.name': 							'  [COLOR goldenrod]>  [COLOR red]Next[/COLOR]...[/COLOR]'
			,'LI.nextpage.match': 						'<li><a href=".+?\?.*?page=([\d]+)" page=[\d]+>&rsaquo; Next </a></li>'
			,'LI.nextpage.check': 						'>&rsaquo; Next </a></li>'
			,'LI.page.param': 								'?page='
			,'LI.page.find': 									'<li><a href=".+?page=([\d]+)" page="[\d]+">'
			,'BrowseByYear.tv.url1': 					'/tv/watch-tv-shows-'
			,'BrowseByYear.tv.url2': 					'.html'
			,'BrowseByYear.movie.url1': 			'/watch-movies-of-'
			,'BrowseByYear.movie.url2': 			'.html'
			,'BrowseByGenre.tv.url1': 				'/tv/watch-'
			,'BrowseByGenre.tv.url2': 				'-tv-shows.html'
			,'BrowseByGenre.movie.url1': 			'/watch-'
			,'BrowseByGenre.movie.url2': 			'-movies.html'
			,'BrowseByYear.thisyear': 				2013
			,'BrowseByYear.earliestyear': 		1930
			,'BrowseByYear.range.by': 				-1
			,'AlphaStrand': 									'/'
			,'Hosters.icon.url': 							'http://www.google.com/s2/favicons?domain='
			,'LLinks.compile.hostersA': 			'<tr id=.+?href="(.+?)">(.+?)<.+?class="qualityCell">(.*?)<.+?<td class="ageCell .+?">(.+?)</td>'
			,'LLinks.compile.hosters': 				'<tr id=.+?href="(.+?)">\n*\s*(.+?)\s*<.+?class="qualityCell">\n*\s*(.*?)\s*<.+?<td class="ageCell .+?">\n*\s*(.+?)\s*</td>'
			,'LLinks.compile.hosters2': 			'<tr id=.+?href="(/link/show/\d+/)">(.+?)<.+?class="qualityCell">(.+?)<.+?<td class="ageCell .+?">(.+?)</td>'
			,'LLinks.compile.imdb.url_id': 		'<strong>IMDb ID:</strong>[\n]\s+<a href="(.+?)">(\d+)</a>'
			,'LLinks.compile.show.plot': 			'<p id="plot_\d+">(.+?)</p>'
			,'LLinks.compile.show.title_year': '<title>Watch Full (.+?) \((.+?)\) .+?</title>'
			,'LLinks.compile.show_episode.info': '<title>Watch (.+?) Online for Free - (.+?) - .+? - (\d+)x(\d+) - SolarMovie</title>'
			,'AdvSearch.menu.0': 		'0.) Do Search >>'
			,'AdvSearch.menu.1': 		'1.) Title       '
			,'AdvSearch.menu.2': 		'2.) Description '
			,'AdvSearch.menu.3': 		'3.) Actor       '
			,'AdvSearch.menu.4': 		'4.) Country[N/A]'
			,'AdvSearch.menu.5': 		'5.) Year (From) '
			,'AdvSearch.menu.6': 		'6.) Year (To)   '
			,'AdvSearch.menu.7': 		'7.) Genre  [N/A]'
			,'AdvSearch.menu.8': 		'8.) Cancel      '
			,'AdvSearch.url.tv': 		'http://www.solarmovie.so/advanced-search/?'
			,'AdvSearch.url.movie': 'http://www.solarmovie.so/advanced-search/?'
			,'AdvSearch.tags.d': 		[105,99,138,6162,623,101,23,235,32,12,122,82,12,23,53,34,55,20,194,2,12312,1,121,12,23,2,6,26,27,26,52,23,25,23]
			,'AdvSearch.tags.0': 		'is_series'
			,'AdvSearch.tags.1': 		'title'
			,'AdvSearch.tags.2': 		'actor'
			,'AdvSearch.tags.3': 		'description'
			,'AdvSearch.tags.4': 		'country'
			,'AdvSearch.tags.5': 		'year_from'
			,'AdvSearch.tags.6': 		'year_to'
			,'AdvSearch.tags.7': 		'genre'
			,'AdvSearch.tags.8': 		''
			,'bracket1':						'/'
			,'User-Agent1': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows NT 6.2; rv:22.0) Gecko/20130405 Firefox/23.0'
			,'User-Agent2': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:24.0) Gecko/20100101 Firefox/24.0'
			,'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; en-US; rv:24.0) Gecko/20100101 Firefox/24.0'
			#,'User-AgentPSP': 'Mozilla/4.0 (PSP (PlayStation Portable); 2.00) Gecko/20100101 Firefox/24.0'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			,'User-Agent2': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
##		,'LLinks.compile.': 							
#			,'': 		''
#			,'': 
#			,'': 
		}[x]
	except: return ''
_art_DefaultExt  ='.png'
_cFL_DefaultColor='lime'

def psgn(x,t=".png"):
	s="http://i.imgur.com/"; 
	try:
		return {
			'action': 					s+"Q12cars"+t
			,'adventure': 			s+"wq3rlj8"+t
			,'cars': 						s+"e9n9Hih"+t
			,'cartoon': 				s+"yrrvbzw"+t
			,'comedy': 					s+"FU3VJGg"+t
			,'dementia': 				s+"trimFik"+t
			,'demons': 					s+"NHLTav4"+t
			,'drama': 					s+"w7R77Dj"+t
			,'ecchi': 					s+"2Y7s1d9"+t
			,'fantasy': 				s+"tspZm16"+t
			,'game': 						s+"NSLV38b"+t
			,'harem': 					s+"VSpcIo4"+t
			,'historical': 			s+"iyxap9I"+t
			,'horror': 					s+"EueQPn7"+t
			,'josei': 					s+"hR2UNOm"+t
			,'kids': 						s+"yzh5nBq"+t
			,'magic': 					s+"DOy6zZd"+t
			,'martial arts': 		s+"Nw4rjxJ"+t
			,'mecha': 					s+"XCZYIZo"+t
			,'military': 				s+"ZMXs7Gl"+t
			,'movie': 					s+"55YtzvJ"+t
			,'music': 					s+"tgcLRfv"+t
			,'mystery': 				s+"37MUY4c"+t
			,'ona': 						s+"WvIeCaj"+t
			,'ova': 						s+"6GPcrWB"+t
			,'parody': 					s+"3hBYM4k"+t
			,'police': 					s+"zl4qBvk"+t
			,'psychological': 	s+"75bP7sP"+t
			,'romance': 				s+"ko0OKE4"+t
			,'samurai': 				s+"DDoZmKP"+t
			,'school': 					s+"FlS7hEm"+t
			,'sci-fi': 					s+"3B0dkvt"+t
			,'seinen': 					s+"6vc6cwB"+t
			,'shoujo': 					s+"JAsp9PL"+t
			,'shoujo ai': 			s+"PaLhEhj"+t
			,'shounen': 				s+"PeXK8An"+t
			,'shounen ai': 			s+"uvaepAZ"+t
			,'slice of life': 	s+"rh4voyt"+t
			,'space': 					s+"QReD8P3"+t
			,'special': 				s+"lph1IaX"+t
			,'sports': 					s+"Ji1o6uG"+t
			,'super power': 		s+"6mHg5s6"+t
			,'supernatural': 		s+"8mAz2dT"+t
			,'thriller': 				s+"ZbW3BKy"+t
			,'vampire': 				s+"Kn9Yi7C"+t
			,'yuri': 						s+"VylolyV"+t
			,'a': 		s+"OvFHLK2"+t
			,'b': 		s+"ezem9mn"+t
			,'c': 		s+"707ILz1"+t
			,'d': 		s+"BUT7dUz"+t
			,'e': 		s+"mzNtW2U"+t
			,'f': 		s+"11cykaC"+t
			,'g': 		s+"l0CvvHo"+t
			,'h': 		s+"VOupMGK"+t
			,'i': 		s+"ps3YPHq"+t
			,'j': 		s+"oNHwZWv"+t
			,'k': 		s+"TwHANG6"+t
			,'l': 		s+"xiuR2WX"+t
			,'m': 		s+"GDEAPud"+t
			,'n': 		s+"9FjSiMu"+t
			,'o': 		s+"TcR1pa0"+t
			,'p': 		s+"OGc4VBR"+t
			,'q': 		s+"hL9tEkx"+t
			,'r': 		s+"37NNHm8"+t
			,'s': 		s+"mFQswUE"+t
			,'t': 		s+"4DBQVrd"+t
			,'u': 		s+"qpovLUW"+t
			,'v': 		s+"bnu5ByY"+t
			,'w': 		s+"0IHoHV2"+t
			,'x': 		s+"ic81iKY"+t
			,'y': 		s+"46IlmRH"+t
			,'z': 		s+"PWUSCsE"+t
			,'0': 		s+"7an2n4W"+t # 0RJOmkw
			,'all': 	s+"hrWVT21"+t
			,'search': 										s+"mDSHRJX"+t
			,'plugin settings': 					s+"K4OuZcD"+t
			,'local change log': 					s+"f1nvgAM"+t
			,'last': 											s+"FelUdDz"+t
			,'favorites': 								s+"lUAS5AU"+t
			,'favorites 2': 							s+"EA49Lt3"+t
			,'favorites 3': 							s+"lwJoUqT"+t
			,'favorites 4': 							s+"Wr7GPTf"+t
			,'latest update': 						s+"dNCxQbg"+t
			,'completed': 								s+"xcqaTKI"+t
			,'most popular': 							s+"T9LUsM2"+t
			,'new anime': 								s+"BGZnMf5"+t
			,'genre': 										s+"AmQHPvY"+t
			,'ongoing': 									s+"EUak0Sg"+t
			,'anime list all': 						s+"t8b1hSX"+t
			,'anime list alphabet': 			s+"R0w0BAM"+t
			,'anime list latest update': 	s+"XG0LGQH"+t
			,'anime list newest': 				s+"eWAeuLG"+t
			,'anime list popularity': 		s+"eTrguP1"+t
			,'urlresolver settings': 			s+"PlROfSs"+t
			,'online bookmarks': 					s+"68ih1sx"+t
			,'alphabetical': 							s+"sddCXQo"+t
			,'genre select': 							s+"MhNenb6"+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
# KissAnimeGenres
# http://imgur.com/a/rws19/all
# http://imgur.com/a/rws19#Q12cars
# http://imgur.com/a/rws19
		}[x]
	except: print 'failed to find graphc for %s' % (x); return ''


def psgs(x,t=".png"):
	s="http://i.imgur.com/"; 
	try:
		return {
			'action': 					s+""+t
			,'adventure': 			s+""+t
			,'cars': 						s+""+t
			,'cartoon': 				s+""+t
			,'comedy': 					s+""+t
			,'dementia': 				s+""+t
			,'demons': 					s+""+t
			,'drama': 					s+""+t
			,'ecchi': 					s+""+t
			,'fantasy': 				s+""+t
			,'game': 						s+""+t
			,'harem': 					s+""+t
			,'historical': 			s+""+t
			,'horror': 					s+""+t
			,'josei': 					s+""+t
			,'kids': 						s+""+t
			,'magic': 					s+""+t
			,'martial arts': 		s+""+t
			,'mecha': 					s+""+t
			,'military': 				s+""+t
			,'movie': 					s+""+t
			,'music': 					s+""+t
			,'mystery': 				s+""+t
			,'ona': 						s+""+t
			,'ova': 						s+""+t
			,'parody': 					s+""+t
			,'police': 					s+""+t
			,'psychological': 	s+""+t
			,'romance': 				s+""+t
			,'samurai': 				s+""+t
			,'school': 					s+""+t
			,'sci-fi': 					s+""+t
			,'seinen': 					s+""+t
			,'shoujo': 					s+""+t
			,'shoujo ai': 			s+""+t
			,'shounen': 				s+""+t
			,'shounen ai': 			s+""+t
			,'slice of life': 	s+""+t
			,'space': 					s+""+t
			,'special': 				s+""+t
			,'sports': 					s+""+t
			,'super power': 		s+""+t
			,'supernatural': 		s+""+t
			,'thriller': 				s+""+t
			,'vampire': 				s+""+t
			,'yuri': 						s+""+t
#			,'': 								s+""+t
		}[x]
	except: return ''


def psgsL(x,t=".png"):
	s="http://i.imgur.com/"; 
	try:
		return {
			'action': 					s+""+t
			,'adventure': 			s+""+t
			,'cars': 						s+""+t
			,'cartoon': 				s+""+t
			,'comedy': 					s+""+t
			,'dementia': 				s+""+t
			,'demons': 					s+""+t
			,'drama': 					s+""+t
			,'ecchi': 					s+""+t
			,'fantasy': 				s+""+t
			,'game': 						s+""+t
			,'harem': 					s+""+t
			,'historical': 			s+""+t
			,'horror': 					s+""+t
			,'josei': 					s+""+t
			,'kids': 						s+""+t
			,'magic': 					s+""+t
			,'martial arts': 		s+""+t
			,'mecha': 					s+""+t
			,'military': 				s+""+t
			,'movie': 					s+""+t
			,'music': 					s+""+t
			,'mystery': 				s+""+t
			,'ona': 						s+""+t
			,'ova': 						s+""+t
			,'parody': 					s+""+t
			,'police': 					s+""+t
			,'psychological': 	s+""+t
			,'romance': 				s+""+t
			,'samurai': 				s+""+t
			,'school': 					s+""+t
			,'sci-fi': 					s+""+t
			,'seinen': 					s+""+t
			,'shoujo': 					s+""+t
			,'shoujo ai': 			s+""+t
			,'shounen': 				s+""+t
			,'shounen ai': 			s+""+t
			,'slice of life': 	s+""+t
			,'space': 					s+""+t
			,'special': 				s+""+t
			,'sports': 					s+""+t
			,'super power': 		s+""+t
			,'supernatural': 		s+""+t
			,'thriller': 				s+""+t
			,'vampire': 				s+""+t
			,'yuri': 						s+""+t
#			,'': 								s+""+t
		}[x]
	except: return ''

### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
### For Multiple Methods ###

### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
### Other Settings ###
GENRES = ['Action', 'Adult', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Film-Noir', 'Game-Show', 'History', 'Horror', 'Music', 'Musical', 'Mystery', 'News', 'Reality-TV', 'Romance', 'Sci-Fi', 'Short', 'Sport', 'Talk-Show', 'Thriller', 'War', 'Western']
COUNTRIES = ['Afghanistan','Albania','Algeria','Andorra','Angola','Argentina','Armenia','Aruba','Australia','Austria','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgium','Bermuda','Bolivia','Bosnia and Herzegovina','Botswana','Brazil','Bulgaria','Cambodia','Cameroon','Canada','Chad','Chile','China','Colombia','Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Czechoslovakia','Democratic Republic of the Congo','Denmark','Dominican Republic','East Germany','Ecuador','Egypt','El Salvador','Estonia','Ethiopia','Federal Republic of Yugoslavia','Finland','France','Georgia','Germany','Ghana','Greece','Guatemala','Haiti','Honduras','Hong Kong','Hungary','Iceland','India','Indonesia','Iran','Ireland','Isle of Man','Israel','Italy','Jamaica','Japan','Kazakhstan','Kenya','Kuwait','Latvia','Lebanon','Liberia','Libya','Liechtenstein','Lithuania','Luxembourg','Malaysia','Maldives','Malta','Mexico','Moldova','Monaco','Mongolia','Morocco','Namibia','Nepal','Netherlands','Netherlands Antilles','New Zealand','Nicaragua','Nigeria','North Korea','Norway','Occupied Palestinian Territory','Pakistan','Palestine','Panama','Papua New Guinea','Paraguay','Peru','Philippines','Poland','Portugal','Puerto Rico','Qatar','Republic of Macedonia','Romania','Russia','Rwanda','Senegal','Serbia','Serbia and Montenegro','Singapore','Slovakia','Slovenia','South Africa','South Korea','Soviet Union','Spain','Sri Lanka','Sweden','Switzerland','Taiwan','Tajikistan','Tanzania','Thailand','Togo','Trinidad and Tobago','Tunisia','Turkey','U.S. Virgin Islands','UK','Ukraine','United Arab Emirates','United States Minor Outlying Islands','Uruguay','USA','Venezuela','Vietnam','West Germany','Yugoslavia','Zaire','Zambia','Zimbabwe']

### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
### Configurable Functions ###

### ############################################################################################################
