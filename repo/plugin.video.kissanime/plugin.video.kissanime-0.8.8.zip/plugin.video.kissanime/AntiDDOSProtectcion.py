# -*- coding: utf-8 -*-
##import AntiDDOSProtectcion

import urllib2,urlparse,re,cookielib,xbmc,os,time
def decryptCFDDOSProtection(url,agent='',DomainD='',AddonID=''):
    #try:
        class NoRedirection(urllib2.HTTPErrorProcessor):    
            def http_response(self,request,response):
                return response
        ##
        #DomainFix='kissanime.com'
        #DomainFix='.kissanime.com'
        #url=url.replace('http://','https://')
        url=url.replace('https://','http://')
        cf_html_file=xbmc.translatePath(os.path.join('special://home','addons',AddonID,'CF_html.txt'))
        ##
        if len(agent)==0: agent='Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'
        #agent='Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'
        cj=cookielib.CookieJar()
        ##
        opener=urllib2.build_opener(NoRedirection, urllib2.HTTPCookieProcessor(cj))
        opener.addheaders=[('User-Agent', agent)]
        response=opener.open(url)
        try: cookie2=str(response.headers.get('Set-Cookie'))
        except: cookie2=''
        print ['cookie2',cookie2]
        result=response.read()
        #try: 
        CF_SaveFile(cf_html_file,result)
        #except: pass
        #print result
        ##
        s='<link rel="shortcut icon" href="/Content/images/favicon.ico" type="image/x-icon" /><script type="text/javascript">'
        if s in result:
        	result=result.split(s)[-1]
        jschl=re.compile('name="jschl_vc" value="(.+?)"/>').findall(result)[0]
        print ['jschl',jschl]
        ##
        init=re.compile('setTimeout\(function\(\){\s*\n*\s*(?:var \D,\D,\D,\D, [0-9A-Za-z]+={"[0-9A-Za-z]+"|.*?.*):(.*?)};').findall(result)[0]
        ##init=re.compile('setTimeout\(function\(\){\s*.*?.*:(.*?)};').findall(result)[0]
        print ['init',init]
        ##builder=re.compile(r"challenge-form\'\);\s*(.*)a.v").findall(result)[0]
        builder=re.compile(r"challenge-form\'\);\s*\n*\r*\a*\s*(.*)a.v").findall(result)[0]
        ##builder=re.compile(r"challenge-form\'\);\s*(.*)a.v").findall(result.replace('\n','').replace('\r','').replace('\a',''))[0]
        print ['builder',builder]
        try: TimeToWait=int(re.compile(r"f.submit\(\);\s*\n*\s*},\s*(\d+)\);\s*\n*\s*},\s*\D+);").findall(result)[0])
        except: TimeToWait=5850
        print ['TimeToWait',TimeToWait]
        decryptVal=CF_parseJSString(init)
        print ['decryptVal',decryptVal]
        lines=builder.split(';')
        ##
        for line in lines:
            if len(line)>0 and '=' in line:
                try:
                    sections=line.split('=')
                    ##
                    line_leftside=sections[0]
                    line_val=CF_parseJSString(sections[1])
                    decryptVal=int(eval(str(decryptVal)+sections[0][-1]+str(line_val)))
                    #if line_leftside.endswith('*'):
                    #	decryptVal=int(eval(str(decryptVal)*sections[0][-1]+str(line_val)))
                    #elif line_leftside.endswith('-'):
                    #	decryptVal=int(eval(str(decryptVal)-sections[0][-1]+str(line_val)))
                    #elif line_leftside.endswith('+'):
                    #	decryptVal=int(eval(str(decryptVal)+sections[0][-1]+str(line_val)))
                    #else:
                    #	decryptVal=int(eval(str(decryptVal)+sections[0][-1]+str(line_val)))
                except: pass
                
        ##
        print ['decryptVal',decryptVal]
        DomainFix=urlparse.urlparse(url).netloc
        if '/' in DomainFix: DomainFix=DomainFix.split('/')[0]
        if 'www.' in DomainFix: DomainFix=DomainFix.replace('www.','')
        print ['DomainFix',DomainFix,len(DomainFix)]
        answer=decryptVal+len(DomainFix)
        print ['answer',answer]
        ##
        try: Domain=re.compile('(\D+://.+?)/').findall(url)[0]
        except: Domain=DomainD
        print ['Domain',Domain]
        #query='%s/cdn-cgi/l/chk_jschl?jschl_vc=%s&jschl_answer=%s'%(url,jschl,answer)
        query='%s/cdn-cgi/l/chk_jschl?jschl_vc=%s&jschl_answer=%s'%(str(Domain),str(jschl),str(answer))
        print ['query',query]
        ##
        xbmc.sleep(5850)
        opener=urllib2.build_opener(NoRedirection,urllib2.HTTPCookieProcessor(cj))
        opener.addheaders=[('User-Agent',agent)]
        response=opener.open(query)
        cookie=str(response.headers.get('Set-Cookie'))
        print ['cookie',cookie]
        result=response.read()
        response.close()
        cf_html_file=xbmc.translatePath(os.path.join('special://home','addons',AddonID,'CF_htmlr.txt'))
        CF_SaveFile(cf_html_file,result)
        
        xbmc.sleep(2000)
        ##
        FoundCookies=''
        #if (len(str(cookie2)) > 5): FoundCookies+='\r\nSet-Cookie3: '+str(cookie2)
        if (len(str(cookie )) > 5): FoundCookies+='\r\nSet-Cookie3: '+str(cookie)+'\r\n'
        print ['FoundCookies',FoundCookies]
        p=[]
        p.append(['cf_clearance=','cf_clearance="'])
        p.append(['; ','"; '])
        p.append([' expires=',' expires="'])
        p.append([' path=',' path="'])
        p.append([' domain=',' domain="'])
        p.append(['',''])
        for p1,p2 in p:
        	FoundCookies=FoundCookies.replace(p1,p2)
        
        
        print ['FoundCookies',FoundCookies]
        #FoundCookies='\r\nSet-Cookie3: '+str(cookie)+'\r\nSet-Cookie3: '+str(cookie2)
        ##
        return FoundCookies
        #return cookie,cookie2
    #except:
    #    return
def CF_parseJSString(s):
    try:
        offset=1 if s[0]=='+' else 0
        return int(eval(s.replace('!+[]','1').replace('!![]','1').replace('[]','0').replace('(','str(')[offset:]))
    except:
        return
def CF_SaveFile(path,data):
	try:
		file=open(path,'w')
		file.write(data)
		file.close()
	except: pass
def CF_OpenFile(path,d=''):
	try:
		if os.path.isfile(path): ## File found.
			file=open(path,'r')
			contents=file.read()
			file.close()
			return contents
		else: return d ## File not found.
	except: return d
