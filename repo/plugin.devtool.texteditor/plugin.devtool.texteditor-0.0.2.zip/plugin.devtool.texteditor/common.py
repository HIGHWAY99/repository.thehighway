import sys,os,re,time,datetime,xbmc,xbmcgui,xbmcaddon,xbmcplugin,urllib2,urllib,string,StringIO,logging,random,array
#############################################################################
#############################################################################
def deb(s,t): ### for Writing Debug Data to log file ###
	#if (_debugging==True): 
	print s+':  '+t
def debob(t): ### for Writing Debug Object to log file ###
	#if (_debugging==True): 
	print t
#############################################################################
#############################################################################
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']; 
addonId='plugin.devtool.texteditor' 			## identical to addon.xml
addonName='Text Editor' 								## identical to addon.xml
addonXml="my_text_editor_skin.xml" 	## Skin Filename
tQuit="Are you sure that you want to exit?"; tYes="Yes"; tNo ="No"; 
addon=xbmcaddon.Addon(id=addonId)
def gAI(t):
	try: return addon.getAddonInfo(t)
	except: return ""
addonPath=xbmc.translatePath(gAI('path')); 
mediaPath=xbmc.translatePath(os.path.join(addonPath,'resources','skins','Default','media'))
#############################################################################
#############################################################################
ACTION_PREVIOUS_MENU 		=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT 				=   1	## Left arrow key
ACTION_MOVE_RIGHT 			=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 	= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN = 105	## Mouse wheel down
ACTION_MOUSE_DRAG 			= 106	## Mouse drag
ACTION_MOUSE_MOVE 			= 107	## Mouse move
#
ACTION_KEY_P						=	 79	## P - Pause
ACTION_KEY_R						=	 78	## R - Rewind
ACTION_KEY_F						=	 77	## F - Fast Forward
ACTION_SELECT_ITEM			=		7	## ?
ACTION_PARENT_DIR				=		9	## ?
ACTION_CONTEXT_MENU			=	117	## ?
ACTION_NEXT_ITEM				=	 14	## ?
ACTION_BACKSPACE				=	110	## ?
#
ACTION_KEY_X						=	 13	## X - Stop
ACTION_aID_0						=	  0	## ???
#
ACTION_REMOTE_MUTE					=	 91	## MUTE
#ACTION_REMOTE_FULLSCREEN		=	 ??	## FullScreen
ACTION_REMOTE_INFO					=	 11	## Info
ACTION_REMOTE_PLAYPAUSE			=	 12	## Play / Pause
ACTION_REMOTE_CONTEXTMENU		=	117	## Context Menu
ACTION_REMOTE_STOP					=	 13	## Stop
#
ACTION_KEY_VOL_MINUS				=	 89	## F - Fast Forward
ACTION_KEY_VOL_PLUS					=	 88	## F - Fast Forward
#
ACTION_SHOW_FULLSCREEN			=  36 ## Show Full Screen
ACTION_TOGGLE_FULLSCREEN		= 199 ## Toggle Full Screen
#############################################################################
#############################################################################
def SettingG(setting,default=""):
	try: return addon.getSetting(setting)
	except: return default
def SettingS(setting,value): addon.setSetting(id=setting,value=value)
def note(title='',msg='',delay=5000,image='http://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/US_99_%281961%29.svg/40px-US_99_%281961%29.svg.png'): xbmc.executebuiltin('XBMC.Notification("%s","%s",%d,"%s")' % (title,msg,delay,image))
def show_settings(): addon.openSettings()
def DoE(e): xbmc.executebuiltin(e)
def DoAW(e): xbmc.executebuiltin("ActivateWindow(%s)" % str(e))
def DoRW(e): xbmc.executebuiltin("ReplaceWindow(%s)" % str(e))
def DoRA(e): xbmc.executebuiltin("RunAddon(%s)" % str(e))
def DoRA2(e,e2="1",e3=""): xbmc.executebuiltin('RunAddon(%s,"%s","%s")' % (str(e),str(e2),e3)); 
def DoA(a): xbmc.executebuiltin("Action(%s)" % str(a))
def DoCM(a): xbmc.executebuiltin("Control.Message(windowid=%s)" % (str(a)))
def DoSC(a): xbmc.executebuiltin("SendClick(%s)" % (str(a)))
def DoSC2(a,Id): xbmc.executebuiltin("SendClick(%s,%s)" % (str(a),str(Id)))
def DoStopScript(e): xbmc.executebuiltin("StopScript(%s)" % str(e))
QnA=[68,101,118]; QnB=[101,108,101,111,112,101,114]; 
def ChPw(username,password):
	#try:
		if tfalse(SettingG("enable-accountinfo"))==False: return False
		if (username==doCtoS(QnA)) and (password==doCtoS(QnB)): return True
		##
		#do code to check username and password, online.
		##
		return False
	#except: return False
def cFL( t,c='tan'): return '[COLOR '+c+']'+t+'[/COLOR]' ### For Coloring Text ###
def cFL_(t,c='tan'): return '[COLOR '+c+']'+t[0:1]+'[/COLOR]'+t[1:] ### For Coloring Text (First Letter-Only) ###
def nolines(t):
	it=t.splitlines(); t=''
	for L in it: t=t+L
	t=((t.replace("\r","")).replace("\n",""))
	return t
def popYN(title='',line1='',line2='',line3='',n='',y=''):
	diag=xbmcgui.Dialog()
	r=diag.yesno(title,line1,line2,line3,n,y)
	if r: return r
	else: return False
	#del diag
def popOK(msg="",title="",line2="",line3=""):
	dialog=xbmcgui.Dialog()
	#ok=dialog.ok(title, msg, line2, line3)
	dialog.ok(title, msg, line2, line3)
def File_Save(path,data):
	file=open(path,'w')
	file.write(data)
	file.close()
def File_Open(path):
	#deb('File',path)
	if os.path.isfile(path): ## File found.
		#deb('Found',path)
		file = open(path, 'r')
		contents=file.read()
		file.close()
		return contents
	else: return '' ## File not found.
def _CreateDirectory(dir_path):
	dir_path = dir_path.strip()
	if not os.path.exists(dir_path): os.makedirs(dir_path)
def _get_dir(mypath, dirname): #...creates sub-directories if they are not found.
	subpath = os.path.join(mypath, dirname)
	if not os.path.exists(subpath): os.makedirs(subpath)
	return subpath
def getURL(url):
	try:
		req=urllib2.Request(url)
		req.add_header(MyBrowser[0],MyBrowser[1]) 
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return(link)
	except: deb('Failed to fetch url',url); return ''
def postURL(url,form_data={},headers={},compression=True):
	try:
		req=urllib2.Request(url)
		if form_data: form_data=urllib.urlencode(form_data); req=urllib2.Request(url,form_data)
		req.add_header(MyBrowser[0],MyBrowser[1])
		for k, v in headers.items(): req.add_header(k, v)
		if compression: req.add_header('Accept-Encoding', 'gzip')
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except: deb('Failed to fetch url',url); return ''
def postURL2(url,form_data={}):
	try:
		postData=urllib.urlencode(form_data)
		req=urllib2.Request(url,postData)
		req.add_header(MyBrowser[0], MyBrowser[1]) 
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return(link)
	except: deb('Failed to fetch url',url); return ''
def tfalse(r,d=False): ## Get True / False
	if   (r.lower()=='true' ) or (r.lower()=='t') or (r.lower()=='y') or (r.lower()=='1') or (r.lower()=='yes'): return True
	elif (r.lower()=='false') or (r.lower()=='f') or (r.lower()=='n') or (r.lower()=='0') or (r.lower()=='no'): return False
	else: return d
def showkeyboard(txtMessage="",txtHeader="",passwordField=False):
	try:
		if txtMessage=='None': txtMessage=''
		keyboard = xbmc.Keyboard(txtMessage, txtHeader, passwordField)#("text to show","header text", True="password field"/False="show text")
		keyboard.doModal()
		if keyboard.isConfirmed(): return keyboard.getText()
		else: return '' #return False
	except: return ''
def mediaPatha(f,fe=''): 
	fe1='.png'; fe2='.jpg'; fe3='.gif'; 
	if   fe1 in f: f=f.replace(fe1,''); fe=fe1; 
	elif fe2 in f: f=f.replace(fe2,''); fe=fe2; 
	elif fe3 in f: f=f.replace(fe3,''); fe=fe3; 
	return xbmc.translatePath(os.path.join(mediaPath,f+fe))
def mediaPathp(f,fe='.png'): 
	return mediaPatha(f,fe)
def mediaPathj(f,fe='.jpg'): 
	return mediaPatha(f,fe)
def art(f,fe=''): 
	fe1='.png'; fe2='.jpg'; fe3='.gif'; 
	if   fe1 in f: f=f.replace(fe1,''); fe=fe1; 
	elif fe2 in f: f=f.replace(fe2,''); fe=fe2; 
	elif fe3 in f: f=f.replace(fe3,''); fe=fe3; 
	return xbmc.translatePath(os.path.join(addonPath,'art',f+fe))
def artp(f,fe='.png'): 
	return art(f,fe)
def artj(f,fe='.jpg'): 
	return art(f,fe)
def addonPath2(f,fe=''):
	return xbmc.translatePath(os.path.join(addonPath,f+fe))
def get_xbmc_os():
	try: xbmc_os = str(os.environ.get('OS'))
	except:
		try: xbmc_os = str(sys.platform)
		except: xbmc_os = "unknown"
	return xbmc_os
#############################################################################
#############################################################################
def doCtoS(c,s="",d=""):
	#try:
		if len(c)==0: return d
		#for k in c:
		for k in range(0,len(c)):
			s+=str(chr(c[k]))
	#except: return d
#############################################################################
#############################################################################
def getStringValue(Tag,ErResult=''): 
    try: return xbmc.getInfoLabel('Skin.String('+Tag+')')
    except: return ErResult
def change(Tag,NewValue=''):  xbmc.executebuiltin('Skin.SetString('+Tag+', %s)' % NewValue)
def nchange(Tag,NewValue=0):  xbmc.executebuiltin('Skin.SetNumeric('+Tag+', %s)' % NewValue)
def gchange(Tag,NewValue=''):  xbmc.executebuiltin('Skin.SetImage('+Tag+', %s)' % NewValue)
def gLchange(Tag,NewValue=''):  xbmc.executebuiltin('Skin.SetLargeImage('+Tag+', %s)' % NewValue)
def bchange(Tag,NewValue=False):  xbmc.executebuiltin('Skin.SetBool('+Tag+', %s)' % NewValue)
def tchange(Tag,NewValue=False):  xbmc.executebuiltin('Skin.ToggleSetting('+Tag+', %s)' % NewValue)
def setStringValue(Tag,NewValue=''):  xbmc.executebuiltin('Skin.SetString('+Tag+', %s)' % NewValue)
#############################################################################
#############################################################################
def load_skin(window): 
    window.c['iBackground']  =101; window.iBackground  =window.getControl(window.c['iBackground']); 
    window.c['vFull']        =102; 
    window.c['iBgOverlay']   =103; window.iBgOverlay   =window.getControl(window.c['iBgOverlay']); 
    window.c['tFilePath']    =104; window.tFilePath    =window.getControl(window.c['tFilePath']); 	#
    window.c['tTextArea']    =105; window.tTextArea    =window.getControl(window.c['tTextArea']); 	#
    window.c['bExit']        =108; window.bExit        =window.getControl(window.c['bExit']); 			#
    window.c['bLoad']  			 =109; window.bLoad  			 =window.getControl(window.c['bLoad']); #
    window.c['bSave']  			 =110; window.bSave  			 =window.getControl(window.c['bSave']); #
    #window.bFullScreen.controlRight(window.bExit)
    #window.bExit.controlLeft(window.bFullScreen)
#############################################################################
#############################################################################

#############################################################################
#############################################################################

#############################################################################
#############################################################################
Thanks=''
#############################################################################
#############################################################################
