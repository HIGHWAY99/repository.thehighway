plugin.video.thebinaryhighway
==================================

My xbmc-addon The Binary Highway.

An Addon for XBMC that is many things.

1.) Provide Tools & Fixes.
2.) Helpful Tool for users with a Fresh Install.
3.) Provide Access to common well-used Repositories.
4.) Includes multiple Updater Tools to Download Updates for differant parts of the addon.
5.) Provide access to show set menus when they are downloaded and appear to be found locally.
6.) Provide easy drop-n-use access for Sub-Addons with pre-defined filename formating.  Also allows each Sub-Addon to include some header text to determine it's Icon, Fanart, and Label Text.
7.) Provide a method to copy new Host Plugins to UrlResolver's plugin folder for those sources not handled by UrlResolver.
8.) A set of common files for config settings, variables, function, and the such... to provide fast and quick making of new Sub-Addons with very limited effort.





