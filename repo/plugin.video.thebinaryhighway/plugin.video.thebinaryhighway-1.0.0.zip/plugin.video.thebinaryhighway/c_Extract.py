### ############################################################################################################
###	#	
### # Author: 			#		The Highway
### # Description: 	#		Unzipper File For:  The Binary Highway
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_OpenFile)
import zipfile
def all(_in, _out, dp=None):
	if dp: return allWithProgress(_in, _out, dp)
	return allNoProgress(_in, _out)
def allNoProgress(_in, _out):
	try:
		try: debob([_in,_out]); debob(zin.infolist())
		except: pass
		zin=zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except: return False
	#except Exception, e:
	#	print str(e)
	#	return False
	return True
def allWithProgress(_in, _out, dp):
	zin=zipfile.ZipFile(_in,  'r'); nFiles=float(len(zin.infolist())); count=0
	try:
		try: debob([_in,_out]); debob(zin.infolist())
		except: pass
		for item in zin.infolist():
			count+=1; update=count / nFiles * 100
			dp.update(int(update))
			try: debob(item)
			except: pass
			zin.extract(item, _out)
	#except Exception, e:
	#	print str(e)
	#	return False
	except: return False
	return True

