### ############################################################################################################
###	#	
### # Site: 				#		Ram FM - http://ramfm.org/
### # Author: 			#		The Highway
### # Description: 	#		Done from scratch by public request.  A real fan favorite!
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui

from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_addon_id)
### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR lime][COLOR yellow][B]RAM FM[/B][/COLOR] [COLOR deeppink]Eighties[/COLOR] Hit Radio[/COLOR]  [v0.0.4]  [Radio]'
SiteTag='ramfm.org'
mainSite='http://ramfm.org/' #'http://ramradio.com/' #'http://ramradio.nl/'
iconSite='http://ramfm.org/images/logo_top.png' #'http://ramfm.org/images/party2.png' #_artIcon
fanartSite='http://ramfm.org/images/bg_gb.jpg' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan'}
iconSite2='http://ramfm.org/images/party2.png'

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']

workingUrl=mainSite+'ram.pls'
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#XBMCHUB','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'Live Streams Playlist (ram.pls)'
		m+=CR+CR+'Features:  '
		m+=CR+'* Listen to the available Radio Stream.'
		m+=CR+'* Browse #/A-Z'
		m+=CR+'* Browse Artist(s)/Song(s) available for request.'
		m+=CR+'* Submit Artist+Song Request while listening to the Radio Stream.'
		m+=CR+'* Listen via the Url for misc. devices.'
		m+=CR+'* Check out the Crew.'
		m+=CR+'* DJ Guide.'
		m+=CR+'* Check out which Studios are online.'
		m+=CR+'* Look at Studio Pictures.'
		m+=CR+'* See what\'s now playing.'
		m+=CR+'* Browse and Listen to Pod Casts.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* Please make your listening to the radio stream while you try to request a song.'
		m+=CR+'* When requesting a song, please remember to move back (..) after you\ve submitted your request.'
		m+=CR+'* Please remember to be kind and respectful when using the Song Requester.'
		m+=CR+'* SlideShow may or may not work at times.'
		#m+=CR+'* '
		#m+=CR+'* '
		m+=CR+''
		m+=CR+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()
def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
### ############################################################################################################
### ############################################################################################################
def Browse_PodCasts():
	html=messupText(nURL('http://www.spreaker.com/show/816525/episodes/feed'),True); deb('length of html',str(len(html))); #debob(html)
	html=nolines(html); fimg='http://d1bm3dmew779uf.cloudfront.net/cover/840eeead3a8e364d6f66a9dd421186ef.jpg'; img='http://d1bm3dmew779uf.cloudfront.net/large/a4f2e48afbd44634852fdf291593ffaf.jpg'; 
	s='<item>(.*?<title>(.+?)</title>.*?<pubDate>(.+?)</pubDate><enclosure.*?url="(http://.+?.mp3.*?)".*?type="audio/mpeg".*?>.*?</enclosure>.*?)</item>'
	matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); debob(matches)
	if len(matches)==0: return
	for (match,_name,_pubDate,_url) in matches:
		_title=cFL(_name.replace('(',cFL('(',colors['11'])).replace(')',cFL(')',colors['11'])),colors['10'])+CR+cFL('['+cFL(_pubDate.replace('+',cFL('+',colors['11'])).replace(':',cFL(':',colors['11'])).replace(',',cFL(',',colors['11'])),colors['6'])+']',colors['10'])
		try: _addon.add_directory({'mode':'PlayURL','url':_url,'title':_name,'site':site},{'title':_title},is_folder=False,fanart=fimg,img=img)
		except: pass
	#set_view('movies',view_mode=int(addst('movies-view'))); eod()
	set_view('list',view_mode=addst('default-view')); eod()

def NowPlaying():
	html=messupText(nURL(mainSite+'index.php'),True); deb('length of html',str(len(html))); #debob(html)
	s='<b>\s*%s\s*.*?\s*<b>:</b>\s*.*?\s*<b>\s*(.*?)\s*</b>' ## Note: some don't have </b> after the the initial string. ##
	try: img=re.compile('<img\s*src="(http://ramfm.org/artistpic/.+?)"\s*width="200"\s*border="0"\s*/>').findall(html.replace('&quot;','"'))[0].replace(' ','%20')
	except: img=iconSite
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Artist:  '+cFL(re.compile('<img\s*src="http://ramfm.org/artistpic/.+?"\s*.*?\s*/>.*?<img src="http://ramfm.org/images/format.png".*?\s/>.*?<b>\s*(.+?)\s*</b>').findall(html.replace('&quot;','"'))[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Song:  '+cFL(re.compile('<img\s*src="http://ramfm.org/artistpic/.+?"\s*.*?\s*/>.*?<img src="http://ramfm.org/images/format.png".*?\s/>.*?<b>\s*.*?\s*</b>.*?<b>\s*(.+?)\s*</b>').findall(html.replace('&quot;','"'))[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Year:  '+cFL(re.compile('<img\s*src="http://ramfm.org/artistpic/.+?"\s*.*?\s*/>.*?<img src="http://ramfm.org/images/format.png".*?\s/>.*?<b>\s*.*?\s*</b>.*?<b>\s*.*?\s*</b>.*?<br />\s*(\d\d\d\d)\s*<br />').findall(html.replace('&quot;','"'))[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Last Played:  '+cFL(re.compile(s % ('last played')).findall(html)[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Requested:  '+cFL(re.compile(s % ('requested')).findall(html)[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':cFL('Average Rotation:  '+cFL(re.compile(s % ('average rotation')).findall(html)[0].replace('<br/>',cFL('  |  ',colors['6'])),colors['10']),colors['6'])},is_folder=True,fanart=fanartSite,img=img)
	except: pass
	set_view('list',view_mode=addst('default-view')); eod()

def ListAZ():
	if xbmc.Player().isPlaying()==False:
		try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':'Denied!  Must be listening to Submit a REQUEST.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
		except: pass
	else:
		_addon.add_directory({'mode':'List','title':'0','site':site},{'title':cFL('0-9',colors['0'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/request.gif')
		for i in range(65, 91): _addon.add_directory({'mode':'List','title':chr(i),'site':site},{'title':cFL(chr(i),colors['0'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/request.gif')
	set_view('list',view_mode=addst('default-view')); eod()

def Browse_List(title):
	if len(title)==0: return
	elif xbmc.Player().isPlaying()==False:
		try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':'Denied!  Must be listening to Submit a REQUEST.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
		except: pass
	else:
		deb('playlist url',mainSite+'requests/playlist'+str(title)+'.php')
		html=messupText(nURL(mainSite+'requests/playlist'+str(title)+'.php'),True); deb('length of html',str(len(html))); #debob(html)
		s='<table cellpadding="0" cellspacing="0" width="100%" align="center">\s*\n*\s*<tr>\s*\n*\s*<td nowrap align="left" bgcolor="#000000" width="10%">\s*\n*\s*\n*\s\n*\s*<img src="(http://ramfm.org/artistpic/.+?)" width="30" height="30" border="0" /></a></td>\s*\n*\s*\n*\s*'+'<td align="left" bgcolor="#000000" width="80%"><font style="font-size: 9pt" color="#FFFF99" face="verdana">\s*(.+?)\s*-\s*(.+?)\s*<br /></font></td>\s*\n*\s*'+'<td bgcolor="#000000" width="10%"><p align="right"><font size="2" color="#003366"><a href="javascript:request\((\d+),\'(\d+.\d+.\d+.\d+)\',\'(\d+)\'\)">\s*\n*\s*'
		matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
		if len(matches)==0: return
		for (img,artist,songtitle,songid,samhost,samport) in matches:
			_url=mainSite+'req/request.php?songid='+str(songid)+'&samport='+str(samport)+'&samhost='+str(samhost)+'&userapp=xbmc'+'&useraddon='+_addon_id
			debob(_url)
			_title='['+songid+']  '+cFL(artist+' - '+cFL(songtitle,colors['10']),colors['6'])
			try: _addon.add_directory({'mode':'DoRequest','url':_url,'title':artist+' - '+songtitle,'site':site},{'title':_title},is_folder=True,fanart=fanartSite,img=img)
			except: pass
	set_view('list',view_mode=addst('default-view')); eod()

def DoRequest(url,title):
	if (len(url)==0) or (len(title)==0): return
	if len(title) > 0: s=''+title+' - '
	else: s=''
	d=datetime.date.today()
	_y=str(d.year); _m=str(d.month); _d=str(d.day)
	if len(_m)==1: _m='0'+_m
	if len(_d)==1: _d='0'+_d
	_date=_y+_m+_d
	#TStamp=str(_date)+str(time.strftime('%H%M')); deb('TStamp',str(TStamp)); ## Year Month Day Hour Minute
	TStamp=str(_date)+str(time.strftime('%H')); deb('TStamp',str(TStamp)); ## Year Month Day Hour
	if len(addst('LastRequestTime'+SiteTag))==0: addstv('LastRequestTime'+SiteTag,'0'); debob('setting timestamp to 0 initially'); 
	LastRequestTime=addst('LastRequestTime'+SiteTag); deb(TStamp,LastRequestTime); 
	if (url==addst('LastRequestURL'+SiteTag)) or (title==addst('LastRequestTitle'+SiteTag)):
		try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'Denied!  [CR]You just requested this song already.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
		except: pass
	#elif xbmc.Player().isPlayingAudio()==False:
	#	try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'Denied!  [CR]Must be listening to Submit a REQUEST.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
	#	except: pass
	elif xbmc.Player().isPlaying()==False:
		try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'Denied!  [CR]Must be listening to Submit a REQUEST.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
		except: pass
	elif (TStamp==LastRequestTime):
		try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'Denied!  [CR]Please don\'t spam the Song Requester.  Please limit to 1 request per hour.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
		except: pass
	#if ( (int(TStamp)-int(LastRequestTime)) < 30 ) or ( (int(LastRequestTime)-int(TStamp)) > (0-30) ):
	else:
		addstv('LastRequestTime'+SiteTag,TStamp); addstv('LastRequestURL'+SiteTag,url); addstv('LastRequestTitle'+SiteTag,title); 
		html=nURL(url)
		#html='Request OK'
		if 'Request OK' in html:
			try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'[Submitted] Request OK.'+'[CR]Please allow them 10 to 15 minutes to process your request.  (ramradio.com)'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
			except: pass
		else:
			try: _addon.add_directory({'mode':'SectionMenu','site':site},{'title':s+'[Submitted] Request may have had a problem.'},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png')
			except: pass
	set_view('list',view_mode=addst('default-view')); eod()

def Browse_Studio():
	html=messupText(nURL(mainSite+'themakingof.php'),True)
	html=nolines(html); deb('length of html',str(len(html))); #debob(html)
	s='<td.+?>\s*[<p>]*\s*[<b>]*\s*<font.+?>\s*[<b>]*\s*<a href="(http://ramfm.org/.+?.[jpg|JPG])" target="_blank".*?>\s*[<font color="#FFFFDD">]*\s*[<b>]*\s*<img.*?src="(http://ramfm.org/.+?.[jpg|JPG])".*?>\s*(.+?)\s*</td>'
	matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	if len(matches)==0: return
	for (_url,img,_name) in matches:
		fimg=_url; _name=_name.replace('</i>','[/I]').replace('<i>','[I]').replace('</b>','[/B]').replace('<b>','[B]').replace('<br>',' ').replace('<br />',' ').replace('<font size="1" face="Verdana" color="#FFFFDD">','').replace('</font>','').replace('<font face="Verdana" size="1" color="#FFFFDD">','').replace('<font color="#FFFFDD" face="Verdana" size="1">','').replace('<font color="#FFFFDD" size="1" face="Verdana">','').replace('<font face="Verdana" color="#FFFFDD" size="1">','').replace('<font color="#FFFFDD">',' ').replace('</a>',' ').strip()
		if ('[/B]' in _name): _name='[B]'+_name
		_title=cFL(_name,colors['10']); debob([_name,img,_url])
		try: _addon.add_directory({'mode':'PlayURL','url':_url,'title':_name,'site':site},{'title':_title},is_folder=False,fanart=fimg,img=img)
		except: pass
	set_view('list',view_mode=addst('default-view')); eod()

def Browse_Crew():
	html=messupText(nURL(mainSite+'inc/crew.php'),True)
	html=nolines(html); deb('length of html',str(len(html))); #debob(html)
	s='<table.*?style="border-collapse: collapse".*?background="http://www.ramfm.org/images/bg-pup.png".*?>\s*<tr>\s*<td.*?>\s*<br /><img.*?src="(http://ramfm.org/.+?.[gif|GIF|jpg|JPG|png|PNG]+)".*?><br />\s*<font.*?><b>(.+?)</b></font></td>\s*(.+?)</tr>\s*</table>'
	matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	if len(matches)==0: return
	for (img,_name,_plot) in matches:
		contextMenuItems=[]; fimg=img; _name=_name.replace('</i>','[/I]').replace('<i>','[I]').replace('</b>','[/B]').replace('<b>','[B]').replace('<br>',' ').replace('<br />',' ').replace('<font size="1" face="Verdana" color="#FFFFDD">','').replace('</font>','').replace('<font face="Verdana" size="1" color="#FFFFDD">','').replace('<font color="#FFFFDD" face="Verdana" size="1">','').replace('<font color="#FFFFDD" size="1" face="Verdana">','').replace('<font face="Verdana" color="#FFFFDD" size="1">','').replace('<font color="#FFFFDD">',' ').replace('</a>','').strip()
		_plot=_plot.replace('</i>','[/I]').replace('<i>','[I]').replace('</b>','[/B]').replace('<b>','[B]').replace('<br>',CR).replace('<br />',CR).replace('<font size="1" face="Verdana" color="#FFFFDD">','').replace('</font>','').replace('<font face="Verdana" size="1" color="#FFFFDD">','').replace('<font color="#FFFFDD" face="Verdana" size="1">','').replace('<font color="#FFFFDD" size="1" face="Verdana">','').replace('<font face="Verdana" color="#FFFFDD" size="1">','').replace('<font color="#FFFFDD">','').replace('<td align="left" valign="top">','').replace('<font face="verdana, tahoma" style=\'font-size: 7pt\' color="#CCDDDD">','').replace('</a>','').replace('</td>','  ').replace('<tr>','').replace('</tr>',CR).replace('<td align="left" height="70" valign="top">','').replace('\t',' ').strip()
		if ('[/B]' in _name): _name='[B]'+_name
		_title=cFL(_name,colors['10']); debob([_name,img,_plot])
		if tfalse(addst("CMI_ShowInfo"))==True: contextMenuItems.append(('Info',ps('cMI.showinfo.url')))
		try: _addon.add_directory({'mode':'PlayURL','url':img,'title':_name,'site':site},{'title':_title,'plot':_plot},is_folder=False,contextmenu_items=contextMenuItems,fanart=fimg,img=img)
		except: pass
	set_view('movies',view_mode=int(addst('movies-view'))); eod()

def Browse_LiveDJs():
	html=messupText(nURL(mainSite+'inc/guide.inc.php'),True)
	html=nolines(html); deb('length of html',str(len(html))); #debob(html)
	s='<tr>\s*<td>\s*<img.*?src="(http://ramfm.org/.+?.[png|PNG|jpg|JPG|gif|GIF])".*?>\s*</td>\s*<td>\s*<font.*?>(.+?)<br />\s*(.+?)\s*<br /><b>(.+?)</b>.*?</font>\s*</td>\s*</tr>'
	matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	if len(matches)==0: return
	for (img,_day,_time,_name) in matches:
		_plot=''; contextMenuItems=[]; fimg=img; _name=_name.replace('</i>','[/I]').replace('<i>','[I]').replace('</b>','[/B]').replace('<b>','[B]').replace('<br>',' ').replace('<br />',' ').replace('<font size="1" face="Verdana" color="#FFFFDD">','').replace('</font>','').replace('<font face="Verdana" size="1" color="#FFFFDD">','').replace('<font color="#FFFFDD" face="Verdana" size="1">','').replace('<font color="#FFFFDD" size="1" face="Verdana">','').replace('<font face="Verdana" color="#FFFFDD" size="1">','').replace('<font color="#FFFFDD">',' ').replace('</a>','').strip()
		_plot=_plot.replace('</i>','[/I]').replace('<i>','[I]').replace('</b>','[/B]').replace('<b>','[B]').replace('<br>',CR).replace('<br />',CR).replace('<font size="1" face="Verdana" color="#FFFFDD">','').replace('</font>','').replace('<font face="Verdana" size="1" color="#FFFFDD">','').replace('<font color="#FFFFDD" face="Verdana" size="1">','').replace('<font color="#FFFFDD" size="1" face="Verdana">','').replace('<font face="Verdana" color="#FFFFDD" size="1">','').replace('<font color="#FFFFDD">','').replace('<td align="left" valign="top">','').replace('<font face="verdana, tahoma" style=\'font-size: 7pt\' color="#CCDDDD">','').replace('</a>','').replace('</td>','  ').replace('<tr>','').replace('</tr>',CR).replace('<td align="left" height="70" valign="top">','').replace('\t',' ').strip()
		if ('[/B]' in _name): _name='[B]'+_name
		_title=cFL(_name,colors['10'])+CR+cFL(_day+cFL(' [',colors['10'])+_time.replace('AM/PM','AM'+cFL('/',colors['10'])+'PM').replace('PM/AM','PM'+cFL('/',colors['10'])+'AM').replace('-',cFL('-',colors['10'])).replace(':',cFL(':',colors['10']))+cFL(']',colors['10']),colors['6']); debob([_name,_title,img,_plot])
		if tfalse(addst("CMI_ShowInfo"))==True: contextMenuItems.append(('Info',ps('cMI.showinfo.url')))
		try: _addon.add_directory({'mode':'PlayURL','url':img,'title':_name,'site':site},{'title':_title,'plot':_plot},is_folder=False,contextmenu_items=contextMenuItems,fanart=fimg,img=img)
		except: pass
	set_view('movies',view_mode=int(addst('movies-view'))); eod()

def Browse_Studios():
	html=messupText(nURL(mainSite+'index.php').replace('&quot;','"'),True)
	html=nolines(html); deb('length of html',str(len(html))); #debob(html)
	s='<td align="center" width="16%"><a onmouseover="popup2\(\'<center><br /><font.*?>(.+?)<br />(.+?)<br /></font><br /><img src="(http://ramfm.org/.*?.[jpg|JPG|png|PNG|gif|GIF]+)" border="0" width="350" /><br /><br /><br /></center>\'\);"><img.*?src="http://ramfm.org/.*?".*?><br /><b><font.*?>.+?[</b>]*</font><br /><font.*?>.+?<br />.+?<br /><font.+?>([Online|Offline]+)[</b>]*</font></font></a></td>'
	matches=re.compile(s).findall(html); deb('# of matches found',str(len(matches))); #debob(matches)
	if len(matches)==0: return
	for (_StudioName,_StudioLocation,img,_status) in matches:
		_plot=''; contextMenuItems=[]; fimg=img; 
		_plot=_plot.replace('</i>','[/I]').replace('<i>','[I]').replace('</b>','[/B]').replace('<b>','[B]').replace('<br>',CR).replace('<br />',CR).replace('<font size="1" face="Verdana" color="#FFFFDD">','').replace('</font>','').replace('<font face="Verdana" size="1" color="#FFFFDD">','').replace('<font color="#FFFFDD" face="Verdana" size="1">','').replace('<font color="#FFFFDD" size="1" face="Verdana">','').replace('<font face="Verdana" color="#FFFFDD" size="1">','').replace('<font color="#FFFFDD">','').replace('<td align="left" valign="top">','').replace('<font face="verdana, tahoma" style=\'font-size: 7pt\' color="#CCDDDD">','').replace('</a>','').replace('</td>','  ').replace('<tr>','').replace('</tr>',CR).replace('<td align="left" height="70" valign="top">','').replace('\t',' ').strip()
		_title=cFL(_StudioName,colors['10'])+CR+cFL(cFL('[',colors['10'])+_status+cFL('] ',colors['10'])+_StudioLocation,colors['6'])
		debob([_StudioName,_StudioLocation,_title,img,_status,_plot])
		if tfalse(addst("CMI_ShowInfo"))==True: contextMenuItems.append(('Info',ps('cMI.showinfo.url')))
		try: _addon.add_directory({'mode':'PlayURL','url':img,'title':_StudioName,'site':site},{'title':_title,'plot':_plot},is_folder=False,contextmenu_items=contextMenuItems,fanart=fimg,img=img)
		except: pass
	set_view('movies',view_mode=int(addst('movies-view'))); eod()

def PlayURLPAPlayer(url):
	play=xbmc.Player(xbmc.PLAYER_CORE_PAPLAYER) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	try: _addon.resolve_url(url)
	except: t=''
	try: play.play(url)
	except: t=''

### ############################################################################################################
### ############################################################################################################
def SectionMenu():
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=True,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	###
	#_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=False,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'PlayURL','url':workingUrl,'site':site},{'title':cFL_('Listen to the Radio Stream',colors['6'])},is_folder=False,fanart=fanartSite,img=iconSite2)
	#_addon.add_directory({'mode':'PlayURLPAPlayer','url':workingUrl,'site':site},{'title':cFL_('Listen (Frodo)',colors['6'])},is_folder=False,fanart=fanartSite,img=iconSite2)
	_addon.add_directory({'mode':'PlayURLPAPlayer','url':'http://uk1-vn.mixstream.net/9866.m','site':site},{'title':cFL_('Listen (Frodo)',colors['6'])},is_folder=False,fanart=fanartSite,img=iconSite2)
	# 
	_addon.add_directory({'mode':'NowPlaying','site':site},{'title':cFL_('Now Playing...',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/format.png')
	_addon.add_directory({'mode':'ListAZ','site':site},{'title':cFL('Song Requester',colors['4'])+CR+' (for ocassional use only, please)'},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/request.png')
	#_addon.add_directory({'mode':'','site':site},{'title':cFL_('',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'SlideShowStart','site':site},{'title':cFL_('Last[COLOR red]FM[/COLOR] SlideShow (Packaged)',colors['6'])},is_folder=True,fanart=fanartSite,img=iconSite2)
	_addon.add_directory({'mode':'BStudio','site':site},{'title':cFL_('Studio: Pictures',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/PowerShot.png')
	_addon.add_directory({'mode':'BCrew','site':site},{'title':cFL_('DJs: Meet The Crew',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/crew.png')
	_addon.add_directory({'mode':'BLiveDJs','site':site},{'title':cFL_('Live Radio: DJ Guide',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/vacancies.png')
	_addon.add_directory({'mode':'BStudios','site':site},{'title':cFL_('Studios',colors['6'])},is_folder=True,fanart=fanartSite,img='http://ramfm.org/images/josstudio.jpg')
	_addon.add_directory({'mode':'BPodCasts','site':site},{'title':cFL_('Pod Casts',colors['6'])},is_folder=True,fanart='http://d1bm3dmew779uf.cloudfront.net/cover/840eeead3a8e364d6f66a9dd421186ef.jpg',img='http://d1bm3dmew779uf.cloudfront.net/large/d68d05dbdc6aec3cd4a0e952dc052a65.jpg')
	
	#_addon.add_directory({'mode':'PlayURL','url':'','site':site},{'title':cFL_('Listen on theRadioStream',colors['6'])},is_folder=False,fanart=fanartSite,img=iconSite2)
	
	#_addon.add_directory({'mode':'PlayURL','url':'http://ramfm.org/index.php?buster=0.9392556274928343#','site':site},{'title':cFL_('Listen on mac-ipad',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/Apple.png')
	#_addon.add_directory({'mode':'PlayURL','url':'http://ramfm.org/index.php?buster=0.9392556274928343#','site':site},{'title':cFL_('Listen on windows',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/Computer-icon.png')
	#_addon.add_directory({'mode':'PlayURL','url':'http://ramfm.org/index.php?buster=0.9392556274928343#','site':site},{'title':cFL_('Listen on flash',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/flash.png')
	_addon.add_directory({'mode':'PlayURL','url':'http://ramfm.org/ram.pls','site':site},{'title':cFL_('Listen on itunes',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/note5.png')
	#_addon.add_directory({'mode':'PlayURL','url':'http://ramfm.org/ram.asx','site':site},{'title':cFL_('Listen on wmp',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/windowsmedia.jpg')
	_addon.add_directory({'mode':'PlayURL','url':'http://ramfm.org/ram.pls','site':site},{'title':cFL_('Listen on winamp',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/winamp.jpg')
	#_addon.add_directory({'mode':'PlayURL','url':'http://ramfm.org/ram.rm','site':site},{'title':cFL_('Listen on realplayer',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/realplayer.jpg')
	_addon.add_directory({'mode':'PlayURL','url':'http://uk1-vn.mixstream.net/listen/9866.m3u','site':site},{'title':cFL_('Listen on default',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/addplayer.png')
	_addon.add_directory({'mode':'PlayURL','url':'http://ramfm.org/ram-bb.m3u','site':site},{'title':cFL_('Listen on blackberry phone',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/blackberry.png')
	_addon.add_directory({'mode':'PlayURL','url':'http://uk1-vn.mixstream.net/9866.m','site':site},{'title':cFL_('Listen on iphone android',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/iphone_logo.png')
	#_addon.add_directory({'mode':'PlayURL','url':'http://uk1-vn.mixstream.net/9866.proxy','site':site},{'title':cFL_('Listen on port 80* winamp',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/port80.png')
	_addon.add_directory({'mode':'PlayURL','url':'http://uk1-vn.mixstream.net/9866.mp3','site':site},{'title':cFL_('Listen on port 80* wmp',colors['6'])},is_folder=False,fanart=fanartSite,img='http://ramfm.org/images/fire_wall.png')
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	if (mode=='SectionMenu') or (mode=='') or (mode=='main') or (mode=='MainMenu'): 		SectionMenu()
	elif (mode=='PlayURL'): 						PlayURL(url)
	elif (mode=='PlayURLPAPlayer'): 		PlayURLPAPlayer(url)
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='NowPlaying'): 		NowPlaying()
	elif (mode=='ListAZ'): 				ListAZ()
	elif (mode=='List'): 					Browse_List(addpr('title',''))
	elif (mode=='DoRequest'): 		DoRequest(url,addpr('title',''))
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	#elif (mode=='Search'): 				Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	#elif (mode=='SearchLast'): 		Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='BStudio'): 			Browse_Studio()
	elif (mode=='BStudios'): 			Browse_Studios()
	elif (mode=='BCrew'): 				Browse_Crew()
	elif (mode=='BLiveDJs'): 			Browse_LiveDJs()
	elif (mode=='BPodCasts'): 		Browse_PodCasts()
	elif (mode=='About'): 				About()
	#elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='SlideShowStart'): path = os.path.join(_addonPath, 'c_SlideShow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); #import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
