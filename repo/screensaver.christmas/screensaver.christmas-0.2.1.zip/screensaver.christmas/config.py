def FetchDefault():
        return 'animated-santa-on-motorcycle'
def FetchList():
        return [
            ['Transparent Snow 01','snow_transparent_01','http://i.imgur.com/UHtty7s.gif'],
            ['Snowy Forest 01','snow_forest_01c','http://i.imgur.com/VLRGkTr.gif'],
            ['Snowy Forest 02','snow_forest_02b','http://i.imgur.com/qIrt730.gif'],
            #['Snowy Forest 02','snow_forest_03',''],
            #['Snowfall 01'    ,'snow_01',''],
            ['Snowfall 02'    ,'snow_02','http://i.imgur.com/EcGvdWS.gif'],
            #['Snow Falling 03','snow_03',''],
            ['Scooter Santa'  ,'animated-santa-on-motorcycle','http://i.imgur.com/hv5Apfo.gif'],
            ['Chimney Santa'  ,'santachimney2_e0','http://i.imgur.com/kQxfoHq.gif'],
            #['Swing 01','swing_01','http://i.imgur.com/tCpjBR1.gif'],
            #['','',''],
            #['','',''],
            ['Testing'        ,'',''],
            #['','',''],
            ['Black','Black1.png',''],['Blank','Blank1.png',''] ]
