# ###  - By TheHighway ### #
# ########################################################## #

import xbmc,xbmcgui,urllib,urllib2,os,sys,logging,array,re,time,datetime,random,string,StringIO,xbmcplugin,xbmcaddon
from config import Config as Config
import common as Common
from common import *
import common
DT={}; now=datetime.date.today(); DT['year']=int(now.strftime("%Y")); DT['month']=int(now.strftime("%m")); DT['day']=int(now.strftime("%d")); debob(DT); 

class MyWindow(xbmcgui.Window):
	button={}
	def __init__(self):
		self.current=0; self.content=[]; self.scr={}; self.scr['L']=0; self.scr['T']=0; self.scr['W']=1280; self.scr['H']=720; 
		self.AniTime=' time=2000 '; self.AniEnd=' end=80 '; 
		self.UseDay=str(DT['day']); self.UseMonth=str(DT['month']); self.UseYear=str(DT['year']); 
		if len(self.UseDay)==1: self.UseDay="0"+self.UseDay
		if len(self.UseMonth)==1: self.UseMonth="0"+self.UseMonth
		self.UseURLCurrent="http://lunaf.com/english/moon-phases/lunar-calendar-"+self.UseYear+"/"+self.UseMonth+"/"+self.UseDay+"/"; self.UseURLPrev=self.UseURLCurrent; self.UseURLNext=self.UseURLCurrent; 
		self.FillInContent(); 
		self.makePageItems(); 
	def FillInContent(self): return
	def GetMoonData(self,offset=0,useURL=''): 
		#self.UseDay=str(int(self.UseDay)+offset); 
		#if len(self.UseDay)==1: self.UseDay="0"+self.UseDay
		#if len(self.UseMonth)==1: self.UseMonth="0"+self.UseMonth
		if   offset == -1: useURL=self.UseURLPrev
		elif offset ==  0: useURL=self.UseURLCurrent
		elif offset ==  1: useURL=self.UseURLNext
		else: useURL=self.UseURLCurrent
		deb(str(offset),useURL); self.UseURLCurrent=useURL; html=getURL(useURL); 
		
		imgMoon="http://lunaf.com"+re.compile('<img src="(/images/moon-phases/.+?.jpg)" id="moon_phase_image_big"').findall(html)[0]
		try: self.UseURLPrev="http://lunaf.com"+re.compile('<a href="(/english/moon-phases/lunar-calendar-.+?)" rel="prev" class="pre call"').findall(html)[0]
		except: self.UseURLPrev=self.UseURLCurrent
		try: self.UseURLNext="http://lunaf.com"+re.compile('<a href="(/english/moon-phases/lunar-calendar-.+?)" rel="next" class="nex call"').findall(html)[0]
		except: self.UseURLNext=self.UseURLCurrent
		try: labDate=re.compile('<p><strong>Lunar phase</strong> on\s+(.+?)\s+is <strong>').findall(html)[0]
		except: labDate=''
		try: labZodiac=re.compile('<img .*? id="moon_phase_in_zodiac" alt="The moon is in zodiac sign\s+.+?" title="(.+?)" />').findall(html)[0]
		except: labZodiac=''
		
		
		self.LabDate.setLabel("[B]"+labDate+"[/B]"); 
		self.LabZodiac.setLabel("[B]"+labZodiac+"[/B]"); 
		self.imgHeart.setImage(imgMoon); 
		return
	def makePageItems(self):
		self.b1=artp("black1"); self.fanart=(xbmc.translatePath(Config.fanart)); self.background=artj("backdrop"); 
		focus=artp("button-focus_lightblue"); nofocus=artp("button-focus_seagreen"); 
		## ### ## Background
		self.BG=xbmcgui.ControlImage(self.scr['L'],self.scr['T'],self.scr['W'],self.scr['H'],self.background,aspectRatio=0); self.addControl(self.BG)
		self.BG.setAnimations([('WindowOpen','effect=fade time=2000 start=0')])
		l=195; t=20; w=self.scr['W']-l-30; h=self.scr['H']-(t*2); 
		l=0; t=0; w=self.scr['W']; h=self.scr['H']; 
		self.imgHeart=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.imgHeart); 
		self.imgHeart.setAnimations([('WindowOpen','effect=fade delay=2000 time=2000 start=0 end=70')])
		## ### ## Date & Zodiac Labels
		h=30+60; l=(self.scr['W']/4); t=10; w=(self.scr['W']-(l*2)-10); self.LabDate=xbmcgui.ControlLabel(l,t,w,h,'','font20','0xFF00ffd8',angle=0,alignment=6); self.addControl(self.LabDate)
		h=30; l=(self.scr['W']/4); t=(self.scr['H']-h-10); w=(self.scr['W']-(l*2)-10); self.LabZodiac=xbmcgui.ControlLabel(l,t,w,h,'','font20','ff8a2be2',angle=0,alignment=6); self.addControl(self.LabZodiac)
		#self.LabZodiac.setAlignment(3); 
		self.GetMoonData(0); 
		## ### ## Buttons
		w=135; h=32; l=20; t=70; #t=170; ## use this for showing the button Side ways on the screen.
		self.button[0]=xbmcgui.ControlButton(l,t,w,h,"Exit",textColor="0xFF000000",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[0])
		t=t+10+h; self.button[1]=xbmcgui.ControlButton(l,t,w,h,"Next",textColor="0xFF000000",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[1])
		t=t+10+h; self.button[2]=xbmcgui.ControlButton(l,t,w,h,"Previous",textColor="0xFF000000",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[2])
		zz=[self.button[0],self.button[1],self.button[2]]
		for z in zz: z.setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start='+str(0-l)+','+str(0-h-10))])
		#for z in zz: z.setAnimations([('WindowOpen','effect=rotate delay=0 time=10 center='+str(l)+','+str(t)+' end=90')]) ## use this for showing the button Side ways on the screen.
		## ### ## Addon Title
		zz=["XBMCHUB","Your","HUB-HUG"]; w=1000; h=50; l=15; t=700; self.LabTitleText=Config.name; self.LabTitle=xbmcgui.ControlLabel(l,t,w,h,'','font30','0xFFFF0000',angle=90); self.addControl(self.LabTitle)
		for z in zz:
			if z+" " in self.LabTitleText: self.LabTitleText=self.LabTitleText.replace(z+" ","[COLOR deepskyblue][B][I]"+z+"[/I][/B][/COLOR]  ")
		if "Highway" in self.LabTitleText: self.LabTitleText=self.LabTitleText.replace("Highway","[COLOR tan]Highway[/COLOR]")
		self.LabTitle.setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start=-100')]); self.LabTitle.setLabel(self.LabTitleText); 
		## ### ## Movements
		self.button[0].controlUp(self.button[2]); self.button[0].controlDown(self.button[1]); self.button[1].controlUp(self.button[0]); self.button[1].controlDown(self.button[2]); self.button[2].controlUp(self.button[1]); self.button[2].controlDown(self.button[0]); 
		self.button[0].controlLeft(self.button[2]); self.button[0].controlRight(self.button[1]); self.button[1].controlLeft(self.button[0]); self.button[1].controlRight(self.button[2]); self.button[2].controlLeft(self.button[1]); self.button[2].controlRight(self.button[0]); 
		## ### ## Focus
		self.setFocus(self.button[0])
		## ### ##
	def onAction(self,action):
		if   action == Config.ACTION_PREVIOUS_MENU: self.CloseWindow1st()
		elif action == Config.ACTION_NAV_BACK: self.CloseWindow1st()
	def onControl(self,control):
		if   control==self.button[0]: self.CloseWindow1st()
		elif control==self.button[1]: self.GetMoonData(1); 
		elif control==self.button[2]: self.GetMoonData(-1); 
	def DoImageChange(self,offset):
		i=(int(self.current)+int(offset))
		if i < 0: i=len(self.content)-1
		if i > (len(self.content)-1): i=0
		self.current=i; self.imgHeart.setImage(self.content[i])
	def CloseWindow1st(self):
		#try: zz=[self.CtrlList,self.RepoThumbnail,self.RepoFanart2,self.RepoFanart,self.LabCurrentRepo,self.LabTitle,self.button[0],self.TVS,self.TVSBGB,self.BGB]
		#except: zz=[]
		#for z in zz:
		#	try: self.removeControl(z); del z
		#	except: pass
		self.close()
## ################################################## ##
## ################################################## ##
## Start of program
TempWindow=MyWindow(); TempWindow.doModal(); del TempWindow
## ################################################## ##
## ################################################## ##
