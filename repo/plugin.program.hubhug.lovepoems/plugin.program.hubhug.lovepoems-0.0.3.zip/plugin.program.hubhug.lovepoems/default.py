# ###  - By TheHighway ### #
# ########################################################## #

import xbmc,xbmcgui,urllib,urllib2,os,sys,logging,array,re,time,datetime,random,string,StringIO,xbmcplugin,xbmcaddon
from config import Config as Config
import common as Common
from common import *
import common

class MyWindow(xbmcgui.Window):
	button={}
	def __init__(self):
		self.current=0; self.content=[]; self.scr={}; self.scr['L']=0; self.scr['T']=0; self.scr['W']=1280; self.scr['H']=720; 
		self.FillInContent(); self.makePageItems(); 
	def FillInContent(self):
		self.cp='http://graphicsheat.com/wp-content/uploads/'; self.content.append(self.cp+'2013/05/Whitek.jpg'); self.content.append(self.cp+'2013/05/WhatLove.jpg'); self.content.append(self.cp+'2013/05/Love-Poems-1.jpg'); self.content.append(self.cp+'2013/05/Love.jpg'); self.content.append(self.cp+'2013/05/AmandasRose.jpg'); self.content.append(self.cp+'2013/05/poem.jpg'); self.content.append(self.cp+'2013/05/pictures-of-love-poems-for-him.jpg'); self.content.append(self.cp+'2013/05/pictures-of-love-poems-for-him.jpg'); self.content.append(self.cp+'2013/05/picture-1.jpg'); self.content.append(self.cp+'2013/05/Love-Poems-For-Him_sweet-love-quotes.jpeg'); self.content.append(self.cp+'2013/05/love-poem-in-spanish.jpg'); self.content.append(self.cp+'2013/05/Love-Poem.jpg'); self.content.append(self.cp+'2013/05/7ae2220e96f39c95_cute_love_poems_3.xxxlarge_0.gif'); self.content.append(self.cp+'2013/05/valentine_love_poems_love-poems.jpg'); self.content.append(self.cp+'2013/05/Short-Love-Christmas-Poems.jpg'); self.content.append(self.cp+'2013/05/Love-Poem-Wallpapers.jpg'); self.content.append(self.cp+'2013/05/love-poems-with-pictures.jpg'); self.content.append(self.cp+'2013/05/love-poem-source.jpg'); self.content.append(self.cp+'2013/05/Love-poems-for-him-love-poems1.gif'); self.content.append(self.cp+'2013/05/love-poems-do-they-still-exist-14.jpg'); self.content.append(self.cp+'2013/05/Love-Poems_love-11-11.jpg'); self.content.append(self.cp+'2013/05/Love-Poems.jpg'); self.content.append(self.cp+'2013/05/lovepo.gif'); self.content.append(self.cp+'2013/05/Love-Poems-for-Him_Love-poem.jpg'); self.content.append(self.cp+'2013/05/il_fullxfull.365238236_gl10.jpg'); self.content.append(self.cp+'2013/05/girl-love-love-quotes-quotes-romantic-love-quotes-Favim.com-562322_large.jpg'); self.content.append(self.cp+'2013/05/girl-love-love-quotes-quotes-romantic-love-quotes-Favim.com-561619.jpg'); self.content.append(self.cp+'2013/05/drew-my-heart.jpg'); self.content.append(self.cp+'2013/05/boy-girl-love-quotes-wrong-Favim.com-412665.jpg'); self.content.append(self.cp+'2013/05/4603568_f520.jpg'); self.content.append(self.cp+'2013/05/10-The-best-pictures-with-love-poems-facebook-share-web1.jpg'); 
		self.cp='http://www.funtasticecards.com/postcard/images/'; self.content.append(self.cp+'romantic-sweet-0s-roses-pink-poem.gif'); self.content.append(self.cp+'romantic-silhouettes-ecard-special-smile-sentimental.gif'); self.content.append(self.cp+'romantic-i-love-you-couple-sunset-02.gif'); self.content.append(self.cp+'sentimental-brunette-cartoon-kiss-animation.gif'); self.content.append(self.cp+'romantic-sweet-nothings-teddies-adoring-thoughts.gif'); self.content.append(self.cp+'romantic-sweet-0s-roses-red-red.gif'); self.content.append(self.cp+'romantic-sweet-0s-roses-purple.gif'); self.content.append(self.cp+'romantic-sensual-couple-silhouette-fantasy.gif'); self.content.append(self.cp+'sentimental-toy-rose-peach.gif'); self.content.append(self.cp+'romantic-ecard-silhouette-lovers-kissing-verse.gif'); self.content.append(self.cp+'romantic-sweet_0s-roses-red-hearts.gif'); self.content.append(self.cp+'romantic-funny-mae-west-star-joke-good.jpg'); self.content.append(self.cp+'romantic-funny-couple-cartoon-bed-experimenting.gif'); 
		self.content.append('http://3.bp.blogspot.com/-i2qXv-9FR5k/UZM-hR354WI/AAAAAAAABWQ/ZbKDSRQUZZc/s400/123.gif'); self.content.append('http://1.bp.blogspot.com/-llj8GdSRkxI/UZM-d17_amI/AAAAAAAABWA/e_fcdTGkNAM/s400/2-love-poem3.gif'); self.content.append('http://4.bp.blogspot.com/-TdIOt7eAa6o/UZM-g11we-I/AAAAAAAABWI/s53kQEDF-n0/s400/Love-poetry-poetry-32727953-400-500.gif'); self.content.append('http://4.bp.blogspot.com/-Bdo1iUd-FOE/UZM_Ccwc3bI/AAAAAAAABWk/YqgoJZjRlZI/s400/friendlover.jpg'); self.content.append('http://4.bp.blogspot.com/-Gpsg0oaX-AM/UZM_D0snf4I/AAAAAAAABXA/ekAvSOFUmyY/s400/love-poem-time1.jpg'); self.content.append('http://1.bp.blogspot.com/-X5t0Y9sErFY/UZM_FZFOgJI/AAAAAAAABXI/JKzHvAx6Oac/s400/love.jpg'); 
		self.content.append('https://lh3.googleusercontent.com/-Yt-tHWBTUP8/UePhEP-KeLI/AAAAAAAAALQ/CYFP3KgqvHE/w426-h307/Animated-Poetry-Picture.gif'); self.content.append('https://lh6.googleusercontent.com/-fcQIMq-9sPI/UePg1bD1P6I/AAAAAAAAAKE/lUENQ4GDPFg/w426-h341/images.jpg'); self.content.append('https://lh5.googleusercontent.com/-_0UyJIZlpgk/UePguWbUtgI/AAAAAAAAAJk/ZfiXxlDotQE/w426-h316/Best%2BEnglish%2BPoetry-Poem%2BBy%2BAll%2Bthe%2BTime%2B%25289%2529.jpg'); self.content.append('https://lh6.googleusercontent.com/-mfADiSWQQYw/UePgnOCn0EI/AAAAAAAAAJI/P2XoCHcNoZo/w426-h320/friendship-poem-wallpaper2%2B%25281%2529.jpg'); self.content.append('https://lh6.googleusercontent.com/-_pENBKSwIzU/UePggQLXIwI/AAAAAAAAAIo/d2IOaY4V3RE/w426-h383/best-love-poems-moore-argument.gif'); self.content.append('https://lh3.googleusercontent.com/-w5FxyGNOGwg/UePgYvGNCFI/AAAAAAAAAIE/b8gLjF7O99U/w426-h349/4ff9c7ed4b65e_ip-english-poems-oriza-sweet-love-words.gif.pagespeed.ce.G-ZA4CTnBQ.gif'); self.content.append('https://lh6.googleusercontent.com/-8xEhp2By0pU/UXUNqHAExnI/AAAAAAAAAio/pDWoNpBw54o/w426-h568/13+-+1'); self.content.append('https://lh6.googleusercontent.com/-jmQiSAeIaBU/UWUuKOVoqFI/AAAAAAAAACY/gnAEs0v0e18/s319-p/photo.jpg'); self.content.append('https://lh6.googleusercontent.com/-S1o8byLwpcE/UWUuKDaYOjI/AAAAAAAAACw/lZyX6QLy2NQ/w106-h105-p/photo.jpg'); 
		self.cp='http://stylegerms.com/wp-content/uploads/2014/01/'; self.content.append(self.cp+'true-love-has-no-ending.gif'); self.content.append(self.cp+'Love-Poems-for-Valentines-Day-14.jpg'); self.content.append(self.cp+'Love-Poems-for-Valentines-Day-7.jpg'); self.content.append(self.cp+'valentine-110102-1.jpg'); self.content.append(self.cp+'51Sux5DDrdL.jpg'); self.content.append(self.cp+'valentines-poem6.gif'); self.content.append(self.cp+'My-Flower-poetry-13425795-1213-645.jpg'); self.content.append(self.cp+'valentines-day-poems.jpg'); self.content.append(self.cp+'sweet-love-quotes.jpeg'); self.content.append(self.cp+'Love-Poems-For-Him_sweet-love-a.gif'); self.content.append(self.cp+'Love-Poems_303570.jpg'); self.content.append(self.cp+'free-poem-card-for-valentine.gif'); self.content.append(self.cp+'valentine_poem_by_scribblemonk-d4obovf.jpg'); self.content.append(self.cp+'147613xcitefun-valentine-poem-14.jpg'); self.content.append(self.cp+'147594xcitefun-valentine-poem-12.jpg'); self.content.append(self.cp+'147604xcitefun-valentine-poem-1.jpg'); self.content.append(self.cp+'Free-nature-wallpaper-95.jpg'); self.content.append(self.cp+'109010-Love+poems+for+him+sad+love.jpg'); self.content.append(self.cp+'deep-love-poems-funny_4721553082484020.jpg'); self.content.append(self.cp+'emo-broken-love-poems-wallpaper.jpg'); self.content.append(self.cp+'LOVEPOEMS1.jpg'); self.content.append(self.cp+'Romantic-Love-Poems.jpg'); self.content.append(self.cp+'10-The-best-pictures-with-love-poems-facebook-share-web1.jpg'); self.content.append(self.cp+'English-Love-Poetry-Quotes-Poems-2013.jpg'); self.content.append(self.cp+'love_poem.jpg'); self.content.append(self.cp+'Short_Love_Sayings_1_short-love-quotes.jpg'); self.content.append(self.cp+'styles1433.jpg'); self.content.append(self.cp+'51584lb3-love-quotes.jpg'); self.content.append(self.cp+'100550image005-love-quotes.jpg'); self.content.append(self.cp+'girl-friend-quotes-7.jpg'); self.content.append(self.cp+'InLoveClub-2212272.jpg'); self.content.append(self.cp+'Love-Poems-for-Him_sad-love-poems-692735.jpeg'); self.content.append(self.cp+'poems_comment_13.jpg'); self.content.append(self.cp+'quotes_010.gif'); self.content.append(self.cp+'rick-kang-quotes-236521.jpg'); self.content.append(self.cp+'valentine_love_poems_quotes.jpg'); 
		self.cp='http://stylegerms.com/wp-content/uploads/2014/02/'; self.content.append(self.cp+'Best-English-Poetry-Poem-By-All-the-Time-7.jpg'); self.content.append(self.cp+'love-poems-1.jpg'); self.content.append(self.cp+'sad-love-poems.jpg'); self.content.append(self.cp+'Romantic-font-b-Love-b-font-font-b-poem-b-font-in-English-Ballet-girl-wall.jpg'); self.content.append(self.cp+'love-poems.jpg'); self.content.append(self.cp+'love-poems1.jpg'); self.content.append(self.cp+'108986-Birthday+love+poems.jpg'); self.content.append(self.cp+'love-poem-short.jpg'); self.content.append(self.cp+'forangelsonly.org_true-love-poem_3-600x776.jpg'); self.content.append(self.cp+'12-The-best-pictures-with-love-poems-facebook-share-web.jpg'); self.content.append(self.cp+'3506993_f496.jpg'); self.content.append(self.cp+'control.jpg'); self.content.append(self.cp+'52474572.jpg'); self.content.append(self.cp+'I-Love-You-Propose-Day-English-Poems-Girl-Boy-Images.jpg'); self.content.append(self.cp+'3506992_f496.jpg'); self.content.append(self.cp+'love-poems-for-him.jpg'); self.content.append(self.cp+'english-love-poetry.jpg'); self.content.append(self.cp+'English-Love-Poetry-Quotes-Poems-2013.jpg'); self.content.append(self.cp+'love-poems-english1.jpg'); self.content.append(self.cp+'short-love-poem-1.jpg'); self.content.append(self.cp+'good-love-quotes.jpg'); self.content.append(self.cp+'short-love-poems-1.jpg'); self.content.append(self.cp+'sad-love-poem1.jpg'); self.content.append(self.cp+'0808-0801-0313-4043.jpg'); self.content.append(self.cp+'http://stylegerms.com/wp-content/uploads/2014/02/31.jpg'); self.content.append(self.cp+'short-love-poems.jpg'); self.content.append(self.cp+'Love-poem.jpg'); 
		
		
		#self.cp=''; 
		#self.content.append(self.cp+''); 
	def makePageItems(self):
		self.b1=artp("black1"); self.background=(xbmc.translatePath(Config.fanart)); self.background=artj("backdrop"); 
		focus=artp("purple_button-focus"); nofocus=artp("pink_button-focus"); 
		## ### ##
		self.BG=xbmcgui.ControlImage(self.scr['L'],self.scr['T'],self.scr['W'],self.scr['H'],self.background,aspectRatio=0); self.addControl(self.BG)
		self.BG.setAnimations([('WindowOpen','effect=fade time=2000 start=0')])
		l=195; t=20; w=self.scr['W']-l-30; h=self.scr['H']-(t*2); 
		self.imgHeart=xbmcgui.ControlImage(l,t,w,h,self.content[self.current],aspectRatio=2); self.addControl(self.imgHeart); 
		self.imgHeart.setAnimations([('WindowOpen','effect=fade delay=2000 time=2000 start=0 end=98')])
		## ### ##
		w=135; h=32; l=30; t=70; self.button[0]=xbmcgui.ControlButton(l,t,w,h,"Exit",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[0])
		t=t+10+h; self.button[1]=xbmcgui.ControlButton(l,t,w,h,"Next",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[1])
		t=t+10+h; self.button[2]=xbmcgui.ControlButton(l,t,w,h,"Previous",textColor="0xFFB22222",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[2])
		zz=[self.button[0],self.button[1],self.button[2]]
		for z in zz: z.setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start='+str(0-l)+','+str(0-h-10))])
		## ### ## Addon Title
		zz=["XBMCHUB","Your","HUB-HUG"]; w=1000; h=50; l=15; t=700; self.LabTitleText=Config.name; self.LabTitle=xbmcgui.ControlLabel(l,t,w,h,'','font30','0xFFFF0000',angle=90); self.addControl(self.LabTitle)
		for z in zz:
			if z+" " in self.LabTitleText: self.LabTitleText=self.LabTitleText.replace(z+" ","[COLOR deepskyblue][B][I]"+z+"[/I][/B][/COLOR]  ")
		if "Highway" in self.LabTitleText: self.LabTitleText=self.LabTitleText.replace("Highway","[COLOR tan]Highway[/COLOR]")
		self.LabTitle.setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start=-100')]); self.LabTitle.setLabel(self.LabTitleText); 
		## ### ## Movements
		self.button[0].controlUp(self.button[2]); self.button[0].controlDown(self.button[1]); self.button[1].controlUp(self.button[0]); self.button[1].controlDown(self.button[2]); self.button[2].controlUp(self.button[1]); self.button[2].controlDown(self.button[0]); 
		self.button[0].controlLeft(self.button[2]); self.button[0].controlRight(self.button[1]); self.button[1].controlLeft(self.button[0]); self.button[1].controlRight(self.button[2]); self.button[2].controlLeft(self.button[1]); self.button[2].controlRight(self.button[0]); 
		## ### ## Focus
		self.setFocus(self.button[0])
		## ### ##
	def onAction(self,action):
		if   action == Config.ACTION_PREVIOUS_MENU: self.CloseWindow1st()
		elif action == Config.ACTION_NAV_BACK: self.CloseWindow1st()
	def onControl(self,control):
		if   control==self.button[0]: self.CloseWindow1st()
		elif control==self.button[1]: self.DoImageChange(1)
		elif control==self.button[2]: self.DoImageChange(-1)
	def DoImageChange(self,offset):
		i=(int(self.current)+int(offset))
		if i < 0: i=len(self.content)-1
		if i > (len(self.content)-1): i=0
		self.current=i; self.imgHeart.setImage(self.content[i])
	def CloseWindow1st(self):
		#try: zz=[self.CtrlList,self.RepoThumbnail,self.RepoFanart2,self.RepoFanart,self.LabCurrentRepo,self.LabTitle,self.button[0],self.TVS,self.TVSBGB,self.BGB]
		#except: zz=[]
		#for z in zz:
		#	try: self.removeControl(z); del z
		#	except: pass
		self.close()
## ################################################## ##
## ################################################## ##
## Start of program
TempWindow=MyWindow(); TempWindow.doModal(); del TempWindow
## ################################################## ##
## ################################################## ##
