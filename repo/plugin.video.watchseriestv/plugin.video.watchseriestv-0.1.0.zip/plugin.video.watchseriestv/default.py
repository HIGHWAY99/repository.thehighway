#############################################################################
#############################################################################
import common
from common import *
from common import (addon_id,addon_name,addon_path)
NextPageImg=art('nextpage.png'); NextPageImg=''


#############################################################################
#############################################################################
def Menu0(): ## Main Menu ##
	cMI=[]
	#cMI.append(('Information','XBMC.Action(Info)'))
	
	#ADDON.add_directory({'mode':'BrowseSeasons','url':'http://watch-series-tv.to/serie/deadbeat','seriestitle':'Deadbeat','img':'http://static.watch-series-tv.to/uploads/thumbs/12/12649-deadbeat.jpg'},{'title':'Deadbeat'},fanart=addonFanart,img=addonIcon)
	
	ADDON.add_directory({'mode':'Search','q':''},{'title':cFL('Search...','lavender')},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'AtoZ'},{'title':cFL('A to Z','orange')},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'Genres'},{'title':cFL('Genres','lawngreen')},fanart=addonFanart,img=addonIcon)
	ADDON.add_directory({'mode':'NewestEpisodesAdded','url':'/latest'},{'title':cFL('Latest Added','maroon')},fanart=addonFanart,img=addonIcon)
	
	
	
	ADDON.add_directory({'mode':'BrowserUrl','url':''+zCoDeSz('domain')},{'title':''+zCoDeSz('domain')+''},fanart=addonFanart,img='http://static.watch-series-tv.to/uploads/thumbs/blank.gif',is_folder=True)
	ADDON.add_directory({'mode':'BrowserUrl','url':'http://tinyurl.com/o52ar6c'},{'title':'#The_Projects @ irc.snoonet.org:6667'},fanart=addonFanart,img='http://i.imgur.com/7YS28Z5.jpg',is_folder=True)
	setView('tvshows',getSet("front-view")); eod()

def Browse_AtoZ():
	for a in ['09','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']:
	  try:
	  	ADDON.add_directory({'mode':'BrowseSeries','url':'/letters/'+a.upper()},{'title':a.upper()},fanart='',img='')
	  except: pass
	setView('tvshows',getSet("atoz-view")); eod()

def Browse_Genres():
	html=nolines(BrowseURL('/genres/action')); 
	html=html.replace('</li>','</li\n>')
	html=html.split('<ul class="pagination" style="list-style-type: none;">')[-1].split('</ul>')[0]
	r=re.compile('<li style="[^"]*">\s*<a href="([^"]+)" style="[^"]*">\s*([^<]+)</a>\s*</li').findall(html)
	if r:
		if len(r) > 0:
			iC=len(r)
			try:
				for a,b in r:
					try: ADDON.add_directory({'mode':'BrowseSeries','url':a},{'title':b},fanart='',img='')
					except: pass
			except: pass
	setView('tvshows',getSet("genres-view")); eod()
#############################################################################
#############################################################################

#############################################################################
#############################################################################

#############################################################################
#############################################################################

def BrowseURL(UrL=''):
		DoMAIN=zCoDeSz('domain')
		if len(UrL)==0: UrL=DoMAIN
		elif UrL.startswith('/'): UrL=DoMAIN+UrL
		return nURL(UrL)

def BrowseURLm(UrL=''):
		DoMAIN=zCoDeSz('domainm')
		wwwDoMAIN=zCoDeSz('domain')
		UrL=UrL.replace(wwwDoMAIN,DoMAIN)
		if len(UrL)==0: UrL=DoMAIN
		elif UrL.startswith('/'): UrL=DoMAIN+UrL
		return nURL(UrL)

#############################################################################
#############################################################################

#############################################################################
#############################################################################

#############################################################################
#############################################################################

def Browse_Newest_Episodes_Added(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		debob([len(html),UrL]); #debob(html); 
		html.replace('</li>','</li\n>')
		r=re.compile('<li>\s*<a\s+href="([^"]+)"(?:\s+title="[^"]+"|)?\s*>\s*([^<]+)<span class="epnum">\s*([^<]+)</span>\s*</a>\s*</li').findall(html)
		if r:
				try:
						#debob(r); 
						if len(r) > 0:
							iC=len(r)+1
							for url,name,yEAr in r:
								try:
									cMI=[]; cMI.append(('Information','XBMC.Action(Info)')); img=''; 
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; 
									#if img=='': img=addonIcon
									#if fimg=='': fimg=addonFanart
									
									name=name.replace("&#039;","'").replace('&quot;','"').replace('&nbsp;',' ')
									pars={'mode':'BrowseLinks','url':url,'img':img,'seriestitle':name,'studio':name,'Thumb':img}; #img=addonIcon; fimg=addonFanart; 
									rTitle=''+name+' [COLOR deeppink]('+yEAr+')[/COLOR]'; 
									debob(pars)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		if '<ul class="pagination">' in html:
			try:
				html2=html.split('<ul class="pagination">')[-1].split('</ul>')[0]
				debob(['pagination html',len(html2)]); #debob(html2); 
				r=re.compile('<li\s*>\s*<a\s+href="([^"]+)"[^>]*>\s*([^<]+)</a>\s*</li').findall(html2)
				if r:
					try:
						if len(r) > 0:
							iC=len(r)
							for url,name in r:
								try:
									pars={'mode':'NewestEpisodesAdded','url':url}
									if '/' in url:
										if 'Page' in name:
											try:
												name+=' - '+url.split('/')[-1]
											except: pass
									ADDON.add_directory(pars,{'title':'[I]Page:  [/I]'+name},fanart='',img='')
								except: pass
					except: pass
			except: pass
#		elif '">Next Page</a' in html:
#			try:
#				nextUrl=re.compile('<a href="([^"]+)">Next Page</a').findall(html)[0]
#				nextUrl=uqP(nextUrl).replace('\\/','/')
#				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domain')+nextUrl
#				if nextUrl.startswith('?'): 
#					if '?' in UrL:
#						nextUrl=UrL.split('?')[0]+nextUrl
#					else:
#						nextUrl=UrL+nextUrl
#				pars={'mode':'NewestEpisodesAdded','url':nextUrl}
#				debob(pars)
#				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
#			except: pass
		setView('tvshows',getSet("latest-added-episodes-view")); eod()

def Browse_Series(UrL=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		debob([len(html),UrL])
		html.replace('</li>','</li\n>')
		r=re.compile('<li><a href="([^"]+)" title="([^"]+)">[^<]+<span class="epnum">([^<]+)</span></a></li').findall(html)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)+1
							for url,name,yEAr in r:
								try:
									cMI=[]; cMI.append(('Information','XBMC.Action(Info)')); img=''; 
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; 
									#if img=='': img=addonIcon
									#if fimg=='': fimg=addonFanart
									
									name=name.replace("&#039;","'")
									pars={'mode':'BrowseSeasons','url':url,'img':img,'seriestitle':name}; #img=addonIcon; fimg=addonFanart; 
									rTitle=''+name+' [COLOR deeppink]('+yEAr+')[/COLOR]'; 
									debob(pars)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		if '<ul class="pagination">' in html:
			try:
				html2=html.split('<ul class="pagination">')[-1].split('</ul>')[0]
				debob(['pagination html',len(html2)]); #debob(html2); 
				r=re.compile('<li\s*>\s*<a\s+href="([^"]+)"[^>]*>\s*([^<]+)</a>\s*</li').findall(html2)
				if r:
					try:
						if len(r) > 0:
							iC=len(r)
							for url,name in r:
								try:
									pars={'mode':'BrowseSeries','url':url}
									if '/' in url:
										if 'Page' in name:
											try:
												name+=' - '+url.split('/')[-1]
											except: pass
									ADDON.add_directory(pars,{'title':'[I]Page:  [/I]'+name},fanart='',img='')
								except: pass
					except: pass
			except: pass
#		elif '">Next Page</a' in html:
#			try:
#				nextUrl=re.compile('<a href="([^"]+)">Next Page</a').findall(html)[0]
#				nextUrl=uqP(nextUrl).replace('\\/','/')
#				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domain')+nextUrl
#				if nextUrl.startswith('?'): 
#					if '?' in UrL:
#						nextUrl=UrL.split('?')[0]+nextUrl
#					else:
#						nextUrl=UrL+nextUrl
#				pars={'mode':'BrowseSeries','url':nextUrl}
#				debob(pars)
#				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
#			except: pass
		setView('tvshows',getSet("series-view")); eod()

def Search(UrL='',q=''):
		DoMAIN=zCoDeSz('domain')
		if len(UrL)==0:
			try:
				if len(q)==0:
					q=qP(str(showkeyboard("","Search...")))
				UrL=DoMAIN+'/search/'+q
			except: pass
		deb('url',str(UrL))
		if len(UrL)==0: eod(); return
		## Note:  Device(s) using Android OS seem to return 0 length for html.
		html=nolines(BrowseURL(UrL)); debob(len(html)); 
		if not '>Search results for ' in html: eod(); return
		html=html.replace('= "','="')
		try: NoOfSearchResults=re.compile('Found (\d+) matches.').findall(html)[0]
		except: NoOfSearchResults='0'
		try: ADDON.add_directory({'mode':''},{'title':'Results Found:  '+NoOfSearchResults},fanart='',img='')
		except: pass
		
		r=re.compile('<div\s+style="[^"]*">\s*<div\s+style="[^"]*">\s*<div\s+style="[^"]*">\s*<a\s+href="([^"]+)"\s+title="([^"]+)"\s+target="_blank"\s*>\s*<img\s+src="([^"]+)"[^>]*>\s*</a>\s*</div\n*>\s*<div valign="top" style="[^"]*">\s*<a\s+href="[^"]+"\s+title="[^"]+"\s+target="_blank"\s*>\s*<strong>\s*([^<]+)</strong>\s*</a>\s*<br />\s*<strong>\s*Description:\s*</strong>\s*([^<]*)<').findall(html.replace('</div>','</div\n>'))
		if r:
			if len(r) > 0:
				iC=len(r); #debob(r); 
				debob(iC); 
				for url,nameTitle,img,name,plot in r:
					try:
						cMI=[]; cMI.append(('Information','XBMC.Action(Info)'))
						if img.startswith('/'): img=DoMAIN+img
						fimg=img; 
						if img=='': img=addonIcon
						if fimg=='': fimg=addonFanart
						
						plot=plot.strip().replace('&quot;','"'); name=name.strip(); nameTitle=nameTitle.strip(); 
						pars={'mode':'BrowseSeasons','url':url,'title':name,'seriestitle':name,'Thumb':img,'img':img}; 
						debob([name,url,img]); 
						
						rTitle=''+name+''
						try: ADDON.add_directory(pars,{'title':rTitle,'plot':plot},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
						except: pass
					except: pass
		if '">Next Search Page</a>' in html:
			try:
				nextUrl=re.compile('<a href="([^"]+)">Next Search Page</a>').findall(html)[0]
				nextUrl=uqP(nextUrl).replace('\\/','/')
				if nextUrl.startswith('/'): nextUrl=zCoDeSz('domain')+nextUrl
				if nextUrl.startswith('?'): 
					if '?' in UrL:
						nextUrl=UrL.split('?')[0]+nextUrl
					else:
						nextUrl=UrL+nextUrl
				pars={'mode':'Search','url':nextUrl}
				debob(pars)
				ADDON.add_directory(pars,{'title':'Next page'},fanart='',img=NextPageImg)
			except: pass
		setView('tvshows',getSet("search-view")); eod()

def Browse_Links(UrL='',NaMe='',seriestitle='',img=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		debob([len(html),UrL])
		html.replace('</tr>','</tr\n>')
		r=re.compile('<tr class="([^"]*)"  id="link_(\d+)">\s*<td>\s*<span>\s*([^<]*)</span>\s*</td>\s*<td>\s*<a\s+target="_blank"\s+href="([^"]+)"\s+class="buttonlink"\s+title="([^"]+)" style="[^"]*" onclick="[^"]*">\s*Watch This Link.\s*</a>\s*</td>\s*<td>\s*<a target="_blank" href="[^"]*" class="freeEpisode" title="Free episode download">Free Episode Download</a>\s*</td>\s*<td>\s*<a href="[^"]*" onclick="[^"]*">Report Link</a>\s*</td>\s*</tr').findall(html)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)
							for TrClass,LinkNo,LinkHostDomain,url,LinkHostDomain2 in r:
								try:
									TrClass=TrClass.strip(); LinkHostDomain=LinkHostDomain.strip();  
									debob([LinkNo,TrClass,LinkHostDomain,url,LinkHostDomain2]); 
									name=NaMe; cMI=[]; cMI.append(('Information','XBMC.Action(Info)')); 
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; pars={'mode':'Playback','url':url,'title':name,'studio':seriestitle,'thumb':img,'img':img,'seriestitle':seriestitle}
									rTitle='[COLOR springgreen]['+LinkNo+'][/COLOR]  '+LinkHostDomain+''
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									debob(pars)
									#try: ADDON.add_video_item(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('episodes',getSet("links-view")); eod()

def Browse_Episodes(UrL='',SeaSoN='',seriestitle='',img=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		debob([len(html),UrL])
		html.replace('</li>','</li\n>')
		r=re.compile('<li\s+itemprop="episode"\s+itemscope\s+itemtype="http://schema.org/TVEpisode">\s*<meta itemprop="episodenumber" content="([^"]*)"/>\s*<meta itemprop="url" content="([^"]*)"/>\s*<a href="([^"]*)"\s*>\s*<span class="[^"]*" itemprop="name">\s*([^<]*)</span>\s*<span class="epnum"  style="[^"]*"\s*>\s*<b>\s*\((\d*) link[s]*\)\s*</b>\s*<span itemprop="datepublished">([^<]*)</span>\s*</span>\s*</a>\s*</li').findall(html)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)
							for EpisodeNumber,url2,url,name,NoOfLinks,DatePublished in r:
								try:
									cMI=[]; cMI.append(('Information','XBMC.Action(Info)')); 
									debob([EpisodeNumber,url2,url,name,NoOfLinks,DatePublished]); 
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; 
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									
									if '&nbsp;&nbsp;&nbsp;' in name:
										try:
											nameA1=(name.split('&nbsp;&nbsp;&nbsp;')[0]).strip()
											nameA2=(name.split('&nbsp;&nbsp;&nbsp;')[1]).strip()
											if nameA1.startswith('Episode'):
												if nameA1 in nameA2:
													name=nameA2
											name=name.replace('&nbsp;',' '); name=name.strip(); 
										except: name=name.replace('&nbsp;',' '); name=name.strip(); 
									else: name=name.replace('&nbsp;',' '); name=name.strip(); 
									
									if '   ' in name:
										name=name.replace('   ',':  ')
									rTitle='[COLOR springgreen]'+EpisodeNumber+'.)[/COLOR] '+name+' [COLOR greenyellow]('+NoOfLinks+')[/COLOR] [COLOR deeppink]['+DatePublished+'][/COLOR]'
									pars={'mode':'BrowseLinks','url':url,'title':name,'studio':seriestitle,'thumb':img,'img':img,'seriestitle':seriestitle}
									debob(pars)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('episodes',getSet("episodes-view")); eod()

def Browse_Seasons(UrL='',seriestitle='',img=''):
		html=nolines(BrowseURL(UrL)); DoMAIN=zCoDeSz('domain')
		debob([len(html),UrL])
		
		if img=='':
			try:
				img=re.compile('<a href="[^"]+"><img src="([^"]+)" alt="Watch Series - [^"]+" title="Watch Series - [^"]+" height="120px" width="\d+px" itemprop="image"/></a>').findall(html)[0]
			except: pass
		
		pars={'mode':'BrowseEpisodes','url':UrL,'season':'','img':img,'seriestitle':seriestitle}; cMI=[]; cMI.append(('Information','XBMC.Action(Info)')); 
		try: ADDON.add_directory(pars,{'title':'[ALL]'},fanart=addonFanart,img=addonIcon,total_items=1,contextmenu_items=cMI,context_replace=False)
		except: pass
		
		html.replace('</ul>','</ul\n>')
		r=re.compile('<div\s+itemprop="season"\s+itemscope\s+itemtype="http://schema.org/TVSeason">\s*<h\d\s+class="lists"\s*[^>]*>\s*<a href="([^"]+)"\s+itemprop="url">\s*<span itemprop="name">\s*([^<]+)</span>\s*</a>\s*</h\d>').findall(html)
		if r:
				try:
						if len(r) > 0:
							iC=len(r)+1
							for url,name in r:
								cMI=[]; cMI.append(('Information','XBMC.Action(Info)')); 
								try:
									if img.startswith('/'): img=DoMAIN+img
									fimg=img; 
									if img=='': img=addonIcon
									if fimg=='': fimg=addonFanart
									
									pars={'mode':'BrowseEpisodes','url':url,'season':name,'img':img,'seriestitle':seriestitle}; #img=addonIcon; fimg=addonFanart; 
									rTitle=''+name+''; 
									debob(pars)
									try: ADDON.add_directory(pars,{'title':rTitle},fanart=fimg,img=img,total_items=iC,contextmenu_items=cMI,context_replace=False)
									except: pass
								except: pass
				except: pass
		setView('tvshows',getSet("seasons-view")); eod()

#############################################################################
#############################################################################

#############################################################################
#############################################################################

#############################################################################
#############################################################################

def GetPlayerCore():
	try:
		PlayerMethod=getSet("core-player")
		if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER
		elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER
		elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER
		else: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	except: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	return PlayerMeth
def PlayStreamWithResolver(url):
		play=xbmc.Player(GetPlayerCore())
		try:
			import urlresolver
			url=urlresolver.HostedMediaFile(url).resolve()
			try: ADDON.resolve_url(url)
			except: pass
			try: play.play(url)
			except: pass
		except: pass
def PlayStream(url):
		play=xbmc.Player(GetPlayerCore())
		try: ADDON.resolve_url(url)
		except: pass
		try: play.play(url)
		except: pass
def PlayURL(url):
		play=xbmc.Player(GetPlayerCore())
		try: play.play(url)
		except: pass
def Playback(url):
		play=xbmc.Player(GetPlayerCore())
		url=url.replace(zCoDeSz('domain'),zCoDeSz('domainm'))
		debob({'page':url})
		#eod()
		html=nolines(BrowseURLm(url))
		#print html
		host_url=re.compile('<a href="([^"]+)" class="push_button blue" style="[^"]*">Click Here to Play</a').findall(html)[0]
		import urlresolver
		vid_url=urlresolver.HostedMediaFile(host_url).resolve()
		try: play.play(vid_url)
		except: pass
#############################################################################
#############################################################################
def zModeCheck(mode='',url=''):
	deb('mode',mode); 
	if (mode=='') or (mode=='main'): Menu0()
	elif mode=='BrowseEpisodes': Browse_Episodes(url,addpr('season'),addpr('seriestitle'),addpr('img'))
	elif mode=='BrowseSeasons': Browse_Seasons(url,addpr('seriestitle'),addpr('img'))
	elif mode=='BrowseLinks': Browse_Links(url,addpr('title'),addpr('seriestitle'),addpr('img'))
	elif mode=='BrowseSeries': Browse_Series(url)
	elif mode=='NewestEpisodesAdded': Browse_Newest_Episodes_Added(url)
	elif mode=='Genres': Browse_Genres()
	elif mode=='AtoZ': Browse_AtoZ()
	elif mode=='Search': Search(url,addpr('q'))
	elif mode=='Playback': Playback(url)
	elif mode=='Play': PlayStream(url)
	elif mode=='PlayR': PlayStreamWithResolver(url)
	elif mode=='BrowserUrl':
		url=addpr('url')
		if '://' in url:
			XBMC_System_Exec('"%s"'%url)
	else: eod()
	
	
	##
zModeCheck(addpr('mode'),addpr('url'))
#############################################################################
#############################################################################
